﻿namespace Pricing.Core.Config
{
	public interface IConfig
	{
		string AuthIdHeader { get; }
		string AuthNameHeader { get; }
        string DbConnectionString { get; }

    }
}
