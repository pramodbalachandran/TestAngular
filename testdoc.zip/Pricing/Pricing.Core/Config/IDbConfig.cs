﻿namespace Pricing.Core.Config
{
	public interface IDbConfig
	{
		string PricingConnectionString { get; }
        string DocumentDbEndpointUrl { get; }
        string DocumentDbPrimaryKey { get; }
        string CacheServerConnectionString { get; }
	}
}
