﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pricing.Core.Constants
{
    public class PricingConsts
    {
        public const string Failed = "PRICING_999";

        public const string UpdateFailed = "PRICING_998";

        public const string BadRequest = "PRICING_990";

        public const string LogInToContinue = "PRICING_991";

        public const string AccessDenied = "PRICING_992";

        public const string JsonInputIsIncorrect = "PRICING_993";

        public const string LocalizationSourceName = "PRICING";

        public const string InternalServerError = "PRICING_500";

        public const string DuplicateCarrier = "PRICING_5000";

        public const string LimitCarriers = "PRICING_5002";

        public const string NoCarrier = "PRICING_5001";

        public const string DuplicateEmailAndDotNumber = "PRICING_5003";

        public const string DuplicateDotNumber = "PRICING_5004";

        public const string VehicleIdNotFound = "PRICING_2100";

        public const string DuplicateEmailAddress = "PRICING_1003";

        public const string EmailValidationFailed = "PRICING_1005";

        public const string InvalidFacebookUser = "PRICING_1002";

        public const string NoUserExists = "PRICING_1001";

        public const string FacebookEmail = "PRICING_1006";

        public const string TooManyAttempts = "PRICING_1007";

        public const string TooManyAttemptsFB = "PRICING_1008";

        public const string InvalidEmailOrPassword = "PRICING_1009";

        public const string IftaIdNotFound = "PRICING_1010";

        public const string CDLAlreadyExists = "PRICING_1011";
    }
}
