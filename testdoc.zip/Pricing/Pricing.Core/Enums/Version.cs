﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pricing.Core.Enums
{
    public enum Version
    {
        V1 = 1
    }
}
