using System;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace Pricing.Core.Entities
{
	using Abstract;

	public class User : IEntity
	{
		public User()
		{

		}
        public string PartitionKey { get; set; }
        public Guid? Id { get; set; }

        //public string[] ItemType { get; }

        public int Version { get; set; }

        public string UserToken { get; set; }

        public string Password { get; set; }

        public string FirstName { get; set; }

        public string LastName { get; set; }

        [Required, MaxLength(200)]
        public string EmailAddress { get; set; }

        public int? LoginAttempts { get; set; }

        public DateTime DateTimeStamp { get; set; }

        public string Idp { get; set; }

        public string PhoneNumber { get; set; }

        public int? CountryId { get; set; }

        public string StreetAddress { get; set; }

        public string PostalCode { get; set; }

        public string City { get; set; }

        public int? StateId { get; set; }

        public bool IsDeviceSetUpCompleted { get; set; }
        public string B2CUserObjectId { get; set; }

        public bool RecieveLogDVIRMails { get; set; }
        public DateTime? CSVCreatedOn { get; set; }

        public string lastContinuationToken { get; set; }
    }
}