﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Pricing.Core.Entities.Dtos
{
    public interface IDto
    {
        Guid Id { get; set; }
    }
}
