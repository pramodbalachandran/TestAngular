﻿using System;
using System.Collections.Generic;
using System.Text;
using Bonsai.Azure.CosmosDb.Models;

namespace Pricing.Core.Entities.Abstract
{
    public interface IEntity : IModel
    {
        
    }
}
