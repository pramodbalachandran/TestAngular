﻿using System;
using System.Collections.Generic;
using System.Text;

using Pricing.Core.Entities;

namespace Pricing.Core.Repositories
{
    public interface ITaskRepository : ICoreRepository<MyTask>
    {

    }
}
