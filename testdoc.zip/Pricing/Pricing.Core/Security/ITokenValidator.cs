﻿using System.Security.Claims;

namespace Pricing.Core.Security
{
	public interface ITokenValidator
	{
		//ClaimsPrincipal ValidateUser(string token, string email);
        ClaimsPrincipal ValidateUser(string email);
    }
}