﻿using System;
using System.Security.Claims;
using System.Linq;
using Microsoft.AspNetCore.Http;

namespace Pricing.Core.Security
{
    public static class CurrentPrincipal
    {
        private static PricingPrincipal _current;
        //private static IHttpContextAccessor _current;
        public static PricingPrincipal Current
        {
            get { return _current; }
            //get { return _current.HttpContext.User as PricingPrincipal; }
        }

        public static void SetCurrentPrincipal(PricingPrincipal principal)
        {
            if (principal == null)
            {
                throw new ArgumentNullException("principal");
            }
            _current = principal;
            //_current.HttpContext.User = principal;
        }

        public static void ValidateAdmin()
        {
            //if (!Current.CurrentUser.IsAdmin)
            //{
            throw new UnauthorizedAccessException("User not allowed to access client");
            //}
        }

        public static string GetClaimValue(string claimType)
        {
            return ClaimsPrincipal.Current.Claims.Where(c => c.Type == claimType)
                   .Select(c => c.Value).FirstOrDefault();
        }

        public static string GetClaimValueEndsWith(string claimType)
        {
            try
            {
                return ClaimsPrincipal.Current.Claims.Where(c => c.Type.EndsWith(claimType))
                       .Select(c => c.Value).FirstOrDefault();
            }
            catch
            {
                return null;
            }
        }
    }
}
