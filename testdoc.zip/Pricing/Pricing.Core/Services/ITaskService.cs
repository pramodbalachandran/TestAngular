﻿using System;
using System.Collections.Generic;
using System.Text;

using Pricing.Core.Entities;

namespace Pricing.Core.Services
{
    public interface ITaskService : IBaseService<MyTask>
    {

        void CreateTask();
    }
}
