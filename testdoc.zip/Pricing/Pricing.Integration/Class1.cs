﻿using System;

namespace Pricing.Integration
{
    public class Class1
    {
    }
}
