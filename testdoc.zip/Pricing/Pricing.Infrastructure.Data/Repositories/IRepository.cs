﻿using System;
using System.Collections.Generic;
using System.Text;
using Pricing.Core.Entities.Abstract;
using Bonsai.Azure.CosmosDb.Abstract;

namespace Pricing.Infrastructure.Data.Repositories
{
    public interface IRepository<T> : IBaseRepository<T> where T : IEntity
    { 

    }
}
