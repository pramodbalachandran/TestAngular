﻿using System.Configuration;

namespace Pricing.Infrastructure.Data.Configuration
{
    using Core.Config;
	public class DbConfig : IDbConfig
	{
        public string PricingConnectionString { get; set; }
        public string DocumentDbEndpointUrl { get; set; }
        public string DocumentDbPrimaryKey { get; set; }
        public string CacheServerConnectionString { get; set; }

	}
}
