﻿using System;
using System.Collections.Generic;
using System.Text;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.AspNetCore.Http;

using Pricing.Core.Config;
using Microsoft.Extensions.Options;

namespace Pricing.Infrastructure.Data
{
    using Configuration;
    public static class PricingContext
    {
        private static IDbConfig _dbconfig;
        public static IHttpContextAccessor HttpContextAccessor;

        public static string DbConnectionString()
        {
            IOptions<DbConfig> options = HttpContextAccessor.HttpContext.RequestServices.GetService<IOptions<DbConfig>>();
            _dbconfig = options.Value;
            return @_dbconfig.PricingConnectionString;
            //return @"mongodb://azure-cosmos123:1hu5nj6Nv8ospkaoTUTh8s5nCgNCEydLJUMxcR8iLlgT6GLjvkqRpa7xx3S5nuSmDT0tcvjB1x5an4xg3epr7A==@azure-cosmos123.documents.azure.com:10255/?ssl=true&replicaSet=globaldb";
        }

        public static string DocumentDbEndpointUrl()
        {
            IOptions<DbConfig> options = HttpContextAccessor.HttpContext.RequestServices.GetService<IOptions<DbConfig>>();
            _dbconfig = options.Value;
            return @_dbconfig.DocumentDbEndpointUrl;
        }

        public static string DocumentDbPrimaryKey()
        {
            IOptions<DbConfig> options = HttpContextAccessor.HttpContext.RequestServices.GetService<IOptions<DbConfig>>();
            _dbconfig = options.Value;
            return @_dbconfig.DocumentDbPrimaryKey;
        }

    }
}
