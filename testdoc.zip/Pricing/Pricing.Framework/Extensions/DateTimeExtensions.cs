﻿using System;

namespace Pricing.Framework.Extensions
{
	public static class DateTimeExtensions
	{
		public static string ToStandardDateTimeString(this DateTime d)
		{
			const string format = "yyyy-MM-dd hh:mm:ss";
			return d.ToString(format);
		}

		public static string ToCultureDateTimeString(this DateTime d)
		{
			const string format = "G";
			return d.ToString(format).Replace('/', '-');
		}

		public static string ToStandardDateTimeString(this DateTime? d)
		{
			return d.HasValue ? d.Value.ToStandardDateTimeString() : null;
		}

		public static string ToCultureDateTimeString(this DateTime? d)
		{
			return d.HasValue ? d.Value.ToCultureDateTimeString() : null;
		}
	}
}
