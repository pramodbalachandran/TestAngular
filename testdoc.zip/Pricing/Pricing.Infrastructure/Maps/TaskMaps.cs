﻿using System;
using System.Collections.Generic;
using System.Text;
using AutoMapper;
using Pricing.Core.Entities;
using Pricing.Core.Entities.Dtos;

namespace Pricing.Infrastructure.Maps
{
    public class TaskMaps : Profile
    {
        public TaskMaps()
        {
            CreateMap<MyTask, MyTaskDto>();
            CreateMap<MyTaskDto, MyTask>();
        }
    }
}
