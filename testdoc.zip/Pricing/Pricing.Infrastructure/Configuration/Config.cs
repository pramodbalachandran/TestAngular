﻿using System;
using System.Configuration;
using Microsoft.Extensions.Configuration;

namespace Pricing.Infrastructure.Configuration
{
    using Core.Config;

    public class Config : IConfig
	{
		
		public string AuthIdHeader { get; set; }
		public string AuthNameHeader { get; set; }		
		public string DbConnectionString { get; set; }

	}
}
