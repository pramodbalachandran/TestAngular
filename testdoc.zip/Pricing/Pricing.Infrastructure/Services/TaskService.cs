﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using Pricing.Core.Entities;
using Pricing.Core.Services;
using Pricing.Infrastructure.Data.Repositories;

namespace Pricing.Infrastructure.Services
{
    public class TaskService : BaseService<MyTask>, ITaskService
    {
        private readonly IRepository<MyTask> _taskRepository;

        public TaskService(IRepository<MyTask> repository) : base(repository)
        {
            _taskRepository = repository;
        }

        public void CreateTask()
        {
            MyTask task = new MyTask
            {
                Version = 1,
                Name = "Task 1",
                Category = "A",
                CreatedDate = DateTime.Today
            };
            Repository.Upsert(task);
            task = new MyTask
            {
                Version = 1,
                Name = "Task 2",
                Category = "A",
                CreatedDate = DateTime.Today
            };
            Repository.Upsert(task);
        }
    }
}
