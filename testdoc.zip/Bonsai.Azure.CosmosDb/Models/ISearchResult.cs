﻿using System.Collections.Generic;

namespace Bonsai.Azure.CosmosDb.Models
{
    public interface ISearchResult<T>
    {
        int PageSize { get; set; }

        int TotalResults { get; set; }

        IList<T> Results { get; set; }

        string ContinuationToken { get; set; }
    }
}