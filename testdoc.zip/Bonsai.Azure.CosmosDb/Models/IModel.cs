﻿using System;

namespace Bonsai.Azure.CosmosDb.Models
{
    public interface IModel    {
        /// <summary>
        /// The unique identifier for the object
        /// </summary>
        Guid? Id { get; set; }

        string PartitionKey { get; set; }
        /// <summary>
        /// The item type of the object
        /// </summary>
        //string[] ItemType { get; }
        string lastContinuationToken { get; set; }
    }
    
}