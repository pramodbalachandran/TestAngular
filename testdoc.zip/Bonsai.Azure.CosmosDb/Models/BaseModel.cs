﻿using System;
using Newtonsoft.Json;

namespace Bonsai.Azure.CosmosDb.Models
{
    public abstract class BaseModel : IModel
    {
        [JsonProperty("id")]
        public Guid? Id { get; set; }

        public string PartitionKey { get; set; }

        public string lastContinuationToken { get; set; }
        //public virtual string[] ItemType => new string[] { this.GetType().Name };
    }

}