﻿using System.Collections.Generic;

namespace Bonsai.Azure.CosmosDb.Models
{
    public class SearchResult<T> : ISearchResult<T>
    {
        public int PageSize { get; set; }
        public int TotalResults { get; set; }
        public IList<T> Results { get; set; }
        public string ContinuationToken { get; set; }
    }
}