﻿using System.Configuration;

namespace Geography.Infrastructure.Data.Configuration
{
    using Core.Config;
    public class DbConfig : IDbConfig
    {
        public string GeographyConnectionString { get; set; }
        public string DocumentDbEndpointUrl { get; set; }
        public string DocumentDbPrimaryKey { get; set; }
        public string CacheServerConnectionString { get; set; }

    }
}
