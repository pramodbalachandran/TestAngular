﻿function procGetairportdetails(docs) {
    var context = getContext();
    var collection = context.getCollection();
    var response = context.getResponse();
    var body = getContext().getResponse().setBody;
    if (!docs) throw new Error("The array is undefined or null.");
    var locationList = JSON.parse(docs);
    var result = {};
    var locationdataArray = [];
    var customerexistingdataArray = [];
    var finaldata = {};
    var arraycount = 0;
    var filterQuerylocation = 'SELECT * FROM c WHERE c.partitionkey="locationmapping"';
    //console.log(locationList.length)
    if (locationList.length > 0) {
        for (var document of locationList) {
            // console.log(document.locationCode);
            var locationfilterquery = 'SELECT * FROM c WHERE c.partitionkey="locationmapping" AND  c.locationCode= "' + document.locationCode + '"';
            var isAccepted =
                collection.queryDocuments(collection.getSelfLink(), locationfilterquery, {},
                    function (err, locationdocuments, responseOptions) {
                        if (err) throw new Error("Error" + err.message);
                        // console.log(locationdocuments.length);
                        if (locationdocuments.length > 0) {
                            for (var locationdata of locationdocuments) {
                                var customerexistingdataJson = {};
                                var airportCodeCap = locationdata.locationCode.toUpperCase();
                                var politicalDivision2NameCap = locationdata.politicalDivision2Name.toLowerCase()
                                    .split(' ')
                                    .map((s) => s.charAt(0).toUpperCase() + s.substring(1))
                                    .join(' ');
                                var designatingLocationNameCap = locationdata.designatingLocationName.toLowerCase()
                                    .split(' ')
                                    .map((s) => s.charAt(0).toUpperCase() + s.substring(1))
                                    .join(' ');
                                customerexistingdataJson["autopopulateformat"] = airportCodeCap + " " + politicalDivision2NameCap + "," + locationdata.countryCode + "-" + designatingLocationNameCap;
                                customerexistingdataJson["airportCode"] = locationdata.locationCode;
                                customerexistingdataJson["airportName"] = locationdata.designatingLocationName;
                                customerexistingdataJson["countryCode"] = locationdata.countryCode;
                                customerexistingdataJson["countryName"] = locationdata.countryName;
                                customerexistingdataJson["politicalDivision2Name"] = locationdata.politicalDivision2Name;
                                customerexistingdataJson["isCustomerData"] = "1";
                                var unique = true;
                                //for (var i = 0, l = customerexistingdataArray.length; i < l; i++) {
                                //    var unique = true;
                                //    if ((customerexistingdataArray[i].airportCode === locationdata.locationCode) && (customerexistingdataArray[i].politicalDivision2Name === locationdata.politicalDivision2Name)
                                //        && (customerexistingdataArray[i].countryCode === locationdata.countryCode)) {
                                //        unique = false;
                                //    }

                                //}
                                if (unique) {
                                    customerexistingdataArray.push(customerexistingdataJson);
                                }
                            }
                        }

                    });
        }
    }
    var islocationAccepted = collection.queryDocuments(collection.getSelfLink(), filterQuerylocation, {},
        function (err, locationdocuments, responseOptions) {
            if (err) throw new Error("Error" + err.message);
            //console.log(locationdocuments.length);
            if (locationdocuments.length > 0) {
                for (var locationdata of locationdocuments) {
                    var customerexistingdataJson = {};
                    var airportCodeCap = locationdata.locationCode.toUpperCase();
                    var politicalDivision2NameCap = locationdata.politicalDivision2Name.toLowerCase()
                        .split(' ')
                        .map((s) => s.charAt(0).toUpperCase() + s.substring(1))
                        .join(' ');
                    var designatingLocationNameCap = locationdata.designatingLocationName.toLowerCase()
                        .split(' ')
                        .map((s) => s.charAt(0).toUpperCase() + s.substring(1))
                        .join(' ');
                    customerexistingdataJson["autopopulateformat"] = airportCodeCap + " " + politicalDivision2NameCap + "," + locationdata.countryCode + "-" + designatingLocationNameCap;
                    customerexistingdataJson["airportCode"] = locationdata.locationCode;
                    customerexistingdataJson["airportName"] = locationdata.designatingLocationName;
                    customerexistingdataJson["countryCode"] = locationdata.countryCode;
                    customerexistingdataJson["countryName"] = locationdata.countryName;
                    customerexistingdataJson["politicalDivision2Name"] = locationdata.politicalDivision2Name;
                    customerexistingdataJson["isCustomerData"] = "0";
                    var unique = true;
                    //for (var i = 0, l = locationdataArray.length; i < l; i++) {

                    //    if ((locationdataArray[i].airportCode === locationdata.locationCode) && (locationdataArray[i].politicalDivision2Name === locationdata.politicalDivision2Name)
                    //        && (locationdataArray[i].countryCode === locationdata.countryCode)) {
                    //        unique = false;
                    //    }
                    //}
                    if (unique) {
                        customerexistingdataArray.push(customerexistingdataJson);
                    }
                    //console.log(unique);
                }
            }


            //response.setBody(resultJson);
        });

    if (!islocationAccepted) throw new Error('The query was not accepted by the server.');
    else {
        //result["CustomerExistingAirportdetails"] = customerexistingdataArray;
        result["Airportdetails"] = customerexistingdataArray;
        //result.push(finaldata);
        response.setBody(result);
    }
}


