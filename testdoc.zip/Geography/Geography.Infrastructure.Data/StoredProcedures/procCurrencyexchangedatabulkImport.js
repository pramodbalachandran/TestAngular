﻿function procCurrencyexchangedatabulkImport(docs) {
    var collection = getContext().getCollection();
    var collectionLink = collection.getSelfLink();
    var body = getContext().getResponse().setBody;
    var nowDate = new Date();
    var recordEffectiveDate = String(('0' + (nowDate.getMonth() + 1)).slice(-2)) + String(('0' + nowDate.getDate()).slice(-2)) + String(nowDate.getFullYear());
    // console.log(recordEffectiveDate);
    // The count of imported docs, also used as current doc index.
    var count = 0;
    // Validate input.
    if (!docs) throw new Error("The array is undefined or null.");
    var currencyList = JSON.parse(docs);
    var docsLength = currencyList.length;
    console.log(docsLength);
    if (docsLength == 0) {
        getContext().getResponse().setBody(0);
    }
    // console.log(JSON.parse(docs).length);
    // Call the create API to create a document.
    else {
        tryCreate(currencyList[count], callback);
    }

    function tryCreate(doc, callback) {
        //console.log(doc.DESIGNATING_CODE);
        var jsonData = {};
        var jsoncurrencyConversion = {};
        var isAccepted = true;
        // var nowDate = new Date();
        // var recordEffectiveDate = nowDate.getDate() + nowDate.getMonth() + nowDate.getFullYear(); 
        // console.log(recordEffectiveDate);
        jsonData["docType"] = "currencyConversion";
        jsonData["docId"] = "currencyConversion::" + recordEffectiveDate;
        jsonData["docCategory"] = "reference";
        jsonData["docStructureVersion"] = 1;
        jsonData["partitionkey"] = "currency";
        jsoncurrencyConversion["countryCode"] = doc.CNTR;
        jsoncurrencyConversion["countryName"] = doc.COUNTRY;
        jsoncurrencyConversion["exchangeRateAmount"] = doc.X;
        jsoncurrencyConversion["currencyName"] = doc.CUR_NAME;
        jsoncurrencyConversion["decimalPlacesQuantity"] = doc.DECIMAL;
        jsoncurrencyConversion["roundingDirectionText"] = doc.ROUNDING;
        jsoncurrencyConversion["localCurrencyCode"] = doc.Local_Cur;
        jsoncurrencyConversion["localConversionToUsdAmount"] = doc.LocalConversiontoUSD;
        jsoncurrencyConversion["localeCodes"] = "";
        jsonData["currencyConversion"] = jsoncurrencyConversion;
        // console.log(jsonData);
        var query = { query: "select * from root r where r.docId = @docId", parameters: [{ name: "@docId", value: jsonData["docId"] }] };
        //var requestOptions = { continuation: continuation };

        var isAccepted = collection.queryDocuments(collectionLink, query, {}, function (err, documents, responseOptions) {
            if (err) throw err;

            if (documents.length > 0) {
                var requestOptions = { id: documents[0].id };
                //console.log(documents[0]["locationCode"]);
                documents[0]["currencyConversion"] = jsoncurrencyConversion;
                // If the document is found, update it.
                // There is no need to check for a continuation token since we are querying for a single document.
                isAccepted = collection.replaceDocument(documents[0]._self, documents[0], requestOptions, callback);
            } else {
                // Else if the query came back empty, but with a continuation token; repeat the query w/ the token.
                // It is highly unlikely for this to happen when performing a query by id; but is included to serve as an example for larger queries.
                isAccepted = collection.createDocument(collectionLink, jsonData, callback);
            }
        });

        //var isAccepted =true;
        // If the request was accepted, callback will be called.
        // Otherwise report current count back to the client, 
        // which will call the script again with remaining set of docs.
        if (!isAccepted) getContext().getResponse().setBody(count);
    }

    // This is called when collection.createDocument is done in order to process the result.
    function callback(err, doc, options) {
        if (err) throw err;

        // One more document has been inserted, increment the count.
        count++;

        if (count >= docsLength) {
            // If we created all documents, we are done. Just set the response.
            getContext().getResponse().setBody(count);
        } else {
            // Create next document.
            tryCreate(currencyList[count], callback);
        }
    }

}