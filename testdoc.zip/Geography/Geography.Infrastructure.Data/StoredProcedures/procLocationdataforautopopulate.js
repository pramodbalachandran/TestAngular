﻿function procGetairportdetails(businessPartyNumber) {
    var context = getContext();
    var collection = context.getCollection();
    var response = context.getResponse();
    var body = getContext().getResponse().setBody;
    var result = {};
    var locationdataArray = [];
    var customerexistingdataArray = [];
    var finaldata = {};
    var arraycount = 0;
    var filterQueryQuotes = 'SELECT * FROM c WHERE c.docType="quotes" AND  c.businessPartyNumber= "' + businessPartyNumber + '"';
    var filterQuerylocation = 'SELECT * FROM c WHERE c.partitionkey="locationmapping"';
    //var filterQueryQuotes = 'SELECT * FROM c WHERE c.docType="quotes"';

    var isAccepted = collection.queryDocuments(collection.getSelfLink(), filterQueryQuotes, {},
        function (err, quotesdocuments, responseOptions) {
            if (err) throw new Error("Error" + err.message);

            var quoteNumberList = quotesdocuments;
            for (var quoteNumber of quotesdocuments) {
                var filterQueryAirFreights = 'SELECT * FROM c WHERE c.docType="airFreightShipmentDetail" AND  c.quoteIdentificationNumber= "' + quoteNumber.quoteIdentificationNumber + '"';
                var subAccepted =
                    collection.queryDocuments(collection.getSelfLink(), filterQueryAirFreights, {},
                        function (err, airfreightdocuments, responseOptions) {
                            if (err) throw new Error("Error" + err.message);
                            if (airfreightdocuments.length > 0)
                                shipmentData["id"] = airfreightdocuments[0].id;
                            shipmentData["docId"] = airfreightdocuments[0].docId;
                            var locationfilterquery = 'SELECT * FROM c WHERE c.partitionkey="locationmapping" AND  (c.locationCode= "' + airfreightdocuments[0].originAirport + '" OR c.locationCode= "' + airfreightdocuments[0].destinationAirport + '"';
                            var sublocationAccepted =
                                collection.queryDocuments(collection.getSelfLink(), locationfilterquery, {},
                                    function (err, locationdocuments, responseOptions) {
                                        if (err) throw new Error("Error" + err.message);
                                        if (locationdocuments.length > 0) {
                                            for (var locationdata of locationdocuments) {
                                                var customerexistingdataJson = {};
                                                customerexistingdataJson["autopopulateformat"] = locationdata.politicalDivision2Name + "," + locationdata.countryCode + "-" + locationdata.designatingLocationName;
                                                customerexistingdataJson["airportCode"] = locationdata.locationCode;
                                                customerexistingdataJson["airportName"] = locationdata.designatingLocationName;
                                                customerexistingdataJson["countryCode"] = locationdata.countryCode;
                                                customerexistingdataJson["countryName"] = locationdata.countryName;
                                                customerexistingdataJson["politicalDivision2Name"] = locationdata.politicalDivision2Name;
                                                for (var i = 0, l = customerexistingdataArray.length; i < l; i++) {
                                                    var unique = true;
                                                    if ((customerexistingdataArray[i].airportCode === locationdata.locationCode) && (customerexistingdataArray[i].politicalDivision2Name === locationdata.politicalDivision2Name)
                                                        && (customerexistingdataArray[i].countryCode === locationdata.countryCode)) {
                                                        unique = false;
                                                    }
                                                    if (unique) {
                                                        customerexistingdataArray.push(customerexistingdataJson);
                                                    }
                                                }
                                            }
                                        }

                                    });
                        });

            }


            //response.setBody(resultJson);
        });
    var islocationAccepted = collection.queryDocuments(collection.getSelfLink(), filterQuerylocation, {},
        function (err, locationdocuments, responseOptions) {
            if (err) throw new Error("Error" + err.message);
            //console.log(locationdocuments.length);
            if (locationdocuments.length > 0) {
                for (var locationdata of locationdocuments) {
                    var locationdataJson = {};
                    locationdataJson["autopopulateformat"] = locationdata.politicalDivision2Name + "," + locationdata.countryCode + "-" + locationdata.designatingLocationName;
                    locationdataJson["airportCode"] = locationdata.locationCode;
                    locationdataJson["airportName"] = locationdata.designatingLocationName;
                    locationdataJson["countryCode"] = locationdata.countryCode;
                    locationdataJson["countryName"] = locationdata.countryName;
                    locationdataJson["politicalDivision2Name"] = locationdata.politicalDivision2Name;
                    var unique = true;
                    for (var i = 0, l = locationdataArray.length; i < l; i++) {

                        if ((locationdataArray[i].airportCode === locationdata.locationCode) && (locationdataArray[i].politicalDivision2Name === locationdata.politicalDivision2Name)
                            && (locationdataArray[i].countryCode === locationdata.countryCode)) {
                            unique = false;
                        }
                    }
                    if (unique) {
                        locationdataArray.push(locationdataJson);
                    }
                    //console.log(unique);
                }
            }


            //response.setBody(resultJson);
        });

    if (!isAccepted || !islocationAccepted) throw new Error('The query was not accepted by the server.');
    else {
        result["CustomerExistingAirportdetails"] = customerexistingdataArray;
        result["Airportdetails"] = locationdataArray;
        //result.push(finaldata);
        response.setBody(result);
    }
}
