﻿function procLocationbulkImport(docs) {
    var collection = getContext().getCollection();
    var collectionLink = collection.getSelfLink();
    var body = getContext().getResponse().setBody;
    // The count of imported docs, also used as current doc index.
    var count = 0;
    // Validate input.
    if (!docs) throw new Error("The array is undefined or null.");
    var locationList = JSON.parse(docs);
    var docsLength = locationList.length;
    if (docsLength == 0) {
        getContext().getResponse().setBody(0);
    }
    // console.log(JSON.parse(docs).length);
    // Call the create API to create a document.
    tryCreate(locationList[count], callback);
    function tryCreate(doc, callback) {
        //console.log(doc.DESIGNATING_CODE);
        var jsonData = {};
        var isAccepted = true;
        jsonData["docType"] = "IAF_WORLDWIDE_LOCATION_MAPPING_RAW_US_NON_DISTINCT_CITY_NAME";
        jsonData["docId"] = doc.COUNTRY_CODE + "::" + doc.CITY_NAME + "::" + doc.CITY_NAME;
        jsonData["docCategory"] = "referenceLocation";
        jsonData["partitionkey"] = doc.DESIGNATING_CODE;//"us";//doc.DESIGNATING_CODE;
        jsonData["docStructureVersion"] = "1";
        jsonData["countryCode"] = doc.COUNTRY_CODE;
        jsonData["politicalDivision1Name"] = doc.CITY_NAME;
        jsonData["politicalDivision2Name"] = doc.CITY_NAME;
        jsonData["locationCode"] = doc.DESIGNATING_CODE;
        jsonData["locationName"] = "";
        jsonData["beyondPointCode"] = doc.BEST_AVAILABLE_SVC_CODE;
        jsonData["politicalDivision1Code"] = doc.STATE_PROV_CODE;
        jsonData["designatingLocationName"] = doc.DESIGNATING_NAME;
        jsonData["postalCode"] = doc.POSTAL_CODE;
        jsonData["countryCode"] = doc.COUNTRY_CODE;
        jsonData["overrideLocationCode"] = doc.RATED_OVER_POINT;
        jsonData["internationalAirFreightPricingOffice"] = doc.IAF_PRICING_OFFICE;
        jsonData["internationalAirFreightPricingOfficeCode"] = doc.IAF_PRICING_OFFICE_CODE;
        // console.log(jsonData);
        var query = { query: "select * from root r where r.docId = @docId", parameters: [{ name: "@docId", value: jsonData["docId"] }] };
        //var requestOptions = { continuation: continuation };

        var isAccepted = collection.queryDocuments(collectionLink, query, {}, function (err, documents, responseOptions) {
            if (err) throw err;

            if (documents.length > 0) {
                var requestOptions = { id: documents[0].id };
                //console.log(documents[0]["locationCode"]);
                documents[0]["locationCode"] = jsonData["locationCode"];
                documents[0]["beyondPointCode"] = jsonData["beyondPointCode"];
                documents[0]["politicalDivision1Code"] = jsonData["politicalDivision1Code"];
                documents[0]["designatingLocationName"] = jsonData["designatingLocationName"];
                documents[0]["postalCode"] = jsonData["postalCode"];
                documents[0]["overrideLocationCode"] = jsonData["overrideLocationCode"];
                documents[0]["internationalAirFreightPricingOffice"] = jsonData["internationalAirFreightPricingOffice"];
                documents[0]["internationalAirFreightPricingOfficeCode"] = jsonData["internationalAirFreightPricingOfficeCode"];
                // If the document is found, update it.
                // There is no need to check for a continuation token since we are querying for a single document.
                isAccepted = collection.replaceDocument(documents[0]._self, documents[0], requestOptions, callback);
            } else {
                // Else if the query came back empty, but with a continuation token; repeat the query w/ the token.
                // It is highly unlikely for this to happen when performing a query by id; but is included to serve as an example for larger queries.
                isAccepted = collection.createDocument(collectionLink, jsonData, callback);
            }
        });

        //var isAccepted =true;
        // If the request was accepted, callback will be called.
        // Otherwise report current count back to the client, 
        // which will call the script again with remaining set of docs.
        if (!isAccepted) getContext().getResponse().setBody(count);
    }

    // This is called when collection.createDocument is done in order to process the result.
    function callback(err, doc, options) {
        if (err) throw err;

        // One more document has been inserted, increment the count.
        count++;

        if (count >= docsLength) {
            // If we created all documents, we are done. Just set the response.
            getContext().getResponse().setBody(count);
        } else {
            // Create next document.
            tryCreate(locationList[count], callback);
        }
    }

}