﻿using System.Collections.Generic;
using System.Text;
using Geography.Core.Entities;
using Microsoft.Azure.Documents;
using Microsoft.Extensions.Logging;

namespace Geography.Infrastructure.Data.Repositories
{
    public class TaskRepository : Repository<MyTask>
    {
        public TaskRepository(IDocumentClient client, ILoggerFactory loggerFactory) : base(client, loggerFactory)
        {

        }

    }
}
