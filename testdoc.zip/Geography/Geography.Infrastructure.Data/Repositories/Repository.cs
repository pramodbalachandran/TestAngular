﻿using System;
using System.Collections.Generic;
using System.Text;

using Geography.Core.Entities.Abstract;
using Bonsai.Azure.CosmosDb;
using Microsoft.Azure.Documents;
using Microsoft.Extensions.Logging;
using System.Threading.Tasks;
using Bonsai.Azure.CosmosDb.Models;
using Geography.Core.Entities;
using System.Linq.Expressions;
using Newtonsoft.Json;

namespace Geography.Infrastructure.Data.Repositories
{
    public class Repository<T> : GenericRepository<T>, IRepository<T> where T : class, IEntity
    {
        //public Repository() : base(CustomerContext.DbConnectionString(), "Customer")
        //{

        //}

        //public Repository(IDocumentClient client, ILoggerFactory loggerFactory) : base(client, loggerFactory)
        //{

        //}

        private const string locationpartitionKey = "locationmapping";
        private const string _dbGFF = "Bonsai";
        private const string _collectionGFF = "GFF";
        private const string _dataFormat = "MMddyyyy";
        private const string _docIdprefix = "currencyConversion::";
        private const string _DocTypecurrencyConversion = "currencyConversion";
        private const string _docTypeLoc = "location";
        private const string _docCategory = "referenceLocation";
        private readonly IDocumentClient _docClient;
        private readonly ILoggerFactory _loggerFactory;
        private readonly GenericRepository<Autopopulateairportdetails> _objAirportdetails;
        private readonly GenericRepository<Autopopulatecustomerexistinglocation> _objExisitingAirportdetails; 
        private readonly GenericRepository<Location> _objDbLocation;
        private readonly GenericRepository<ResponseCurrencyExDetails> _objDbCurrency;
        private readonly GenericRepository<Country> _objDbCountry;
        public Repository(IDocumentClient client, ILoggerFactory loggerFactory)
            : base(client, loggerFactory, "Customer", "external")
        {
            _docClient = client;
            _loggerFactory = loggerFactory;
            _objDbLocation = new GenericRepository<Location>(_docClient, _loggerFactory, _dbGFF, _collectionGFF);
            _objDbCountry = new GenericRepository<Country>(_docClient, _loggerFactory, _dbGFF, _collectionGFF);
            _objDbCurrency = new GenericRepository<ResponseCurrencyExDetails>(_docClient, _loggerFactory, _dbGFF, _collectionGFF);
            _objAirportdetails = new GenericRepository<Autopopulateairportdetails>(_docClient, _loggerFactory, _dbGFF, _collectionGFF);
            _objExisitingAirportdetails = new GenericRepository<Autopopulatecustomerexistinglocation>(_docClient, _loggerFactory, _dbGFF, _collectionGFF);
        }

        public async Task<ISearchResult<ResponseCurrencyExDetails>> GetCurrencyDetails()
        {
            Expression<Func<ResponseCurrencyExDetails, bool>> criteria = d => d.docType == _DocTypecurrencyConversion && d.DocId == _docIdprefix + "10162018";//DateTime.Now.ToString(_dataFormat);
            SearchModel mod = new SearchModel
            {
                PageSize = 100
            };
            var lst = await _objDbCurrency.Get(criteria, mod);
            return lst;
        }
        public async Task<Autopopulateairportdetails> Getairportdetailsforautopopulate(string businessPartyNumber)
        {
            Autopopulateairportdetails objAutopopulateairportdetails = new Autopopulateairportdetails();
            string lastContinuationToken = string.Empty;
            var lstExistingData = await _objExisitingAirportdetails.ExecuteStoredProcedure(businessPartyNumber, "procGetairportdetailsforcustomer", "quotes").ConfigureAwait(true);
            var lstExistingDatajsonArray = lstExistingData != null && lstExistingData.location != null ? JsonConvert.SerializeObject(lstExistingData.location) : "[]";
            var lstExistingCustomerAirport = await _objAirportdetails.ExecuteStoredProcedure(lstExistingDatajsonArray, "procGetairportdetailswithcustomerdata", locationpartitionKey).ConfigureAwait(true);
            do
            {
                Autopopulateairportdetails objAutopopulateairportdetailscontinuous = new Autopopulateairportdetails();
                objAutopopulateairportdetailscontinuous = await _objAirportdetails.ExecuteStoredProcedureContinuoulsy(lastContinuationToken, "procGetairportdetails", locationpartitionKey).ConfigureAwait(true);
                lastContinuationToken = objAutopopulateairportdetails.lastContinuationToken;
                if (objAutopopulateairportdetails == null|| objAutopopulateairportdetails.Airportdetails==null)
                    objAutopopulateairportdetails = objAutopopulateairportdetailscontinuous;
                else if(objAutopopulateairportdetailscontinuous != null&& objAutopopulateairportdetailscontinuous.Airportdetails!=null)
                    objAutopopulateairportdetails.Airportdetails.AddRange(objAutopopulateairportdetailscontinuous.Airportdetails);
            }
            while (!string.IsNullOrEmpty(lastContinuationToken));
            if (objAutopopulateairportdetails != null && objAutopopulateairportdetails.Airportdetails != null&& lstExistingCustomerAirport!=null
                && lstExistingCustomerAirport.Airportdetails!=null)
            {
                objAutopopulateairportdetails.Airportdetails.AddRange(lstExistingCustomerAirport.Airportdetails);
            }
          
            return objAutopopulateairportdetails;
        }
        public async Task<Autopopulateairportdetails> GetSelectedairportdetailsforautopopulate(string businessPartyNumber)
        {
            var lstExistingData = await _objExisitingAirportdetails.ExecuteStoredProcedure(businessPartyNumber, "procGetairportdetailsforcustomer", "quotes").ConfigureAwait(true);
            var lstExistingDatajsonArray = lstExistingData != null && lstExistingData.location != null ? JsonConvert.SerializeObject(lstExistingData.location) : "[]";
            var lstExistingCustomerAirport = await _objAirportdetails.ExecuteStoredProcedure(lstExistingDatajsonArray, "procGetairportdetailswithcustomerdata", locationpartitionKey).ConfigureAwait(true);

            var lst = await _objAirportdetails.ExecuteStoredProcedureContinuoulsy(null, "procGetairportdetails", locationpartitionKey).ConfigureAwait(true);

            return lstExistingCustomerAirport;
        }
        public async Task<ISearchResult<Location>> GetpoliticalDivision2NameDetails(string partitionkey)
        {
            Expression<Func<Location, bool>> criteria = d => d.docType == _docTypeLoc;
            SearchModel mod = new SearchModel
            {
                PageSize = 100
            };
            var lst = await _objDbLocation.Get(criteria, mod);
            return lst;
        }
        public async Task<ISearchResult<Country>> Getcountrylist(string countrycode, string stateprovincecode)
        {
            Expression<Func<Country, bool>> criteria = d => d.docCategory == _docCategory &&  (!string.IsNullOrEmpty(countrycode) ? (d.countryCode == countrycode&&d.politicalDivision1Code !="") : 1==1)
            &&  (!string.IsNullOrEmpty(stateprovincecode) ? d.politicalDivision1Code == stateprovincecode : 1==1);

            SearchModel mod = new SearchModel
            {
                PageSize = 100
            };
            var lst = await _objDbCountry.Get(criteria, mod);

            return lst;
        }
       
    }
}
