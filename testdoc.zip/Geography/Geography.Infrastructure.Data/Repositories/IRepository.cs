﻿using System;
using System.Collections.Generic;
using System.Text;
using Geography.Core.Entities.Abstract;
using Bonsai.Azure.CosmosDb.Abstract;
using System.Threading.Tasks;
using Bonsai.Azure.CosmosDb.Models;
using Geography.Core.Entities;

namespace Geography.Infrastructure.Data.Repositories
{
    public interface IRepository<T> : IBaseRepository<T> where T : IEntity
    {
        Task<ISearchResult<Location>> GetpoliticalDivision2NameDetails(string docType);
        Task<ISearchResult<ResponseCurrencyExDetails>> GetCurrencyDetails();
        Task<ISearchResult<Country>> Getcountrylist(string countrycode, string stateprovincecode);
        Task<Autopopulateairportdetails> Getairportdetailsforautopopulate(string businessPartyNumber);
        Task<Autopopulateairportdetails> GetSelectedairportdetailsforautopopulate(string businessPartyNumber);
    }
}
