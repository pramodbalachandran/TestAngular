﻿using System.Security.Claims;

namespace Geography.Core.Security
{
    using Entities;
 
    public class GeographyPrincipal : ClaimsPrincipal
    {
        public GeographyPrincipal(User currentUser)
        {
            CurrentUser = currentUser;
        }

        public User CurrentUser { get; private set; }
    }
}
