﻿using System;
using System.Collections.Generic;
using System.Text;

using Geography.Core.Entities;

namespace Geography.Core.Repositories
{
    public interface ITaskRepository : ICoreRepository<MyTask>
    {

    }
}
