﻿
namespace Geography.Core.Services
{
    using Entities;
    public interface ILogService : IBaseService<Log>
    {

    }
}
