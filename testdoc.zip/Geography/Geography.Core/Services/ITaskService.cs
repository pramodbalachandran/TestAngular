﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Bonsai.Azure.CosmosDb.Models;
using Geography.Core.Entities;
using Geography.Core.Entities.Dtos;

namespace Geography.Core.Services
{
    public interface ITaskService : IBaseService<MyTask>
    {

        void CreateTask();

        dynamic GetpoliticalDivision2NameDetails(string partitionkey);

        dynamic GetCurrencyDetails();


        dynamic ValidateAddressDetails(Address objAddress);

        object Getcountrylist(string countrycode, string stateprovincecode);

        object Getairportdetailsforautopopulate(string businessPartyNumber);

        object GetSelectedairportdetailsforautopopulate(string businessPartyNumber);
       
    }
}
