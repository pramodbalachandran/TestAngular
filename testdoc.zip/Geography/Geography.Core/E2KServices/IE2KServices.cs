﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Bonsai.Azure.CosmosDb.Models;
using Geography.Core.Entities;
using Geography.Core.Entities.Dtos;

namespace Geography.Core.Services
{
    public interface IE2KServices 
    {
        dynamic FindFreightserviceType(Freightservice objFreightservice);
    }
}
