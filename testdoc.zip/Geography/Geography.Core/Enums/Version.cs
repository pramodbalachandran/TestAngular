﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Geography.Core.Enums
{
    public enum Version
    {
        V1 = 1
    }
}
