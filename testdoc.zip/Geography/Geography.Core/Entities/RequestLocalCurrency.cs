﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Geography.Core.Entities
{
    public class RequestLocalCurrency
    {
        [JsonProperty(PropertyName = "ClientIp4")]
        public string ClientIp4 { get; set; }

        [JsonProperty(PropertyName = "BaseCurrency")]
        public string BaseCurrency { get; set; }
    }

    public class RequestCurrencyTypes
    {
        [JsonProperty(PropertyName = "ClientIp4")]
        public string ClientIp4 { get; set; }

        [JsonProperty(PropertyName = "OriginCountry")]
        public string OriginCountry { get; set; }

        [JsonProperty(PropertyName = "DestinationCountry")]
        public string DestinationCountry { get; set; }
    }
}
