﻿using Bonsai.Azure.CosmosDb.Models;
using Geography.Core.Entities.Abstract;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Geography.Core.Entities
{
    public class Airportdetail
    {
        [JsonProperty(PropertyName = "autopopulateformat")]
        public string autopopulateformat { get; set; }
        [JsonProperty(PropertyName = "airportCode")]
        public string airportCode { get; set; }
        [JsonProperty(PropertyName = "airportName")]
        public string airportName { get; set; }
        [JsonProperty(PropertyName = "countryCode")]
        public string countryCode { get; set; }
        [JsonProperty(PropertyName = "countryName")]
        public string countryName { get; set; }
        [JsonProperty(PropertyName = "politicalDivision2Name")]
        public string politicalDivision2Name { get; set; }
        [JsonProperty(PropertyName = "autopopulateformat1")]
        public string autopopulateformat1 { get; set; }
        [JsonProperty(PropertyName = "autopopulateformat2")]
        public string autopopulateformat2 { get; set; }
        [JsonProperty(PropertyName = "postalCode")]
        public string postalCode { get; set; }
        [JsonProperty(PropertyName = "region")]
        public string region { get; set; }       
        [JsonProperty(PropertyName = "isCustomerData")]
        public string isCustomerData { get; set; }
    }

    public class Autopopulateairportdetails: IEntity
    {
        [JsonProperty(PropertyName = "Airportdetails")]
        public List<Airportdetail> Airportdetails { get; set; }
        [JsonProperty(PropertyName = "id")]
        public Guid? Id { get; set; }
        public string PartitionKey { get; set; }
        public string lastContinuationToken { get; set; }
    }
    public class Autopopulatecustomerexistinglocation : IEntity
    {
        [JsonProperty(PropertyName = "location")]
        public List<location> location { get; set; }
        [JsonProperty(PropertyName = "id")]
        public Guid? Id { get; set; }
        public string PartitionKey { get; set; }
        public string lastContinuationToken { get; set; }
    }
    public class location
    {

        [JsonProperty(PropertyName = "locationCode")]
        public string locationCode { get; set; }

        [JsonProperty(PropertyName = "politicalDivision2Name")]
        public string politicalDivision2Name { get; set; }
    }
}
