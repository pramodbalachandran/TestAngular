﻿using Geography.Core.Entities.Abstract;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Geography.Core.Entities
{
    public class ResponseCurrencyExDetails : IEntity
    {
        [JsonProperty(PropertyName = "docType")]
        public string docType { get; set; }

        [JsonProperty(PropertyName = "docId")]
        public string DocId { get; set; }

        [JsonProperty(PropertyName = "docCategory")]
        public string DocCategory { get; set; }

        [JsonProperty(PropertyName = "docStructureVersion")]
        public string DocStructureVersion { get; set; }

        [JsonProperty(PropertyName = "currencyConversion")]
        public List<CurrencyExDetails> LstCurrencyDetails { get; set; }
        public Guid? Id { get; set; }
        public string PartitionKey { get; set; }
        public string lastContinuationToken { get; set; }
    }

    public class CurrencyExDetails
    {
        [JsonProperty(PropertyName = "countryCode")]
        public string CountryCode { get; set; }

        [JsonProperty(PropertyName = "countryName")]
        public string CountryName { get; set; }

        [JsonProperty(PropertyName = "exchangeRateAmount")]
        public float ExchangeRateAmount { get; set; }

        [JsonProperty(PropertyName = "currencyName")]
        public string CurrencyName { get; set; }

        [JsonProperty(PropertyName = "decimalPlacesQuantity")]
        public Int16 DecimalPlacesQuantity { get; set; }

        [JsonProperty(PropertyName = "roundingDirectionText")]
        public string RoundingDirectionText { get; set; }

        [JsonProperty(PropertyName = "localCurrencyCode")]
        public string LocalCurrencyCode { get; set; }

        [JsonProperty(PropertyName = "localeCodes")]
        public string LocaleCodes { get; set; }

        [JsonProperty(PropertyName = "localConversionToUsdAmount")]
        public string LocalConversionToUsdAmount { get; set; }

        [JsonProperty(PropertyName = "currencyDescription")]
        public string CurrencyDescription { get; set; }
    }
}
