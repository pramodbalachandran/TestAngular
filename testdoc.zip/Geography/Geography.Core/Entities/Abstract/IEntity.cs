﻿using System;
using System.Collections.Generic;
using System.Text;
using Bonsai.Azure.CosmosDb.Models;
namespace Geography.Core.Entities.Abstract
{
    public interface IEntity : IModel
    {

    }
}
