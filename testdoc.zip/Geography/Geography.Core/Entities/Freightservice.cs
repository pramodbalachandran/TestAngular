﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Geography.Core.Entities
{
    public class Freightservice
    {
        [JsonProperty(PropertyName = "CityOrg")]
        public string CityOrg { get; set; }
        [JsonProperty(PropertyName = "StateProvOrg")]
        public string StateProvOrg { get; set; }
        [JsonProperty(PropertyName = "PostalCodeOrg")]
        public string PostalCodeOrg { get; set; }
        [JsonProperty(PropertyName = "CountryCodeOrg")]
        public string CountryCodeOrg { get; set; }
        [JsonProperty(PropertyName = "CityDes")]
        public string CityDes { get; set; }
        [JsonProperty(PropertyName = "StateProvDes")]
        public string StateProvDes { get; set; }
        [JsonProperty(PropertyName = "PostalCodeDes")]
        public string PostalCodeDes { get; set; }
        [JsonProperty(PropertyName = "CountryCodeDes")]
        public string CountryCodeDes { get; set; }
    }
    public class ServiceTypes
    {
        [JsonProperty(PropertyName = "ServiceTypeCodeCA")]
        public string ServiceTypeCodeCA { get; set; }
        [JsonProperty(PropertyName = "ServiceTypeCodeEC")]
        public string ServiceTypeCodeEC { get; set; }
        [JsonProperty(PropertyName = "ServiceTypeCodeCX")]
        public string ServiceTypeCodeCX { get; set; }
    }
}
