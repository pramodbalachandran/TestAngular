﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Geography.Core.Entities
{
    using Abstract;
    public class UserAccountSetting : IEntity
    {
        public string PartitionKey { get; set; }
        public Guid? Id { get; set; }
        //public string[] ItemType { get; }
        public int Version { get; set; }
        public int UserId { get; set; }
        public int RoleId { get; set; }
        public string CMVLicense { get; set; }
        public int? ExceptionTypeId { get; set; }
        public string DrivingCategory { get; set; }
        public bool? IsTeamDriver { get; set; }
        public int StatusId { get; set; }
        public int? CreatedBy { get; set; }
        public DateTime CreatedOn { get; set; }
        public int? ModifiedBy { get; set; }
        public DateTime? ModifiedOn { get; set; }
        public bool IsDelete { get; set; }
        public string StateIssued { get; set; }
        public int? VehicleTypeId { get; set; }
        public bool CreatedByWebAdminTool { get; set; }
        //public long? MPUserId { get; set; }
        public int? Is100AirMileRadiusExceptionEnabled { get; set; }
        public string ExceptionType { get; set; }

        public bool? IsLicenseAccepted { get; set; }

        public DateTime? LicenseAcceptedDate { get; set; }

        public string ExemptionReason { get; set; }
        public User User { get; set; }

        public string lastContinuationToken { get; set; }
    }
}
