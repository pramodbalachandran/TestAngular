﻿using System;
using System.ComponentModel.DataAnnotations;
namespace Geography.Core.Entities
{

    public class Log : BaseEntity
    {
        [Required]
        public DateTime Date { get; set; }
        [MaxLength(50)]
        public string Server { get; set; }
        [Required]
        public int Level { get; set; }
        [MaxLength(1000)]
        public string Message { get; set; }
        public string StackTrace { get; set; }
    }
}
