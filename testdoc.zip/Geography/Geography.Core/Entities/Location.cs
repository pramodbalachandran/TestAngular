﻿using System;
using System.Collections.Generic;
using System.Text;
using Geography.Core.Entities.Abstract;
namespace Geography.Core.Entities
{
    using Abstract;
    using Newtonsoft.Json;

    public class Location : IEntity
    {
        public Location()
        {

        }
        [JsonProperty(PropertyName = "id")]
        public Guid? Id { get; set; }
        public string docType { get; set; }
        public string docId { get; set; }
        public string partitionkey { get; set; }
        public string docStructureVersion { get; set; }
        public string locationTypeText { get; set; }
        public string locationCode { get; set; }
        public string countryCode { get; set; }
        public List<State> state { get; set; }
        public string PartitionKey { get; set; }

        public string lastContinuationToken { get; set; }
    }
    public class City
    {
        public string cityName { get; set; }
        public string politicalDivision2Name { get; set; }
        public string designatingCode { get; set; }
        public string designatingLocationName { get; set; }
        public string politicalDivision1Code { get; set; }
        public string politicalDivision1Name { get; set; }
        public string postalCode { get; set; }
        public string beyondPointCode { get; set; }
        public string overrideLocationCode { get; set; }
        public string internationalAirFreightPricingOffice { get; set; }
        public string internationalAirFreightPricingOfficeCode { get; set; }

        public string PartitionKey { get; set; }
    }

    public class State
    {
        public string stateProvCode { get; set; }
        public List<City> city { get; set; }
    }

}
