﻿using Geography.Core.Entities.Abstract;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Geography.Core.Entities
{
    public class Country:IEntity
    {
        [JsonProperty(PropertyName = "id")]
        public Guid? Id { get; set; }
        [JsonProperty(PropertyName = "docType")]
        public string docType { get; set; }

        [JsonProperty(PropertyName = "countryCode")]
        public string countryCode { get; set; }
        public string PartitionKey { get; set; }  
        
        [JsonProperty(PropertyName = "stateProvCode")]
        public string stateProvCode { get; set; }

        [JsonProperty(PropertyName = "cityName")]
        public string cityName { get; set; }

        [JsonProperty(PropertyName = "countryName")]
        public string countryName { get; set; }

        [JsonProperty(PropertyName = "docCategory")]
        public string docCategory { get; set; }

        [JsonProperty(PropertyName = "politicalDivision1Code")]
        public string politicalDivision1Code { get; set; }

        [JsonProperty(PropertyName = "politicalDivision1Name")]
        public string politicalDivision1Name { get; set; }

        public string lastContinuationToken { get; set; }
    }
    public class Countryrootlist
    {
        public List<Countrylist> results { get; set; }
    }
    public class Countrylist
    {
        [JsonProperty(PropertyName = "countryCode")]
        public string countryCode { get; set; }
        [JsonProperty(PropertyName = "countryName")]
        public string countryName { get; set; }
        [JsonProperty(PropertyName = "politicalDivision1Code")]
        public string politicalDivision1Code { get; set; }

        [JsonProperty(PropertyName = "politicalDivision1Name")]
        public string politicalDivision1Name { get; set; }
    }
}
