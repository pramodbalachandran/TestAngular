﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Geography.Core.Entities
{
    public class AccessRequest
    {
        public string AccessLicenseNumber { get; set; }
        public string UserId { get; set; }
        public string Password { get; set; }
    }

    public class Request
    {
        public string RequestAction { get; set; }
    }

    public class Address
    {

        [JsonProperty(PropertyName = "City")]
        public string City { get; set; }
        [JsonProperty(PropertyName = "StateProvinceCode")]
        public string StateProvinceCode { get; set; }
        [JsonProperty(PropertyName = "PostalCode")]
        public string PostalCode { get; set; }
    }

    public class AddressValidationRequest
    {
        public Request Request { get; set; }
        public Address Address { get; set; }
    }

    public class AddressValidation
    {
        public AccessRequest AccessRequest { get; set; }
        public AddressValidationRequest AddressValidationRequest { get; set; }
    }
    public class Airportdetailsrequest
    {

        [JsonProperty(PropertyName = "businessPartyNumber")]
        public string businessPartyNumber { get; set; }
    }
}
