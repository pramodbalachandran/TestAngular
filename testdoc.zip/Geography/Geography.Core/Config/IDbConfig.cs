﻿

namespace Geography.Core.Config
{
    public interface IDbConfig
    {
        string GeographyConnectionString { get; }
        string DocumentDbEndpointUrl { get; }
        string DocumentDbPrimaryKey { get; }
        string CacheServerConnectionString { get; }
    }
}
