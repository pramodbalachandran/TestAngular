﻿using System;

namespace Geography.Integration
{
    public class Class1
    {
    }
}
