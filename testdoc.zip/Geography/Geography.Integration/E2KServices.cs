﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Net.Http;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Linq;
using Bonsai.Azure.CosmosDb.Models;
using Geography.Core.Entities;
using Geography.Core.Entities.Dtos;
using Geography.Core.Services;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using RestSharp;

namespace Geography.Integration
{
    public class E2KServices   : IE2KServices
    {
        private readonly IConfiguration _appConfig;
        private const string InternalServerError = "500";
        private const string RequestSuccess = "200";
        private const string StatusSuccess = "1";
        private const string StatusFailure = "0";
        private const string SuccessMessage = "Success";
        private const string FailureMessage = "Failed";
        private const string FreightServicesurl = "FreightServicesRequest:FreightServicesurl";
        public E2KServices(IConfiguration appConfig) : base()
        {
            _appConfig = appConfig;
        }

        public dynamic FindFreightserviceType(Freightservice objFreightservice)
        {
            string url = _appConfig[FreightServicesurl];
            int codeCount = 0;
            //string currentDirectory = Directory.GetCurrentDirectory();
            //string filePath = System.IO.Path.Combine(currentDirectory, "Files", "FreightServiceRequest.xml");
            //string filePath = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) + @"\Files\FreightServiceRequest.xml";
            //string soapString = System.IO.File.ReadAllText(filePath);
            //var dirPath = Assembly.GetExecutingAssembly().Location;
            var soapString = System.IO.File.ReadAllText(@".\Files\FreightServiceRequest.xml");
            soapString = soapString.Replace("City_Org", objFreightservice.CityOrg);
            soapString = soapString.Replace("City_Des", objFreightservice.CityDes);
            soapString = soapString.Replace("StateProv_Org", objFreightservice.StateProvOrg);
            soapString = soapString.Replace("StateProv_Des", objFreightservice.StateProvDes);
            soapString = soapString.Replace("PostalCode_Org", objFreightservice.PostalCodeOrg);
            soapString = soapString.Replace("PostalCode_Des", objFreightservice.PostalCodeDes);
            soapString = soapString.Replace("CountryCode_Org", objFreightservice.CountryCodeOrg);
            soapString = soapString.Replace("CountryCode_Des", objFreightservice.CountryCodeDes);

            /*START:Call soap ui using RestClient*/

            var client = new RestClient(url);
            // client.Authenticator = new HttpBasicAuthenticator(username, password);
            var request = new RestRequest();
            request.Method = Method.POST;
            request.RequestFormat = DataFormat.Xml;
            request.AddParameter("text/xml", soapString, ParameterType.RequestBody);
            // execute the request
            IRestResponse response = client.Execute(request);
            var content = response.Content;

            /*END:Call soap ui using RestClient*/

            /*START:Call soap ui using httpclient*/

            //HttpResponseMessage response = await PostXmlRequest(url, soapString);
            //string content = await response.Content.ReadAsStringAsync();

            /*START:Call soap ui using httpclient*/

            // string jsonResponse = "{\"Code1\":\"1\",\"Code2\":\"2\",\"Code3\":\"3\"}";
            ServiceTypes objServiceTypes = new ServiceTypes();
            if (response.IsSuccessful)
            {
                XDocument doc = XDocument.Parse(content);
                XNamespace ns = "http://www.ups.com/XMLSchema/E2kGetValidServicesRspn/v1_0_1";
                IEnumerable<XElement> soapresponses = doc.Descendants(ns + "E2kGetValidServicesRspn").Descendants(ns + "Services").Descendants(ns + "Service");
                foreach (XElement res in soapresponses)
                {
                    codeCount++;
                    string strResponseCode = (string)res.Element(ns + "Code");
                    switch (strResponseCode.ToUpper())
                    {
                        case "CA":
                            objServiceTypes.ServiceTypeCodeCA = strResponseCode.ToUpper();
                            break;
                        case "EC":
                            objServiceTypes.ServiceTypeCodeEC = strResponseCode.ToUpper();
                            break;

                        case "CX":
                            objServiceTypes.ServiceTypeCodeCX = strResponseCode.ToUpper();
                            break;
                    }
                }
                string jsonResponse = JsonConvert.SerializeObject(objServiceTypes);
                return new ResponseModel
                {
                    responseData = JObject.Parse(jsonResponse),
                    responseStatus = new Core.Entities.Dtos.ResponseStatus
                    {
                        status = RequestSuccess,
                        message = SuccessMessage
                    }
                };
            }
            else
            {
                //var res = SendConfirmationEmailOnSignUp(signUpRequest.EmailAddress);
                return new ResponseModel
                {
                    responseStatus = new Core.Entities.Dtos.ResponseStatus
                    {
                        message = FailureMessage,
                        status = InternalServerError
                    },
                };
            }

        }

        public static async Task<HttpResponseMessage> PostXmlRequest(string baseUrl, string xmlString)
        {
            using (var httpClient = new HttpClient())
            {
                var httpContent = new StringContent(xmlString, Encoding.UTF8, "text/xml");

                return await httpClient.PostAsync(baseUrl, httpContent);
            }
        }
    }
}
