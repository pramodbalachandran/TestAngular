﻿using System;
using System.Collections.Generic;
using System.Text;
using AutoMapper;
using Geography.Core.Entities;
using Geography.Core.Entities.Dtos;

namespace Geography.Infrastructure.Maps
{
    public class TaskMaps : Profile
    {
        public TaskMaps()
        {
            CreateMap<MyTask, MyTaskDto>();
            CreateMap<MyTaskDto, MyTask>();
        }
    }
}
