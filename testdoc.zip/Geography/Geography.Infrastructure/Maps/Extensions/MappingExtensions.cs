﻿

namespace Geography.Infrastructure.Maps.Extensions
{
    using AutoMapper;
    using Core.Entities;
    using Core.Entities.Abstract;

    public static class MappingExtensions
    {
        public static IMappingExpression<TSource, TDest> IgnoreBaseEntityWithId<TSource, TDest>(
            this IMappingExpression<TSource, TDest> expression) where TDest : BaseEntity
        {
            expression
                .ForMember(x => x.Id, y => y.Ignore());
            //.ForMember(x => x.CreatedById, y => y.Ignore())
            //.ForMember(x => x.CreatedBy, y => y.Ignore())
            //.ForMember(x => x.CreatedDate, y => y.Ignore())
            //.ForMember(x => x.ModifiedById, y => y.Ignore())
            //.ForMember(x => x.ModifiedBy, y => y.Ignore())
            //.ForMember(x => x.ModifiedDate, y => y.Ignore());

            return expression;
        }

        public static IMappingExpression<TSource, TDest> IgnoreBaseEntity<TSource, TDest>(
            this IMappingExpression<TSource, TDest> expression) where TDest : BaseEntity
        {
            expression
                .ForMember(x => x.Id, y => y.Ignore());
            //.ForMember(x => x.ModifiedById, y => y.Ignore())
            //.ForMember(x => x.CreatedBy, y => y.Ignore())
            //.ForMember(x => x.CreatedDate, y => y.Ignore())
            //.ForMember(x => x.ModifiedBy, y => y.Ignore())
            //.ForMember(x => x.ModifiedDate, y => y.Ignore());

            return expression;
        }
    }
}