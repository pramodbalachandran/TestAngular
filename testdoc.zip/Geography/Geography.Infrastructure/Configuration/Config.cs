﻿using System;
using System.Configuration;
using Microsoft.Extensions.Configuration;

namespace Geography.Infrastructure.Configuration
{
    using Core.Config;

    public class Config : IConfig
    {

        public string DbConnectionString { get; set; }
        public string AuthIdHeader { get; set; }
        public string AuthNameHeader { get; set; }

    }
       
}

