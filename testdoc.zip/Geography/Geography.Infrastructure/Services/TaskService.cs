﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Net.Http;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Linq;
using Bonsai.Azure.CosmosDb.Models;
using Geography.Core.Entities;
using Geography.Core.Entities.Dtos;
using Geography.Core.Services;
using Geography.Infrastructure.Data.Repositories;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using RestSharp;

namespace Geography.Infrastructure.Services
{
    public class TaskService : BaseService<MyTask>, ITaskService
    {
        private readonly IRepository<MyTask> _taskRepository;
        private readonly IConfiguration _appConfig;
        private static readonly HttpClient _htpclient = new HttpClient();
        private const string InternalServerError = "500";
        private const string RequestSuccess = "200";
        private const string StatusSuccess = "1";
        private const string StatusFailure = "0";
        private const string SuccessMessage = "Success";
        private const string FailureMessage = "Failed";
        private const string AccessLicenseNumber = "AccessRequest:AccessLicenseNumber";
        private const string UserId = "AccessRequest:UserId";
        private const string Password = "AccessRequest:Password";
        private const string Addressapiurl = "AccessRequest:Addressapiurl";
        private const string RequestAction = "AccessRequest:RequestAction";
       
        public TaskService(IRepository<MyTask> repository, IConfiguration appConfig) : base(repository)
        {
            _appConfig = appConfig;
            _taskRepository = repository;
        }

        public void CreateTask()
        {
            MyTask task = new MyTask
            {
                Version = 1,
                Name = "Task 1",
                Category = "A",
                CreatedDate = DateTime.Today
            };
            Repository.Upsert(task);
            task = new MyTask
            {
                Version = 1,
                Name = "Task 2",
                Category = "A",
                CreatedDate = DateTime.Today
            };
            Repository.Upsert(task);
        }

        public dynamic GetCurrencyDetails()
        {
            return _taskRepository.GetCurrencyDetails();
        }

        public dynamic GetpoliticalDivision2NameDetails(string partitionkey)
        {
            Task<ISearchResult<Location>> GFFList = _taskRepository.GetpoliticalDivision2NameDetails(partitionkey);
            var CountryList = GFFList.Result.Results;
            var CityDetails = (from a in CountryList
                               from b in a.state
                               from c in b.city
                               where c.cityName.StartsWith(partitionkey)
                               select new { cityName = c.cityName }).ToList();
            return CityDetails;

        }

        public object Getairportdetailsforautopopulate(string businessPartyNumber)
        {
            //return _taskRepository.Getairportdetailsforautopopulate(businessPartyNumber);
            Task<Autopopulateairportdetails> GFFList = _taskRepository.Getairportdetailsforautopopulate(businessPartyNumber);
            List<Airportdetail> objAirportLisFinal = new List<Airportdetail>();
            List<Airportdetail> objAirportList = (GFFList.Result!=null&& GFFList.Result.Airportdetails!=null) ?GFFList.Result.Airportdetails.Where(x=>x.isCustomerData=="0").OrderBy(x=>x.autopopulateformat).ToList():null;
            List<Airportdetail> objAirportListExisting = (GFFList.Result != null && GFFList.Result.Airportdetails != null) ? GFFList.Result.Airportdetails.Where(x => x.isCustomerData == "1").ToList() : null;
            objAirportLisFinal = objAirportList.Concat(objAirportListExisting).ToList();
            Autopopulateairportdetails objAutopopulateairportdetails = new Autopopulateairportdetails();
            objAutopopulateairportdetails.Airportdetails = objAirportLisFinal;
            return objAutopopulateairportdetails;

        }
        public object GetSelectedairportdetailsforautopopulate(string businessPartyNumber)
        {
            //return _taskRepository.Getairportdetailsforautopopulate(businessPartyNumber);
            Task<Autopopulateairportdetails> GFFListExisting = _taskRepository.GetSelectedairportdetailsforautopopulate(businessPartyNumber);
            List<Airportdetail> objAirportListCustomer = (GFFListExisting.Result != null && GFFListExisting.Result.Airportdetails != null) ? GFFListExisting.Result.Airportdetails.Where(x => x.isCustomerData == "1").ToList() : null;

            Autopopulateairportdetails objAutopopulateairportdetails = new Autopopulateairportdetails();
            objAutopopulateairportdetails.Airportdetails = objAirportListCustomer;
            return objAutopopulateairportdetails;
        }
            public object Getcountrylist(string countrycode, string stateprovincecode)
        {
          // return  _taskRepository.Getcountrylist(countrycode, stateprovincecode);
            Task<ISearchResult<Country>> GFFList = _taskRepository.Getcountrylist(countrycode, stateprovincecode);
            var CountryList = GFFList.Result.Results;
            Countryrootlist objCountryrootlist = new Countryrootlist();

            //objCountryrootlist.results = (from a in CountryList
            //                              select new Countrylist { countryCode = a.countryCode, countryName = a.countryName, politicalDivision1Code = a.politicalDivision1Code, politicalDivision1Name = a.politicalDivision1Name }).ToList();
            if (string.IsNullOrEmpty(countrycode) && string.IsNullOrEmpty(stateprovincecode))
            {
                objCountryrootlist.results = (from a in CountryList
                                              group a by new { a.countryCode,a.countryName} into grpList
                                              orderby grpList.Key.countryName
                                              select new Countrylist { countryCode = grpList.Key.countryCode, countryName = grpList.Select(x=>x.countryName).FirstOrDefault() }).ToList();
            }
            else if (!string.IsNullOrEmpty(countrycode) && string.IsNullOrEmpty(stateprovincecode))
            {
                objCountryrootlist.results = (from a in CountryList
                                              group a by new { countryCode=a.countryCode, countryName=a.countryName, politicalDivision1Code=a.politicalDivision1Code, politicalDivision1Name= a.politicalDivision1Name } into grpList
                                              orderby grpList.Key.politicalDivision1Name 
                                              select new Countrylist { countryCode = grpList.Key.countryCode, countryName = grpList.Key.countryName, politicalDivision1Code = grpList.Key.politicalDivision1Code,politicalDivision1Name =!string.IsNullOrEmpty(grpList.Key.politicalDivision1Name)? (grpList.Key.politicalDivision1Name.First().ToString().ToUpper() + grpList.Key.politicalDivision1Name.Substring(1)): grpList.Key.politicalDivision1Name }).ToList();
            }
            else if (!string.IsNullOrEmpty(countrycode) && !string.IsNullOrEmpty(stateprovincecode))
            {
                objCountryrootlist.results = (from a in CountryList
                                              group a by new { a.countryCode, a.countryName, a.politicalDivision1Code, a.politicalDivision1Name } into grpList
                                              select new Countrylist { countryCode = grpList.Key.countryCode, countryName = grpList.Key.countryName, politicalDivision1Code = grpList.Key.politicalDivision1Code, politicalDivision1Name = grpList.Key.politicalDivision1Name }).ToList();
            }
            return objCountryrootlist;
        }
        public dynamic ValidateAddressDetails(Address objAddress)
        {
            //HttpClient http = new HttpClient();
            //string url = _appConfig[Addressapiurl];
            //AddressValidation objAddressValidation = new AddressValidation();
            //AccessRequest objAccessRequest = new AccessRequest();
            //objAccessRequest.AccessLicenseNumber = _appConfig[AccessLicenseNumber]; 
            //objAccessRequest.UserId = _appConfig[UserId]; 
            //objAccessRequest.Password = _appConfig[Password]; 
            //objAddressValidation.AccessRequest = objAccessRequest;

            //AddressValidationRequest objAddressValidationRequest = new AddressValidationRequest();
            //Request objRequest = new Request();
            //objRequest.RequestAction = _appConfig[RequestAction]; 
            //objAddressValidationRequest.Request = objRequest;
            //objAddressValidationRequest.Address = objAddress;

            //objAddressValidation.AccessRequest = objAccessRequest;
            //objAddressValidation.AddressValidationRequest = objAddressValidationRequest;
            //HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Post, url);
            //request.Headers.Add("Access-Control-Allow-Headers", "Origin,X-Requested-With,Content-Type,Accept");
            //request.Headers.Add("Access-Control-Allow-Methods", "POST");
            //request.Headers.Add("Access-Control-Allow-Origin", "*");
            ////request.Headers.Add("content-type", "application/json");
            //var json = JsonConvert.SerializeObject(objAddressValidation);
            //request.Content = new StringContent(json, Encoding.UTF8, "application/json");
            //HttpResponseMessage response = await http.SendAsync(request);
            //string resContent = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
            //JObject rss = JObject.Parse(resContent);
            ////return rss;
            //return new AddressapiResponseStatus
            //{
            //    TransactionReference = (string)rss["AddressValidationResponse"]["Response"]["TransactionReference"],
            //    ResponseStatusCode = (string)rss["AddressValidationResponse"]["Response"]["ResponseStatusCode"],
            //    ResponseStatusDescription = (string)rss["AddressValidationResponse"]["Response"]["ResponseStatusDescription"],
            //    //City = (string)rss["AddressValidationResult"][0]["Address"]["City"],
            //   // StateProvinceCode = (string)rss["AddressValidationResult"][0]["Address"]["StateProvinceCode"],
            //};
            bool isvalidationsuccess = false;
            string url = _appConfig[Addressapiurl];
            AddressValidation objAddressValidation = new AddressValidation();
            AccessRequest objAccessRequest = new AccessRequest();
            objAccessRequest.AccessLicenseNumber = _appConfig[AccessLicenseNumber];
            objAccessRequest.UserId = _appConfig[UserId];
            objAccessRequest.Password = _appConfig[Password];
            objAddressValidation.AccessRequest = objAccessRequest;

            AddressValidationRequest objAddressValidationRequest = new AddressValidationRequest();
            Request objRequest = new Request();
            objRequest.RequestAction = _appConfig[RequestAction];
            objAddressValidationRequest.Request = objRequest;
            objAddressValidationRequest.Address = objAddress;

            objAddressValidation.AccessRequest = objAccessRequest;
            objAddressValidation.AddressValidationRequest = objAddressValidationRequest;


            var client = new RestClient(url);
            // client.Authenticator = new HttpBasicAuthenticator(username, password);

            var request = new RestRequest();
            request.Method = Method.POST;
            request.RequestFormat = DataFormat.Json;
            request.AddParameter("application/json", JsonConvert.SerializeObject(objAddressValidation), ParameterType.RequestBody);
            // easily add HTTP Headers
            request.AddHeader("Access-Control-Allow-Headers", "Origin,X-Requested-With,Content-Type,Accept");
            request.AddHeader("Access-Control-Allow-Methods", "POST");
            request.AddHeader("Access-Control-Allow-Origin", "*");
            request.AddHeader("content-type", "application/json");
            // execute the request
            IRestResponse response = client.Execute(request);
            //var response = "{\"AddressValidationResponse\": {\"Response\": {\"TransactionReference\": \"\",\"ResponseStatusCode\": \"1\",\"ResponseStatusDescription\": \"Success\"},\"AddressValidationResult\": [{\"Rank\": \"1\",\"Quality\": \"0.9750\",\"Address\": {\"City\": \"ALPHARETTA\",\"StateProvinceCode\": \"GA\"},\"PostalCodeLowEnd\": \"30005\",\"PostalCodeHighEnd\": \"30005\"},{\"Rank\": \"2\",\"Quality\": \"0.9750\",\"Address\": {\"City\": \"JOHNS CREEK\",\"StateProvinceCode\": \"GA\"},\"PostalCodeLowEnd\": \"30005\",\"PostalCodeHighEnd\": \"30005\"}]}}";
            //var response = "{\"AddressValidationResponse\": {\"Response\": {\"TransactionReference\": \"\",\"ResponseStatusCode\": \"1\",\"ResponseStatusDescription\": \"Success\"},\"AddressValidationResult\":{\"Rank\": \"1\",\"Quality\": \"0.9750\",\"Address\": {\"City\": \"ALPHARETTA\",\"StateProvinceCode\": \"GA\"},\"PostalCodeLowEnd\": \"30005\",\"PostalCodeHighEnd\": \"30005\"}}}";
            var content = response.Content;
            JObject jsonResult = JObject.Parse(content);
            //JArray ResponseStatusCode1 = (JArray)jsonResult.SelectToken("AddressValidationResponse");
            string ResponseStatusCode = (string)jsonResult["AddressValidationResponse"]["Response"]["ResponseStatusCode"];
            var jsonResponse = string.Empty;
            // return jsonResult["AddressValidationResponse"]["Response"];
            if (ResponseStatusCode == "1")
            {

                if (jsonResult["AddressValidationResponse"]["AddressValidationResult"] is JArray)
                {
                    foreach (var address in jsonResult["AddressValidationResponse"]["AddressValidationResult"])
                    {
                        if (!string.IsNullOrEmpty(objAddress.StateProvinceCode) && objAddress.StateProvinceCode.ToLower().Trim() == ((string)address["Address"]["StateProvinceCode"]).ToLower().Trim())
                        {
                            if (objAddress.City.ToLower().Trim()== ((string)address["Address"]["City"]).ToLower().Trim()&& 
                                objAddress.PostalCode.Trim() == ((string)address["PostalCodeLowEnd"]).ToLower().Trim())
                            {
                                isvalidationsuccess = true;
                                break;
                            }
                        }
                        else if (string.IsNullOrEmpty(objAddress.StateProvinceCode) && objAddress.City.ToLower().Trim() == ((string)address["Address"]["City"]).ToLower().Trim() &&
                                objAddress.PostalCode.Trim() == ((string)address["PostalCodeLowEnd"]).ToLower().Trim())
                        {
                            isvalidationsuccess = true;
                            break;
                        }
                    }
                }
                else if(!string.IsNullOrEmpty(objAddress.StateProvinceCode))
                {
                    if((((string)jsonResult["AddressValidationResponse"]["AddressValidationResult"]["Address"]["StateProvinceCode"]).ToLower().Trim() == objAddress.StateProvinceCode.ToLower().Trim()) && 
                        (((string)jsonResult["AddressValidationResponse"]["AddressValidationResult"]["Address"]["City"]).ToLower().Trim() == objAddress.City.ToLower().Trim()))
                    {
                        if(objAddress.PostalCode.Trim() == ((string)jsonResult["AddressValidationResponse"]["AddressValidationResult"]["PostalCodeLowEnd"]).ToLower().Trim())
                        {
                            isvalidationsuccess = true;
                        }
                       
                    }

                }
                else if (string.IsNullOrEmpty(objAddress.StateProvinceCode))
                {
                    if((((string)jsonResult["AddressValidationResponse"]["AddressValidationResult"]["Address"]["City"]).ToLower().Trim() == objAddress.City.ToLower().Trim()))
                    {
                        isvalidationsuccess = true;
                    }
                }
            }
            if (isvalidationsuccess)
                jsonResponse = "{\"ResponseStatusCode\":\"1\"}";
            else
                jsonResponse = "{\"ResponseStatusCode\":\"0\"}";
            return jsonResponse;

        }
  
    }
}
