﻿using System.Net;
using System.IO;
using Newtonsoft.Json;
using System.Net.Http;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Mvc.Controllers;

namespace Geography.Framework.Attributes
{
    using Core.Enums;
    using ContentTypes;
    using Core.Entities.Dtos;
    using Microsoft.AspNetCore.Mvc;

    public class CustomerActionAttribute : ActionFilterAttribute
    {
        private readonly ILogger _logger;
        private static System.Diagnostics.Stopwatch stopwatch = new System.Diagnostics.Stopwatch();

        public CustomerActionAttribute(ILoggerFactory loggerFactory)
        {
            _logger = loggerFactory.CreateLogger("Geography.Framework.Attributes.CustomerActionAttribute");
        }

        private void LogStartTime(string methodName)
        {
            stopwatch.Reset();
            stopwatch.Start();
            _logger.LogInformation(stopwatch.Elapsed + " BEGINS Method: " + methodName);
        }

        private void LogEndTime(string methodName)
        {
            stopwatch.Stop();
            _logger.LogInformation(stopwatch.Elapsed + " ENDS Method: " + methodName);
        }

        public override void OnActionExecuting(ActionExecutingContext actionContext)
        {
            var controllerActionDescriptor = actionContext.ActionDescriptor as ControllerActionDescriptor;
            LogStartTime(controllerActionDescriptor.ActionName);
            //if (actionContext.HttpContext.Request.Method == "Post" || actionContext.HttpContext.Request.Method == "Get")
            //{
            var requestData = actionContext.ActionArguments;
            string requestJson = JsonConvert.SerializeObject(requestData, Formatting.Indented, new JsonSerializerSettings { ReferenceLoopHandling = ReferenceLoopHandling.Ignore });
            _logger.LogInformation(controllerActionDescriptor.ActionName + ": Json Request: " + requestJson);
            //}
        }

        public override void OnActionExecuted(ActionExecutedContext actionExecutedContext)
        {
            var controllerActionDescriptor = actionExecutedContext.ActionDescriptor as ControllerActionDescriptor;
            string methodName = controllerActionDescriptor.ActionName;

            if (actionExecutedContext.Exception == null)
            {
                if (actionExecutedContext.ModelState.IsValid)
                {
                    //var result = actionExecutedContext.ActionDescriptor.Parameters;
                    //JsonResponseDto responseDto = new JsonResponseDto()
                    //{
                    //    responseData = actionExecutedContext.Result,
                    //    //responseData = result.Model,
                    //    responseStatus = new ResponseStatus
                    //    {
                    //        status = ((int)HttpStatusCode.OK).ToString(),
                    //        message = "Success"
                    //    }
                    //};
                    //actionExecutedContext.Result = new JsonResult(responseDto);
                    //try
                    //{
                    //    string responseJson = JsonConvert.SerializeObject(responseDto, Formatting.Indented, new JsonSerializerSettings { PreserveReferencesHandling = PreserveReferencesHandling.Objects });
                    //    _logger.LogInformation(methodName + ": Json Response: " + responseJson);
                    //}
                    //catch { }
                }
                base.OnActionExecuted(actionExecutedContext);
                LogEndTime(methodName);
                actionExecutedContext.Canceled = true;
            }
        }
    }
}
