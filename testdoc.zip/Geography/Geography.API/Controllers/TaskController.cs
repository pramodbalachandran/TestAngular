﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.Extensions.Configuration;
using Bonsai.Azure.CosmosDb.Models;
using Geography.Core.Entities;
using Geography.Core.Entities.Dtos;
using Geography.Core.Services;
using Geography.Infrastructure.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace Geography.API.Controllers
{
    [AllowAnonymous]
    //[Route("api/[controller]")]
    public class TaskController : ResourceController<MyTaskDto, MyTask>
    {
        private readonly ITaskService _taskService;
        private readonly IE2KServices _e2kService;
        private readonly IMapper _mapper;
        IConfiguration _configuration;
        
        public TaskController(ITaskService service, IMapper mapper, IConfiguration configuration, IE2KServices e2k)
            : base(service, mapper)
        {
            _taskService = service;
            _mapper = mapper;
            _configuration = configuration;
            _e2kService = e2k;

        }

        public void CreateTasks()
        {
            _taskService.CreateTask();
        }

        [HttpPost]
        public object GetpoliticalDivision2NameDetails([FromBody] Country Country)
        {
            return _taskService.GetpoliticalDivision2NameDetails(Country.cityName);
        }

        [HttpGet]
        public object GetCurrencyDetailList()
        {
            return _taskService.GetCurrencyDetails();
        }

        [HttpPost]
        public object Getcountrylist([FromBody] Country Country)
        {
            string countryCode = Country == null ? null : Country.countryCode;
            string stateProvCode = Country == null ? null : Country.stateProvCode;
            return _taskService.Getcountrylist(countryCode, stateProvCode);
        }

        [HttpPost]
        public dynamic ValidateAddressDetails([FromBody] Address objAddress)
        {
            return _taskService.ValidateAddressDetails(objAddress);
        }
        [HttpPost]
        public dynamic FindFreightserviceType([FromBody] Freightservice objFreightservice)
        {
            return _e2kService.FindFreightserviceType(objFreightservice);
        }
        
        [HttpPost]
        public object Getairportdetailsforautopopulate([FromBody] Airportdetailsrequest Airportdetailsrequest)
        {
            return _taskService.Getairportdetailsforautopopulate(Airportdetailsrequest.businessPartyNumber);
        }
        [HttpPost]
        public object GetSelectedairportdetailsforautopopulate([FromBody] Airportdetailsrequest Airportdetailsrequest)
        {
            return _taskService.GetSelectedairportdetailsforautopopulate(Airportdetailsrequest.businessPartyNumber);
        }
    }
}
