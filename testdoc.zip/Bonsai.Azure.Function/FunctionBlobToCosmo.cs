using System.IO;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Azure.WebJobs.Host;
using Newtonsoft.Json;
using System;
using CsvHelper;
using System.Linq;
using Microsoft.Azure.Documents;
using Microsoft.Extensions.Logging;
using Microsoft.Azure.Documents.Client;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace Bonsai.Azure.Function
{
    public static class FunctionBlobToCosmo
    {
        //const string EndPoint = "https://bonsaiqa.documents.azure.com:443/";
        //const string Key = "cIQh64EbylahenGNbOtDQ1XOCB0flSuugZNDXKKPxaFvhtJLArtTOAfGvyO0pGEAW61lzSgnIbigzxPYONbhdQ==";
        const string EndPoint = "https://bonsaidev.documents.azure.com:443/";
        const string Key = "P4S1zbzDqq7SncLqpetVl8xFrgECyEw1g3teoLRqF0R0Xf0XKD38OWMeIhfIWpempl3MKApOtIagTHnAjHIklw==";
        //const string EndPoint = "https://bonsaiuat.documents.azure.com:443/";
        //const string Key = "3LvyLyi8vL8ih8WvHzL29JeSJoOVNTCou4w7N4jzbklBQXIfGSXh6aYnHdHPMdKv10iKEv0jogf5gNYYCJTY1A==";
        const string DbName = "Bonsai";
        const string CollectionName = "GFF";
        const int BatchSize = 1000;
        static string _spName;
        static string _partitionKey;
        static TraceWriter _log;

        [FunctionName("FunctionBlobToCosmo")]
        public static void Run([BlobTrigger("bonsaicontainer/{name}", Connection = "Connection")]Stream myBlob, string name, TraceWriter log)
        {
            try
            {
                _log = log;
                _log.Info("Processing the file: " + name);
                var jsonContent = ConvertToJSON(myBlob);
                if (jsonContent != null)
                {
                    _log.Info("Successfully converted the contents to JSON. Updating the Database..");
                }

                string spName = string.Empty;

                if (name.ToLower().Contains("PM_Cost_Routes_Info.csv"))
                {
                    _spName = "procPMInterfaceDataImport";
                    _partitionKey = "iafRouteSource";
                }
                else if (name.ToLower().Contains("location"))
                {
                    _spName = "procLocationbulkImport";
                    _partitionKey = "locationmapping";
                }
                else if (name.ToLower().Contains("currency"))
                {
                    _spName = "procCurrencyexchangedatabulkImport";
                    _partitionKey = "currency";
                }
                else
                {
                    return;
                }
                Task<object> result = ExecuteStoredProcedure(jsonContent);
            }
            catch(Exception ex)
            {
                _log.Info("Exception in Run method: " + ex);
            }
        }
        public class responseBulkImport 
        {
            public int deleted { get; set; }
            public bool continuation { get; set; }
        }
        private static async Task<object> ExecuteStoredProcedureDel()
        {
            bool continuation = false;
            DocumentClient client = new DocumentClient(new Uri(EndPoint), Key);
            do
            {
                responseBulkImport objresponseBulkImport = new responseBulkImport();
                objresponseBulkImport = await client.ExecuteStoredProcedureAsync<responseBulkImport>(UriFactory.CreateStoredProcedureUri(DbName, CollectionName, "procbulkDelete"), new RequestOptions { PartitionKey = new PartitionKey("iafRouteSource") }, "SELECT * FROM c where c.docType='iafRouteSource'");
                continuation = objresponseBulkImport.continuation;
                _log.Info($"deleted:{objresponseBulkImport.deleted}");
            } while (continuation);
            return null;
        }

        private static async Task<object> ExecuteStoredProcedure(object contents)
        {
            try
            {
                Task<StoredProcedureResponse<object>> sprocResponse = null;
                DocumentClient client = new DocumentClient(new Uri(EndPoint), Key);
                int startRecord = 0;
                int endRecord = BatchSize;
                List<object> listContents = (List<object>)contents;
                if (listContents.Count > BatchSize)
                {
                    while (startRecord < listContents.Count)
                    {
                        var batch = listContents.Skip(startRecord).Take(endRecord - startRecord);
                        startRecord = endRecord;
                        endRecord += (listContents.Count - endRecord) >= BatchSize ? BatchSize : listContents.Count - endRecord;
                        string jsonBatchString = JsonConvert.SerializeObject(batch);
                        var response = await client.ExecuteStoredProcedureAsync<object>(UriFactory.CreateStoredProcedureUri(DbName, CollectionName, _spName), new RequestOptions { PartitionKey = new PartitionKey(_partitionKey) }, jsonBatchString);
                        _log.Info($"Executed�Store�Procedure:�response:{response.Response}");
                    }
                }
                else
                {
                    string jsonString = JsonConvert.SerializeObject(listContents);
                    var response = await client.ExecuteStoredProcedureAsync<object>(UriFactory.CreateStoredProcedureUri(DbName, CollectionName, _spName), new RequestOptions { PartitionKey = new PartitionKey(_partitionKey) }, jsonString);
                    _log.Info($"Executed�Store�Procedure:�response:{response.Response}");
                }
                return sprocResponse;
            }
            catch(Exception ex)
            {
                _log.Info("Exception While Executing SP : " + _spName + "\n" + ex);
                return false;
            }
        }

        /// <summary>
        /// Converts the input stream to JSON
        /// </summary>
        /// <param name="myBlob">stream containing the contents of csv</param>
        /// <returns></returns>
        private static object ConvertToJSON(Stream myBlob)
        {
            try
            {
                StreamReader streamReader = new StreamReader(myBlob);
                CsvReader csvReader = new CsvReader(streamReader);

                bool isRecordBad = false;
                var csvRecords = new List<object>();
                var badRecords = new List<object>();
                csvReader.Configuration.BadDataFound = context =>
                {
                    isRecordBad = true;
                    badRecords.Add(context.RawRecord);
                };
                while (csvReader.Read())
                {
                    var record = csvReader.GetRecord<object>();
                    if (!isRecordBad)
                    {
                        csvRecords.Add(record);
                    }

                    isRecordBad = false;
                }

                return csvRecords;
            }
            catch (Exception ex)
            {
                _log.Info("Exception Occured in ConvertToJSON Method: "  + ex);
                return null;
            }
        }
    }
}
