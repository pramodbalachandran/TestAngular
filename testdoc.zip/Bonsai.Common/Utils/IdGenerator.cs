﻿using System;

namespace Bonsai.Common.Utils
{
    public static class IdGenerator
    {
        public static Guid GetGuid() => Guid.NewGuid();
    }
}
