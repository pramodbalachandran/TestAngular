﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Bonsai.Common.Utils
{
    public static class Extensions
    {
        public static Guid? ToGuid(this string guidString)
        {
            if (!string.IsNullOrEmpty(guidString) && Guid.TryParse(guidString, out Guid guid))
            {
                return guid;
            }

            return null;
        }

        public static string ToCsv(this IEnumerable<string> value)
        {
            if (value != null && value.Any())
            {
                return String.Join(",", value); 
            }

            return string.Empty;
        }
    }
}
