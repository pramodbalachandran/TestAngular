﻿using System;
using System.Collections.Generic;
using System.Text;
using AutoMapper;
using Miscellaneous.Core.Entities;
using Miscellaneous.Core.Entities.Dtos;

namespace Miscellaneous.Infrastructure.Maps
{
    public class TaskMaps : Profile
    {
        public TaskMaps()
        {
            CreateMap<MyTask, MyTaskDto>();
            CreateMap<MyTaskDto, MyTask>();
        }
    }
}
