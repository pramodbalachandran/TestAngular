﻿using System;
using System.IO;
using System.Text.RegularExpressions;

namespace Miscellaneous.Framework.Extensions
{

	public static class StringExtensions
	{
		public static bool Contains(this string s, string value, StringComparison comparison)
		{
			return s.IndexOf(value, comparison) > -1;
		}

		public static string RemoveInvalidFileNameCharacters(this string s)
		{
			var regexSearch = new string(Path.GetInvalidFileNameChars());
			var r = new Regex(string.Format("[{0}]", Regex.Escape(regexSearch)));
			return r.Replace(s, "");
		}

		public static string RemoveNonContentTypeCharacters(this string s)
		{
			var r = new Regex(@"[^A-Za-z0-9\/\-\+\.]");
			return r.Replace(s, "");
		}

		public static string RemovePunctuation(this string s)
		{
			var r = Regex.Replace(s, "\\p{P}+", "");
			return r;
		}
	}
}
