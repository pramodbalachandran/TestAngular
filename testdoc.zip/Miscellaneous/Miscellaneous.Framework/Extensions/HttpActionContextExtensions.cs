﻿using System;
using System.Linq;
using System.Net;
using System.Collections.Generic;
using System.Reflection;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc.Abstractions;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.Mvc.Controllers;
using Microsoft.Extensions.Primitives;

namespace Miscellaneous.Framework.Extensions
{
    using Extensions;
    using Helpers;
    using Core.Constants;
    using Core.Entities.Dtos;
    using Microsoft.AspNetCore.Mvc.Authorization;
    using Microsoft.AspNetCore.Mvc;

    public static class HttpActionContextExtensions
    {
        public static bool SkipAuthorization(this ActionExecutingContext actionContext)
        {
            if (actionContext == null)
            {
                throw new ArgumentNullException("actionContext");
            }
            //return actionContext.ActionDescriptor.GetCustomAttributes<AllowAnonymousAttribute>().Any();
            foreach (var filterDescriptors in actionContext.ActionDescriptor.FilterDescriptors)
            {
                if (filterDescriptors.Filter.GetType() == typeof(AllowAnonymousFilter))
                {
                    return true;
                }
            }
            return false;
        }

        public static IEnumerable<T> GetCustomAttributes<T>(this ActionDescriptor actionDescriptor) where T : Attribute
        {
            var controllerActionDescriptor = actionDescriptor as ControllerActionDescriptor;
            if (controllerActionDescriptor != null)
            {
                return controllerActionDescriptor.MethodInfo.GetCustomAttributes<T>();
            }
            return Enumerable.Empty<T>();
        }

        public static void HandleUnauthorizedRequest(this ActionExecutingContext actionContext)
        {
            JsonResponseDto responseDto = new JsonResponseDto()
            {
                responseData = Utils.GetMessage(PricingConsts.LogInToContinue),
                responseStatus = new ResponseStatus
                {
                    status = ((int)HttpStatusCode.Unauthorized).ToString(),
                    message = HttpStatusCode.Unauthorized.ToString()
                }
            };
            actionContext.Result = new JsonResult(responseDto);
        }

        public static void HandleForbiddenRequest(this ActionExecutingContext actionContext)
        {
            JsonResponseDto responseDto = new JsonResponseDto()
            {
                responseData = Utils.GetMessage(PricingConsts.AccessDenied),
                responseStatus = new ResponseStatus
                {
                    status = ((int)HttpStatusCode.Forbidden).ToString(),
                    message = HttpStatusCode.Forbidden.ToString()
                }
            };
            actionContext.Result = new JsonResult(responseDto);
        }

        public static string GetToken(this ActionExecutingContext actionContext, string tokenHeader)
        {
            return actionContext.HttpContext.Request.Headers.Keys.Contains(tokenHeader) ? 
                actionContext.HttpContext.Request.Headers[tokenHeader].ToString() : null;
        }

        public static int GetHeaderValueAsInt(this ActionExecutingContext actionContext, string key)
        {
            int res = 0;
            string value = actionContext.HttpContext.Request.Headers[key].ToString();
            if (string.IsNullOrWhiteSpace(value))
            {
                return res;
            }
            int.TryParse(value, out res);
            return res;
        }

        public static string GetAuthenticationHeaderValue(this ActionExecutingContext actionContext)
        {
            return actionContext.HttpContext.Request.Headers["Authorization"].ToString();
        }

        public static int GetQueryStringValueAsInt(this ActionExecutingContext actionContext, string key)
        {
            int res = 0;
            string value = actionContext.HttpContext.Request.Query[key];
            if (string.IsNullOrWhiteSpace(value))
            {
                return res;
            }
            int.TryParse(value, out res);
            return res;
        }
    }
}
