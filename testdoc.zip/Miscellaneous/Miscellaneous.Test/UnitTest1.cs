using System;
using Xunit;

namespace Miscellaneous.Test
{
    public class UnitTest1
    {
        [Fact]
        public void Test1()
        {

        }
    }
}
