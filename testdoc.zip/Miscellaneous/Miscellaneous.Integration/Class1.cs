﻿using System;

namespace Miscellaneous.Integration
{
    public class Class1
    {
    }
}
