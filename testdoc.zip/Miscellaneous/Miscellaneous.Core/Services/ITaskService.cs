﻿using System;
using System.Collections.Generic;
using System.Text;

using Miscellaneous.Core.Entities;

namespace Miscellaneous.Core.Services
{
    public interface ITaskService : IBaseService<MyTask>
    {

        void CreateTask();
    }
}
