﻿using System;
using System.Collections.Generic;
using System.Text;

using Miscellaneous.Core.Entities;

namespace Miscellaneous.Core.Repositories
{
    public interface ITaskRepository : ICoreRepository<MyTask>
    {

    }
}
