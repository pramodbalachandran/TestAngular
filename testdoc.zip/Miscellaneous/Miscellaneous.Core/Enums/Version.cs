﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Miscellaneous.Core.Enums
{
    public enum Version
    {
        V1 = 1
    }
}
