﻿using System;
using System.Reflection;
using System.Runtime.Serialization;
using System.Text;

namespace Miscellaneous.Core.Exceptions
{
	using Attributes;

	[Serializable]
	public class UniquenessViolationException : Exception
	{
		public UniquenessViolationException()
		{
			
		}

		public UniquenessViolationException(string message) : base(message)
		{
			
		}
		
		public UniquenessViolationException(string message, Exception inner)
			: base(message, inner)
		{

		}

		protected UniquenessViolationException(SerializationInfo info, StreamingContext context)
			: base(info, context)
		{

		}

		public  static UniquenessViolationException FromObject(dynamic obj)
		{
			var message = new StringBuilder();
			message.Append("An item with these fields already exists:\n");
			PropertyInfo[] properties = obj.GetType().GetProperties();
			foreach (var property in properties)
			{
				var uniqueness = property.GetCustomAttribute<UniquenessAttribute>();
				if (uniqueness == null || !uniqueness.UserVisible)
				{
					continue;
				}

				string propertyName = uniqueness.DisplayName;
				if (String.IsNullOrWhiteSpace(propertyName))
				{
					propertyName = property.Name;
				}
				message.AppendFormat("{0}\n", propertyName);
			}
			return new UniquenessViolationException(message.ToString());
		}
	}
}
