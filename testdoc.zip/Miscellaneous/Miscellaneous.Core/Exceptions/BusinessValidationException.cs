﻿using System;

namespace Miscellaneous.Core.Exceptions
{
    [Serializable]
    public class BusinessValidationException : ApplicationException
    {
        public string ExceptionKey { get; set; }
        public BusinessValidationException(string message) : base(message)
        {
            
        }
    }
}
