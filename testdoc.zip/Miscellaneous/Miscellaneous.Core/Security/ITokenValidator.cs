﻿using System.Security.Claims;

namespace Miscellaneous.Core.Security
{
	public interface ITokenValidator
	{
		//ClaimsPrincipal ValidateUser(string token, string email);
        ClaimsPrincipal ValidateUser(string email);
    }
}