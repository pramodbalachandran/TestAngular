﻿using System.Security.Claims;

namespace Miscellaneous.Core.Security
{
    using Entities;
 
    public class PricingPrincipal : ClaimsPrincipal
    {
        public PricingPrincipal(User currentUser)
        {
            CurrentUser = currentUser;
        }

        public User CurrentUser { get; private set; }
    }
}
