﻿using System;
using System.Collections.Generic;
using System.Text;
using Bonsai.Azure.CosmosDb.Models;

namespace Miscellaneous.Core.Entities.Abstract
{
    public interface IEntity : IModel
    {
        
    }
}
