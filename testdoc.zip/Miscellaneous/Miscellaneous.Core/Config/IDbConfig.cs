﻿namespace Miscellaneous.Core.Config
{
	public interface IDbConfig
	{
		string MiscConnectionString { get; }
        string DocumentDbEndpointUrl { get; }
        string DocumentDbPrimaryKey { get; }
        string CacheServerConnectionString { get; }
	}
}
