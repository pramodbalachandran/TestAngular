﻿using System;
using System.Collections.Generic;
using System.Text;

using Miscellaneous.Core.Entities.Abstract;
using Bonsai.Azure.CosmosDb;
using Microsoft.Azure.Documents;
using Microsoft.Extensions.Logging;

namespace Miscellaneous.Infrastructure.Data.Repositories
{
    public class Repository<T> : GenericRepository<T>, IRepository<T> where T : class, IEntity
    {
        //public Repository() : base(CustomerContext.DbConnectionString(), "Customer")
        //{

        //}

        //public Repository(IDocumentClient client, ILoggerFactory loggerFactory) : base(client, loggerFactory)
        //{

        //}

        public Repository(IDocumentClient client, ILoggerFactory loggerFactory) 
            : base(client, loggerFactory, "Customer", "external")
        {

        }

    }
}
