﻿using System;
using System.Collections.Generic;
using System.Text;
using Miscellaneous.Core.Entities.Abstract;
using Bonsai.Azure.CosmosDb.Abstract;

namespace Miscellaneous.Infrastructure.Data.Repositories
{
    public interface IRepository<T> : IBaseRepository<T> where T : IEntity
    { 

    }
}
