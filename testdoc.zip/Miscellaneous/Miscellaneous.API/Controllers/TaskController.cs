﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Miscellaneous.Core.Entities;
using Miscellaneous.Core.Entities.Dtos;
using Miscellaneous.Core.Services;
using Miscellaneous.Infrastructure.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace Miscellaneous.API.Controllers
{
    [AllowAnonymous]
    //[Route("api/[controller]")]
    public class TaskController : ResourceController<MyTaskDto, MyTask>
    {
        private readonly ITaskService _taskService;
        private readonly IMapper _mapper;

        public TaskController(ITaskService service, IMapper mapper)
            : base(service, mapper)
        {
            _taskService = service;
            _mapper = mapper;

        }

        public void CreateTasks()
        {
            _taskService.CreateTask();
        }
    }
}
