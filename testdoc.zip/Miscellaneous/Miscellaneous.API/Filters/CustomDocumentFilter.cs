﻿using Swashbuckle.AspNetCore.Swagger;
using Swashbuckle.AspNetCore.SwaggerGen;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using Microsoft.AspNetCore.Authorization;

namespace Miscellaneous.API.Filters
{
    public class CustomDocumentFilter : IDocumentFilter
    {

        public void Apply(SwaggerDocument swaggerDoc, DocumentFilterContext context)
        {
            var thisAssemblyTypes = Assembly.GetExecutingAssembly().GetTypes().ToList();

            //var controllers = thisAssemblyTypes.Where(t => t.IsSubclassOf(typeof(ResourceController<,>))).ToList();
            var controllers = thisAssemblyTypes.Where(t => t.BaseType.ToString().Contains("ResourceController")).ToList();

            if (!controllers.Any()) return;
            var reqMethods = new[] { "Get", "GetAll", "Add", "Update", "Delete" };
            foreach (var controller in controllers)
            {
                var methods = controller.GetMethods().Where(a => reqMethods.Contains(a.Name)).ToList();
                if (!methods.Any())
                    continue;
                foreach (var method in methods)
                {
                    var path = "/" + controller.Name.Replace("Controller", "", StringComparison.CurrentCulture) + "/Named/" + method.Name;
                    var pathItem = new PathItem();
                    var op = new Operation();
                    op.Tags = new List<string> { "Methods" };
                    op.OperationId = method.Name;
                    IList<IParameter> paramList = new List<IParameter>();
                    foreach (var parameter in method.GetParameters())
                    {
                        IParameter param = new BodyParameter();
                        param.Name = parameter.Name;
                        param.In = "body";
                        param.Required = true;
                        paramList.Add(param);

                    }
                    op.Parameters = paramList;
                    op.Summary = "method / data";
                    op.Description = "Here is where we go deep into the description and options for the call.";
                    op.Consumes = new List<string>();
                    op.Produces = new List<string> { "application/json" };
                    op.Deprecated = false;

                    var response = new Response() { Description = "OK" };
                    response.Schema = new Schema { Type = "array", Items = context.SchemaRegistry.GetOrRegister(method.ReturnType) };
                    op.Responses = new Dictionary<string, Response> { { "200", response } };

                    var security = GetSecurityForOperation(controller);
                    if (security != null)
                        op.Security = new List<IDictionary<string, IEnumerable<string>>> { security };

                    if (method.Name == "Add")
                        pathItem.Post = op;
                    else if (method.Name == "Update")
                        pathItem.Put = op;
                    else if (method.Name == "Delete" || method.Name == "Remove")
                        pathItem.Delete = op;
                    else if (method.Name == "Get")
                        pathItem.Post = op;
                    else
                        pathItem.Get = op;
                    swaggerDoc.Paths.Add(path, pathItem);
                }
            }
        }

        private Dictionary<string, IEnumerable<string>> GetSecurityForOperation(MemberInfo odataContoller)
        {
            Dictionary<string, IEnumerable<string>> securityEntries = null;
            if (odataContoller.GetCustomAttribute(typeof(AuthorizeAttribute)) != null)
            {
                securityEntries = new Dictionary<string, IEnumerable<string>> { { "oauth2", new[] { "actioncenter" } } };
            }
            return securityEntries;
        }

    }
}
