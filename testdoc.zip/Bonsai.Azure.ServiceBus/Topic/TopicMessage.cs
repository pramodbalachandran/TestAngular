﻿using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using System;
using System.Text;

namespace Bonsai.Azure.ServiceBus.Topic
{
    public partial class TopicMessage<T>
    {
        public TopicMessage(TopicMessageProperties messageProperties,
            TopicEvent topicEvent, T body)
        {
            this.MessageProperties = messageProperties;
            this.Event = topicEvent;
            this.Body = body;
        }

        /// <summary>
        /// Ignore this property when serializing to JSON
        /// </summary>
        [JsonIgnore]
        public TopicMessageProperties MessageProperties { get; set; }

        public TopicEvent Event { get; set; }

        /// <summary>
        /// Original request body as sent to API, with partyId added if was not present
        /// </summary>
        public T Body { get; set; }


        /// <summary>
        /// Serialize the notification message body (Event + Body) to JSON bytes
        /// </summary>
        /// <returns></returns>
        public byte[] ToJsonBytes()
        {
            if (this.Event != null || this.Body != null)
            {
                var serializerSettings = new JsonSerializerSettings { ContractResolver = new CamelCasePropertyNamesContractResolver() };
                var json = JsonConvert.SerializeObject(this, serializerSettings);
                return Encoding.UTF8.GetBytes(json); 
            }

            return Array.Empty<byte>();
        }

    }
}
