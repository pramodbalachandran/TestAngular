﻿using System;
using System.ComponentModel.DataAnnotations;
using Newtonsoft.Json;
using Bonsai.Common.Utils;

namespace Bonsai.Azure.ServiceBus.Topic
{
    public partial class TopicEvent
    {
        /// <summary>
        /// Construct with the default values
        /// </summary>
        public TopicEvent()
        {
            this.EventId = IdGenerator.GetGuid();
            this.EventType = "notification";
            this.TimeOccurred = DateTime.UtcNow;
            this.Producer = "Bonsai";
            this.ProducerType = ProducerType.system;
        }

        /// <summary>
        /// The system maintained unique identifier for a Event
        /// </summary>
        /// <value>The system maintained unique identifier for a Event</value>
        [Required]
        public Guid EventId { get; set; }

        /// <summary>
        /// The specific type of event type being notification/information
        /// </summary>
        /// <value>The specific type of event type being notification/information</value>
        [Required]
        public string EventType { get; set; }

        /// <summary>
        /// the date and time the event happened
        /// </summary>
        /// <value>the date and time the event happened</value>
        [Required]
        public DateTime TimeOccurred { get; set; }

        /// <summary>
        /// the producer of the event
        /// </summary>
        /// <value>the producer of the event</value>
        public string Producer { get; set; }

        /// <summary>
        /// The specific type of procedure type being notification/customer/colleague/channel/other
        /// </summary>
        /// <value>The specific type of procedure type being notification/customer/colleague/channel/other</value>
        public ProducerType ProducerType { get; set; }


        /// <summary>
        /// Returns the JSON string presentation of the object
        /// </summary>
        /// <returns>JSON string presentation of the object</returns>
        public string ToJson()
        {
            return JsonConvert.SerializeObject(this, Formatting.Indented);
        }
    }

    public enum ProducerType
    {
        customer,
        quotes,
        pricing,
        geography,
        miscellaneous,
        system
    };
}
