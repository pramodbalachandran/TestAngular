﻿using System;
using System.Collections.Generic;
using Bonsai.Common.Utils;

namespace Bonsai.Azure.ServiceBus.Topic
{
    /// <summary>
    /// message properties for a Azure service bus topic message
    /// </summary>
    public class TopicMessageProperties
    {
        /// <summary>
        /// list of properties
        /// </summary>
        public IEnumerable<string> MessageProperties { get; set; }
        public Operation Operation { get; set; }

        /// <summary>
        /// The GUID of the object to which the message relates. 
        /// </summary>
        public Guid Id { get; set; }
        public MessageType MessageType { get; set; }

        /// <summary>
        /// Relates to the version of the API initiating the message. "2.0"
        /// </summary>
        public string Version { get; set; }

        public TopicMessageProperties()
        {

        }

        public TopicMessageProperties(
            IEnumerable<string> messageProperties, Operation operation, 
            Guid id, MessageType messageType, string version = "2.0")
        {
            this.MessageProperties = messageProperties;
            this.Operation = operation;
            this.Id = id;
            this.MessageType = messageType;
            this.Version = version;
        }

        public Dictionary<string, object> GetMessageProperties()
        {
            return new Dictionary<string, object>
            {
                {"messageproperties", this.MessageProperties.ToCsv() },
                {"operation", this.Operation },
                {"id", this.Id },
                {"messagetype", this.MessageType },
                {"version", this.Version },
            };
        }
    }

    public enum Operation
    {
        Create,
        Update,
        Delete
    };

    public enum MessageType
    {
        customer,
        quotes,
        pricing,
        geography,
        miscellaneous,
        system
    };

}
