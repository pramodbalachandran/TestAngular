﻿using System.Linq;
using System.Threading.Tasks;
using Microsoft.Azure.ServiceBus;

namespace Bonsai.Azure.ServiceBus.Topic
{
    public class TopicSender : ITopicSender
    {
        private static ITopicClient _topicClient;

        public TopicSender(string azureServiceBusConnection, string topicName)
        {
            _topicClient = new TopicClient(azureServiceBusConnection, topicName, RetryPolicy.Default);
        }

        public async Task<bool> SendToServiceBusTopic<T>(TopicMessage<T> message)
        {
            var topicMessage = new Message
            {
                Body = message.ToJsonBytes()
            };

            // Add user properties to the message if any
            var userProperties = message.MessageProperties.GetMessageProperties();
            if(message.MessageProperties?.GetMessageProperties()?.Any() == true)
            {
                foreach (var property in userProperties)
                {
                    topicMessage.UserProperties.Add(property.Key, property.Value);
                }
            }
            
            await _topicClient.SendAsync(topicMessage);

            return true;
        }
    }
}
