﻿using System.Threading.Tasks;

namespace Bonsai.Azure.ServiceBus.Topic
{
    public interface ITopicSender
    {
        Task<bool> SendToServiceBusTopic<T>(TopicMessage<T> topicMessage);
    }
}
