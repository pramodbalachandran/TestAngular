﻿using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using System;
using System.Text;

namespace Bonsai.Azure.ServiceBus.Queue
{
    public partial class QueueMessage<T>
    {
        public QueueMessage(QueueMessageProperties messageProperties,
            QueueEvent queueEvent, T body)
        {
            this.MessageProperties = messageProperties;
            this.Event = queueEvent;
            this.Body = body;
        }

        /// <summary>
        /// Ignore this property when serializing to JSON
        /// </summary>
        [JsonIgnore]
        public QueueMessageProperties MessageProperties { get; set; }

        public QueueEvent Event { get; set; }

        /// <summary>
        /// Original request body as sent to API
        /// </summary>
        public T Body { get; set; }


        /// <summary>
        /// Serialize the notification message body (Event + Body) to JSON bytes
        /// </summary>
        /// <returns></returns>
        public byte[] ToJsonBytes()
        {
            if (this.Event != null || this.Body != null)
            {
                var serializerSettings = new JsonSerializerSettings { ContractResolver = new CamelCasePropertyNamesContractResolver() };
                var json = JsonConvert.SerializeObject(this, serializerSettings);
                return Encoding.UTF8.GetBytes(json); 
            }

            return Array.Empty<byte>();
        }

    }
}
