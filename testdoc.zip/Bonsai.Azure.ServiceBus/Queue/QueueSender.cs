﻿using System.Linq;
using System.Threading.Tasks;
using Microsoft.Azure.ServiceBus;

namespace Bonsai.Azure.ServiceBus.Queue
{
    public class QueueSender : IQueueSender
    {
        private static IQueueClient _queueClient;

        public QueueSender(string azureServiceBusConnection, string queueName)
        {
            _queueClient = new QueueClient(azureServiceBusConnection, queueName);
        }

        public async Task<bool> SendToServiceBusQueue<T>(QueueMessage<T> message)
        {
            var queueMessage = new Message
            {
                Body = message.ToJsonBytes()
            };

            // Add user properties to the message if any
            var userProperties = message.MessageProperties.GetMessageProperties();
            if(message.MessageProperties?.GetMessageProperties()?.Any() == true)
            {
                foreach (var property in userProperties)
                {
                    queueMessage.UserProperties.Add(property.Key, property.Value);
                }
            }
            
            await _queueClient.SendAsync(queueMessage);

            return true;
        }
    }
}
