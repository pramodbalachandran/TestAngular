﻿using System.Threading.Tasks;

namespace Bonsai.Azure.ServiceBus.Queue
{
    public interface IQueueSender
    {
        Task<bool> SendToServiceBusQueue<T>(QueueMessage<T> queueMessage);
    }
}
