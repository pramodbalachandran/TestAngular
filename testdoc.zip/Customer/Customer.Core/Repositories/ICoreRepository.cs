﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;

using Customer.Core.Entities.Abstract;

namespace Customer.Core.Repositories
{
	public interface ICoreRepository<T> where T : IEntity
	{
		T GetById(int id);
        IQueryable<T> GetAll();
		IQueryable<T> GetByIds(List<int> ids);
		IQueryable<T> GetByValues(List<string> values, string propertyName);
		IQueryable<T> Query(Expression<Func<T, bool>> filter);
		void Add(T entity);
		void Update(T entity);
		void Remove(T entity);
		void RemoveAll(ICollection<T> entities);
	}
}
