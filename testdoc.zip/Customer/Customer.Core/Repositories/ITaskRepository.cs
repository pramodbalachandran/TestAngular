﻿using System;
using System.Collections.Generic;
using System.Text;

using Customer.Core.Entities;

namespace Customer.Core.Repositories
{
    public interface ITaskRepository : ICoreRepository<MyTask>
    {

    }
}
