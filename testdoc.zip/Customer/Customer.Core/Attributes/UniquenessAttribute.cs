﻿namespace Customer.Core.Attributes
{
	using System;

	public class UniquenessAttribute : Attribute
	{
		public bool UserVisible { get; set; }
		public string DisplayName { get; set; }

		public UniquenessAttribute()
		{
			UserVisible = true;
			DisplayName = String.Empty;
		}

		public UniquenessAttribute(bool userVisible = true)
		{
			UserVisible = userVisible;
			DisplayName = String.Empty;
		}

		public UniquenessAttribute(string displayName = "")
		{
			UserVisible = true;
			DisplayName = displayName;
		}

		public UniquenessAttribute(string displayName = "", bool userVisible = true)
		{
			DisplayName = displayName;
			UserVisible = userVisible;
		}
	}
}
