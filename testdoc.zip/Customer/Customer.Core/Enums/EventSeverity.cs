﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Customer.Core.Enums
{
    public enum EventSeverity
    {
        None = 0,
        Trace,
        Debug,
        Info,
        Warning,
        Error,
        Fatal
    }
}
