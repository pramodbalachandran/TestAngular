﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Customer.Core.Enums
{
    public enum Version
    {
        V1 = 1
    }
}
