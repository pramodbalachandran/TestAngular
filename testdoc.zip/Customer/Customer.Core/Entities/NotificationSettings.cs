﻿using Customer.Core.Entities.Abstract;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Customer.Core.Entities
{
    public class NotificationSettings 
    {
        [JsonProperty(PropertyName = "emailQuoteStatusExpiring")]
        public bool QuoteStatusExpiringRequiredEmailIndicator { get; set; }

        [JsonProperty(PropertyName = "emailQuoteRespondByUSP")]
        public bool QuoteRespondByUPSRequiredEmailIndicator { get; set; }

        [JsonProperty(PropertyName = "emailPickupRequest")]
        public bool PickupRequestRequiredEmailIndicator { get; set; }

        [JsonProperty(PropertyName = "emailPreApprovedRate")]
        public bool PreApprovedRateRequiredEmailIndicator { get; set; }

        [JsonProperty(PropertyName = "emailResetPassword")]
        public bool ResetPasswordRequiredEmailIndicator { get; set; }
    }
}
