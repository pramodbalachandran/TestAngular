﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Customer.Core.Entities
{
    public class EmailRequest
    {
        [JsonProperty(PropertyName = "message")]
        public MessageDetails Message { get; set; }

        [JsonProperty(PropertyName = "saveToSentItems")]
        public bool SaveToSentItems { get; set; }
    }

    public class MessageDetails
    {
        [JsonProperty(PropertyName = "subject")]
        public string Subject { get; set; }

        [JsonProperty(PropertyName = "body")]
        public MessageBody Body { get; set; }

        [JsonProperty(PropertyName = "toRecipients")]
        public List<ToRecipients> ToRecipients { get; set; }

        [JsonProperty(PropertyName = "internetMessageHeaders")]
        public List<InternetMessageHeaders> IntMessageHeaders { get; set; }
    }

    public class MessageBody
    {
        [JsonProperty(PropertyName = "contentType")]
        public string ContentType { get; set; }

        [JsonProperty(PropertyName = "content")]
        public string Content { get; set; }
    }

    public class ToRecipients
    {
        [JsonProperty(PropertyName = "emailAddress")]
        public EmailAddress EmailAddress { get; set; }
    }

    public class EmailAddress
    {
        [JsonProperty(PropertyName = "address")]
        public string Address { get; set; }
    }

    public class InternetMessageHeaders
    {
        [JsonProperty(PropertyName = "name")]
        public string Name { get; set; }

        [JsonProperty(PropertyName = "value")]
        public string Value { get; set; }
    }


}
