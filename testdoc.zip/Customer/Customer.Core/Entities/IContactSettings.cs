﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Customer.Core.Entities
{
    public interface IContactSettings
    {
        bool DoShowEditContactForm { get; set; }
        string PhoneNo { get; set; }
        string ContactName { get; set; }
        string EmailAddress { get; set; }
        string UserId { get; set; }
        string LastUsedDate { get; set; }
    }
}
