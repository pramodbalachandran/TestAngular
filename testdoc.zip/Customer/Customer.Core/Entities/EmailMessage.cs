﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Customer.Core.Entities
{
    public class EmailMessage
    {
        /// <summary>
        /// To email address
        /// </summary>
        [JsonProperty(PropertyName = "ToAddress")]
        public List<string> ToAddress { get; set; }

        /// <summary>
        /// From email address
        /// </summary>
        [JsonProperty(PropertyName = "FromAddress")]
        public string FromAddress { get; set; }

        /// <summary>
        /// Message subject 
        /// </summary>
        [JsonProperty(PropertyName = "MsgSubject")]
        public string MsgSubject { get; set; }

        /// <summary>
        /// Message body 
        /// </summary>
        [JsonProperty(PropertyName = "MsgBody")]
        public string MsgBody { get; set; }
    }
}
