﻿namespace Customer.Core.Entities
{
    public interface IQuoteDetails
    {
        string UserId { get; set; }

        string QuoteNumber { get; set; }
        string QuoteInitiatedDate { get; set; }
        float QuotePrice { get; set; }
        string CustomerName { get; set; }
        string QuoteStatus { get; set; }
    }
}
