﻿using Customer.Core.Entities.Abstract;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Customer.Core.Entities
{
    public class ShipingAddress : IEntity
    {
        [JsonProperty(PropertyName = "id")]
        public Guid? Id { get; set; }

        public string PartitionKey { get; set; }

        [JsonProperty(PropertyName = "UserId")]
        public string UserId { get; set; }
        [JsonProperty(PropertyName = "addressLine1")]
        public string AddressLine1 { get; set; }

        [JsonProperty(PropertyName = "addressLine2")]
        public string AddressLine2 { get; set; }

        [JsonProperty(PropertyName = "addressLine3")]
        public string AddressLine3 { get; set; }

        [JsonProperty(PropertyName = "addressLine4")]
        public string AddressLine4 { get; set; }

        [JsonProperty(PropertyName = "politicalDivision2Name")]
        public string PoliticalDivision2Name { get; set; }

        [JsonProperty(PropertyName = "politicalDivision1Code")]
        public string PoliticalDivision1Code { get; set; }

        [JsonProperty(PropertyName = "politicalDivision1Name")]
        public string PoliticalDivision1Name { get; set; }

        [JsonProperty(PropertyName = "postalCode")]
        public string PostalCode { get; set; }

        [JsonProperty(PropertyName = "countryCode")]
        public string CountryCode { get; set; }

        [JsonProperty(PropertyName = "countryName")]
        public string CountryName { get; set; }

        [JsonProperty(PropertyName = "DoShowEditShippingForm")]
        public bool DoShowEditShippingForm { get; set; }


        public string lastContinuationToken { get; set; }

        ////Last visited date time
        //[JsonProperty(PropertyName = "lastVisitedDate")]
        //public DateTime? LastVisitedDate { get; set; }
    }

    public class BillingAdress 
    {
        [JsonProperty(PropertyName = "contactName")]
        public string ContactName { get; set; }

        [JsonProperty(PropertyName = "addressLine1")]
        public string AddressLine1 { get; set; }

        [JsonProperty(PropertyName = "addressLine2")]
        public string AddressLine2 { get; set; }

        [JsonProperty(PropertyName = "addressLine3")]
        public string AddressLine3 { get; set; }

        [JsonProperty(PropertyName = "addressLine4")]
        public string AddressLine4 { get; set; }

        [JsonProperty(PropertyName = "politicalDivision2Name")]
        public string PoliticalDivision2Name { get; set; }

        [JsonProperty(PropertyName = "politicalDivision1Code")]
        public string PoliticalDivision1Code { get; set; }

        [JsonProperty(PropertyName = "politicalDivision1Name")]
        public string PoliticalDivision1Name { get; set; }

        [JsonProperty(PropertyName = "postalCode")]
        public string PostalCode { get; set; }

        [JsonProperty(PropertyName = "countryCode")]
        public string CountryCode { get; set; }

        [JsonProperty(PropertyName = "countryName")]
        public string CountryName { get; set; }

    }

    public class ContactDetails
    {
        [JsonProperty(PropertyName = "contactName")]
        public string ContactName { get; set; }

        [JsonProperty(PropertyName = "emailAddress")]
        public string EmailAddress { get; set; }

        [JsonProperty(PropertyName = "phoneNumber")]
        public string PhoneNumber { get; set; }


        [JsonProperty(PropertyName = "DoShowEditContactForm")]
        public bool DoShowEditContactForm { get; set; }
        /// <summary>
        /// Last visited date time
        /// </summary>
        [JsonProperty(PropertyName = "lastUsedDate")]
        public DateTime? LastVisitedDate { get; set; }


    }
}
