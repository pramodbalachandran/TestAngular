﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Customer.Core.Entities
{
    public class BlockUserRequest
    {
        /// <summary>
        /// User name 
        /// </summary>
        [JsonProperty(PropertyName = "UserName")]
        public string UserId { get; set; }

        [JsonProperty(PropertyName = "SetAccountState")]
        public bool AccountState { get; set; }
    }
}
