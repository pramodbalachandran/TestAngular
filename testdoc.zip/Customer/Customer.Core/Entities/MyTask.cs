﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using Customer.Core.Entities.Abstract;
using Newtonsoft.Json;

namespace Customer.Core.Entities
{
    public class MyTask : IEntity
    {
        [JsonProperty(PropertyName = "id")]
        public Guid? Id { get; set; }

        public string PartitionKey { get; set; }


        //public string[] ItemType { get; }
        [JsonProperty(PropertyName = "Version")]
        public int Version { get; set; }

        [JsonProperty(PropertyName = "Name")]
        public string Name { get; set; }

        [JsonProperty(PropertyName = "Category")]
        public string Category { get; set; }

        [JsonProperty(PropertyName = "Date")]
        public DateTime Date { get; set; }

        [JsonProperty(PropertyName = "CreatedDate")]
        public DateTime CreatedDate { get; set; }

        public string lastContinuationToken { get; set; }

    }
}