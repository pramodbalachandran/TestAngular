﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Customer.Core.Entities
{
    using Abstract;
    using Newtonsoft.Json;

    public class UserAccountSetting :IEntity
    {
        [JsonProperty(PropertyName = "id")]
        public Guid? Id { get; set; }

        public string PartitionKey { get; set; }

        [JsonProperty(PropertyName = "Version")]
        public int Version { get; set; }

        [JsonProperty(PropertyName = "UserId")]
        public int UserId { get; set; }

        [JsonProperty(PropertyName = "RoleId")]
        public int RoleId { get; set; }

        [JsonProperty(PropertyName = "CMVLicense")]
        public string CMVLicense { get; set; }

        [JsonProperty(PropertyName = "ExceptionTypeId")]
        public int? ExceptionTypeId { get; set; }

        [JsonProperty(PropertyName = "DrivingCategory")]
        public string DrivingCategory { get; set; }

        [JsonProperty(PropertyName = "IsTeamDriver")]
        public bool? IsTeamDriver { get; set; }

        [JsonProperty(PropertyName = "StatusId")]
        public int StatusId { get; set; }

        [JsonProperty(PropertyName = "CreatedBy")]
        public int? CreatedBy { get; set; }

        [JsonProperty(PropertyName = "CreatedOn")]
        public DateTime CreatedOn { get; set; }

        [JsonProperty(PropertyName = "ModifiedBy")]
        public int? ModifiedBy { get; set; }

        [JsonProperty(PropertyName = "ModifiedOn")]
        public DateTime? ModifiedOn { get; set; }

        [JsonProperty(PropertyName = "IsDelete")]
        public bool IsDelete { get; set; }

        [JsonProperty(PropertyName = "StateIssued")]
        public string StateIssued { get; set; }

        [JsonProperty(PropertyName = "VehicleTypeId")]
        public int? VehicleTypeId { get; set; }

        [JsonProperty(PropertyName = "CreatedByWebAdminTool")]
        public bool CreatedByWebAdminTool { get; set; }

        [JsonProperty(PropertyName = "Is100AirMileRadiusExceptionEnabled")]
        public int? Is100AirMileRadiusExceptionEnabled { get; set; }

        [JsonProperty(PropertyName = "ExceptionType")]
        public string ExceptionType { get; set; }

        [JsonProperty(PropertyName = "IsLicenseAccepted")]
        public bool? IsLicenseAccepted { get; set; }

        [JsonProperty(PropertyName = "LicenseAcceptedDate")]
        public DateTime? LicenseAcceptedDate { get; set; }

        [JsonProperty(PropertyName = "ExemptionReason")]
        public string ExemptionReason { get; set; }

        [JsonProperty(PropertyName = "User")]
        public User User { get; set; }
        public string lastContinuationToken { get; set; }
    }
}
