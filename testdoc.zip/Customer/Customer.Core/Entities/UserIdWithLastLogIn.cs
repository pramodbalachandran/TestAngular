﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Customer.Core.Entities
{
    public class UserIdWithLastLogIn
    {
        [JsonProperty(PropertyName = "UserId")]
        public string UserId;

        [JsonProperty(PropertyName = "LastLoginOn")]
        public string LastLoginOn;
    }
}
