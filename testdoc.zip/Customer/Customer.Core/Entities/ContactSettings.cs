﻿using Customer.Core.Entities.Abstract;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Customer.Core.Entities
{
    public class ContactSettings : IContactSettings, IEntity
    {
        [JsonProperty(PropertyName = "id")]
        public Guid? Id { get; set; }

        public string PartitionKey { get; set; }

        [JsonProperty(PropertyName = "DoShowEditContactForm")]
        public bool DoShowEditContactForm { get; set; }

        [JsonProperty(PropertyName = "PhoneNo")]
        public string PhoneNo { get; set; }

        [JsonProperty(PropertyName = "ContactName")]
        public string ContactName { get; set; }

        [JsonProperty(PropertyName = "EmailAddress")]
        public string EmailAddress { get; set; }

        [JsonProperty(PropertyName = "UserId")]
        public string UserId { get; set; }

        [JsonProperty(PropertyName = "LastUsedDate")]
        public string LastUsedDate { get; set; }

        public string lastContinuationToken { get; set; }

    }
}
