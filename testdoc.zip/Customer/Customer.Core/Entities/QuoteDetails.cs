﻿using Bonsai.Azure.CosmosDb.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Customer.Core.Entities
{
    public class QuoteDetails : IModel
    {
        [JsonProperty(PropertyName = "UserId")]
        public string UserId { get; set; }

        [JsonProperty(PropertyName = "id")]
        public Guid? Id { get; set; }

        [JsonProperty(PropertyName = "QuotePrice")]
        public float QuotePrice { get; set; }

        [JsonProperty(PropertyName = "CustomerName")]
        public string CustomerName { get; set; }

        [JsonProperty(PropertyName = "QuoteStatus")]
        public string QuoteStatus { get; set; }

        [JsonProperty(PropertyName = "QuoteNumber")]
        public string QuoteNumber { get; set; }

        [JsonProperty(PropertyName = "QuoteInitiatedDate")]
        public string QuoteInitiatedDate { get; set; }
        public string PartitionKey { get; set; }

        public string lastContinuationToken { get; set; }
    }
}
