﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Customer.Core.Entities
{
    public class VerifyEmail
    {
        [JsonProperty(PropertyName = "EmailId")]
        public string EmailId { get; set; }

        [JsonProperty(PropertyName = "DisplayName")]
        public string DisplayName { get; set; }

        [JsonProperty(PropertyName = "Username")]
        public string Username { get; set; }

        [JsonProperty(PropertyName = "VerificationCode")]
        public string VerificationCode { get; set; }

    }
}
