﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Customer.Core.Entities
{
    public class RequestUserSignUp
    {
        [JsonProperty(PropertyName = "accountEnabled")]
        public string AccountEnabled { get; set; }

        [JsonProperty(PropertyName = "creationType")]
        public string CreationType { get; set; }

        [JsonProperty(PropertyName = "displayName")]
        public string DisplayName { get; set; }

        [JsonProperty(PropertyName = "passwordProfile")]
        public PasswordProfile PasswordProfile { get; set; }

        [JsonProperty(PropertyName = "otherMails")]
        public List<string> otherMails { get; set; }

        [JsonProperty(PropertyName = "signInNames")]
        public List<SignInNames> SignInNames { get; set; }

        [JsonProperty(PropertyName = "country")]
        public string Country { get; set; }

        [JsonProperty(PropertyName = "employeeId")]
        public string employeeId { get; set; }
    }

    public class PasswordProfile
    {
        [JsonProperty(PropertyName = "password")]
        public string Password { get; set; }

        [JsonProperty(PropertyName = "forceChangePasswordNextLogin")]
        public string ForceChangePasswordNextLogin { get; set; }        
    }

    public class ResetPasswordRequest
    {
        [JsonProperty(PropertyName = "passwordProfile")]
        public PasswordProfile PasswordProfile { get; set; }
    }

    public class SignInNames
    {
        [JsonProperty(PropertyName = "type")]
        public string type { get; set; }

        [JsonProperty(PropertyName = "value")]
        public string Value { get; set; }
    }
}
