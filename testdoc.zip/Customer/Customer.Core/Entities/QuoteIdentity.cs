﻿using Newtonsoft.Json;
using Customer.Core.Entities.Abstract;
using System;

namespace Customer.Core.Entities
{
    public class QuoteIdentity : IEntity
    {
        [JsonProperty(PropertyName = "id")]
        public Guid? Id { get; set; }

        public string PartitionKey  { get; set; }

        public string lastContinuationToken { get; set; }
    }
}
