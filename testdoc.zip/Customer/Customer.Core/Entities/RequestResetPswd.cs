﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Customer.Core.Entities
{
    public class RequestResetPswd
    {
        [JsonProperty(PropertyName = "UserName")]
        public string UserId { get; set; }

        [JsonProperty(PropertyName = "SCode")]
        public string SecureCode { get; set; }

        [JsonProperty(PropertyName = "NewPswd")]
        public string NewPassword { get; set; }
    }
}
