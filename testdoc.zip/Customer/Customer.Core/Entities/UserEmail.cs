﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Customer.Core.Entities
{
    public class UserEmail
    {
        [JsonProperty(PropertyName = "EmailId")]
        public string EmailId { get; set; }
    }

    public class CustId
    {
        [JsonProperty(PropertyName = "customerId")]
        public string CustomerId { get; set; }
    }

    public class UserSecureOTP
    {
        [JsonProperty(PropertyName = "extension_d860aa645e344dcab1faa983cedbdc33_UserSecureOTP")]
        public string UserSecureCode { get; set; }
    }

    public class FailedAttempted
    {
        [JsonProperty(PropertyName = "extension_d860aa645e344dcab1faa983cedbdc33_FailedAttempted")]
        public int failAttempted { get; set; }
    }

    public class UserEmaiAndId
    {
        [JsonProperty(PropertyName = "EmailId")]
        public string EmailId { get; set; }

        [JsonProperty(PropertyName = "UserId")]
        public string UserId { get; set; }
    }

    public class UpdateDisplayNameRequest
    {
        [JsonProperty(PropertyName = "DisplayName")]
        public string DisplayName { get; set; }

        [JsonProperty(PropertyName = "EmailAddress")]
        public string EmailAddress { get; set; }

        [JsonProperty(PropertyName = "UserId")]
        public string UserId { get; set; }
    }

    public class DisplayNameRequest
    {
        [JsonProperty(PropertyName = "displayName")]
        public string DisplayName { get; set; }

        [JsonProperty(PropertyName = "extension_d860aa645e344dcab1faa983cedbdc33_emailAddress")]
        public string EmailAddress { get; set; }
    }
}
