﻿using Bonsai.Azure.CosmosDb.Models;
using Newtonsoft.Json;
//using Quotes.Core.Entities.Abstract;
using System;
using System.Collections.Generic;
using System.Text;

namespace Customer.Core.Entities
{
    /// <summary>
    /// Quote detail entity
    /// </summary>
    public class QuoteDetail : IModel
    {
        [JsonProperty(PropertyName = "id")]
        public Guid? Id { get; set; }
        /// <summary>
        /// Shipment setvice type e.g.- Ocean Freight/ International Air Freight / North America Air Freight
        /// </summary>
        [JsonProperty(PropertyName = "ShipmentServiceType")]
        public string ShipmentServiceType { get; set; }

        [JsonProperty(PropertyName = "UserId")]
        public string UserId { get; set; }

        /// <summary>
        /// Shipment Frequency Type - one time / multiple time
        /// </summary>
        [JsonProperty(PropertyName = "ShipmentFrequencyType")]
        public string ShipmentFrequencyType { get; set; }

        [JsonProperty(PropertyName = "QuoteNumber")]
        public string QuoteNumber { get; set; }

        [JsonProperty(PropertyName = "QuoteStatus")]
        public string QuoteStatus { get; set; }

        [JsonProperty(PropertyName = "QuoteInitiatedDate")]
        public string QuoteInitiatedDate { get; set; }


        [JsonProperty(PropertyName = "Status")]
        public string Status { get; set; }

        [JsonProperty(PropertyName = "CurrentPageState")]
        public string CurrentPageState { get; set; }

        /// <summary>
        /// Shipment Type - Airport to A / Door to Airport / A to D / D to D
        /// </summary>
        [JsonProperty(PropertyName = "ShipmentType")]
        public string ShipmentType { get; set; }

        public string PartitionKey { get; set; }

        [JsonProperty(PropertyName = "ShipingA2ADetail")]
        public A2ADetail ShipingA2ADetail { get; set; }

        [JsonProperty(PropertyName = "ShipingD2ADetail")]
        public D2ADetail ShipingD2ADetail { get; set; }

        [JsonProperty(PropertyName = "AboutShipment")]
        public AboutShipment AboutShipment { get; set; }


        [JsonProperty(PropertyName = "ShipmentDate")]
        public AboutShipment ShipmentDate { get; set; }

        [JsonProperty(PropertyName = "CommodityCharacteristics")]
        public CommodityCharacteristics CommodityCharacteristics { get; set; }

        [JsonProperty(PropertyName = "shipmentCommodity")]
        public Commodity shipmentCommodity { get; set; }

        public string lastContinuationToken { get; set; }
    }

    /// <summary>
    /// Airport to airport
    /// </summary>
    public class A2ADetail
    {
        [JsonProperty(PropertyName = "OriginCityAirport")]
        public string OriginCityAirport { get; set; }

        [JsonProperty(PropertyName = "DestinationCityAirport")]
        public string DestinationCityAirport { get; set; }
    }

    public class D2ADetail
    {
        [JsonProperty(PropertyName = "DestinationCityAirport")]
        public string DestinationCityAirport { get; set; }

        [JsonProperty(PropertyName = "OriginShippingAddress")]
        public ShipingAddress OriginShippingAddress { get; set; }
    }

    public class A2DDetail
    {
        /// TBD
    }

    public class D2DDetail
    {
        /// TBD
    }

    public class AboutShipment
    {
        [JsonProperty(PropertyName = "PreferUnitsOfMeasurement")]
        public string PreferUnitsOfMeasurement { get; set; }

        [JsonProperty(PropertyName = "ShipmentWeightTotalOrWeightByPiece")]
        public string ShipmentWeightTotalOrWeightByPiece { get; set; }

        [JsonProperty(PropertyName = "ShipmentTotalWeight")]
        public float ShipmentTotalWeight { get; set; }

        [JsonProperty(PropertyName = "ShipmentPieceDetails")]
        public List<ShipmentPieceDetails> ShipmentPieceDetails { get; set; }
    }

    public class ShipmentPieceDetails
    {
        [JsonProperty(PropertyName = "PackageType")]
        public string PackageType { get; set; }

        [JsonProperty(PropertyName = "Quantity")]
        public int Quantity { get; set; }

        [JsonProperty(PropertyName = "Length")]
        public float Length { get; set; }

        [JsonProperty(PropertyName = "Width")]
        public float Width { get; set; }

        [JsonProperty(PropertyName = "Height")]
        public float Height { get; set; }

        [JsonProperty(PropertyName = "Weight")]
        public float Weight { get; set; }
    }

    public class CommodityCharacteristics
    {
        [JsonProperty(PropertyName = "hazardousSelected")]
        public Int32 hazardousSelected { get; set; }

        [JsonProperty(PropertyName = "perishableSelected")]
        public Int32 perishableSelected { get; set; }

        [JsonProperty(PropertyName = "temperatureSelected")]
        public Int32 temperatureSelected { get; set; }
    }

    public class Commodity
    {
        [JsonProperty(PropertyName = "CommodityTypeCode")]
        public string CommodityTypeCode { get; set; }

        [JsonProperty(PropertyName = "commodityProducts")]
        public string commodityProducts { get; set; }

        [JsonProperty(PropertyName = "shipmentValue")]
        public string shipmentValue { get; set; }

        [JsonProperty(PropertyName = "currecy")]
        public string currecy { get; set; }

    }

}
