﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Customer.Core.Entities.Dtos
{
    public interface IDto
    {
        Guid Id { get; set; }
    }
}
