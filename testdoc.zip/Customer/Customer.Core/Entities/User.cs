using System;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace Customer.Core.Entities
{
	using Abstract;
    using Newtonsoft.Json;

    public class User : IEntity
	{
		public User()
		{

		}
        [JsonProperty(PropertyName = "id")]
        public Guid? Id { get; set; }

        public string PartitionKey { get; set; }
        //public string[] ItemType { get; }
        [JsonProperty(PropertyName = "Version")]
        public int Version { get; set; }

        [JsonProperty(PropertyName = "UserToken")]
        public string UserToken { get; set; }

        [JsonProperty(PropertyName = "Password")]
        public string Password { get; set; }

        [JsonProperty(PropertyName = "FirstName")]
        public string FirstName { get; set; }

        [JsonProperty(PropertyName = "LastName")]
        public string LastName { get; set; }

        [JsonProperty(PropertyName = "EmailAddress")]
        [Required, MaxLength(200)]
        public string EmailAddress { get; set; }

        [JsonProperty(PropertyName = "LoginAttempts")]
        public int? LoginAttempts { get; set; }

        [JsonProperty(PropertyName = "DateTimeStamp")]
        public DateTime DateTimeStamp { get; set; }

        [JsonProperty(PropertyName = "Idp")]
        public string Idp { get; set; }

        [JsonProperty(PropertyName = "PhoneNumber")]
        public string PhoneNumber { get; set; }

        [JsonProperty(PropertyName = "CountryId")]
        public int? CountryId { get; set; }

        [JsonProperty(PropertyName = "StreetAddress")]
        public string StreetAddress { get; set; }

        [JsonProperty(PropertyName = "PostalCode")]
        public string PostalCode { get; set; }

        [JsonProperty(PropertyName = "City")]
        public string City { get; set; }

        [JsonProperty(PropertyName = "StateId")]
        public int? StateId { get; set; }

        [JsonProperty(PropertyName = "IsDeviceSetUpCompleted")]
        public bool IsDeviceSetUpCompleted { get; set; }

        [JsonProperty(PropertyName = "B2CUserObjectId")]
        public string B2CUserObjectId { get; set; }

        [JsonProperty(PropertyName = "RecieveLogDVIRMails")]
        public bool RecieveLogDVIRMails { get; set; }

        [JsonProperty(PropertyName = "CSVCreatedOn")]
        public DateTime? CSVCreatedOn { get; set; }

        public virtual UserAccountSetting UserAccountSetting { get; set; }

        public string lastContinuationToken { get; set; }
    }
}