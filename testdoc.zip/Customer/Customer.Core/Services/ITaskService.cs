﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Bonsai.Azure.CosmosDb.Models;
using Customer.Core.Entities;
using Customer.Core.Entities.Dtos;

namespace Customer.Core.Services
{
    public interface ITaskService : IBaseService<MyTask>
    {
        List<UserIdWithLastLogIn> GetAllAssociatedIds(string emailId);

        object SendEmailWithAllAssociatedIds(List<UserIdWithLastLogIn> userIdList, string emailId);

        Task<ISearchResult<CustomerProfile>> GetCustomerProfile(string custId);

        Task<CustomerProfile> UpdateCustomerProfile(CustomerProfile userProfile);

        Task<UpserProfile> UpdateUpserProfile(UpserProfile userProfile);

        Task<ShipingAddress> AddShippingAddress(ShipingAddress shipingAddress);
        Task<ISearchResult<ShipingAddress>> GetCustomersshippingAddress(string custId);

        Task<ShipingAddress> UpdateShippingAddress(ShipingAddress shipingAddress);

        Task<ContactSettings> AddContact(ContactSettings contactDetails);
        Task<ISearchResult<ContactSettings>> GetCustomersContacts(string custId);

        Task<ContactSettings> UpdateContact(ContactSettings contactDetails);
        
        void CreateCustomerProfle(CustomerProfile customerProfile);

        Task<ResponseModel> CreateUpserProfle(UpserProfile upserProfile);

        Task<ISearchResult<UpserProfile>> GetUpserProfile(string custId);
    }
}
