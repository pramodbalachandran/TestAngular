﻿using Customer.Core.Entities;
using Customer.Core.Entities.Dtos;
using System;
using System.Collections.Generic;
using System.Text;

namespace Customer.Core.Services
{
    /// <summary>
    /// Mess
    /// </summary>
    public interface IMessageService
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="message"></param>
        /// <param name="isHtmlBody"></param>
        /// <returns></returns>
        object UseEmailService(EmailMessage message, bool isHtmlBody);

        /// <summary>
        /// Send Verification Email On SignUp
        /// </summary>
        /// <param name="email"></param>
        /// <param name="displayName"></param>
        /// <param name="username"></param>
        void SendVerificationEmailOnSignUp(VerifyEmail verifyEmail);

        /// <summary>
        /// Send OTP for Forgot password functionality
        /// </summary>
        /// <param name="otp"></param>
        void SendOtpForgotPassword(VerifyEmail otpDetail);

        /// <summary>
        /// Message content for successful pswd changed
        /// </summary>
        /// <param name="otpDetail"></param>
        void CreateMessageContentForSuccessfulResetPswd(VerifyEmail verifyEmail);

    }
}
