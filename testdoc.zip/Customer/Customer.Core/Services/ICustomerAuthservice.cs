﻿using Customer.Core.Entities;
using Customer.Core.Entities.Dtos;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace Customer.Core.Services
{
    public interface ICustomerAuthservice 
    {
        Task<ResponseModel> SendCreateUserRequest(CustomerProfile signUpRequest);        

        Task<dynamic> GetUsernameLinkedToEmailRequest(UserEmail userEmail);

        Task<dynamic> InitiateForgotPassword(UserEmaiAndId userDetail);

        Task<dynamic> VerifySCodeResetPswd(RequestResetPswd requestResetPswd);

        Task<ResponseStatus> AuthenticateUser(RequestSignIn signInRequest);

        Task<dynamic> GetUsernameSuggestions(CustId username);

        void UpdateDisplayName(UpdateDisplayNameRequest request);

        Task<dynamic> VerifyUserUsingEmail(string uid, string verificationCode);

        Task<dynamic> ResetForgotPswd(RequestResetPswd request);

        void BlockUserAfterSignUp(string userId);
    }
}
