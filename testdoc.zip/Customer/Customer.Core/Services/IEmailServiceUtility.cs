﻿using Customer.Core.Entities;
using Customer.Core.Entities.Dtos;
using System;
using System.Collections.Generic;
using System.Text;

namespace Customer.Core.Services
{
    public interface IEmailServiceUtility
    {
        object SendMail(EmailMessage message, bool isHtmlBody);

        void SendMailUsingSendGrid(string message, string emailId, string displayName, string sub);
    }
}
