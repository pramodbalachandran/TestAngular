﻿
namespace Customer.Core.Services
{
    using Entities;
    public interface ILogService : IBaseService<Log>
    {

    }
}
