﻿namespace Customer.Core.Config
{
	public interface IDbConfig
	{
		string CustomerConnectionString { get; }
        string DocumentDbEndpointUrl { get; }
        string DocumentDbPrimaryKey { get; }
        string CacheServerConnectionString { get; }
	}
}
