﻿using Bonsai.Azure.CosmosDb;
using Bonsai.Azure.CosmosDb.Models;
using Customer.Core.Entities;
using Microsoft.Azure.Documents;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Text;

namespace Customer.Infrastructure.Data.Repositories
{
    public class TaskAuthRepository :AuthRepositories<MyTask>
    {
        private readonly IDocumentClient _docClient;

        private readonly ILoggerFactory _loggerFactory;

        private readonly GenericRepository<IModel> _objDb;
        public TaskAuthRepository(IDocumentClient client, ILoggerFactory loggerFactory) : base(client, loggerFactory)
        {
            _docClient = client;
            _loggerFactory = loggerFactory;
            //_objDb = new GenericRepository<IModel>(_docClient, _loggerFactory,"Quotes","QuotesDetails");
        }
    }
}
