﻿using System;
using System.Collections.Generic;
using System.Text;

using Customer.Core.Entities.Abstract;
using Bonsai.Azure.CosmosDb;
using Microsoft.Azure.Documents;
using Microsoft.Extensions.Logging;
using Bonsai.Azure.CosmosDb.Models;
using System.Threading.Tasks;
using System.Linq.Expressions;
using Customer.Core.Entities;

namespace Customer.Infrastructure.Data.Repositories
{
    public class Repository<T> : GenericRepository<T>, IRepository<T> where T : class, IEntity
    {
        private const string _dbQuotes = "Bonsai";
        private const string _collectionQuotesDetail = "GFF";
        private const string _dbCustomer = "Bonsai";
        private const string _collectionCustomerProfile = "GFF";
        private const string _collectionShippingAdd = "GFF";
        private const string _collectionCustContacts = "GFF";

        //public Repository() : base(CustomerContext.DbConnectionString(), "Customer")
        //{

        //}

        //public Repository(IDocumentClient client, ILoggerFactory loggerFactory) : base(client, loggerFactory)
        //{

        //}

        private readonly IDocumentClient _docClient;

        private readonly ILoggerFactory _loggerFactory;

        private readonly GenericRepository<QuoteDetails> _objDb;
        private readonly GenericRepository<QuoteDetail> _objDb1;
        private readonly GenericRepository<CustomerProfile> _objDbUser;
        private readonly GenericRepository<ShipingAddress> _objDbUserShipAddress;
        private readonly GenericRepository<ContactSettings> _objDbUserContact;
        private readonly GenericRepository<UpserProfile> _objUpserUser;
        public Repository(IDocumentClient client, ILoggerFactory loggerFactory) 
            : base(client, loggerFactory, _dbCustomer, "external")
        {
            _docClient = client;
            _loggerFactory = loggerFactory;
            _objDb = new GenericRepository<QuoteDetails>(_docClient, _loggerFactory, _dbQuotes, _collectionQuotesDetail);
            _objDb1 = new GenericRepository<QuoteDetail>(_docClient, _loggerFactory, _dbQuotes, _collectionQuotesDetail);
            _objDbUser = new GenericRepository<CustomerProfile>(_docClient, _loggerFactory, _dbCustomer, _collectionCustomerProfile);
            _objDbUserShipAddress = new GenericRepository<ShipingAddress>(_docClient, _loggerFactory, _dbCustomer, _collectionShippingAdd);
            _objDbUserContact = new GenericRepository<ContactSettings>(_docClient, _loggerFactory, _dbCustomer, _collectionCustContacts);
            _objUpserUser = new GenericRepository<UpserProfile>(_docClient, _loggerFactory, _dbCustomer, _collectionCustomerProfile);
        }

        public Task<ContactSettings> AddContact(ContactSettings contactDetails)
        {
            return _objDbUserContact.Upsert(contactDetails);
        }

        public Task<ShipingAddress> AddShippingAddress(ShipingAddress shipingAddress)
        {
            return _objDbUserShipAddress.Upsert(shipingAddress);
        }

        public async Task<ISearchResult<CustomerProfile>> GetCustomerProfile(string custId)
        {
            //Expression<Func<CustomerProfile, bool>> criteria = d => d.UserId == custId && d.DocType="" ;
            //SearchModel mod = new SearchModel
            //{
            //    PageSize = 100
            //};
            //var lst = await _objDbUser.Get(criteria, mod);
            //return lst;

            string getcustomerQuery = "SELECT * FROM GFF c where c.docType='customerprofile' and c.userId='" + custId + "' ";
            SearchModel mod = new SearchModel
            {
                PageSize = 100,
            };
            return await _objDbUser.Get(getcustomerQuery, mod).ConfigureAwait(false);
        }

        public async Task<ISearchResult<UpserProfile>> GetUpserProfile(string custId)
        {

            string getcustomerQuery = "SELECT * FROM GFF c where c.docType='customerprofile' and c.userId='" + custId + "' ";
            SearchModel mod = new SearchModel
            {
                PageSize = 100,
            };
            return await _objUpserUser.Get(getcustomerQuery, mod).ConfigureAwait(false);
        }

        public async Task<ISearchResult<ContactSettings>> GetCustomersContacts(string custId)
        {
            Expression<Func<ContactSettings, bool>> criteria = d => d.UserId.StartsWith(custId);
            SearchModel mod = new SearchModel
            {
                PageSize = 100
            };
            var lst = await _objDbUserContact.Get(criteria, mod);
            return lst;
        }

        public async Task<ISearchResult<ShipingAddress>> GetCustomersshippingAddress(string custId)
        {
            Expression<Func<ShipingAddress, bool>> criteria = d => d.UserId.StartsWith(custId);
            SearchModel mod = new SearchModel
            {
                PageSize = 100
            };
            var lst = await _objDbUserShipAddress.Get(criteria, mod);
            return lst;
        }

        public  async Task<ISearchResult<QuoteDetails>> GetMyQuotes(string custId)
        {
            try
            {
                Expression<Func<QuoteDetails, bool>> criteria = d => d.UserId.StartsWith(custId);
                SearchModel mod = new SearchModel
                {
                    PageSize = 100
                };
                //var lst= await _objDb.GetAll("", mod);
                 var lst = await _objDb.Get(criteria, mod);
                return lst;               
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public Task<ContactSettings> UpdateContact(ContactSettings contactDetails)
        {
            return _objDbUserContact.Upsert(contactDetails);
        }

        public Task<CustomerProfile> UpdateCustProfile(CustomerProfile userProfile)
        {
            return _objDbUser.Upsert(userProfile);
        }

        public Task<UpserProfile> UpdateUpserProfile(UpserProfile upserProfile)
        {
            return _objUpserUser.Upsert(upserProfile);
        }

        public Task<ShipingAddress> UpdateShippingAddress(ShipingAddress shipingAddress)
        {
            return _objDbUserShipAddress.Upsert(shipingAddress);
        }

        public Task<QuoteDetail> SaveQuoteForLater(QuoteDetail quoteDetail)
        {
            return _objDb1.Upsert(quoteDetail);
        }

        public async Task<ISearchResult<QuoteDetail>> GetSavedQuote(Guid? quoteId)
        {
            Expression<Func<QuoteDetail, bool>> criteria = d => d.Id == quoteId;
            SearchModel mod = new SearchModel
            {
                PageSize = 100
            };
            var lst = await _objDb1.Get(criteria, mod).ConfigureAwait(false);
            return lst;
        }
        /// <summary>
        /// Save customer profile in Bonsai database
        /// </summary>
        /// <param name="customerProfile"></param>
        public async void CreateCustomerProfle(CustomerProfile customerProfile)
        {
            _objDbUser.Upsert(customerProfile);
        }

        /// <summary>
        /// Save Upser profile in Bonsai database
        /// </summary>
        /// <param name="customerProfile"></param>
        public async void CreateUpserProfile(UpserProfile upserProfile)
        {
            _objUpserUser.Upsert(upserProfile);
        }
    }
}
