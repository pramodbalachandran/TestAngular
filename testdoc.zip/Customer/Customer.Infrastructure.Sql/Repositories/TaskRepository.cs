﻿using System;
using System.Collections.Generic;
using System.Text;
using Bonsai.Azure.CosmosDb;
using Bonsai.Azure.CosmosDb.Models;
using Customer.Core.Entities;
using Microsoft.Azure.Documents;
using Microsoft.Extensions.Logging;

namespace Customer.Infrastructure.Data.Repositories
{
    public class TaskRepository : Repository<MyTask>
    {
        private readonly IDocumentClient _docClient;

        private readonly ILoggerFactory _loggerFactory;

        private readonly GenericRepository<IModel> _objDb;
        public TaskRepository(IDocumentClient client, ILoggerFactory loggerFactory) : base(client, loggerFactory)
        {
            _docClient = client;
            _loggerFactory = loggerFactory;
            //_objDb = new GenericRepository<IModel>(_docClient, _loggerFactory,"Quotes","QuotesDetails");
        }

       

    }
}
