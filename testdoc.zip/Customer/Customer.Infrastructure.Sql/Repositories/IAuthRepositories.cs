﻿using Bonsai.Azure.CosmosDb.Abstract;
using Bonsai.Azure.CosmosDb.Models;
using Customer.Core.Entities;
using Customer.Core.Entities.Abstract;
using System;
using System.Threading.Tasks;

namespace Customer.Infrastructure.Data.Repositories
{
    public interface IAuthRepositories<T> : IBaseRepository<T> where T : IEntity
    {
        Task<ISearchResult<CustomerProfile>> GetCustomerProfile(string custId);
        Task<CustomerProfile> UpdateCustProfile(CustomerProfile userProfile);
    }
}
