﻿using Bonsai.Azure.CosmosDb;
using Bonsai.Azure.CosmosDb.Models;
using Customer.Core.Entities;
using Customer.Core.Entities.Abstract;
using Microsoft.Azure.Documents;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Customer.Infrastructure.Data.Repositories
{
    public class AuthRepositories<T>: GenericRepository<T>, IAuthRepositories<T> where T : class, IEntity
    {

        private const string _dbCustomer = "Bonsai";
        private const string _collectionName = "GFF";
        private readonly GenericRepository<CustomerProfile> _objDbUser;
        private readonly IDocumentClient _docClient;
        private readonly ILoggerFactory _loggerFactory;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="client"></param>
        /// <param name="loggerFactory"></param>
        public AuthRepositories(IDocumentClient client, ILoggerFactory loggerFactory)
            : base(client, loggerFactory, _dbCustomer, "external")
        {
            _docClient = client;
            _loggerFactory = loggerFactory;
            _objDbUser = new GenericRepository<CustomerProfile>(_docClient, _loggerFactory, _dbCustomer, _collectionName);
        }

        public async Task<ISearchResult<CustomerProfile>> GetCustomerProfile(string custId)
        {
            string getcustomerQuery = "SELECT * FROM GFF c where c.docType='customerprofile' and c.userId='" + custId.ToLower() + "' ";
            SearchModel mod = new SearchModel
            {
                PageSize = 100,
            };
            return await _objDbUser.Get(getcustomerQuery, mod).ConfigureAwait(false);
        }

        public Task<CustomerProfile> UpdateCustProfile(CustomerProfile userProfile)
        {
            return _objDbUser.Upsert(userProfile);
        }
    }
}
