﻿using Customer.Core.Entities.Abstract;
using Bonsai.Azure.CosmosDb.Abstract;
using System.Threading.Tasks;
using Bonsai.Azure.CosmosDb.Models;
using Customer.Core.Entities;
using System;

namespace Customer.Infrastructure.Data.Repositories
{
    public interface IRepository<T> : IBaseRepository<T> where T : IEntity
    {
        Task<ISearchResult<QuoteDetails>> GetMyQuotes(string custId);

        Task<ISearchResult<CustomerProfile>> GetCustomerProfile(string custId);

        Task<ISearchResult<UpserProfile>> GetUpserProfile(string custId);

        Task<CustomerProfile> UpdateCustProfile(CustomerProfile userProfile);

        Task<UpserProfile> UpdateUpserProfile(UpserProfile userProfile);
        
        Task<ShipingAddress> AddShippingAddress(ShipingAddress shipingAddress);

        Task<ISearchResult<ShipingAddress>> GetCustomersshippingAddress(string custId);

        Task<ShipingAddress> UpdateShippingAddress(ShipingAddress shipingAddress);

        Task<ContactSettings> AddContact(ContactSettings contactDetails);
        Task<ISearchResult<ContactSettings>> GetCustomersContacts(string custId);

        Task<ContactSettings> UpdateContact(ContactSettings contactDetails);

        Task<QuoteDetail> SaveQuoteForLater(QuoteDetail quoteDetail);
        Task<ISearchResult<QuoteDetail>> GetSavedQuote(Guid? quoteId);

        void CreateCustomerProfle(CustomerProfile customerProfile);

        void CreateUpserProfile(UpserProfile customerProfile);
    }
}
