﻿using System;

namespace Customer.Integration
{
    public class Class1
    {
    }
}
