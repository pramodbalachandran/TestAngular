﻿using System.Net.Http;
using System.Threading.Tasks;
using Customer.Core.Services;

namespace Customer.Infrastructure.Services
{
    public class HttpClientService : IHttpClientService
    {
        public async Task<HttpResponseMessage> SendAsyncRequest(HttpRequestMessage requestMessage)
        {
            return await new HttpClient().SendAsync(requestMessage).ConfigureAwait(false);
        }
    }
}
