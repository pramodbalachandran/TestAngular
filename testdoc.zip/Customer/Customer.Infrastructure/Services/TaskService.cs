﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using Bonsai.Azure.CosmosDb.Models;
using Customer.Core.Constants;
using Customer.Core.Entities;
using Customer.Core.Entities.Dtos;
using Customer.Core.Services;
using Customer.Infrastructure.Data.Repositories;
using Microsoft.Extensions.Configuration;

namespace Customer.Infrastructure.Services
{
    public class TaskService : BaseService<MyTask>, ITaskService
    {
        private const string LineBreak = "<br/>";
        private const string StrongTextStart = "<b>";
        private const string StrongTextEnd = "</b>";
        private const string DefaultFromEmail = "SmtpServerSettings:FromDefaultEmail";
        private const string InvalidDataErrMsg = "Invalid data provided in request.";
        private readonly IRepository<MyTask> _repository;
        private readonly IMessageService _messageService;
        private readonly IConfiguration _appConfig;

        public TaskService(IRepository<MyTask> repository, IMessageService messageService, IConfiguration appConfig) : base(repository)
        {
            _repository = repository;
            _messageService = messageService;
            _appConfig = appConfig;
        }

        public Task<ContactSettings> AddContact(ContactSettings contactDetails)
        {
            return _repository.AddContact(contactDetails);
        }

        public Task<ShipingAddress> AddShippingAddress(ShipingAddress shipingAddress)
        {
            return _repository.AddShippingAddress(shipingAddress);
        }

        public void CreateTask()
        {
            MyTask task = new MyTask
            {
                Version = 1,
                Name = "Task 1",
                Category = "A",
                CreatedDate = DateTime.Today
            };
            Repository.Upsert(task);
            task = new MyTask
            {
                Version = 1,
                Name = "Task 2",
                Category = "A",
                CreatedDate = DateTime.Today
            };
            Repository.Upsert(task);
        }

        public List<UserIdWithLastLogIn> GetAllAssociatedIds(string emailId)
        {

            //Todo implementation
            List<UserIdWithLastLogIn> userIdList = new List<UserIdWithLastLogIn>();
            UserIdWithLastLogIn uId = new UserIdWithLastLogIn
            {
                UserId = "UPS11000667",
                LastLoginOn = "02/20/2018"
            };
            userIdList.Add(uId);
            uId = new UserIdWithLastLogIn
            {
                UserId = "UPS12000543",
                LastLoginOn = "05/25/2018"
            };
            userIdList.Add(uId);
            uId = new UserIdWithLastLogIn
            {
                UserId = "UPS12000765",
                LastLoginOn = "06/15/2018"
            };
            userIdList.Add(uId);

            return userIdList;

        }

        public Task<ISearchResult<CustomerProfile>> GetCustomerProfile(string custId)
        {
            return _repository.GetCustomerProfile(custId);
        }

        public Task<ISearchResult<UpserProfile>> GetUpserProfile(string custId)
        {
            return _repository.GetUpserProfile(custId);
        }

        public Task<ISearchResult<ContactSettings>> GetCustomersContacts(string custId)
        {
            return _repository.GetCustomersContacts(custId);
        }

        public Task<ISearchResult<ShipingAddress>> GetCustomersshippingAddress(string custId)
        {
            return _repository.GetCustomersshippingAddress(custId);
        }

        /// <summary>
        /// Send Email With AllAssociated Ids
        /// </summary>
        /// <param name="userIdList"></param>
        /// <param name="userEmailId"></param>
        /// <returns></returns>
        public object SendEmailWithAllAssociatedIds(List<UserIdWithLastLogIn> userIdList, string userEmailId)
        {
            EmailMessage message = new EmailMessage();
            StringBuilder messageBody = new StringBuilder();
            messageBody.Append("Hello, " + "<a href=\"" + userEmailId + "\">" + userEmailId + "</a>,");
            messageBody.Append(LineBreak + LineBreak + "Thank you for using UPS. The following My UPS User IDs are associated with the e-mail address you submitted." + LineBreak + LineBreak + "Your My UPS User IDs:" + LineBreak + LineBreak);

            foreach (var id in userIdList)
            {
                messageBody.Append(StrongTextStart + id.UserId + StrongTextEnd + " (Last logged in on " + id.LastLoginOn + ")" + LineBreak);
            }
            messageBody.Append(LineBreak + "Please save this e-mail, as it contains links and information that will help you get the most from My UPS." + LineBreak + LineBreak);
            messageBody.Append("If you have forgotten your passwords, visits <a href=\"https://www.ups.com/us/en/help-center/legal-terms-conditions/privacy-notice.page?\">Forgot User ID or Password</a> on UPS.com to reset them.");
            messageBody.Append(LineBreak + LineBreak + "Thank you for choosing My UPS. To learn more ways to make My UPS work for you, please visit <a href=\"https://www.ups.com/us/en/help-center/legal-terms-conditions/privacy-notice.page?\">Business Solutions</a>.");
            message.FromAddress = _appConfig[DefaultFromEmail];

            message.ToAddress = new List<string>
            {
                userEmailId
            };
            message.MsgBody = messageBody.ToString();

            return _messageService.UseEmailService(message, true);
        }

        public Task<ContactSettings> UpdateContact(ContactSettings contactDetails)
        {
            return _repository.UpdateContact(contactDetails);
        }

        public Task<CustomerProfile> UpdateCustomerProfile(CustomerProfile userProfile)
        {
            return _repository.UpdateCustProfile(userProfile);
        }

        public Task<UpserProfile> UpdateUpserProfile(UpserProfile upserProfile)
        {
            return _repository.UpdateUpserProfile(upserProfile);
        }

        public Task<ShipingAddress> UpdateShippingAddress(ShipingAddress shipingAddress)
        {
            return _repository.UpdateShippingAddress(shipingAddress);
        }

        private CustomColumnSelectionMyQuoyes UpdateDefaultColumnSelectionForQuotesDashBoard()
        {
            return new CustomColumnSelectionMyQuoyes
            {
                ColDateCreated = true,
                ColQuoteName = true,
                ColCustomerName = true,
                ColValue = true,
                ColStatus = true,
                ColSource = true,
                ColPriority = true,
                ColDueDate = true,
                ColQuoteNumber = false,
                ColQuoteType = false,
                ColGadWeight = false,
                ColAnalystLevel = false,
                ColServiceType = false,
                ColOrigin = false,
                ColDestination = false
            };
        }

        /// <summary>
        /// To create customer profile
        /// </summary>
        /// <param name="customerProfile"></param>
        public void CreateCustomerProfle(CustomerProfile customerProfile)
        {
            customerProfile.BusinessPartyNumber = string.IsNullOrEmpty(customerProfile.BusinessPartyNumber) ? string.Empty : customerProfile.BusinessPartyNumber;
            customerProfile.AccountNumber = string.IsNullOrEmpty(customerProfile.AccountNumber) ? string.Empty : customerProfile.AccountNumber;
            customerProfile.DocType = CustomerDocumentType.CustomerProfile;
            customerProfile.DocId = CustomerDocumentType.CustomerProfile + customerProfile.BusinessPartyNumber + customerProfile.AccountNumber;
            customerProfile.PartitionKey = CustomerDocumentType.CustomerProfile;
            customerProfile.UserId = customerProfile.UserId.ToLower();
            customerProfile.ContactAsBillingAddressIndicator = true;
            customerProfile.Password = string.Empty;
            customerProfile.CustColumnSelection = UpdateDefaultColumnSelectionForQuotesDashBoard();
            customerProfile.NotificationSettings = new NotificationSettings
            {
                PickupRequestRequiredEmailIndicator = true,
                ResetPasswordRequiredEmailIndicator = true,
                QuoteStatusExpiringRequiredEmailIndicator = true,
                PreApprovedRateRequiredEmailIndicator = true,
                QuoteRespondByUPSRequiredEmailIndicator = true
            };
            _repository.CreateCustomerProfle(customerProfile);
        }

        /// <summary>
        /// To create upser profile
        /// </summary>
        /// <param name="customerProfile"></param>
        public async Task<ResponseModel> CreateUpserProfle(UpserProfile upserProfile)
        {
            if (upserProfile == null || string.IsNullOrEmpty(upserProfile.UserId) || string.IsNullOrEmpty(upserProfile.BusinessPartyNumber) || string.IsNullOrEmpty(upserProfile.BusinessPartyName) )
            {
                return new ResponseModel
                {
                    responseStatus = new ResponseStatus
                    {
                        errorMessage = InvalidDataErrMsg,
                        status = Convert.ToInt16(HttpStatusCode.BadRequest).ToString()
                    }
                };
            }

            upserProfile.BusinessPartyNumber = string.IsNullOrEmpty(upserProfile.BusinessPartyNumber) ? string.Empty : upserProfile.BusinessPartyNumber;
            upserProfile.AccountNumber = string.IsNullOrEmpty(upserProfile.AccountNumber) ? string.Empty : upserProfile.AccountNumber;
            upserProfile.DocType = CustomerDocumentType.CustomerProfile;
            upserProfile.DocId = CustomerDocumentType.CustomerProfile + upserProfile.BusinessPartyNumber + upserProfile.AccountNumber;
            upserProfile.PartitionKey = CustomerDocumentType.CustomerProfile;
            upserProfile.CustColumnSelection = UpdateDefaultColumnSelectionForQuotesDashBoard();
            upserProfile.UserId = upserProfile.UserId.ToLower();
            _repository.CreateUpserProfile(upserProfile);
            return new ResponseModel
            {
                responseStatus = new ResponseStatus
                {
                    errorMessage = InvalidDataErrMsg,
                    status = Convert.ToInt16(HttpStatusCode.Created).ToString()
                }
            };
        }
    }

}
