﻿using Customer.Core.Entities;
using Customer.Core.Services;
using Microsoft.Extensions.Configuration;
using System.IO;
using System.Reflection;
using System.Text;

namespace Customer.Infrastructure.Services
{
    /// <summary>
    /// Message Service Declaration
    /// </summary>
    public class MessageService : IMessageService
    {
        private const string BaseUrl = "OtherSetting:BonsaiApiBaseUrl";
        private const string VerifyMethod = "VerifyEmail?vc=";
        private const string QueryStrUid = "&uid=";
        private const string SubjectVerificationEmail = "OtherSetting:SubjectVerificationEmailOnSignUp";
        private const string LineBreakTag2 = "<br><br>";
        private const string Hello = "Hello, ";
        private const string Comma = ",";
        private const string VerifyLinkMessage = "Please click or copy paste below link to verify your email.";
        private const string SubjectResetPswdPin = "OtherSetting:SubjectResetPswdPin";
        private const string BoldStart = "<b>";
        private const string BoldCloseTag = "</b>";
        private const string Dot = ".";
        private const string SubjectPswdReset = "OtherSetting:SubjectResetPswdSuccess";
        private readonly IEmailServiceUtility _emailServiceUtility;
        private readonly IConfiguration _appConfig;
        public MessageService(IEmailServiceUtility emailServiceUtility, IConfiguration appConfig)
        {
            _emailServiceUtility = emailServiceUtility;
            _appConfig = appConfig;
        }

        /// <summary>
        /// Email content - Send PIN
        /// </summary>
        /// <param name="otpDetail"></param>
        public void SendOtpForgotPassword(VerifyEmail otpDetail)
        {           
            StringBuilder sb = new StringBuilder();
            sb.Append(Hello+ otpDetail.DisplayName+",");
            sb.Append(LineBreakTag2);
            sb.Append("Please use this pin - "+ otpDetail.VerificationCode +" to reset your password.Valid only for 10 minutes"+ LineBreakTag2);
            _emailServiceUtility.SendMailUsingSendGrid(sb.ToString(), otpDetail.EmailId, otpDetail.DisplayName, _appConfig[SubjectResetPswdPin]);
        }

        /// <summary>
        /// Message content for successful pswd changed
        /// </summary>
        /// <param name="verifyEmail"></param>
        public void CreateMessageContentForSuccessfulResetPswd(VerifyEmail verifyEmail)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append(Hello + BoldStart + verifyEmail.DisplayName + BoldCloseTag + Dot);
            sb.Append(LineBreakTag2);
            sb.Append("Per your request, the password for your My UPS User ID has been changed.." + LineBreakTag2);
            sb.Append("Your " + BoldStart + "My UPS User ID" + BoldCloseTag + " is: " + BoldStart + verifyEmail.Username + BoldCloseTag + LineBreakTag2);
            sb.Append("Please save this e-mail, as it contains links and information that will help you get the most from My UPS.");
            _emailServiceUtility.SendMailUsingSendGrid(sb.ToString(), verifyEmail.EmailId, verifyEmail.DisplayName, _appConfig[SubjectPswdReset]);
        }

        /// <summary>
        /// Send Verification Email On SignUp
        /// </summary>
        /// <param name="email"></param>
        /// <param name="displayName"></param>
        /// <param name="username"></param>
        public void SendVerificationEmailOnSignUp(VerifyEmail verifyEmail)
        {
            string verificationLink = _appConfig[BaseUrl] + VerifyMethod + verifyEmail.VerificationCode + QueryStrUid + verifyEmail.Username;
            StringBuilder sb = new StringBuilder();
            sb.Append(Hello + verifyEmail.DisplayName + Comma);
            sb.Append(LineBreakTag2);
            sb.Append(VerifyLinkMessage + LineBreakTag2);
            sb.Append(verificationLink);
            sb.Append(LineBreakTag2);
            _emailServiceUtility.SendMailUsingSendGrid(sb.ToString(), verifyEmail.EmailId, verifyEmail.DisplayName, _appConfig[SubjectVerificationEmail]);
        }

        /// <summary>
        /// Using Email utility service for Message
        /// </summary>
        /// <param name="message"></param>
        /// <returns></returns>
        public object UseEmailService(EmailMessage message, bool isHtmlBody)
        {
            return _emailServiceUtility.SendMail(message, isHtmlBody);
        }
    }
}
