﻿using Customer.Core.Entities;
using Customer.Core.Entities.Dtos;
using Customer.Core.Services;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Clients.ActiveDirectory;
using System.IdentityModel.Tokens.Jwt;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Security.Claims;
using System.IO;
using System.Security.Cryptography.X509Certificates;
using System.Reflection;
using Customer.Infrastructure.Data.Repositories;
using System.Linq;

namespace Customer.Infrastructure.Services
{
    public class CustomerAuthService : ICustomerAuthservice
    {
        #region private members
        private AuthenticationContext _authContext;
        private ClientCredential _credential;
        private readonly IConfiguration _appConfig;
        private readonly IAuthRepositories<MyTask> _repository;
        private readonly IHttpClientService _httpClientService;
        private static readonly HttpClient _htpclient = new HttpClient();
        private readonly IMessageService _messageService;
        private const string AuthAppId = "AzureADGraphAPI:AuthAppId";
        private const string KeyClientId = "AzureADGraphAPI:KeyClientId";
        private const string KeyGrantType = "AzureADGraphAPI:KeyGrantType";
        private const string KeyScope = "AzureADGraphAPI:KeyScope";
        private const string KeyPassword = "AzureADGraphAPI:KeyPassword";
        private const string KeyUsername = "AzureADGraphAPI:KeyUsername";
        private const string KeyResponseType = "AzureADGraphAPI:KeyResponseType";
        private const string AuthResponseType = "AzureADGraphAPI:AuthResponseType";
        private const string AuthScope = "AzureADGraphAPI:AuthScope";
        private const string AuthUrl = "AzureADGraphAPI:AuthUrl";
        private const string AuthGrantType = "AzureADGraphAPI:AuthGrantType";
        private const string ADGraphEndpoint = "AzureADGraphAPI:ADGraphEndpoint";
        private const string B2CTenant = "AzureAdB2C:Tenant";
        private const string MSBaseURL = "AzureADGraphAPI:MSBaseURL";
        private const string B2CClientId = "AzureADGraphAPI:GraphAPIAppClientId";
        private const string B2CClientSecret = "AzureADGraphAPI:GraphAPIAppClientSecret";
        private const string APIVersion = "AzureADGraphAPI:APIVersion";
        private const string AbsoluteUriUser = "AzureADGraphAPI:AbsoluteUserUri";
        private const string AccEnabled = "AzureADGraphAPI:AccountEnabled";
        private const string CrType = "AzureADGraphAPI:CreationType";
        private const string SignInNamesTypeUserName = "AzureADGraphAPI:SignInNamesTypeUserName";
        private const string SignInNamesTypeEmail = "AzureADGraphAPI:SignInNamesTypeEmail";
        private const string ForceChangePasswordNextLogin = "AzureADGraphAPI:ForceChangePasswordNextLogin";
        private const string DefaultFromEmail = "SmtpServerSettings:FromDefaultEmail";
        private const string QuestionMark = "?";
        private const string SchemeBearer = "Bearer";
        private const string MediaType = "application/json";
        private const string MediaTypeUrlEncoded = "application/x-www-form-urlencoded";
        private const string UrlTypeUserLinkedToEmail = "userLinkedToEmail";
        private const string UrlTypeUserDetailByUserId = "userDetailByUserId";
        private const string UrlTypeUsernameSuggestion = "usernameSuggestion";
        private const string UrlTypeUpdateUser = "updateUser";
        private const string FilterWithSignInNames = "&$filter=signInNames/any(x:x/value eq";
        private const string FilterWithEmail = "&$filter=otherMails/any(x:x eq";
        private const string FilterWithEmail2 = "&$filter=startswith(extension_d860aa645e344dcab1faa983cedbdc33_emailAddress,";
        private const string FilterWithusername = "&$filter=startswith(employeeId,";
        private const string SingleWhiteSpace = " ";
        private const string SingleQuote = "'";
        private const string ClosingParenthesis = ")";
        private const string ForwardSlash = "/";
        private const string Result = "Result";
        private const string ResponseData = "responseData";
        private const string Value = "value";
        private const string ObjectId = "objectId";
        private const string Patch = "PATCH";
        private const string UsernameObj = "employeeId";
        private const string UsernameIsAvailable = "Username is Available";
        private const string SignInNames = "signInNames";
        private const string CtypeName = "name";
        private const string AccountEnabled = "accountEnabled";
        private const string UserBlocked = "User is blocked after 3 consecutive failed login attempts";
        private const string Error = "error_description";
        private const string AccessToken = "access_token";
        private const string ErrorHeader1 = "odata.error";
        private const string Level2Code = "code";
        private const string Level2Message = "message";
        private const string InvalidDataErrMsg = "Invalid data provided in request.";
        private const int NumberOfAttemptBeforeBlock = 2;
        private const string BadRequest = "400";
        private const string ErrEmailAlreadyExists = "EmailId already in use";
        private const string StringCombination = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        private const string UsrEmail = "otherMails";
        private const string OtpExpiryDuration = "OtherSetting:PasswordResetOtpDurationInMinutes";
        private const string DisplayName = "displayName";
        private const string Status200 = "200";
        private const string FailedUpdatePswd = "Failed to update password.";
        private const string ErrInvalidOtp = "Bad Request, Invalid PIN Entered.";
        private const string ErrPinBlocked = "Unauthorized, PIN verification blocked";
        private const string Status401 = "401";
        private const string ErrMsgUnauthorized = "Unauthorized";
        private const string NoOfAttemptsForgotPswdPin = "OtherSetting:NoOfAttemptsForgotPswdPIN";
        private const string AttemptsLeft = " attempts left";
        private const string TimeInMinutesPinVerificationBlocked = "OtherSetting:NoOfMinutesPinVerificationBlocked";
        private const string UserIsBlocked = "CustomMessages:MsgUserBlocked";
        #endregion

        /// <summary>
        /// constructor
        /// </summary>
        /// <param name="appConfig"></param>
        /// <param name="messageService"></param>
        /// <param name="httpClientService"></param>
        /// <param name="repositories"></param>
        public CustomerAuthService(IConfiguration appConfig, IMessageService messageService, IHttpClientService httpClientService, IAuthRepositories<MyTask> repositories)
        {
            _httpClientService = httpClientService;
            _appConfig = appConfig;
            _authContext = new AuthenticationContext(_appConfig[MSBaseURL] + _appConfig[B2CTenant]);
            _credential = new ClientCredential(_appConfig[B2CClientId], _appConfig[B2CClientSecret]);
            _messageService = messageService;
            _repository = repositories;
        }

        /// <summary>
        /// Sign Up
        /// </summary>
        /// <param name="signUpRequest"></param>
        /// <returns></returns>
        public async Task<ResponseModel> SendCreateUserRequest(CustomerProfile signUpRequest)
        {
            if (string.IsNullOrEmpty(signUpRequest.UserId) || string.IsNullOrEmpty(signUpRequest.CompanyName) || string.IsNullOrEmpty(signUpRequest.Password) || string.IsNullOrEmpty(signUpRequest.EmailAddress) || string.IsNullOrEmpty(signUpRequest.PhoneNumber))
            {
                return new ResponseModel
                {
                    responseStatus = new ResponseStatus
                    {
                        errorMessage = InvalidDataErrMsg,
                        status = Convert.ToInt16(HttpStatusCode.BadRequest).ToString()
                    }
                };
            }
            if (GetJsonObject(SerialiseJson(GetUserDetailsbyUsername(new CustId
            {
                CustomerId = signUpRequest.EmailAddress
            })))[Result][ResponseData][Value].HasValues)
            {
                return new ResponseModel
                {
                    responseStatus = new ResponseStatus
                    {
                        errorMessage = ErrEmailAlreadyExists,
                        status = BadRequest
                    }
                };
            }

            string url = _appConfig[ADGraphEndpoint] + _appConfig[B2CTenant] + _appConfig[AbsoluteUriUser] + QuestionMark + _appConfig[APIVersion];

            var request = await CreateHttpReq(url, HttpMethod.Post, SerialiseJson(CreateUserRequestModel(signUpRequest))).ConfigureAwait(false);
            var response = await _httpClientService.SendAsyncRequest(request).ConfigureAwait(false);
            var res = GetJsonObject(await response.Content.ReadAsStringAsync().ConfigureAwait(false));
            if (!response.IsSuccessStatusCode)
            {
                return new ResponseModel
                {
                    responseStatus = new ResponseStatus
                    {
                        errorMessage = FormatErrors(res),
                        status = Convert.ToInt16(response.StatusCode).ToString()
                    }
                };
            }
            else
            {
                var verificationCode = GenerateRandomCodeForEmailVerification();
                signUpRequest.EmailVerificationCode = verificationCode;
                SendConfirmationEmailOnSignUp(signUpRequest);
                return new ResponseModel
                {
                    responseStatus = new ResponseStatus
                    {
                        errorMessage = response.ReasonPhrase,
                        status = Convert.ToInt16(response.StatusCode).ToString(),
                        accessToken = verificationCode
                    },
                    responseData = res
                };
            }
        }

        /// <summary>
        /// Validate login
        /// </summary>
        /// <param name="signInRequest"></param>
        /// <returns></returns>
        public async Task<ResponseStatus> AuthenticateUser(RequestSignIn signInRequest)
        {
            if (!string.IsNullOrEmpty(signInRequest.Username) && !string.IsNullOrEmpty(signInRequest.Password))
            {
                var custDetail = await _repository.GetCustomerProfile(signInRequest.Username).ConfigureAwait(false);
                if (custDetail.Results[0].IsUserBlocked)
                {
                    if (DateTime.Now.Subtract(DateTime.MinValue.AddMilliseconds(Convert.ToDouble((custDetail.Results[0].UserUnblockTime)))).TotalMinutes >= 1)
                    {
                        UnBlockUser(signInRequest.Username);
                        custDetail.Results[0].IsUserBlocked = false;
                        custDetail.Results[0].FailedLoginAttempt = 0;
                        _repository.UpdateCustProfile(custDetail.Results[0]);
                    }
                    else
                    {
                        return new ResponseStatus
                        {
                            errorMessage = _appConfig[UserIsBlocked],
                            status = Status401
                        };
                    }
                }

                HttpRequestMessage request = new HttpRequestMessage(HttpMethod.Post, _appConfig[AuthUrl])
                {
                    Content = new FormUrlEncodedContent(
                                new List<KeyValuePair<string, string>>
                                {
                                new KeyValuePair<string, string>(_appConfig[KeyClientId], WebUtility.UrlEncode(_appConfig[AuthAppId])),
                                new KeyValuePair<string,string>(_appConfig[KeyGrantType],WebUtility.UrlEncode(_appConfig[AuthGrantType])),
                                new KeyValuePair<string,string>(_appConfig[KeyPassword],signInRequest.Password),
                                new KeyValuePair<string, string>(_appConfig[KeyResponseType], _appConfig[AuthResponseType]),
                                new KeyValuePair<string,string>(_appConfig[KeyScope],_appConfig[AuthScope]),
                                new KeyValuePair<string,string>(_appConfig[KeyUsername],WebUtility.UrlEncode(signInRequest.Username))
                                }
                )
                };
                var response = await _httpClientService.SendAsyncRequest(request).ConfigureAwait(false);
                if (!response.IsSuccessStatusCode)
                {
                    try
                    {
                        HttpResponseMessage res = await FAtp(signInRequest.Username,custDetail.Results[0]).ConfigureAwait(false);
                        if (res.StatusCode == HttpStatusCode.Unauthorized)
                        {
                            return new ResponseStatus
                            {
                                errorMessage = _appConfig[UserIsBlocked],
                                status = Convert.ToInt16(res.StatusCode).ToString()
                            };
                        }
                        return new ResponseStatus
                        {
                            errorMessage = (string)JObject.Parse(await response.Content.ReadAsStringAsync().ConfigureAwait(false))[Error],
                            status = Convert.ToInt16(response.StatusCode).ToString()
                        };
                    }
                    catch
                    {
                        return new ResponseStatus
                        {
                            errorMessage = (string)JObject.Parse(await response.Content.ReadAsStringAsync().ConfigureAwait(false))[Error],
                            status = ((int)HttpStatusCode.BadRequest).ToString()
                        };
                    }
                }
                else
                {
                    ResetFAtp(signInRequest.Username);
                    return new ResponseStatus
                    {
                        accessToken = (string)JObject.Parse(await response.Content.ReadAsStringAsync().ConfigureAwait(false))[AccessToken],
                        UserName = GetUsername((string)JObject.Parse(await response.Content.ReadAsStringAsync().ConfigureAwait(false))[AccessToken]),
                        status = Convert.ToInt16(response.StatusCode).ToString()
                    };
                }
            }
            else
            {
                return new ResponseStatus
                {
                    errorMessage = BadRequest,
                    status = ((int)HttpStatusCode.BadRequest).ToString()
                };
            }
        }

        /// <summary>
        /// Get Username Linked To Email 
        /// </summary>
        /// <param name="userEmail"></param>
        /// <returns></returns>
        public async Task<dynamic> GetUsernameLinkedToEmailRequest(UserEmail userEmail)
        {
            var response = await _httpClientService.SendAsyncRequest(await CreateHttpReq(GetUrlByType(UrlTypeUserLinkedToEmail, userEmail.EmailId), HttpMethod.Get, string.Empty).ConfigureAwait(false)).ConfigureAwait(false);
            var res = GetJsonObject(await response.Content.ReadAsStringAsync().ConfigureAwait(false));
            if (!response.IsSuccessStatusCode)
            {
                return new ResponseModel
                {
                    responseStatus = new ResponseStatus
                    {
                        errorMessage = FormatErrors(res),
                        status = Convert.ToInt16(response.StatusCode).ToString()
                    }
                };
            }
            else
            {
                List<string> lstOfUserNames = new List<string>();
                foreach (var list in res[Value])
                {
                    foreach (var signNames in list[SignInNames])
                    {

                        lstOfUserNames.Add(signNames[Value].ToString());
                    }
                }
                return lstOfUserNames;
            }
        }

        /// <summary>
        /// Failed login attempt
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        private async Task<dynamic> FAtp(string userId, CustomerProfile custDetail)
        {
            var jsonObj = GetJsonObject(SerialiseJson(GetUserDetailsbyUsername(new CustId
            {
                CustomerId = userId
            })));
            if ((bool)jsonObj[Result][ResponseData][Value][0][AccountEnabled])
            {
                if (custDetail.FailedLoginAttempt == 0)
                {
                    custDetail.FailedLoginAttempt = 1;
                    return await UpdateFailedAttempted(custDetail).ConfigureAwait(false);
                }
                else
                {
                    if (custDetail.FailedLoginAttempt == NumberOfAttemptBeforeBlock)
                    {
                        custDetail.UserUnblockTime= (DateTime.Now - DateTime.MinValue).TotalMilliseconds.ToString();
                        custDetail.IsUserBlocked = true;
                        _repository.UpdateCustProfile(custDetail);
                        return await BlockUser((string)jsonObj[Result][ResponseData][Value][0][ObjectId]).ConfigureAwait(false);
                    }
                    else
                    {
                        custDetail.FailedLoginAttempt++;
                        return await UpdateFailedAttempted(custDetail).ConfigureAwait(false);
                    }
                }
            }
            else
            {
                return new HttpResponseMessage
                {
                    StatusCode = HttpStatusCode.Unauthorized
                };
            }
        }

        /// <summary>
        /// Reset failed login attempt
        /// </summary>
        /// <param name="userId"></param>
        private async void ResetFAtp(string userId)
        {
            var custDetail = await _repository.GetCustomerProfile(userId).ConfigureAwait(false);
            custDetail.Results[0].FailedLoginAttempt = 0;
            custDetail.Results[0].LastLoggedInTime = DateTime.Now;
            _repository.UpdateCustProfile(custDetail.Results[0]);
        }

        /// <summary>
        /// Get Url
        /// </summary>
        /// <param name="urlType"></param>
        /// <param name="userEmailOrUserId"></param>
        /// <returns></returns>
        private string GetUrlByType(string urlType, string userEmailOrUserId)
        {
            string url = string.Empty;

            if (urlType == UrlTypeUserLinkedToEmail)
            {
                url = _appConfig[ADGraphEndpoint] + _appConfig[B2CTenant] + _appConfig[AbsoluteUriUser] + QuestionMark + _appConfig[APIVersion] + FilterWithEmail2 + SingleQuote + userEmailOrUserId + SingleQuote + ClosingParenthesis;
            }
            else if (urlType == UrlTypeUserDetailByUserId)
            {
                url = _appConfig[ADGraphEndpoint] + _appConfig[B2CTenant] + _appConfig[AbsoluteUriUser] + QuestionMark + _appConfig[APIVersion] + FilterWithSignInNames + SingleWhiteSpace + SingleQuote + userEmailOrUserId + SingleQuote + ClosingParenthesis;
            }
            else if (urlType == UrlTypeUpdateUser)
            {
                url = _appConfig[ADGraphEndpoint] + _appConfig[B2CTenant] + _appConfig[AbsoluteUriUser] + ForwardSlash + userEmailOrUserId + QuestionMark + _appConfig[APIVersion];
            }
            else if (urlType == UrlTypeUsernameSuggestion)
            {
                url = _appConfig[ADGraphEndpoint] + _appConfig[B2CTenant] + _appConfig[AbsoluteUriUser] + QuestionMark + _appConfig[APIVersion] + FilterWithusername + SingleQuote + userEmailOrUserId + SingleQuote + ClosingParenthesis;
            }


            return url;
        }

        /// <summary>
        /// Get Username
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        private string GetUsername(string data)
        {
            if (new JwtSecurityTokenHandler().CanReadToken(data) != true)
            {
                return string.Empty;
            }
            else
            {
                foreach (var c in new JwtSecurityTokenHandler().ReadJwtToken(data).Claims)
                {
                    if (c.Type == CtypeName)
                    {
                        return c.Value;
                    }
                }
                return string.Empty;
            }
        }

        /// <summary>
        /// Get Json
        /// </summary>
        /// <param name="dataContent"></param>
        /// <returns></returns>
        private JObject GetJsonObject(string dataContent) => JObject.Parse(dataContent);

        /// <summary>
        /// Sign Up Request
        /// </summary>
        /// <param name="signUpRequest"></param>
        /// <returns></returns>
        private RequestUserSignUp CreateUserRequestModel(CustomerProfile signUpRequest)
        {
            List<SignInNames> lstSignInNames = new List<SignInNames>();
            SignInNames signInNames = new SignInNames
            {
                type = _appConfig[SignInNamesTypeUserName],
                Value = signUpRequest.UserId
            };
            lstSignInNames.Add(signInNames);
            signInNames = new SignInNames
            {
                type = _appConfig[SignInNamesTypeEmail],
                Value = signUpRequest.EmailAddress
            };
            lstSignInNames.Add(signInNames);
            List<string> emaillst = new List<string>
            {
                signUpRequest.EmailAddress
            };
            return new RequestUserSignUp
            {
                AccountEnabled = _appConfig[AccEnabled],
                Country = signUpRequest.CountryCode,
                CreationType = _appConfig[CrType],
                DisplayName = signUpRequest.CompanyName,
                otherMails = emaillst,
                PasswordProfile = new PasswordProfile
                {
                    ForceChangePasswordNextLogin = _appConfig[ForceChangePasswordNextLogin],
                    Password = signUpRequest.Password
                },
                SignInNames = lstSignInNames,
                employeeId=signUpRequest.UserId
            };
        }

        /// <summary>
        /// Email
        /// </summary>
        /// <param name="email"></param>
        /// <returns></returns>
        private EmailRequest CreateEmailRequest(string email)
        {
            ToRecipients toRecip = new ToRecipients
            {
                EmailAddress = new EmailAddress
                {
                    Address = email
                }
            };
            List<ToRecipients> lstToRecipt = new List<ToRecipients>
            {
                toRecip
            };

            List<InternetMessageHeaders> lstIntMsgHeaders = new List<InternetMessageHeaders>();
            InternetMessageHeaders msgHeader = new InternetMessageHeaders
            {
                Name = "x-custom-header-group-name",
                Value = "Nevada"
            };
            lstIntMsgHeaders.Add(msgHeader);

            msgHeader = new InternetMessageHeaders
            {
                Name = "x-custom-header-group-id",
                Value = "NV001"
            };
            lstIntMsgHeaders.Add(msgHeader);
            return new EmailRequest
            {
                Message = new MessageDetails
                {
                    Subject = "Successfully Sign-Up UPS Account",
                    Body = new MessageBody
                    {
                        Content = "Welcome " + email + ", Your are successfully registered.",
                        ContentType = "Text"
                    },
                    ToRecipients = lstToRecipt
                    //IntMessageHeaders = lstIntMsgHeaders
                },
                SaveToSentItems = false
            };
        }

        /// <summary>
        /// Http request
        /// </summary>
        /// <param name="url"></param>
        /// <param name="httpMethod"></param>
        /// <param name="content"></param>
        /// <returns></returns>
        private async Task<HttpRequestMessage> CreateHttpReq(string url, HttpMethod httpMethod, string content)
        {
            if (!string.IsNullOrEmpty(content))
            {
                HttpRequestMessage request = new HttpRequestMessage(httpMethod, url);
                request.Headers.Authorization = new AuthenticationHeaderValue(SchemeBearer, await GetAT().ConfigureAwait(false));
                request.Content = new StringContent(content, Encoding.UTF8, MediaType);
                return request;
            }
            else
            {
                HttpRequestMessage request = new HttpRequestMessage(httpMethod, url);
                request.Headers.Authorization = new AuthenticationHeaderValue(SchemeBearer, await GetAT().ConfigureAwait(false));
                return request;
            }
        }

        /// <summary>
        /// Serialise Json
        /// </summary>
        /// <param name="obj"></param>
        /// <returns></returns>
        private string SerialiseJson(dynamic obj) => JsonConvert.SerializeObject(obj);

        /// <summary>
        /// Update failed attempt
        /// </summary>
        /// <param name="customer"></param>
        /// <returns></returns>
        private async Task<dynamic> UpdateFailedAttempted(CustomerProfile customer) => _repository.UpdateCustProfile(customer);

        /// <summary>
        /// Formay Error string
        /// </summary>
        /// <param name="resJson"></param>
        /// <returns></returns>
        private string FormatErrors(JObject resJson) => (string)resJson[ErrorHeader1][Level2Code] + SingleWhiteSpace + (string)resJson[ErrorHeader1][Level2Message][Value];

        /// <summary>
        /// Get access token
        /// </summary>
        /// <returns></returns>
        private async Task<string> GetAT() => (await _authContext.AcquireTokenAsync(_appConfig[ADGraphEndpoint], _credential).ConfigureAwait(false)).AccessToken;      

        /// <summary>
        /// update user details
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="jsonContent"></param>
        /// <returns></returns>
        private async Task<HttpResponseMessage> UpdateUserDetails(string userId, string jsonContent) => await _httpClientService.SendAsyncRequest(await CreateHttpReq(GetUrlByType(UrlTypeUpdateUser, userId), new HttpMethod(Patch), jsonContent)).ConfigureAwait(false);

        /// <summary>
        /// set secure code
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="sCode"></param>
        /// <returns></returns>
        private async Task<HttpResponseMessage> SetSecureCodeForUser(string userId, string sCode)
        {
            var custDetail = await _repository.GetCustomerProfile(userId).ConfigureAwait(false);
            custDetail.Results[0].OtpCode = sCode;
            _repository.UpdateCustProfile(custDetail.Results[0]);

            return new HttpResponseMessage
            {
                StatusCode = HttpStatusCode.OK
            };
        }

        /// <summary>
        /// Send Confirmation for signUp
        /// </summary>
        /// <param name="customerProfile"></param>
        private async void SendConfirmationEmailOnSignUp(CustomerProfile customerProfile)
        {
            VerifyEmail verifyEmail = new VerifyEmail
            {
                DisplayName = customerProfile.CompanyName,
                EmailId = customerProfile.EmailAddress,
                Username = customerProfile.UserId,
                VerificationCode = customerProfile.EmailVerificationCode
            };

            _messageService.SendVerificationEmailOnSignUp(verifyEmail);
        }

        /// <summary>
        /// Send Email Confirmation for change password
        /// </summary>
        /// <param name="customerProfile"></param>
        private async void SendEmailOnSuccessfulPswdReset(CustomerProfile customerProfile)
        {
            VerifyEmail verifyEmail = new VerifyEmail
            {
                DisplayName = customerProfile.CompanyName,
                EmailId = customerProfile.EmailAddress,
                Username = customerProfile.UserId
            };
            _messageService.CreateMessageContentForSuccessfulResetPswd(verifyEmail);
        }

        /// <summary>
        /// Block user
        /// </summary>
        /// <param name="userId"></param>
        public async void BlockUserAfterSignUp(string userId)
        {

            BlockUser((string)GetJsonObject(SerialiseJson(GetUserDetailsbyUsername(new CustId
            {
                CustomerId = userId
            })))[Result][ResponseData][Value][0][ObjectId]);
        }

        /// <summary>
        /// Username suggestion
        /// </summary>
        /// <param name="username"></param>
        /// <returns></returns>
        private async Task<dynamic> GetUsernameSuggestion(CustId username)
        {
            var response = await _httpClientService.SendAsyncRequest(await CreateHttpReq(GetUrlByType(UrlTypeUsernameSuggestion, username.CustomerId), HttpMethod.Get, string.Empty).ConfigureAwait(false)).ConfigureAwait(false);
            var res = GetJsonObject(await response.Content.ReadAsStringAsync().ConfigureAwait(false));

            var data = await response.Content.ReadAsStringAsync().ConfigureAwait(false);

            if (!response.IsSuccessStatusCode)
            {
                return new ResponseStatus
                {
                    errorMessage = FormatErrors(res),
                    status = Convert.ToInt16(response.StatusCode).ToString()
                };

            }
            else
            {
                List<string> lstOfUserNames = new List<string>();

                foreach (var list in res[Value])
                {
                    lstOfUserNames.Add(list[UsernameObj].ToString().ToLower());
                }
                if (lstOfUserNames.Count > 0)
                {
                    return GetUniqueUsernames(lstOfUserNames, username.CustomerId);
                }
                else
                {
                    lstOfUserNames.Add(UsernameIsAvailable);
                    return lstOfUserNames;
                }
            }
        }

        /// <summary>
        /// Get Unique Usernames
        /// </summary>
        /// <param name="lstUsernames"></param>
        /// <param name="userchoice"></param>
        /// <returns></returns>
        private List<string> GetUniqueUsernames(List<string> lstUsernames, string userchoice)
        {
            List<string> SuggestedUsernames = new List<string>();
            int nameAppender = 1;
            int counter = 1;

            while (counter <= 3)
            {
                bool chk = true;
                while (chk)
                {
                    var newUsername = userchoice + nameAppender;
                    if (!lstUsernames.Contains(newUsername.ToLower()))
                    {
                        SuggestedUsernames.Add(newUsername);
                        chk = false;
                        counter++;
                    }
                    nameAppender++;
                }

            }
            return SuggestedUsernames;
        }
        /// <summary>
        /// Get User Details by Username
        /// </summary>
        /// <param name="username"></param>
        /// <returns></returns>
        private async Task<dynamic> GetUserDetailsbyUsername(CustId username)
        {
            var response = await _httpClientService.SendAsyncRequest(await CreateHttpReq(GetUrlByType(UrlTypeUserDetailByUserId, username.CustomerId), HttpMethod.Get, string.Empty).ConfigureAwait(false)).ConfigureAwait(false);
            var res = GetJsonObject(await response.Content.ReadAsStringAsync().ConfigureAwait(false));
            if (!response.IsSuccessStatusCode)
            {
                return new ResponseModel
                {
                    responseStatus = new ResponseStatus
                    {
                        errorMessage = FormatErrors(res),
                        status = Convert.ToInt16(response.StatusCode).ToString()
                    }
                };
            }
            else
            {
                return new ResponseModel
                {
                    responseStatus = new ResponseStatus
                    {
                        status = Convert.ToInt16(response.StatusCode).ToString()
                    },
                    responseData = res
                };
            }
        }

        /// <summary>
        /// Generate Validation Code
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        private async Task<string> GenerateValidationCode(string userId)
        {
            var secureCode = GenerateRandomCode();
            await SetSecureCodeForUser(userId, secureCode + SingleQuote + (DateTime.Now.AddMinutes(Convert.ToDouble(_appConfig[OtpExpiryDuration])) - DateTime.MinValue).TotalMilliseconds).ConfigureAwait(false);
            return secureCode;
        }

        /// <summary>
        /// Generate Random Code For Email Verification
        /// </summary>
        /// <returns></returns>
        private string GenerateRandomCodeForEmailVerification()
        {
            return new string(Enumerable.Repeat(StringCombination, new Random().Next(51, 100))
              .Select(s => s[new Random().Next(s.Length)]).ToArray());
        }

        /// <summary>
        /// Generate Random Code
        /// </summary>
        /// <returns></returns>
        private string GenerateRandomCode()
        {
            var generator = new Random();
            return generator.Next(0, 999999).ToString("D6");
        }

        /// <summary>
        /// Initiate Forgot Password
        /// </summary>
        /// <param name="userDetail"></param>
        /// <returns></returns>
        public async Task<dynamic> InitiateForgotPassword(UserEmaiAndId userDetail)
        {
            try
            {
                var uDetail = GetJsonObject(SerialiseJson(GetUserDetailsbyUsername(new CustId
                {
                    CustomerId = userDetail.UserId
                })));
                var userEmail = (string)uDetail[Result][ResponseData][Value][0][UsrEmail][0];
                if (!string.IsNullOrEmpty(userEmail))
                {
                    if (userEmail == userDetail.EmailId)
                    {
                        _messageService.SendOtpForgotPassword(new VerifyEmail
                        {
                            DisplayName = (string)uDetail[Result][ResponseData][Value][0][DisplayName],
                            EmailId = userDetail.EmailId,
                            VerificationCode = await GenerateValidationCode(userDetail.UserId).ConfigureAwait(false)
                        });
                    }
                    else
                    {
                        return GetResponseModel(BadRequest, string.Empty, string.Empty, string.Empty);
                    }
                }
                else
                {
                    return GetResponseModel(BadRequest, string.Empty, string.Empty, string.Empty);
                }
                return GetResponseModel(Status200, string.Empty, string.Empty, string.Empty);
            }
            catch
            {
                return GetResponseModel(BadRequest, string.Empty, string.Empty, string.Empty);
            }
        }

        /// <summary>
        /// Get ResponseModel
        /// </summary>
        /// <param name="status"></param>
        /// <param name="errorMessage"></param>
        /// <returns></returns>
        private ResponseModel GetResponseModel(string status, string errorMessage, string sCode,string username)
        {
            return new ResponseModel
            {
                responseStatus = new ResponseStatus
                {
                    status = status,
                    errorMessage = errorMessage,
                    accessToken=sCode,
                    UserName=username
                }
            };
        }

        /// <summary>
        /// Block User
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        public async Task<dynamic> BlockUser(string userId)
        {
            var responseMessage = await UpdateUserDetails(userId, JsonConvert.SerializeObject(new AccountEnabledDisabled
            {
                AccountEnabled = false
            })).ConfigureAwait(false);
            return new HttpResponseMessage
            {
                StatusCode = HttpStatusCode.Unauthorized
            };
        }

        /// <summary>
        /// Get Otp Expiry Time
        /// </summary>
        /// <param name="otpTime"></param>
        /// <returns></returns>
        private DateTime GetOtpExpiryTime(string otpTime)
        {
            try
            {
                DateTime dt = DateTime.MinValue;
                return dt.AddMilliseconds(Convert.ToDouble((otpTime).Split(SingleQuote)[1]));
            }
            catch
            {
                DateTime dateTime = new DateTime();
                dateTime = DateTime.Now.AddDays(-1);
                return dateTime;
            }
        }

        /// <summary>
        /// Reset password
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="pswd"></param>
        /// <param name="sCode"></param>
        /// <returns></returns>
        private async Task<dynamic> ResetPassword(string userId, string pswd, string sCode)
        {
            if (!string.IsNullOrEmpty(userId) && !string.IsNullOrEmpty(sCode) && !string.IsNullOrEmpty(pswd))
            {
                var custDetail = await _repository.GetCustomerProfile(userId).ConfigureAwait(false);

                if (custDetail.Results[0].OtpCode == sCode)
                {                   
                    var responseMessage = await UpdateUserDetails((string)GetJsonObject(SerialiseJson(GetUserDetailsbyUsername(new CustId
                    {
                        CustomerId = userId
                    })))[Result][ResponseData][Value][0][ObjectId], JsonConvert.SerializeObject(new ResetPasswordRequest
                    {
                        PasswordProfile = new PasswordProfile
                        {
                            ForceChangePasswordNextLogin = _appConfig[ForceChangePasswordNextLogin],
                            Password = pswd
                        }
                    })).ConfigureAwait(false);
                    if (responseMessage.IsSuccessStatusCode)
                    {
                        UnBlockUser(userId).ConfigureAwait(false);
                        custDetail.Results[0].FailedLoginAttempt = 0;
                        custDetail.Results[0].OtpCode = GenerateRandomCodeForEmailVerification();
                        _repository.UpdateCustProfile(custDetail.Results[0]);
                        SendEmailOnSuccessfulPswdReset(custDetail.Results[0]);
                        return GetResponseModel(Convert.ToInt16(responseMessage.StatusCode).ToString(), string.Empty, string.Empty, string.Empty);
                    }
                    else
                    {
                        return GetResponseModel(Convert.ToInt16(responseMessage.StatusCode).ToString(), FailedUpdatePswd + FormatErrors(GetJsonObject(await responseMessage.Content.ReadAsStringAsync().ConfigureAwait(false))), string.Empty, string.Empty);
                    }
                }
                else
                {
                    return GetResponseModel(Status401, ErrMsgUnauthorized, string.Empty, string.Empty);
                }
            }
            else
            {
                return GetResponseModel(BadRequest, string.Empty, string.Empty, string.Empty);
            }
        }

        /// <summary>
        /// Verify OTP Reset Pswd
        /// </summary>
        /// <param name="requestResetPswd"></param>
        /// <returns></returns>
        public async Task<dynamic> VerifySCodeResetPswd(RequestResetPswd requestResetPswd)
        {
            if (!string.IsNullOrEmpty(requestResetPswd.UserId) && !string.IsNullOrEmpty(requestResetPswd.SecureCode))
            {
                var custDetail = await _repository.GetCustomerProfile(requestResetPswd.UserId).ConfigureAwait(false);
                if ((int)GetOtpExpiryTime(custDetail.Results[0].OtpCode).Subtract(DateTime.Now).TotalMinutes > 0)
                {
                    if (UserBlockTillTimeForWrongPIN(custDetail.Results[0].PinAttemptBlockedTillTime))
                    {
                        if ((custDetail.Results[0].OtpCode).Split(SingleQuote)[0] == requestResetPswd.SecureCode)
                        {
                            var sCode = GenerateRandomCodeForEmailVerification();
                            custDetail.Results[0].OtpCode = sCode;
                            custDetail.Results[0].FailedPinAttempt = 0;
                            _repository.UpdateCustProfile(custDetail.Results[0]);

                            return GetResponseModel(Status200, string.Empty, sCode, string.Empty);
                        }
                        else
                        {
                            var pinFAtp = ++custDetail.Results[0].FailedPinAttempt;
                            if (pinFAtp >= Convert.ToInt16(_appConfig[NoOfAttemptsForgotPswdPin]))
                            {
                                custDetail.Results[0].PinAttemptBlockedTillTime = DateTime.Now.AddMinutes(Convert.ToDouble(_appConfig[TimeInMinutesPinVerificationBlocked]));
                                custDetail.Results[0].FailedPinAttempt = 0;
                                _repository.UpdateCustProfile(custDetail.Results[0]);
                                return GetResponseModel(Status401, ErrInvalidOtp, string.Empty, string.Empty);
                            }
                            else
                            {
                                _repository.UpdateCustProfile(custDetail.Results[0]);
                                return GetResponseModel(BadRequest, ErrInvalidOtp, (Convert.ToInt16(_appConfig[NoOfAttemptsForgotPswdPin]) - pinFAtp).ToString() + AttemptsLeft, string.Empty);
                            }
                        }
                    }
                    else
                    {
                        return GetResponseModel(Status401, ErrPinBlocked, string.Empty, string.Empty);
                    }
                }
                else
                {
                    return GetResponseModel(BadRequest, ErrInvalidOtp, string.Empty, string.Empty);
                }
            }
            else
            {
                return GetResponseModel(BadRequest, ErrInvalidOtp, string.Empty, string.Empty);
            }
        }

        /// <summary>
        /// to verify if PIN is blocked
        /// </summary>
        /// <param name="dt"></param>
        /// <returns></returns>
        private bool UserBlockTillTimeForWrongPIN(DateTime dt)
        {
            try
            {
                if (dt.Subtract(DateTime.Now).TotalMinutes > 0)
                {
                    return false;
                }
                else
                {
                    return true;
                }
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        /// Get Username Suggestions
        /// </summary>
        /// <param name="username"></param>
        /// <returns></returns>
        public Task<dynamic> GetUsernameSuggestions(CustId username)
        {
            return GetUsernameSuggestion(username);
        }

        /// <summary>
        /// Update Display Name
        /// </summary>
        /// <param name="request"></param>
        public async void UpdateDisplayName(UpdateDisplayNameRequest request)
        {
            var jsonObj = GetJsonObject(SerialiseJson(GetUserDetailsbyUsername(new CustId
            {
                CustomerId = request.UserId
            })));

            _httpClientService.SendAsyncRequest(await CreateHttpReq(GetUrlByType(UrlTypeUpdateUser, (string)jsonObj[Result][ResponseData][Value][0][ObjectId]), new HttpMethod(Patch), JsonConvert.SerializeObject(new DisplayNameRequest
            {
                DisplayName = request.DisplayName,
                EmailAddress = request.EmailAddress
            })).ConfigureAwait(false)).ConfigureAwait(false);
        }

        /// <summary>
        /// UnBlock User
        /// </summary>
        /// <param name="userId"></param>
        /// <returns></returns>
        private async Task<dynamic> UnBlockUser(string userId)
        {
            return await UpdateUserDetails((string)GetJsonObject(SerialiseJson(GetUserDetailsbyUsername(new CustId
            {
                CustomerId = userId
            })))[Result][ResponseData][Value][0][ObjectId], JsonConvert.SerializeObject(new AccountEnabledDisabled
            {
                AccountEnabled = true
            })).ConfigureAwait(false);
        }

        /// <summary>
        /// Verify User Using Email
        /// </summary>
        /// <param name="uid"></param>
        /// <param name="verificationCode"></param>
        /// <returns></returns>
        public async Task<dynamic> VerifyUserUsingEmail(string uid, string verificationCode)
        {
            var custDetail = await _repository.GetCustomerProfile(uid).ConfigureAwait(false);
            if (custDetail.Results[0].EmailVerificationCode == verificationCode)
            {
                UnBlockUser(uid);
                custDetail.Results[0].EmailVerificationCode = string.Empty;
                _repository.UpdateCustProfile(custDetail.Results[0]);
                return new HttpResponseMessage
                {
                    StatusCode = HttpStatusCode.OK
                };
            }
            return new HttpResponseMessage
            {
                StatusCode = HttpStatusCode.Unauthorized
            };
        }

        /// <summary>
        /// public method ref for reset forgot password
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public Task<dynamic> ResetForgotPswd(RequestResetPswd request)
        {
            return ResetPassword(request.UserId, request.NewPassword, request.SecureCode);
        }
    }
}
