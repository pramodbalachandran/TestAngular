﻿using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using Bonsai.Azure.CosmosDb.Models;
using Customer.Core.Entities.Abstract;
using Customer.Core.Services;
using Customer.Infrastructure.Data.Repositories;

namespace Customer.Infrastructure.Services
{
    public abstract class BaseService<T> : IBaseService<T> where T: class, IEntity
    {
        protected readonly IRepository<T> Repository;

        protected BaseService(IRepository<T> repository)
        {
            Repository = repository;

        }

        protected BaseService()
        {

        }

        public virtual Task<T> Get(Guid id)
        {
            Task<T> mytask = Repository.Get(id);
            return mytask;
        }

        public virtual Task<ISearchResult<T>> GetAll()
        {
            //filter => filter.Category == "A"
            Task<ISearchResult<T>> result = Repository.Get(filter => 1 == 1, new SearchModel {
                PageSize = 20
            });
            return result;
        }

        public virtual Task<ISearchResult<T>> Query(Expression<Func<T, bool>> filter)
        {
            Task<ISearchResult<T>> result = Repository.Get(filter, new SearchModel());
            return result;
        }

        public virtual Task Remove(Guid id)
        {
            return Repository.Delete(id);
        }

        public virtual Task<T> Add(T item)
        {
            return Repository.Upsert(item);
        }

        public virtual Task<T> Update(T item)
        {
            return Repository.Upsert(item);
        }
    }
}
