﻿using System;
using System.Collections.Generic;
using System.Text;

using Microsoft.Extensions.DependencyInjection;

namespace Customer.Infrastructure.Extensions
{
    using Configuration;
    using Core.Config;

    public static class ServiceCollectionExtension
    {
        public static IServiceCollection AddInfrastructureServices(this IServiceCollection services)
        {
            services.AddTransient<IConfig, Config>();
            //services.AddTransient<INormalizedDataService, NormalizedDataService>();
            return services;
        }
    }
}
