﻿using System;
using System.Collections.Generic;
using System.Text;
using AutoMapper;
using Customer.Core.Entities;
using Customer.Core.Entities.Dtos;

namespace Customer.Infrastructure.Maps
{
    public class TaskMaps : Profile
    {
        public TaskMaps()
        {
            CreateMap<MyTask, MyTaskDto>();
            CreateMap<MyTaskDto, MyTask>();
        }
    }
}
