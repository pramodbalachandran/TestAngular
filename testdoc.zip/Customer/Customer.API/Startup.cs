﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Autofac;
using Autofac.Extensions.DependencyInjection;
using AutoMapper;
using Customer.Core.Config;
using Customer.Core.Entities;
using Customer.Core.Repositories;
using Customer.Core.Services;
using Customer.Framework.Attributes;
using Customer.Infrastructure.Configuration;
using Customer.Infrastructure.Data;
using Customer.Infrastructure.Data.Configuration;
using Customer.Infrastructure.Data.Repositories;
using Customer.Infrastructure.Services;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Azure.Documents;
using Microsoft.Azure.Documents.Client;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Swashbuckle.AspNetCore.Swagger;

namespace Customer.API
{
    using Customer.Framework.Helpers.EmailUtility;
    using Filters;
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }
        public IContainer ApplicationContainer { get; private set; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public IServiceProvider ConfigureServices(IServiceCollection services)
        {
            //services.AddHttpContextAccessor();
            //services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();
            services.AddCors();
            services.AddMvc(option =>
            {
                option.Filters.Add<AuthenticateAttribute>();
                option.Filters.Add<ErrorHandlerAttribute>();
                option.Filters.Add<CustomerActionAttribute>();
            });

            services.AddSwaggerGen(c => 
            {
                //c.DescribeAllEnumsAsStrings();
                c.SwaggerDoc("v1", new Info
                {
                    Version = "v1",
                    Title = "Bonsai API",
                    Description = "This new version of the Bonsai API has been created to reflect the changing approach to managing pricing data in UPS.  Initially version set to 1.0"
                });
                c.DocumentFilter<CustomDocumentFilter>();
                //var basePath = AppContext.BaseDirectory;
                //var xmlPath = Path.Combine(basePath, "Customer.API.xml");
                //c.IncludeXmlComments(xmlPath);
            });

            services.AddAutoMapper(typeof(Startup));
            services.AddOptions();
            services.Configure<Config>(options => Configuration.GetSection("ConfigSettings").Bind(options));
            services.Configure<DbConfig>(options => Configuration.GetSection("DbConfigSettings").Bind(options));

            var builder = new ContainerBuilder();
            builder.Populate(services);
            builder = RegisterComponents(builder);
            this.ApplicationContainer = builder.Build();

            return new AutofacServiceProvider(this.ApplicationContainer);

            /*
            services.AddSingleton<IConfiguration>(Configuration);
            services.AddSingleton<IConfig, Config>();
            services.AddSingleton<IDbConfig, DbConfig>();

            services.AddScoped<AuthenticateAttribute>();
            services.AddScoped<ErrorHandlerAttribute>();
            services.AddScoped<PricingActionAttribute>();
            */
        }

        public ContainerBuilder RegisterComponents(ContainerBuilder builder)
        {
            builder.RegisterInstance(Configuration).As<IConfiguration>().SingleInstance();
            builder.RegisterType<Config>().As<IConfig>().SingleInstance();
            builder.RegisterType<DbConfig>().As<IDbConfig>().SingleInstance();

            builder.RegisterType<AuthenticateAttribute>().InstancePerRequest();
            builder.RegisterType<ErrorHandlerAttribute>().InstancePerRequest();
            builder.RegisterType<CustomerActionAttribute>().InstancePerRequest();

            builder.RegisterType<TaskRepository>().As<IRepository<MyTask>>().InstancePerLifetimeScope();
            builder.RegisterType<TaskAuthRepository>().As<IAuthRepositories<MyTask>>().InstancePerLifetimeScope();
            builder.RegisterType<TaskService>().As<ITaskService>().InstancePerLifetimeScope();
            builder.RegisterType<CustomerAuthService>().As<ICustomerAuthservice>().InstancePerLifetimeScope();
            builder.RegisterType<HttpClientService>().As<IHttpClientService>().InstancePerLifetimeScope();


            builder.RegisterType<MessageService>().As<IMessageService>().InstancePerLifetimeScope();
            builder.RegisterType<EmailServiceUtility>().As<IEmailServiceUtility>().InstancePerLifetimeScope();

            builder.RegisterType<HttpContextAccessor>().As<IHttpContextAccessor>().InstancePerLifetimeScope();

            DbConfig dbConfig = Configuration.GetSection("DbConfigSettings").Get<DbConfig>();
            builder.RegisterInstance(new DocumentClient(new Uri(dbConfig.DocumentDbEndpointUrl),
                dbConfig.DocumentDbPrimaryKey)).As<IDocumentClient>().SingleInstance();

            return builder;
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, 
                        IHostingEnvironment env, 
                        IApplicationLifetime appLifetime)
        {
            app.UseCors(builder => builder.WithOrigins("http://localhost:6420").AllowAnyHeader().AllowAnyMethod());
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseMvc(routes =>
            {
                routes.MapRoute(
                    name: "NamedAction",
                    template: "{controller}/Named/{action}/{id?}"
                    );
                routes.MapRoute(
                    name: "default",
                    template: "{controller}/{id}");
            });

            app.UseSwagger()
            .UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "Bonsai API");
            });

            var httpContextAccessor = app.ApplicationServices.GetService<IHttpContextAccessor>();
            CustomerContext.HttpContextAccessor = httpContextAccessor;
            appLifetime.ApplicationStopped.Register(() => this.ApplicationContainer.Dispose());
        }
    }
}
