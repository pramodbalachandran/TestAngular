﻿using System.Threading.Tasks;
using AutoMapper;
using Bonsai.Azure.CosmosDb.Models;
using Customer.Core.Entities;
using Customer.Core.Entities.Dtos;
using Customer.Core.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;

namespace Customer.API.Controllers
{
    [AllowAnonymous]
    [Route("api/[controller]")]
    public class TaskController : ResourceController<MyTaskDto, MyTask>
    {
        private readonly ITaskService _taskService;
        private readonly ICustomerAuthservice _custAuthService;
        private readonly IMapper _mapper;

        public TaskController(ITaskService service, IMapper mapper,ICustomerAuthservice custAuthService)
            : base(service, mapper)
        {
            _taskService = service;
            _mapper = mapper;
            _custAuthService = custAuthService;

        }
        
        [HttpPost]
        [Route("RequestForAssociatedUserIds")]
        public Task<dynamic> RequestForAssociatedUserIds([FromBody] UserEmail emailId)
        {
           return _custAuthService.GetUsernameLinkedToEmailRequest(emailId);
        }

        [HttpPost]
        [Route("RecoverMyId")]
        public object RequestToRecoverMyId([FromBody] UserEmail emailId)
        {
            var listOfIds = _taskService.GetAllAssociatedIds(emailId.EmailId);

            return _taskService.SendEmailWithAllAssociatedIds(listOfIds, emailId.EmailId);
        }

        [HttpGet]
        [Route("VerifyEmail")]
        public void VerifyEmail([FromQuery] string vc,string uid)
        {
             _custAuthService.VerifyUserUsingEmail(uid, vc);
        }

        /// <summary>
        /// Get customer profile based on user
        /// </summary>
        /// <param name="custId"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("GetCustomerProfile")]
        public Task<ISearchResult<CustomerProfile>> GetCustProfile([FromBody] CustId customerDetails)
        {
            return _taskService.GetCustomerProfile(customerDetails.CustomerId);
        }

        /// <summary>
        /// Get upser profile based on user
        /// </summary>
        /// <param name="custId"></param>
        /// <returns></returns>
        [HttpPost]
        [Route("GetUpserProfile")]
        public Task<ISearchResult<UpserProfile>> GetUpserProfile([FromBody] CustId customerDetails)
        {
            return _taskService.GetUpserProfile(customerDetails.CustomerId);
        }

        [HttpPost]
        [Route("AddShippingAddr")]
        public Task<ShipingAddress> AddCustShippingAddresses([FromBody] ShipingAddress shipingAddress)
        {
            return _taskService.AddShippingAddress(shipingAddress);
        }

        [HttpPost]
        [Route("CustShipAddress")]
        public Task<ISearchResult<ShipingAddress>> GetCustShippingAddresses([FromBody] CustId custId)
        {
            return _taskService.GetCustomersshippingAddress(custId.CustomerId);
        }

        [HttpPost]
        //[Route("UpdateShipAddr")]
        public Task<ShipingAddress> UpdateCustShippingAddresses([FromBody] ShipingAddress shipingAddress)
        {
            return _taskService.UpdateShippingAddress(shipingAddress);
        }

        [HttpPost]
        [Route("UpdateCustomerProfile")]
        public Task<CustomerProfile> UpdateCustomerProfile([FromBody] CustomerProfile customerProfile)
        {
            _custAuthService.UpdateDisplayName(new UpdateDisplayNameRequest
            {
                DisplayName = customerProfile.CompanyName,
                UserId = customerProfile.UserId,
                EmailAddress = customerProfile.EmailAddress
            });
            return _taskService.UpdateCustomerProfile(customerProfile);
        }

        [HttpPost]
        [Route("UpdateUpserProfile")]
        public Task<UpserProfile> UpdateUpserProfile([FromBody] UpserProfile upserProfile)
        {
            return _taskService.UpdateUpserProfile(upserProfile);
        }

        [HttpPost]
        [Route("AddContactDetails")]
        public Task<ContactSettings> AddContactDetails([FromBody] ContactSettings contactDetails)
        {
            return _taskService.AddContact(contactDetails);
        }

        [HttpPost]
        [Route("GetContacts")]
        public Task<ISearchResult<ContactSettings>> GetContactdetails([FromBody] CustId custId)
        {
            return _taskService.GetCustomersContacts(custId.CustomerId);
        }

        [HttpPost]
        [Route("UpdateContact")]
        public Task<ContactSettings> UpdateContactdetails([FromBody] ContactSettings contactDetails)
        {
            return _taskService.UpdateContact(contactDetails);
        }

        [HttpPost]
        [Route("CreateUser")]
        public Task<ResponseModel> CreateNewCustomer([FromBody] CustomerProfile signUpRequest)
        {
            Task<ResponseModel> response = _custAuthService.SendCreateUserRequest(signUpRequest);
            if (response.Result.responseStatus.status == "200" || response.Result.responseStatus.status == "201")
            {
                _custAuthService.BlockUserAfterSignUp(signUpRequest.UserId);
                signUpRequest.EmailVerificationCode = response.Result.responseStatus.accessToken;
                _taskService.CreateCustomerProfle(signUpRequest);
            }
            return response;
        }

        /// <summary>
        /// Create upser profile on DB
        /// </summary>
        /// <param name="upserProfile">Request data with the newly logged in upser</param>
        [HttpPost]
        [Route("CreateUpser")]
        public Task<ResponseModel> CreateNewUpser([FromBody] UpserProfile upserProfile)
        {
            Task<ResponseModel> response = _taskService.CreateUpserProfle(upserProfile);
            return response;
        }

        [HttpPost]
        [Route("EmailMyUserIds")]
        public Task<dynamic> EmailMyUserIdsLinkedWithEmail([FromBody] UserEmail userEmail) => _custAuthService.GetUsernameLinkedToEmailRequest(userEmail);

        [HttpPost]
        [Route("GetUsernameSuggestion")]
        public Task<dynamic> UsernameSuggestions([FromBody] CustId userId) => _custAuthService.GetUsernameSuggestions(userId);

        [HttpPost]
        [Route("ForgotPassword")]
        public Task<dynamic> ForgotPasswordInitiated([FromBody] UserEmaiAndId userDetail) => _custAuthService.InitiateForgotPassword(userDetail);

        [HttpPost]
        [Route("VerifyFPCode")]
        public Task<dynamic> VerifySecureCodeToResetPassword([FromBody] RequestResetPswd request) => _custAuthService.VerifySCodeResetPswd(request);

        [HttpPost]
        [Route("ResetPswd")]
        public Task<dynamic> ResetForgotPassword([FromBody] RequestResetPswd request) => _custAuthService.ResetForgotPswd(request);

        [HttpPost]
        [Route("ValidateUser")]
        public Task<ResponseStatus> ValidateUserSignIn([FromBody] RequestSignIn signUpRequest) => _custAuthService.AuthenticateUser(signUpRequest);  
    }
}
