﻿using System;
using System.Collections.Generic;
//using AutoMapper;
using Customer.Core.Entities;
using Customer.Core.Entities.Dtos;
using Customer.Core.Security;
using Customer.Core.Services;

using Microsoft.AspNetCore.Mvc;

namespace Customer.API.Controllers
{
    using AutoMapper;
    using Bonsai.Azure.CosmosDb.Models;
    using Core.Entities.Abstract;
    using System.Threading.Tasks;

    public abstract class ResourceController<T, K> : Controller
        where T : IDto
		where K : IEntity
	{
		protected readonly IBaseService<K> Service;
        private readonly IMapper _mapper;

        /// <summary>
        /// Constructor method
        /// </summary>
        /// <param name="service"></param>
		protected ResourceController(IBaseService<K> service, IMapper mapper)
		{
			Service = service;
            _mapper = mapper;

        }

        protected ResourceController()
        {

        }

        /// <summary>
        /// Method used to filtering data
        /// </summary>
        /// <returns></returns>
		[HttpGet]
		public virtual async Task<ISearchResult<T>> GetAll()
		{
            return _mapper.Map<ISearchResult<T>>(await Service.GetAll());
		}

        /// <summary>
        /// Method used to get data by ID
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
		[HttpPost]
		public virtual T Get(Guid id)
		{
			var item = Service.Get(id);
			return _mapper.Map<T>(item);
		}

        /// <summary>
        /// Method used to Save data
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
		[HttpPost]
		public virtual T Add(T entity)
		{
			var item = _mapper.Map<K>(entity);
			var result = Service.Add(item);
			return _mapper.Map<T>(result);
		}

        /// <summary>
        /// Method used to delete data by ID
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
		[HttpDelete]
		public virtual bool Delete(Guid id)
		{
			return Remove(id);
		}

        /// <summary>
        /// Method used to remove data by ID
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        [HttpDelete]
        private bool Remove(Guid id)
		{
			//if (id == 0) return false;
			//var entity = Service.Get(id);
			Service.Remove(id);
			return true;
		}

        /// <summary>
        /// Method used to Update table
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
		[HttpPut]
		public virtual T Update(T entity)
		{
			//var systemEntity = Service.Get(entity.Id);
            //_mapper.Map(entity, systemEntity);
			//Service.Update(systemEntity);
            //return _mapper.Map<T>(systemEntity);

            var item = _mapper.Map<K>(entity);
            var result = Service.Update(item);
            return _mapper.Map<T>(result);

		}
	}
}
