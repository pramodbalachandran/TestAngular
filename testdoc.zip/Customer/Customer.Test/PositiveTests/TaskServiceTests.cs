﻿using System;
using System.Collections.Generic;
using Xunit;
using Moq;
using Customer.Infrastructure.Data.Repositories;
using Customer.Infrastructure.Services;
using Customer.Core.Entities;
using Customer.Core.Services;
using Bonsai.Azure.CosmosDb.Models;
using System.Threading.Tasks;
using Customer.Core.Entities.Dtos;
using System.Net;

namespace Customer.Test.PositiveTests
{
    public class TaskServiceTests
    {
        #region Private Members
        private const string _dummyContactNam = "Dummy Name";
        private const string _dummuUserId = "DummyId001";
        private const string _dummyCompanyNam = "ABC Test Company";
        private const string _dummyUserNam = "upser";
        private const string _dummyCity = "New York";
        private const string _dummyAddress1 = "Test Address 1";
        private const string _dummyAddress2 = "Address Line 2";
        private const string _dummyCountry = "UK";
        private const string _dummyUserId = "DumyId001";
        private const string _DummyMailMsg = "Mail sent successfully";
        private const string _dummyDate1 = "05/25/2018";
        private const string _dummyUid1 = "UPS12000543";
        private const string _duumDate2 = "06/15/2018";
        private const string _dummyUid2 = "UPS11000667";
        private readonly TaskService _taskService;
        private readonly Mock<IRepository<MyTask>> _taskRepository;
        private readonly Mock<IMessageService> _messageService;
        private readonly Mock<Microsoft.Extensions.Configuration.IConfiguration> _appConfig;        

        #endregion
        public TaskServiceTests()
        {
            _taskRepository = new Mock<IRepository<MyTask>>();
            _messageService = new Mock<IMessageService>();
            _appConfig = new Mock<Microsoft.Extensions.Configuration.IConfiguration>();
            _taskService = new TaskService(_taskRepository.Object, _messageService.Object, _appConfig.Object);

            ContactSettings contDetails = new ContactSettings
            {
                Id = new Guid(),
                ContactName = _dummyContactNam,
                UserId = _dummuUserId
            };
            ShipingAddress shipAdd = new ShipingAddress
            {
                Id = new Guid(),
                AddressLine1 = _dummyAddress1,
                AddressLine2 = _dummyAddress2,
                PoliticalDivision1Name = _dummyCity,
                CountryName = _dummyCountry,
                UserId = _dummyUserId
            };
            CustomerProfile custP = new CustomerProfile
            {
                Id = new Guid(),
                CompanyName = _dummyCompanyNam,
                BillingCity = _dummyCity
            };
            UpserProfile upserProf = new UpserProfile
            {
                Id = new Guid(),
                BusinessPartyName = _dummyUserNam
            };
            ISearchResult<UpserProfile> srUpserProf = new SearchResult<UpserProfile>
            {
                Results = new List<UpserProfile>()
            };
            ISearchResult<CustomerProfile> srCustProf = new SearchResult<CustomerProfile>
            {
                Results = new List<CustomerProfile>()
            };
            ISearchResult<ShipingAddress> srShipAddr = new SearchResult<ShipingAddress>
            {
                Results = new List<ShipingAddress>()
            };
            ISearchResult<ContactSettings> srContDetails = new SearchResult<ContactSettings>
            {
                Results = new List<ContactSettings>()
            };
            srContDetails.Results.Add(contDetails);
            srShipAddr.Results.Add(shipAdd);
            srCustProf.Results.Add(custP);
            srUpserProf.Results.Add(upserProf);
            _taskRepository.Setup(tr => tr.AddContact(It.IsAny<ContactSettings>())).Returns(Task.FromResult(contDetails));
            _taskRepository.Setup(tr => tr.AddShippingAddress(It.IsAny<ShipingAddress>())).Returns(Task.FromResult(shipAdd));
            _taskRepository.Setup(tr => tr.GetCustomerProfile(It.IsAny<string>())).Returns(Task.FromResult(srCustProf));
            _taskRepository.Setup(tr => tr.GetUpserProfile(It.IsAny<string>())).Returns(Task.FromResult(srUpserProf));
            _taskRepository.Setup(tr => tr.GetCustomersContacts(It.IsAny<string>())).Returns(Task.FromResult(srContDetails));
            _taskRepository.Setup(tr => tr.GetCustomersshippingAddress(It.IsAny<string>())).Returns(Task.FromResult(srShipAddr));
            _taskRepository.Setup(tr => tr.UpdateContact(It.IsAny<ContactSettings>())).Returns(Task.FromResult(contDetails));
            _taskRepository.Setup(tr => tr.UpdateCustProfile(It.IsAny<CustomerProfile>())).Returns(Task.FromResult(custP));
            _taskRepository.Setup(tr => tr.UpdateUpserProfile(It.IsAny<UpserProfile>())).Returns(Task.FromResult(upserProf));
        }

        [Fact]
        public void TestAddContact()
        {
            var response = _taskService.AddContact(It.IsAny<ContactSettings>());
            Assert.NotNull(response);
            Assert.IsType<ContactSettings>(response.Result);
            Assert.Contains(new Guid().ToString(), response.Result.Id.ToString());
        }

        [Fact]
        public void TestUpdateContactDetails()
        {
            var response = _taskService.UpdateContact(It.IsAny<ContactSettings>());
            Assert.NotNull(response);
            Assert.IsType<ContactSettings>(response.Result);
            Assert.Contains(new Guid().ToString(), response.Result.Id.ToString());
        }

        [Fact]
        public void TestAddShippingAddress()
        {
            var response = _taskService.AddShippingAddress(It.IsAny<ShipingAddress>());
            Assert.NotNull(response);
            Assert.IsType<ShipingAddress>(response.Result);
            Assert.Contains(new Guid().ToString(), response.Result.Id.ToString());
        }

        [Fact]
        public void TestGetShippingAddress()
        {
            var response = _taskService.GetCustomersshippingAddress(It.IsAny<string>());
            Assert.NotEmpty(response.Result.Results);
            Assert.IsType<SearchResult<ShipingAddress>>(response.Result);
            Assert.Contains(response.Result.Results[0].AddressLine1, _dummyAddress1);
        }

        [Fact]
        public void GetCustomerProfileTest()
        {
            var response = _taskService.GetCustomerProfile(It.IsAny<string>());
            Assert.NotEmpty(response.Result.Results);
            Assert.IsType<SearchResult<CustomerProfile>>(response.Result);
            Assert.Contains(response.Result.Results[0].CompanyName, _dummyCompanyNam);
        }

        [Fact]
        public void GetUpserProfileTest()
        {
            var response = _taskService.GetUpserProfile(It.IsAny<string>());
            Assert.NotEmpty(response.Result.Results);
            Assert.IsType<SearchResult<UpserProfile>>(response.Result);
            Assert.Contains(response.Result.Results[0].BusinessPartyName, _dummyUserNam);
        }

        [Fact]
        public void UpdateCustomerProfileTest()
        {
            var response = _taskService.UpdateCustomerProfile(It.IsAny<CustomerProfile>());
            Assert.NotNull(response);
            Assert.IsType<CustomerProfile>(response.Result);
            Assert.Contains(new Guid().ToString(), response.Result.Id.ToString());
        }

        [Fact]
        public void TestGetContactDetails()
        {
            var response = _taskService.GetCustomersContacts(It.IsAny<string>());
            Assert.NotEmpty(response.Result.Results);
            Assert.IsType<SearchResult<ContactSettings>>(response.Result);
            Assert.Contains(response.Result.Results[0].ContactName, _dummyContactNam);
        }

        [Fact]
        public void CreateUpserProfleTest()
        {
            UpserProfile upserProf = new UpserProfile
            {
                Id = new Guid(),
                BusinessPartyName = _dummyUserNam,
                BusinessPartyNumber = _dummyUserNam,
                UserId = _dummyUserNam
            };
            var response = _taskService.CreateUpserProfle(upserProf);
            Assert.NotNull(response);
            Assert.IsType<ResponseModel>(response.Result);
            Assert.Equal(Convert.ToInt16(HttpStatusCode.Created).ToString(), response.Result.responseStatus.status.ToString());
        }

        [Fact]
        public void UpdateUpserProfileTest()
        {
            var response = _taskService.UpdateUpserProfile(It.IsAny<UpserProfile>());
            Assert.NotNull(response);
            Assert.IsType<UpserProfile>(response.Result);
            Assert.Contains(new Guid().ToString(), response.Result.Id.ToString());
        }
    }
}
