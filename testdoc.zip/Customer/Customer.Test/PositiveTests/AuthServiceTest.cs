﻿using System;
using System.Collections.Generic;
using System.Text;
using Xunit;
using Moq;
using Customer.Core.Services;
using Customer.Infrastructure.Services;
using Customer.Core.Entities;
using System.Net.Http;
using System.Net;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using Customer.Infrastructure.Data.Repositories;
using Bonsai.Azure.CosmosDb.Models;

namespace Customer.Test.PositiveTests
{
    public class AuthServiceTest
    {
        #region private members
        private readonly IConfiguration _appConfig;
        private readonly Mock<IMessageService> _messageService;
        private readonly Mock<IAuthRepositories<MyTask>> _authRepo;
        private readonly CustomerAuthService _authService;
        private readonly Mock<IHttpClientService> _httpClientService;
        private readonly CustomerProfile _signUpRequest;
        private const string _dummyCompanyNam = "ABC Test Company";
        private const string _dummyCity = "New York";
        #endregion
        public AuthServiceTest()
        {
            IConfigurationBuilder configurationBuilder = new ConfigurationBuilder();
            configurationBuilder.AddJsonFile("appsettings.json");
            _appConfig = configurationBuilder.Build();
            _messageService = new Mock<IMessageService>();
            _authRepo = new Mock<IAuthRepositories<MyTask>>();
            _httpClientService = new Mock<IHttpClientService>();
            _authService = new CustomerAuthService(_appConfig, _messageService.Object, _httpClientService.Object,_authRepo.Object);
            _signUpRequest = new CustomerProfile
            {
                CompanyName = "UPS",
                ContactName = "Test User1",
                AccountNumber = "UPS098456FF",
                ContactType = "Company",
                Password = "Test@1234",
                CountryCode = "India",
                PhoneNumber = "9876543254",
                Extension = "001",
                EmailAddress = "test@test.com",
                UserId = "test1",
                TermsAccepted = true
            };
            StringContent obj = new StringContent("{\"value\":[{\"objectId\":\"111ABC\",\"extension_d860aa645e344dcab1faa983cedbdc33_UserSecureOTP\":\"123456'"+ (DateTime.Now.AddMinutes(1000) - DateTime.MinValue).TotalMilliseconds + "\",}],\"responseData\":{\"odata.metadata\":\"https://graph.windows.net/BonsaiB2cTenantQA.onmicrosoft.com/$metadata#directoryObjects/Microsoft.DirectoryServices.User/@Element\",\"odata.type\":\"Microsoft.DirectoryServices.User\",\"objectType\":\"User\",\"objectId\":\"085b81db-b5d7-4f93-a6cc-14b138c2f5cd\",\"deletionTimestamp\":null,\"accountEnabled\":true,\"ageGroup\":null,\"assignedLicenses\":[],\"assignedPlans\":[],\"city\":null,\"companyName\":null,\"consentProvidedForMinor\":null,\"country\":\"India\",\"createdDateTime\":null,\"creationType\":\"LocalAccount\",\"department\":null,\"dirSyncEnabled\":null,\"displayName\":\"Amit Singh Tomar\",\"employeeId\":null,\"facsimileTelephoneNumber\":null,\"givenName\":null,\"immutableId\":null,\"isCompromised\":null,\"jobTitle\":null,\"lastDirSyncTime\":null,\"legalAgeGroupClassification\":null,\"mail\":null,\"mailNickname\":\"fe0f6030-1e64-445c-a730-ce39be149b59\",\"mobile\":null,\"onPremisesDistinguishedName\":null,\"onPremisesSecurityIdentifier\":null,\"otherMails\":[\"amit.tomar@ust-global.com\"],\"passwordPolicies\":null,\"passwordProfile\":null,\"physicalDeliveryOfficeName\":null,\"postalCode\":null,\"preferredLanguage\":null,\"provisionedPlans\":[],\"provisioningErrors\":[],\"proxyAddresses\":[],\"refreshTokensValidFromDateTime\":\"2018-11-09T08:29:20.6377115Z\",\"showInAddressList\":null,\"signInNames\":[{\"type\":\"userName\",\"value\":\"ast111\"}],\"sipProxyAddress\":null,\"state\":null,\"streetAddress\":null,\"surname\":null,\"telephoneNumber\":null,\"usageLocation\":null,\"userIdentities\":[],\"userPrincipalName\":\"fe0f6030-1e64-445c-a730-ce39be149b59@BonsaiB2cTenantQA.onmicrosoft.com\",\"userState\":null,\"userStateChangedOn\":null,\"userType\":\"Member\"},\"responseStatus\":{\"status\":\"201\",\"errorMessage\":\"Created\",\"UserName\":null,\"accessToken\":null},\"requestId\":\"79584128\"}");    //("{\"value\":[{\"objectId\":\"111ABC\"}],\"responseData\":{\"odata.metadata\":\"https://graph.windows.net/BonsaiB2cTenantQA.onmicrosoft.com/$metadata#directoryObjects/Microsoft.DirectoryServices.User/@Element\",\"odata.type\":\"Microsoft.DirectoryServices.User\",\"objectType\":\"User\",\"objectId\":\"085b81db-b5d7-4f93-a6cc-14b138c2f5cd\",\"deletionTimestamp\":null,\"accountEnabled\":true,\"ageGroup\":null,\"assignedLicenses\":[],\"assignedPlans\":[],\"city\":null,\"companyName\":null,\"consentProvidedForMinor\":null,\"country\":\"India\",\"createdDateTime\":null,\"creationType\":\"LocalAccount\",\"department\":null,\"dirSyncEnabled\":null,\"displayName\":\"Amit Singh Tomar\",\"employeeId\":null,\"facsimileTelephoneNumber\":null,\"givenName\":null,\"immutableId\":null,\"isCompromised\":null,\"jobTitle\":null,\"lastDirSyncTime\":null,\"legalAgeGroupClassification\":null,\"mail\":null,\"mailNickname\":\"fe0f6030-1e64-445c-a730-ce39be149b59\",\"mobile\":null,\"onPremisesDistinguishedName\":null,\"onPremisesSecurityIdentifier\":null,\"otherMails\":[\"amit.tomar@ust-global.com\"],\"passwordPolicies\":null,\"passwordProfile\":null,\"physicalDeliveryOfficeName\":null,\"postalCode\":null,\"preferredLanguage\":null,\"provisionedPlans\":[],\"provisioningErrors\":[],\"proxyAddresses\":[],\"refreshTokensValidFromDateTime\":\"2018-11-09T08:29:20.6377115Z\",\"showInAddressList\":null,\"signInNames\":[{\"type\":\"userName\",\"value\":\"ast111\"}],\"sipProxyAddress\":null,\"state\":null,\"streetAddress\":null,\"surname\":null,\"telephoneNumber\":null,\"usageLocation\":null,\"userIdentities\":[],\"userPrincipalName\":\"fe0f6030-1e64-445c-a730-ce39be149b59@BonsaiB2cTenantQA.onmicrosoft.com\",\"userState\":null,\"userStateChangedOn\":null,\"userType\":\"Member\"},\"responseStatus\":{\"status\":\"201\",\"errorMessage\":\"Created\",\"UserName\":null,\"accessToken\":null},\"requestId\":\"79584128\"}");

            HttpResponseMessage response = new HttpResponseMessage
            {
                StatusCode = HttpStatusCode.OK,
               Content=obj
            };
            _httpClientService.Setup(htp => htp.SendAsyncRequest(It.IsAny<HttpRequestMessage>())).Returns(Task.FromResult(response));
            CustomerProfile custP = new CustomerProfile
            {
                Id = new Guid(),
                CompanyName = _dummyCompanyNam,
                BillingCity = _dummyCity
            };
            ISearchResult<CustomerProfile> srCustProf = new SearchResult<CustomerProfile>
            {
                Results = new List<CustomerProfile>()
            };
            srCustProf.Results.Add(custP);
            _authRepo.Setup(r => r.GetCustomerProfile(It.IsAny<string>())).Returns(Task.FromResult(srCustProf));
        }

        [Fact]
        public void TestAddNewCustomer()
        {
            var response = _authService.SendCreateUserRequest(_signUpRequest);
            Assert.NotNull(response);
        }


        [Fact]
        public void TestAuthenticateUser()
        {
            var response = _authService.AuthenticateUser(new RequestSignIn
            {
                Username = "TestUser",
                Password = "password123"
            });
            Assert.NotNull(response);
        }

        [Fact]
        public void TestInitiateForgotPassword()
        {
            var response = _authService.InitiateForgotPassword(new UserEmaiAndId
            {
                UserId = "UserId1",
                EmailId=It.IsAny<string>()
            });
            Assert.NotNull(response);
        }

        [Fact]
        public void TestVerifySCodeResetPswd()
        {
            var response = _authService.VerifySCodeResetPswd(new RequestResetPswd
            {
                UserId = "UserId1",
                NewPassword="newPassword",
                SecureCode="123456"
            });
            Assert.NotNull(response);
        }
    }
}
