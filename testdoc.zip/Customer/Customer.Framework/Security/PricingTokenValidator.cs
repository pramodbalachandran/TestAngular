﻿using System;
using System.Linq;
using System.Security.Claims;
using Microsoft.Extensions.Logging;

namespace Customer.Framework.Security
{
	using Core.Entities;
	using Core.Repositories;
	using Core.Security;

	public class PricingTokenValidator : ITokenValidator
	{
		private readonly ILogger _logger;
		private readonly ICoreRepository<User> _userRepository;

		public PricingTokenValidator(ICoreRepository<User> userRepository, ILoggerFactory loggerFactory)
		{
			_userRepository = userRepository;
			_logger = loggerFactory.CreateLogger("Customer.Framework.Security.PricingTokenValidator");
		}

        public ClaimsPrincipal ValidateUser(string email)
        {
            try
            {
                User currentUser = _userRepository.Query(u => u.EmailAddress == email).FirstOrDefault();

                if (currentUser == null)
                {
                    return null;
                }

                var customerPrincipal = new PricingPrincipal(currentUser);
                var identity = new ClaimsIdentity("userid");
                identity.AddClaim(new Claim(ClaimTypes.NameIdentifier, currentUser.UserToken, null, "userid"));
                identity.AddClaim(new Claim(ClaimTypes.Name, currentUser.FirstName));

                customerPrincipal.AddIdentity(identity);

                return customerPrincipal;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.ToString());
                return null;
            }
        }
 	}
}