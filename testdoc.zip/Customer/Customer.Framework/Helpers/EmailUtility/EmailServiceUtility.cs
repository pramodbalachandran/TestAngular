﻿using Customer.Core.Entities;
using System;
using System.Net;
using System.Net.Mail;
using Microsoft.Extensions.Configuration;
using Customer.Core.Services;
using Customer.Core.Entities.Dtos;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Reflection;
using SendGrid;
using SendGrid.Helpers.Mail;

namespace Customer.Framework.Helpers.EmailUtility
{
    public class EmailServiceUtility : IEmailServiceUtility
    {
        private const string SmtpHost = "SmtpServerSettings:SmtpHost";
        private const string SmtpUserId = "SmtpServerSettings:Id";
        private const string SmtpPassword = "SmtpServerSettings:Pswd";
        private const string EmailTemplatePath = @"Helpers\EmailUtility\EmailTemplate.txt";
        private const string EmaimBodyRef = "emb_e2dB0dy_ups_em1l";
        private readonly IConfiguration _appConfig;

        public EmailServiceUtility(IConfiguration appConfig)
        {
            _appConfig = appConfig;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="message"></param>
        /// <returns></returns>
        public object SendMail(EmailMessage message, bool isHtmlBody)
        {
            try
            {
                SmtpClient client = new SmtpClient(_appConfig[SmtpHost])
                {
                    UseDefaultCredentials = false,
                    Credentials = new NetworkCredential(_appConfig[SmtpUserId], _appConfig[SmtpPassword])
                };

                MailMessage mailMessage = new MailMessage
                {
                    From = new MailAddress(message.FromAddress)
                };
                foreach (var toAdd in message.ToAddress)
                {
                    mailMessage.To.Add(toAdd);
                }
                mailMessage.Body = GenerateEmailTemplateWithMessageBody(message.MsgBody);
                mailMessage.Subject = message.MsgSubject;
                mailMessage.IsBodyHtml = isHtmlBody;
                client.Send(mailMessage);

                return new Dictionary<string, string>() {

                        { "Message", "Mail sent successfully"}
                };

            }
            catch (Exception ex)
            {
                //Todo add log for failure
                throw ex;
            }
        }

        /// <summary>
        /// Send Mail Using SendGrid
        /// </summary>
        /// <param name="message"></param>
        /// <param name="emailId"></param>
        /// <param name="displayName"></param>
        /// <param name="sub"></param>
        public async void SendMailUsingSendGrid(string message, string emailId, string displayName, string sub)
        {
            var client = new SendGridClient(_appConfig["SendGridSettings:SendGridApiKey"]);
            var from = new SendGrid.Helpers.Mail.EmailAddress(_appConfig["EmailSettings:BonsaiSupportEmail"], _appConfig["EmailSettings:BonsaiSupport"]);
            var subject = sub;
            var to = new SendGrid.Helpers.Mail.EmailAddress(emailId, displayName);
            var plainTextContent = string.Empty;
            var messageBodyhtmlContent = GenerateEmailTemplateWithMessageBody(message);
            var msg = MailHelper.CreateSingleEmail(from, to, subject, plainTextContent, messageBodyhtmlContent);
            var response = client.SendEmailAsync(msg);
        }

        /// <summary>
        /// Generate Message body
        /// </summary>
        /// <param name="messageBody"></param>
        /// <returns></returns>
        private string GenerateEmailTemplateWithMessageBody(string messageBody)
        {
            return File.ReadAllText(Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), EmailTemplatePath), Encoding.UTF8).Replace(EmaimBodyRef, messageBody);
        }
    }
}
