﻿using System;
using System.Linq;
using System.ComponentModel;
using System.Collections.Generic;

namespace Customer.Framework.Extensions
{    
    public static class EnumExtensions
	{
		public static object ValueToUnderlyingType(this Enum e)
		{
			return Convert.ChangeType(e, Enum.GetUnderlyingType(e.GetType()));
		}

		public static string ToIntString(this Enum e)
		{
			return e.ValueToUnderlyingType().ToString();
		}

		public static bool IsDefined(this Enum e)
		{
			return Enum.IsDefined(e.GetType(), e);
		}

		public static int[] ToIntArray(this Enum e)
		{
			return e.ToString().Split(new[] { ',' }).Select(x => (int)Enum.Parse(e.GetType(), x)).ToArray();
		}

		public static string[] ToStringArray(this Enum e)
		{
			return e.ToString().Split(new[] { ',' });
		}

        public static string ToFriendlyEnum(this string value)
        {
            char[] chars = value.ToCharArray();
            string output = String.Empty;

            for (int i = 0; i < chars.Length; i++)
            {
                if (i <= 0 || chars[i - 1].ToString() != chars[i - 1].ToString().ToUpper() && chars[i].ToString() != chars[i].ToString().ToLower())
                {
                    output += " ";
                }

                output += chars[i];
            }

            return output.Trim();
        }


        public static TAttribute GetAttribute<TAttribute>(this Enum parameterInfo) where TAttribute : Attribute
        {
            object[] attributes = parameterInfo.GetType().GetField(parameterInfo.ToString()).GetCustomAttributes(typeof(TAttribute), false);
            return attributes.Length > 0 ? (TAttribute)attributes[0] : null;
        }

        public static bool HasAttribute<TAttribute>(this Enum parameterInfo) where TAttribute : Attribute
        {
            return parameterInfo.GetType().GetField(parameterInfo.ToString()).GetCustomAttributes(typeof(TAttribute), false).Length > 0;
        }

        public static string ToFriendlyEnum(this Enum type)
        {
            return type.HasAttribute<DescriptionAttribute>() ? type.GetAttribute<DescriptionAttribute>().Description : type.ToString().ToFriendlyEnum();
        }

        public static void ForEach<T>(this IEnumerable<T> enumeration, Action<T> action)
        {
            foreach (T item in enumeration)
            {
                action(item);
            }
        }
    }
}
