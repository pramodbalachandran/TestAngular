﻿using System.Net;
using System.Net.Http;
using System.Web.Http.Controllers;
using System.Web.Http.Filters;


namespace Navistar.EDL.Framework.Attributes
{
    using Newtonsoft.Json;
    using Core.Logging;
    using System.Linq;
    using Core.Exceptions;
    using Navistar.EDL.Framework.Helpers;
    using Constants;

    public class ValidateModelAttribute : ActionFilterAttribute
	{
        private readonly ILogger _logger;
        public ValidateModelAttribute()
        {
            _logger = Logger.GetLogger("Navistar.EDL.Framework.Attributes.EDLActionAttribute");
        }
        public override void OnActionExecuting(HttpActionContext actionContext)
		{
            //if (!actionContext.ModelState.IsValid)
            //{
            //    actionContext.Response = actionContext.Request.CreateErrorResponse(HttpStatusCode.BadRequest,actionContext.ModelState);
            //}
            //  SQL Injecttion
            if (actionContext.Request.Method == HttpMethod.Post || actionContext.Request.Method == HttpMethod.Get) 
            {
                var requestData = actionContext.ActionArguments;
                string[] Blacklist = { "' or", "' and"," drop table "," delete from " };
                string requestJson = JsonConvert.SerializeObject(requestData, Formatting.Indented, new JsonSerializerSettings { ReferenceLoopHandling = ReferenceLoopHandling.Ignore });

                if (Blacklist.Any(requestJson.ToLower().Contains))
                {
                    _logger.Write(Core.Logging.EventSeverity.Debug, actionContext.ActionDescriptor.ActionName + " User Attempted SQL Injection");
                    throw new BusinessValidationException("Invalid Data - Sql Injection Attack");
                }
            }
        }
	}
}
