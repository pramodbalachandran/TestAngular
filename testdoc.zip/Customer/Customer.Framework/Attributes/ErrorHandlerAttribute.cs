﻿using System;
using System.Net;
using System.Net.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Http;

namespace Customer.Framework.Attributes
{
    using ContentTypes;
    using Helpers;
    using Core.Constants;
    using Core.Exceptions;
    using Core.Entities.Dtos;

    public class ErrorHandlerAttribute : ExceptionFilterAttribute
    {
        private readonly ILogger _logger;

        public ErrorHandlerAttribute(ILoggerFactory loggerFactory)
        {
            _logger = loggerFactory.CreateLogger("Customer.Framework.Attributes.ErrorHandlerAttribute");
        }

        public override void OnException(ExceptionContext exceptionContext)
        {
            
            if (exceptionContext.Exception != null)
            {
                _logger.LogError(exceptionContext.Exception.ToString());
                exceptionContext.Result = GetResponse(exceptionContext);
            }
        }

        /// <summary>
        /// Exception details
        /// ------------------
        /// 400 - bad request- all bussiness validation exceptions
        /// 401 - If not authorized
        /// 500 - Internal server error- can be due to json structure missmatch
        /// 200 - success
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        private IActionResult GetResponse(ExceptionContext context)
        {

            HttpStatusCode status = HttpStatusCode.InternalServerError;
            String message = String.Empty;
            String responseData = "Internal Server Error";

            var exceptionType = context.Exception.GetType();
            if (exceptionType == typeof(BusinessValidationException))
            {
                var validationException = context.Exception as BusinessValidationException;
                responseData = validationException.Message;
                status = HttpStatusCode.BadRequest;
            }
            else if (exceptionType == typeof(DataValidationException))
            {
                var validationException = context.Exception as DataValidationException;
                responseData = validationException.Message;
                status = HttpStatusCode.NotAcceptable;
            }
            else
            {
                responseData = "Internal Server Error";
                status = HttpStatusCode.InternalServerError;
            }
            message = context.Exception.ToString();
            context.ExceptionHandled = true;

            JsonResponseDto responseDto = new JsonResponseDto()
            {
                responseData = responseData,
                responseStatus = new ResponseStatus
                {
                    status = ((int)status).ToString(),
                    errorMessage = message
                }
            };
            return new JsonResult(responseDto);
        }
    }
}
