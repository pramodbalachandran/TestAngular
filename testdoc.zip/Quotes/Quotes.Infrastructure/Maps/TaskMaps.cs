﻿using System;
using System.Collections.Generic;
using System.Text;
using AutoMapper;
using Quotes.Core.Entities;
using Quotes.Core.Entities.Dtos;

namespace Quotes.Infrastructure.Maps
{
    public class TaskMaps : Profile
    {
        public TaskMaps()
        {
            CreateMap<MyTask, MyTaskDto>();
            CreateMap<MyTaskDto, MyTask>();
        }
    }
}
