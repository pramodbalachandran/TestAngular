﻿using Microsoft.AspNetCore.Http;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Blob;
using Quotes.Core.Entities;
using Quotes.Core.Services;
using System;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace Quotes.Infrastructure.Services
{
    public class FileTransferService: IFileTransferService
    {
        private CloudStorageAccount _storageAccount;
        private CloudBlobClient _blobClient;
        private CloudBlobContainer _blobContainer;
        private CloudBlockBlob _blockBlob;
        private string _storageConnectionString = "DefaultEndpointsProtocol=https;AccountName=bonsaistoragedev;AccountKey=EDnNrlE/C6HS0Ng3nxsoAY3WHew00jk4EAurykD5rpM77k3F7MQNJ+L/UqFZLQwhBgaioh04ZOPPS/QOKUSw0w==;EndpointSuffix=core.windows.net";
        private const string ContainerName = "bonsaicontainer";

        /// <summary>
        /// Upload file to blob and returns the path
        /// </summary>
        /// <param name="file"></param>
        /// <returns></returns>
        public async Task<QuoteAttachment[]> FileUpload(IFormFile file)
        {
            try
            {
                if (CloudStorageAccount.TryParse(_storageConnectionString, out _storageAccount))
                {
                    string fileContents = ReadFile(file);

                    string name = new string(file.FileName.TakeWhile(c => c != '.').ToArray());
                    string extension = new string(file.FileName.SkipWhile(c => c != '.').Skip(1).ToArray());
                    string fileName = name + DateTime.Now.ToString("-yyyy-dd-M-HH-mm-ss.") + extension;

                    _blobClient = _storageAccount.CreateCloudBlobClient();
                    _blobContainer = _blobClient.GetContainerReference(ContainerName);
                    await _blobContainer.CreateIfNotExistsAsync().ConfigureAwait(false);
                    _blockBlob = _blobContainer.GetBlockBlobReference(fileName);

                    await _blockBlob.UploadTextAsync(fileContents).ConfigureAwait(false);
                                       
                    QuoteAttachment[] attachmentReference = new QuoteAttachment[] { new QuoteAttachment { FileName = fileName, FilePathName = _blockBlob.Uri.ToString() } };

                    return attachmentReference;
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        /// <summary>
        /// Download file belonging to the specified quote ID, from the blob
        /// </summary>
        /// <param name="quoteId">quote Id</param>
        /// <returns></returns>
        public async Task<Stream> FileDownload(string filename)
        {
            try
            {
                if (CloudStorageAccount.TryParse(_storageConnectionString, out _storageAccount))
                {
                    _blobClient = _storageAccount.CreateCloudBlobClient();
                    _blobContainer = _blobClient.GetContainerReference(ContainerName);
                    _blockBlob = _blobContainer.GetBlockBlobReference(filename);//todo - read from DB and get the actual file name wrt the quote id

                    string downloadedContentsStr = await _blockBlob.DownloadTextAsync().ConfigureAwait(false);
                    Stream downloadedContents = new MemoryStream();
                    await _blockBlob.DownloadToStreamAsync(downloadedContents).ConfigureAwait(false);

                    return downloadedContents;
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        /// <summary>
        /// Read from the file stream and convert to string
        /// </summary>
        /// <param name="file">contents of the file</param>
        /// <returns>string output of file contents</returns>
        private string ReadFile(IFormFile file)
        {
            var result = string.Empty;
            using (var reader = new StreamReader(file.OpenReadStream()))
            {
                result = reader.ReadToEnd();
            }

            return result;
        }
    }
}
