﻿using Quotes.Core.Constants;
using Quotes.Core.Entities;
using Quotes.Core.Enums;
using System;
using System.Collections.Generic;
using System.Text;

namespace Quotes.Infrastructure.Services
{
   public class QuotesService
    {
        private const string PrefixB = "B";
        private const string DateFormatForQuote = "yyyyMMddhhmmss";

        public QuoteData GenerateQuoteRequest(QuoteData quoteData)
        {
            QuoteData formattedQuoteData = quoteData;
            formattedQuoteData.QuoteTypeDescriptionText = Enum.GetName(typeof(QuotesType), formattedQuoteData.QuoteTypeCode);
            
            //formattedQuoteData.QuoteRequestDate = quoteData.QuoteRequestDate ?? null;
            formattedQuoteData.AccountNumber = quoteData.BusinessPartyNumber.ToLower();
            formattedQuoteData.QuoteStatusDescriptionText = Enum.GetName(typeof(QuotesStatus), formattedQuoteData.QuoteStatusCode);
            if (string.IsNullOrEmpty(formattedQuoteData.QuoteNumber))
            {
                formattedQuoteData.QuoteNumber = GenerateQuoteNumber(formattedQuoteData.QuoteTypeDescriptionText);
                formattedQuoteData.QuoteRequestDate = DateTime.Now.ToString();
            }
            if (string.IsNullOrEmpty(formattedQuoteData.QuoteRequestDate))
            {
                formattedQuoteData.QuoteRequestDate = DateTime.Now.ToString();
            }
                formattedQuoteData.QuoteStatusUpdateDate = DateTime.Now.ToString();
            // formattedQuoteData.Id = Guid.NewGuid();

            formattedQuoteData.QuoteIdentificationNumber = formattedQuoteData.QuoteNumber;
            formattedQuoteData = AddQuoteRequestData(formattedQuoteData);
            return formattedQuoteData;

        }

        public AirFreightShipmentDetail GenerateShipmentRequest(AirFreightShipmentDetail shipmentDetails)
        {
            AirFreightShipmentDetail formattedShipmentDetails = shipmentDetails;
            formattedShipmentDetails.MovementTypeDescriptionText = Enum.GetName(typeof(MovementType), formattedShipmentDetails.MovementTypeCode);
            formattedShipmentDetails = AddShipmentRequestData(formattedShipmentDetails);

            return formattedShipmentDetails;

        }
        string GenerateQuoteNumber(string quoteTypeDescriptionText)
        {
            return PrefixB + DateTime.Now.ToString(DateFormatForQuote); ;
        }

        QuoteData AddQuoteRequestData(QuoteData quoteData)
        {
            quoteData.DocType = QuoteDocumentType.DocTypeQuotes;
            quoteData.DocId = QuoteDocumentType.DocTypeQuotes + "::" + quoteData.QuoteIdentificationNumber + "::" + quoteData.BusinessPartyName + "::" + quoteData.BusinessPartyNumber;
            quoteData.DocStructureVersion = 1;
            quoteData.PartitionKey = quoteData.DocType;
            return quoteData;

        }

        AirFreightShipmentDetail AddShipmentRequestData(AirFreightShipmentDetail shipmentDetails)
        {
            shipmentDetails.DocType = QuoteDocumentType.DocTypeAirFreightShipmentDetail;
            shipmentDetails.ShipmentDetailIdentificationNumber = QuotesConsts.ShipmentDetailIdentificationNumber + DateTime.Now.ToString("MMddyyyyhhmmss");
            shipmentDetails.DocId = QuoteDocumentType.DocTypeAirFreightShipmentDetail + "::" + shipmentDetails.ShipmentDetailIdentificationNumber;
                
            shipmentDetails.DocStructureVersion = 1;
            shipmentDetails.PartitionKey = QuoteDocumentType.DocTypeQuotes;
            return shipmentDetails;

        }
        /// <summary>
        /// To save the origin/destnation address in customer's profile
        /// </summary>
        /// <param name="customerId"></param>
        /// <param name="shipmentDetails"></param>
        /// <returns></returns>
        public ShipingAddress GetOriginShippingAddress( AirFreightShipmentDetail shipmentDetails)
        {
            ShipingAddress shippingAddress = new ShipingAddress();
            shippingAddress.AddressLine1 = shipmentDetails.originAddressLine1Text;
            shippingAddress.AddressLine2 = shipmentDetails.originAddressLine2Text;
            shippingAddress.AddressLine3 = shipmentDetails.originAddressLine3Text;
            shippingAddress.CountryCode = shipmentDetails.OriginLocationCountryCode;
            shippingAddress.PoliticalDivision2Name = shipmentDetails.OriginLocationPoliticalDivsion2Code;
            shippingAddress.PoliticalDivision1Code = shipmentDetails.OriginPoliticalDivision1Name;
            shippingAddress.PostalCode= shipmentDetails.OriginLocationPostalCode;

            return shippingAddress;
        }
        public ShipingAddress GetDestinationShippingAddress( AirFreightShipmentDetail shipmentDetails)
        {
            ShipingAddress shippingAddress = new ShipingAddress();
            shippingAddress.AddressLine1 = shipmentDetails.DestinationAddressLine1Text;
            shippingAddress.AddressLine2 = shipmentDetails.DestinationAddressLine2Text;
            shippingAddress.AddressLine3 = shipmentDetails.DestinationAddressLine3Text;
            shippingAddress.CountryCode = shipmentDetails.DestinationLocationCountryCode;
            shippingAddress.PoliticalDivision2Name = shipmentDetails.DestinationLocationPoliticalDivsion2Code;
            shippingAddress.PoliticalDivision1Code = shipmentDetails.DestinationPoliticalDivision1Name;
            shippingAddress.PostalCode = shipmentDetails.DestinationLocationCountryCode;
            return shippingAddress;
        }
    }
}
