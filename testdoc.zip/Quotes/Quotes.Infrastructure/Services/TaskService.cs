﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using Bonsai.Azure.CosmosDb.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Quotes.Core.Entities;
using Quotes.Core.Entities.Dtos;
using Quotes.Core.Enums;
using Quotes.Core.Services;
using Quotes.Infrastructure.Data.Repositories;

namespace Quotes.Infrastructure.Services
{
    public class TaskService : BaseService<MyTask>, ITaskService
    {
        private const string ConfirmDetailPage = "14";
        private const string QuoteStatusNotSubmitted = "Not Submitted";
        private const string QuoteStatusForDb = "NotSubmitted";
        private const string InternalServerError = "500";
        private const string RequestSuccess = "200";
        private const string QuoteDuplicated = "Successfully duplicated quoute";
        private const string V = "Request failed.";
        private const string SuccessMessage = "Success";
        private const string AwaitingUPSResponse = "Awaiting UPS Response";
        private const string StatusSuccess = "200";
        private const int Completed = 2;
        private const int Declined = 4;
        private const int Accepted = 5;
        private const string ErrMsgInvalidData = "Invalid quote data.";
        private const string StatusBadRequest = "400";
        private const string ServiceTypeEC = "EC";
        private const string ServiceTypeCA = "CA";
        private const string ValueZero = "0.0";
        private const string L1 = "responseData";
        private const string L2 = "routeService";
        private const string U45AF = "u45OriginalAf";
        private const string O45AF = "o45OriginalAf";
        private const string O100AF = "o100OriginalAf";
        private const string O500AF = "o500OriginalAf";
        private const string RouteServCode = "routeServiceCode";
        private readonly IRepository<MyTask> _taskRepository;
        private readonly IFileTransferService _fileTransferService;
        QuotesService quoteService = new QuotesService();
        private readonly IE2KServices _e2kService;

        public TaskService(IRepository<MyTask> repository, IFileTransferService fileTransferService, IE2KServices e2kService) : base(repository)
        {
            _taskRepository = repository;
            _fileTransferService = fileTransferService;
            _e2kService = e2kService;
        }

        public void CreateTask()
        {
            MyTask task = new MyTask
            {
                Version = 1,
                Name = "Task 1",
                Category = "A",
                CreatedDate = DateTime.Today
            };
            Repository.Upsert(task);
            task = new MyTask
            {
                Version = 1,
                Name = "Task 2",
                Category = "A",
                CreatedDate = DateTime.Today
            };
            Repository.Upsert(task);
        }
        /// <summary>
        /// Method used to save the quote data
        /// </summary>
        /// <params>QuoteDataRequest</params>
        /// <returns>QuoteData</returns>
        public JsonResponseDto SaveQuoteForLater(QuoteDataRequest quoteDataRequest)
        {
            if (quoteDataRequest != null)
            {

                QuoteData quoteData = quoteDataRequest.QuoteRequestData;

                quoteData = quoteService.GenerateQuoteRequest(quoteData);

                bool continueToken = true;
                do
                {
                    var resDelete = _taskRepository.DeleteDuplicateShipmentDetails("select * from c WHERE c.docType=\"airFreightShipmentDetail\" and c.quoteIdentificationNumber=\"" + quoteData.QuoteIdentificationNumber + "\"");
                    continueToken = resDelete.Result.ContinuationToken;
                } while (continueToken);
                foreach (var shipmentDetail in quoteDataRequest.LstShipmentDetail)
                {
                    //Get the shipment details
                    AirFreightShipmentDetail shipmentDetails = shipmentDetail;
                    shipmentDetails = quoteService.GenerateShipmentRequest(shipmentDetails);

                    shipmentDetails.QuoteIdentificationNumber = quoteData.QuoteIdentificationNumber;
                    //Save shipment data
                    AirFreightShipmentDetail savedShipmentDetails = _taskRepository.SaveAirFreightShipmentDetail(shipmentDetails);
                    //Get the customer profile information if customer choose to save th shipment address in the profile.
                    if (shipmentDetails.ShipmentOriginAddressProfileSaveIndicator || shipmentDetails.ShipmentDestinationAddressProfileSaveIndicator)
                    {
                        var customerDetails = _taskRepository.GetCustomerProfile(quoteData.BusinessPartyNumber).Result.Results[0];
                        //Get the shipping address list
                        if (customerDetails != null)
                        {
                            List<ShipingAddress> shippingAddressList = customerDetails.ShippingAddress.ToList();
                            //To save the origin address in Customer profile
                            if (shipmentDetails.ShipmentOriginAddressProfileSaveIndicator)
                            {
                                var originShipmentAddress = quoteService.GetOriginShippingAddress(shipmentDetails);

                                //Check for duplicate
                                if (!shippingAddressList.Exists(item => item.AddressLine1.ToLower() == originShipmentAddress.AddressLine1.ToLower() &&
                                                                      item.AddressLine2.ToLower() == originShipmentAddress.AddressLine2.ToLower() &&
                                                                      item.AddressLine3.ToLower() == originShipmentAddress.AddressLine3.ToLower() &&
                                                                      item.PoliticalDivision2Name.ToLower() == originShipmentAddress.PoliticalDivision2Name.ToLower() &&
                                                                      item.CountryCode.ToLower() == originShipmentAddress.CountryCode.ToLower() &&
                                                                      item.PoliticalDivision1Code.ToLower() == originShipmentAddress.PoliticalDivision1Code.ToLower() &&
                                                                      item.PostalCode.ToLower() == originShipmentAddress.PostalCode.ToLower()
                                                                     ))

                                    shippingAddressList.Add(originShipmentAddress);



                            }

                            //To save the destination address in Customer Profile
                            if (shipmentDetails.ShipmentDestinationAddressProfileSaveIndicator)
                            {
                                var destShipmentAddress = quoteService.GetDestinationShippingAddress(shipmentDetails);
                                //Check for duplicate
                                if (!shippingAddressList.Exists(item => item.AddressLine1.ToLower() == destShipmentAddress.AddressLine1.ToLower() &&
                                                                      item.AddressLine2.ToLower() == destShipmentAddress.AddressLine2.ToLower() &&
                                                                      item.AddressLine3.ToLower() == destShipmentAddress.AddressLine3.ToLower() &&
                                                                      item.PoliticalDivision2Name.ToLower() == destShipmentAddress.PoliticalDivision2Name.ToLower() &&
                                                                      item.CountryCode.ToLower() == destShipmentAddress.CountryCode.ToLower() &&
                                                                      item.PoliticalDivision1Code.ToLower() == destShipmentAddress.PoliticalDivision1Code.ToLower() &&
                                                                      item.PostalCode.ToLower() == destShipmentAddress.PostalCode.ToLower()
                                                                     ))
                                    shippingAddressList.Add(destShipmentAddress);

                            }
                            customerDetails.ShippingAddress = shippingAddressList.ToArray();
                            //Save the customer profile
                            _taskRepository.UpdateCustProfile(customerDetails);
                        }

                    }
                }
                QuoteData savedQuoteData = _taskRepository.SaveQuoteForLater(quoteData);
                var responseData = new
                {
                    quoteDetailsId = savedQuoteData.Id,
                    quoteNumber = savedQuoteData.QuoteNumber
                };
                JsonResponseDto saveQuoteResponse = new JsonResponseDto()
                {
                    responseData = responseData,
                    responseStatus = new ResponseStatus
                    {
                        status = RequestSuccess,
                        message = SuccessMessage
                    }
                };
                return saveQuoteResponse;
            }
            else
            {
                return new JsonResponseDto
                {
                    responseStatus = new ResponseStatus
                    {
                        message = ErrMsgInvalidData,
                        status = StatusBadRequest
                    }
                };
            }

        }

        public Task<QuoteDataRequest> GetQuoteDetails(string quoteNumber)
        {
            Task<QuoteDataRequest> GFFList= _taskRepository.GetQuoteDetails(quoteNumber);
            if(GFFList!=null&& GFFList.Result!=null && GFFList.Result.LstShipmentDetail.Count >0)
            {
                foreach (var shipmentDetail in GFFList.Result.LstShipmentDetail)
                {
                    string countryCode = shipmentDetail.OriginLocationCountryCode;
                    if (countryCode != "0" && !string.IsNullOrEmpty(countryCode))
                    {
                        Task<QuoteRootLocation> GFFLocation = _taskRepository.Getquotedatacountrynames(countryCode);
                        if (GFFLocation.Result != null)
                        {
                            shipmentDetail.OriginLocationCountryName = GFFLocation.Result.countryName;
                        }
                    }
                    countryCode = shipmentDetail.DestinationLocationCountryCode;
                    if (countryCode != "0" && !string.IsNullOrEmpty(countryCode))
                    {
                        Task<QuoteRootLocation> GFFLocationDes = _taskRepository.Getquotedatacountrynames(countryCode);
                        if (GFFLocationDes.Result != null)
                        {
                            shipmentDetail.DestinationLocationCountryName = GFFLocationDes.Result.countryName;
                        }
                    }
                }
            }

            return GFFList;
        }

        public Task<ISearchResult<CommodityTypeList>> GetCommodityTypeList()
        {
            return _taskRepository.GetCommodityTypeList();
        }

        public Task<ISearchResult<QuoteData>> GetQuoteList(string accountNumber)
        {
            Task<ISearchResult<QuoteData>> resp = _taskRepository.GetQuoteList(accountNumber);
            resp.Result.Results.Where(item => item.QuoteStatusCode == 1).ToList().ForEach(item => item.QuoteStatusDescriptionText = QuoteStatusForDb);
            foreach (var quotes in resp.Result.Results)
            {
                if (quotes.QuoteStatusCode == 1)
                {
                    quotes.QuoteStatusDescriptionText = QuoteStatusNotSubmitted;
                }
                else if (quotes.QuoteStatusCode == 7)
                {
                    quotes.QuoteStatusDescriptionText = AwaitingUPSResponse;
                }
            }
            return resp;
        }

        /// <summary>
        /// To get the existing commodity item
        /// </summary>
        /// <param></param>
        /// <returns>CommodityTypeList</returns>
        public Task<CommodityNames> GetCommodityNameList(string accountNumber)
        {
            return _taskRepository.GetCommodityNameList(accountNumber);
        }

        /// <summary>
        /// Upload file
        /// </summary>
        /// <param name="file"></param>
        /// <returns>QuoteAttachment info</returns>
        public string FileUpload(IFormFile file)
        {
            Task<QuoteAttachment[]> attachmentInfo = _fileTransferService.FileUpload(file);
            return attachmentInfo.Result[0].FilePathName;
        }

        /// <summary>
        /// Create Duplicate Quote
        /// </summary>
        /// <param name="quoteNumber"></param>
        /// <returns></returns>
        public async Task<ResponseModel> CreateDuplicateQuote(string quoteNumber)
        {
            var quoteDetail = await _taskRepository.GetQuoteDetails(quoteNumber).ConfigureAwait(false);
            quoteDetail.QuoteRequestData.QuoteNumber = string.Empty;
            quoteDetail.QuoteRequestData.Id = null;
            if (quoteDetail.QuoteRequestData.QuoteStatusCode == Completed || quoteDetail.QuoteRequestData.QuoteStatusCode == Declined || quoteDetail.QuoteRequestData.QuoteStatusCode == Accepted)
            {
                quoteDetail.QuoteRequestData.LastVisitedPage = ConfirmDetailPage;
            }
            quoteDetail.QuoteRequestData.QuoteStatusCode = 1;           
            var quoteData = quoteService.GenerateQuoteRequest(quoteDetail.QuoteRequestData);
            foreach (var shipmentDtl in quoteDetail.LstShipmentDetail)
            {
                var shipmentDetails = shipmentDtl;
                shipmentDetails = quoteService.GenerateShipmentRequest(shipmentDetails);
                shipmentDetails.QuoteIdentificationNumber = quoteData.QuoteIdentificationNumber;
                shipmentDetails.Id = null;
                _taskRepository.SaveAirFreightShipmentDetail(shipmentDetails);
                quoteDetail.QuoteRequestData = _taskRepository.SaveQuoteForLater(quoteData);
                quoteDetail.QuoteRequestData.QuoteStatusDescriptionText = QuoteStatusNotSubmitted;
            }
            return new ResponseModel
            {
                responseData = quoteDetail,
                responseStatus = new ResponseStatus
                {
                    status = RequestSuccess,
                    message = QuoteDuplicated
                }
            };
        }

        /// <summary>
        /// To delete customer quote - quote status changed to delete .
        /// </summary>
        /// <param name="quoteNumber"></param>
        /// <returns>ResponseStatus</returns>
        public async Task<ResponseStatus> DeleteCustomerQuote(string quoteNumber)
        {
            var quoteDetail = await _taskRepository.GetQuoteDetails(quoteNumber).ConfigureAwait(false);
            quoteDetail.QuoteRequestData.QuoteStatusCode = 6;
            quoteDetail.QuoteRequestData.QuoteStatusDescriptionText = Enum.GetName(typeof(QuotesStatus), quoteDetail.QuoteRequestData.QuoteStatusCode);
            quoteDetail.QuoteRequestData.QuoteStatusUpdateDate = DateTime.Now.ToString();
            quoteDetail.QuoteRequestData = _taskRepository.SaveQuoteForLater(quoteDetail.QuoteRequestData);
            ResponseStatus response = new ResponseStatus
            {
                status = RequestSuccess,
                message = SuccessMessage
            };
            return response;
        }

        /// <summary>
        /// Download file belonging to the specified quote ID, from the blob
        /// </summary>
        /// <param name="quoteId">quote Id</param>
        /// <returns></returns>
        public Stream GetFile(string quoteId)
        {
            Task<Stream> result = _fileTransferService.FileDownload("UPS_IPR_IAF.pdf");
            return result.Result;
        }



        public async Task<CalculatedMBPResponse> CalculateMBP(CalculateMbpRateRequest request)
        {
            var locationCodes = await  _taskRepository.GetLocationCodes(request).ConfigureAwait(false);
            request.OriginCode = locationCodes.Origin;
            request.DestinationCode = locationCodes.Destination;
            return await  _taskRepository.CalculateMBP(request).ConfigureAwait(false);
        }

        public async Task<ResponseModel> GetWeightBreaksDetails(List<IafRouteDetailRequest> request)
        {
            return new ResponseModel
            {
                responseData = (await _taskRepository.GetWeightBreaksDetails(request).ConfigureAwait(false)).WeightBreakDetailList,
                responseStatus=new ResponseStatus
                {
                    status= StatusSuccess
                }
            };
        }

        /// <summary>
        /// Download UPS Default Template File
        /// </summary>
        /// <returns></returns>
        public Stream GetUPSDefaultTemplateFile()
        {
            Task<Stream> result = _fileTransferService.FileDownload("P20181116102808663_SCHLUMBERGER.xlsx");
            return result.Result;
        }

        public ResponseModel GetE2KBidCharges(QuoteDataRequest quoteRequestData)
        {
           return _e2kService.GetE2kBidCharges(quoteRequestData);
        }

        public async  Task<ListOfQuoteData> GetQuoteListIntPortal(string accountNumber)
        {
            var resp = await _taskRepository.GetQuoteListIntPortal(accountNumber.ToLower());
            resp.ListOfQuotes.Where(item => item.QuoteRequestData.QuoteStatusCode == 1).ToList().ForEach(item => item.QuoteRequestData.QuoteStatusDescriptionText = QuoteStatusForDb);
            foreach (var quotes in resp.ListOfQuotes)
            {
                quotes.QuoteValue= await CalculateQuoteValue(quotes);
                if (quotes.QuoteRequestData.QuoteStatusCode == 1)
                {
                    quotes.QuoteRequestData.QuoteStatusDescriptionText = QuoteStatusNotSubmitted;
                }
                else if (quotes.QuoteRequestData.QuoteStatusCode == 7)
                {
                    quotes.QuoteRequestData.QuoteStatusDescriptionText = AwaitingUPSResponse;
                }
            }
            return resp;
        }

        /// <summary>
        /// calculate the quote value
        /// </summary>
        /// <param name="quoteData"></param>
        /// <returns></returns>
        private async Task<string> CalculateQuoteValue(QuoteDataRequestInternalPortal quoteData)
        {
            var serviceType = GetserviceTypeSelection(quoteData.QuoteRequestData.ServiceTypes);
            var quoteValue = 0.00;
            foreach (var sd in quoteData.LstShipmentDetail)
            {
                if (!string.IsNullOrEmpty(sd.OriginLocationCode) && !string.IsNullOrEmpty(sd.DestinationLocationCode))
                {
                    List<IafRouteDetailRequest> lstIafRoute = new List<IafRouteDetailRequest>
                        {
                            new IafRouteDetailRequest
                            {
                                OriginCode = sd.OriginLocationCode,
                                DestinationCode = sd.DestinationLocationCode
                            }
                        };
                    var result = await GetWeightBreaksDetails(lstIafRoute);
                    var jsonString = JsonConvert.SerializeObject(result);
                    var json = JObject.Parse(jsonString);
                    quoteValue += Convert.ToDouble(ProcessQuoteValue(serviceType, json, Convert.ToDouble(quoteData.GADWeight)));
                }
            }
            return quoteValue.ToString();
        }

        /// <summary>
        /// select the service type
        /// </summary>
        /// <param name="serviceTypes"></param>
        /// <returns></returns>
        private string GetserviceTypeSelection(ServiceTypes serviceTypes)
        {
            if (serviceTypes.ConsolidatedECSelected == true && serviceTypes.DirectCASelected == true)
            {
                return ServiceTypeEC;
            }
            else if (serviceTypes.ConsolidatedECSelected == true && serviceTypes.DirectCASelected == false)
            {
                return ServiceTypeEC;
            }
            else if (serviceTypes.ConsolidatedECSelected == false && serviceTypes.DirectCASelected == true)
            {
                return ServiceTypeCA;
            }
            else
            {
                return ServiceTypeEC;
            }
        }

        /// <summary>
        /// Process quote value
        /// </summary>
        /// <param name="serviceType"></param>
        /// <param name="json"></param>
        /// <param name="gadWeight"></param>
        /// <returns></returns>
        private string ProcessQuoteValue(string serviceType, JObject json, double gadWeight)
        {
            if (serviceType == ServiceTypeEC)
            {
                if ((string)json[L1][0][L2][0][RouteServCode] == ServiceTypeEC)
                {
                    if (gadWeight <= 45)
                    {
                        return (gadWeight * Convert.ToDouble(json[L1][0][L2][0][U45AF])).ToString();
                    }
                    else if (gadWeight > 45 && gadWeight <= 100)
                    {
                        return (gadWeight * Convert.ToDouble(json[L1][0][L2][0][O45AF])).ToString();
                    }
                    else if (gadWeight > 100 && gadWeight <= 500)
                    {
                        return (gadWeight * Convert.ToDouble(json[L1][0][L2][0][O100AF])).ToString();
                    }
                    else if (gadWeight > 500)
                    {
                        return (gadWeight * Convert.ToDouble(json[L1][0][L2][0][O500AF])).ToString();
                    }
                    else
                    {
                        return ValueZero;
                    }
                }
                else if ((string)json[L1][0][L2][1][RouteServCode] == ServiceTypeEC)
                {
                    if (gadWeight <= 45)
                    {
                        return (gadWeight * Convert.ToDouble(json[L1][0][L2][1][U45AF])).ToString();
                    }
                    else if (gadWeight > 45 && gadWeight <= 100)
                    {
                        return (gadWeight * Convert.ToDouble(json[L1][0][L2][1][O45AF])).ToString();
                    }
                    else if (gadWeight > 100 && gadWeight <= 500)
                    {
                        return (gadWeight * Convert.ToDouble(json[L1][0][L2][1][O100AF])).ToString();
                    }
                    else if (gadWeight > 500)
                    {
                        return (gadWeight * Convert.ToDouble(json[L1][0][L2][1][O500AF])).ToString();
                    }
                    else
                    {
                        return ValueZero;
                    }
                }
                else
                {
                    return ValueZero;
                }
            }
            else if (serviceType == ServiceTypeCA)
            {
                if ((string)json[L1][0][L2][0][RouteServCode] == ServiceTypeCA)
                {
                    if (gadWeight <= 45)
                    {
                        return (gadWeight * Convert.ToDouble(json[L1][0][L2][0][U45AF])).ToString();
                    }
                    else if (gadWeight > 45 && gadWeight <= 100)
                    {
                        return (gadWeight * Convert.ToDouble(json[L1][0][L2][0][O45AF])).ToString();
                    }
                    else if (gadWeight > 100 && gadWeight <= 500)
                    {
                        return (gadWeight * Convert.ToDouble(json[L1][0][L2][0][O100AF])).ToString();
                    }
                    else if (gadWeight > 500)
                    {
                        return (gadWeight * Convert.ToDouble(json[L1][0][L2][0][O500AF])).ToString();
                    }
                    else
                    {
                        return ValueZero;
                    }
                }
                else if ((string)json[L1][0][L2][1][RouteServCode] == ServiceTypeCA)
                {
                    if (gadWeight <= 45)
                    {
                        return (gadWeight * Convert.ToDouble(json[L1][0][L2][1][U45AF])).ToString();
                    }
                    else if (gadWeight > 45 && gadWeight <= 100)
                    {
                        return (gadWeight * Convert.ToDouble(json[L1][0][L2][1][O45AF])).ToString();
                    }
                    else if (gadWeight > 100 && gadWeight <= 500)
                    {
                        return (gadWeight * Convert.ToDouble(json[L1][0][L2][1][O100AF])).ToString();
                    }
                    else if (gadWeight > 500)
                    {
                        return (gadWeight * Convert.ToDouble(json[L1][0][L2][1][O500AF])).ToString();
                    }
                    else
                    {
                        return ValueZero;
                    }
                }
                else
                {
                    return ValueZero;
                }
            }
            else
            {
                return ValueZero;
            }
        }

        /// <summary>
        /// Update quote status for Pinned or unpinned
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public async Task<ResponseModel> PinnedOrUnPinnedQuotes(LstOfIdsPinnedOrUnpinned request)
        {
            return new ResponseModel
            {
                responseData = await _taskRepository.PinnedOrUnPinnedQuotes(request).ConfigureAwait(false),
                responseStatus = new ResponseStatus
                {
                    status = StatusSuccess
                }
            };
        }

        public async Task<ResponseModel> DuplicateMultipleQuotes(ListOfIds request)
        {
            return new ResponseModel
            {
                responseData = await _taskRepository.DuplicateMultipleQuotes(request).ConfigureAwait(false),
                responseStatus = new ResponseStatus
                {
                    status = StatusSuccess
                }
            };
        }
    }
}