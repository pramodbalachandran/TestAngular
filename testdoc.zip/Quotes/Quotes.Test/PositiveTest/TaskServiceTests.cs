﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using Bonsai.Azure.CosmosDb.Models;
using Microsoft.AspNetCore.Http;
using Moq;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Quotes.Core.Entities;
using Quotes.Core.Entities.Dtos;
using Quotes.Core.Services;
using Quotes.Infrastructure.Data.Repositories;
using Quotes.Infrastructure.Services;
using Xunit;

namespace Quotes.Test.PositiveTest
{
    public class TaskServiceTests
    {
        private const string AddrLine1 = "Address line 1";
        private const string AddrLine1_2 = "New line 1";
        private const string AddrLine2 = "Address line 2";
        private const string AddrLine3 = "Address line 3";
        private const string UserName = "TestUser";
        private const string OriginCountryCode = "US";
        private const string PoliticalDiv2Code = "NYC";
        private const string PoliticalDiv1Name = "New York";
        private const string PostalCode = "10001";
        private const string respData = "responseData";
        private const string quoteId = "quoteDetailsId";
        private const string CountryCode = "IND";
        private const string ShipmentId = "shipmentDetailsId";
        private const string ComodCode = "TestCode1";
        private const string CommoDescText = "Commodity description";
        private const string NotSubmittedStatus = "Not Submitted";
        private const string QuoteNumber = "B10102018010101";
        #region Private Members
        private readonly TaskService _taskService;
        private readonly Mock<IRepository<MyTask>> _taskRepository;
        private readonly Mock<IFileTransferService> _fileTransferService;
        private readonly Mock<IE2KServices> _e2kService;
        private QuoteDataRequest _quoteRequest;
        private List<IafRouteDetailRequest> lstIafRoute;


        #endregion

        public TaskServiceTests()
        {
            _taskRepository = new Mock<IRepository<MyTask>>();
            _fileTransferService = new Mock<IFileTransferService>();
            _e2kService = new Mock<IE2KServices>();
            _taskService = new TaskService(_taskRepository.Object, _fileTransferService.Object, _e2kService.Object);

            var afShipmentDetail = new AirFreightShipmentDetail
            {
                Id = new Guid(),
                MovementTypeCode = 1,
                ShipmentOriginAddressProfileSaveIndicator = true,
                ShipmentDestinationAddressProfileSaveIndicator = true,
                originAddressLine1Text = AddrLine1,
                originAddressLine2Text = AddrLine2,
                originAddressLine3Text = AddrLine3,
                OriginLocationCountryCode = OriginCountryCode,
                OriginLocationPoliticalDivsion2Code = PoliticalDiv2Code,
                OriginPoliticalDivision1Name = PoliticalDiv1Name,
                OriginLocationPostalCode = PostalCode,
                DestinationAddressLine1Text = AddrLine1,
                DestinationAddressLine2Text = AddrLine1_2,
                DestinationAddressLine3Text = AddrLine3,
                DestinationLocationCountryCode = CountryCode,
                DestinationLocationPoliticalDivsion2Code = PoliticalDiv2Code,
                DestinationPoliticalDivision1Name = PoliticalDiv1Name,
                DestinationLocationPostalCode = PostalCode
            };
            List<AirFreightShipmentDetail> lstAfShip = new List<AirFreightShipmentDetail>();
            lstAfShip.Add(afShipmentDetail);
            _quoteRequest = new QuoteDataRequest
            {
                QuoteRequestData = new QuoteData
                {
                    Id = new Guid(),
                    QuoteTypeCode = 1,
                    QuoteStatusCode = 1,
                    BusinessPartyNumber = UserName,
                    QuoteValidityStartDate = DateTime.Now.ToShortDateString(),
                    QuoteValidityEndDate=DateTime.Now.AddDays(7).ToShortDateString()
                },
                LstShipmentDetail = lstAfShip
            };
            List<ShipingAddress> lstShippingAddr = new List<ShipingAddress>();
            ShipingAddress shipingAddress = new ShipingAddress
            {
                AddressLine1 = AddrLine1_2,
                AddressLine2 = AddrLine2,
                AddressLine3 = AddrLine3,
                CountryCode = OriginCountryCode,
                PoliticalDivision2Name = PoliticalDiv2Code,
                PoliticalDivision1Code = PoliticalDiv1Name,
                PostalCode = PostalCode
            };
            lstShippingAddr.Add(shipingAddress);
            List<CommodityType> lstComType = new List<CommodityType>();
            CommodityType comType = new CommodityType
            {
                CommodityTypeCode = ComodCode,
                CommodityTypeDescriptionText = CommoDescText
            };
            lstComType.Add(comType);
            CommodityTypeList commodityType = new CommodityTypeList
            {
                Id = new Guid(),
                CommodityTypeLists = lstComType.ToArray()
            };
            CustomerProfile customerProfile = new CustomerProfile
            {
                ShippingAddress = lstShippingAddr.ToArray()
            };
            ISearchResult<CustomerProfile> srCustProfile = new SearchResult<CustomerProfile>
            {
                Results = new List<CustomerProfile>()
            };
            ISearchResult<CommodityTypeList> srCommodityTypeLst = new SearchResult<CommodityTypeList>
            {
                Results = new List<CommodityTypeList>()
            };
            ISearchResult<QuoteData> srQuoteRespDto = new SearchResult<QuoteData>
            {
                Results = new List<QuoteData>()
            };
            QuoteData quoteResponceDto = new QuoteData
            {
                Id = new Guid(),
                QuoteNumber = QuoteNumber,
                QuoteStatusCode = 1,
                QuoteStatusDescriptionText = "NotSubmitted"
            };
            QuoteAttachment[] quoteAttach = { new QuoteAttachment { FilePathName = "filepath" } };
            Stream stream = new MemoryStream(Encoding.ASCII.GetBytes("filecontents"));
            lstIafRoute = new List<IafRouteDetailRequest>();
            IafRouteDetailRequest iafRoute = new IafRouteDetailRequest
            {
                OriginCode = "ABE",
                DestinationCode = "BUD"
            };
            List<IafRouteDetails> lstIafRouteDetail = new List<IafRouteDetails>();
            List<RouteService> lstRouteService = new List<RouteService>();
            RouteService rs = new RouteService
            {
                U45Original = "1.878512",
                O45Original = "1.818512",
                RouteWay = new RouteWay
                {
                    RouteWayName = "ABE - NYC - FRA - BUD",
                    RouteSegmentCountQuantity = "3"
                },
                RouteServiceCode = "EC"
            };
            lstRouteService.Add(rs);
            IafRouteDetails weightDetail = new IafRouteDetails
            {
                OriginCode = "ABE",
                DestinationCode = "BUD",
                OriginGatewayCode = "JFK",
                RouteService = lstRouteService
            };
            lstIafRouteDetail.Add(weightDetail);
            RateCalculatorDetailResponse weightCalculatorResponse = new RateCalculatorDetailResponse
            {
                WeightBreakDetailList = lstIafRouteDetail
            };
            lstIafRoute.Add(iafRoute);
            srQuoteRespDto.Results.Add(quoteResponceDto);
            srCommodityTypeLst.Results.Add(commodityType);
            srCustProfile.Results.Add(customerProfile);
            _taskRepository.Setup(tr => tr.SaveAirFreightShipmentDetail(It.IsAny<AirFreightShipmentDetail>())).Returns(afShipmentDetail);
            _taskRepository.Setup(tr => tr.UpdateCustProfile(It.IsAny<CustomerProfile>())).Returns(Task.FromResult(customerProfile));
            _taskRepository.Setup(tr => tr.SaveQuoteForLater(It.IsAny<QuoteData>())).Returns(_quoteRequest.QuoteRequestData);
            _taskRepository.Setup(tr => tr.GetCustomerProfile(It.IsAny<string>())).Returns(Task.FromResult(srCustProfile));
            _taskRepository.Setup(tr => tr.GetQuoteDetails(It.IsAny<string>())).Returns(Task.FromResult(_quoteRequest));
            _taskRepository.Setup(tr => tr.GetCommodityTypeList()).Returns(Task.FromResult(srCommodityTypeLst));
            _taskRepository.Setup(tr => tr.GetQuoteList(It.IsAny<string>())).Returns(Task.FromResult(srQuoteRespDto));
            _fileTransferService.Setup(ft => ft.FileUpload(It.IsAny<IFormFile>())).Returns(Task.FromResult(quoteAttach));
            _fileTransferService.Setup(ft => ft.FileDownload(It.IsAny<string>())).Returns(Task.FromResult(stream));
            _taskRepository.Setup(tr => tr.GetWeightBreaksDetails(lstIafRoute)).Returns(Task.FromResult(weightCalculatorResponse));
        }

        [Fact]
        public void TestSaveQuoteForLater()
        {
            var response = _taskService.SaveQuoteForLater(_quoteRequest);
            var json = JObject.Parse(JsonConvert.SerializeObject(response));
            Assert.Contains(new Guid().ToString(), (string)json[respData][quoteId]);
        }

        [Fact]
        public void TestGetQuoteDetails()
        {
            var response = _taskService.GetQuoteDetails(It.IsAny<string>());
            Assert.IsType<QuoteDataRequest>(response.Result);
            Assert.Contains(new Guid().ToString(), response.Result.QuoteRequestData.Id.ToString());
            Assert.Equal(DateTime.Now.Date.ToShortDateString(), response.Result.QuoteRequestData.QuoteValidityStartDate);
            Assert.Equal(DateTime.Now.AddDays(7).Date.ToShortDateString(), response.Result.QuoteRequestData.QuoteValidityEndDate);
        }

        [Fact]
        public void TestGetCommodityTypeList()
        {
            var response = _taskService.GetCommodityTypeList();
            Assert.IsType<CommodityTypeList>(response.Result.Results[0]);
            Assert.Contains(ComodCode, response.Result.Results[0].CommodityTypeLists[0].CommodityTypeCode);
            Assert.Contains(CommoDescText, response.Result.Results[0].CommodityTypeLists[0].CommodityTypeDescriptionText);
        }

        [Fact]
        public void TestGetQuoteList()
        {
            var response = _taskService.GetQuoteList(It.IsAny<string>());
            Assert.Contains(NotSubmittedStatus, response.Result.Results[0].QuoteStatusDescriptionText);
            Assert.Contains(QuoteNumber, response.Result.Results[0].QuoteNumber);
            Assert.IsType<QuoteResponceDto>(response.Result.Results[0]);
        }

        [Fact]
        public void TestFileUpload()
        {
            string response = _taskService.FileUpload(It.IsAny<IFormFile>());
            Assert.Equal("filepath", response);
        }

        [Fact]
        public void TestFileDownload()
        {
            Stream response = _taskService.GetFile("");
            StreamReader reader = new StreamReader(response);
            string fileContents = reader.ReadToEnd();
            Assert.Equal("filecontents", fileContents);
        }

        [Fact]
        public void TestGetWeightBreaksDetails()
        {
            var response = _taskService.GetWeightBreaksDetails(lstIafRoute);
            List<IafRouteDetails> lstWeightDetail = (List<IafRouteDetails>) response.Result.responseData;
            Assert.Equal("ABE - NYC - FRA - BUD", lstWeightDetail[0].RouteService[0].RouteWay.RouteWayName);
        }

        [Fact]
        public void TestUPSTemplateFileDownload()
        {
            Stream response = _taskService.GetUPSDefaultTemplateFile();
            StreamReader reader = new StreamReader(response);
            string fileContents = reader.ReadToEnd();
            Assert.Equal("filecontents", fileContents);
        }
    }
}
