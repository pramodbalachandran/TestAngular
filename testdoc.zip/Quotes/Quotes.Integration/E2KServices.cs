﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Net.Http;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Linq;
using Bonsai.Azure.CosmosDb.Models;
using Quotes.Core.Entities;
using Quotes.Core.Entities.Dtos;
using Quotes.Core.Services;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using RestSharp;
using System.Net;
using Quotes.Infrastructure.Data.Repositories;
using Quotes.Core.Constants;

namespace Quotes.Integration
{
    public class E2KServices : IE2KServices
    {
        private readonly IRepository<MyTask> _taskRepository;
        private readonly IConfiguration _appConfig;
        public E2KServices(IConfiguration appConfig, IRepository<MyTask> repository) : base()
        {
            _appConfig = appConfig;
            _taskRepository = repository;
        }

        private XmlDocument GenerateRequest(XmlDocument reqDoc, AirFreightShipmentDetail shipmentDetail)
        {
            reqDoc.SelectSingleNode(E2kConstants.E2kRequest_DataSource_Node).InnerText = "BIA";
            reqDoc.SelectSingleNode(E2kConstants.E2kRequest_Domain_Node).InnerText = "US";
            reqDoc.SelectSingleNode(E2kConstants.E2kRequest_User_Node).InnerText = "CSN9NVW";
            reqDoc.SelectSingleNode(E2kConstants.E2kRequest_ShipperCity_Node).InnerText = shipmentDetail.OriginLocationCity;// "LONDON";
            reqDoc.SelectSingleNode(E2kConstants.E2kRequest_ShipperCountry_Node).InnerText = shipmentDetail.OriginLocationCountryCode;// "GB";
            reqDoc.SelectSingleNode(E2kConstants.E2kRequest_ConsigneeCity_Node).InnerText = shipmentDetail.DestinationLocationCity;// "HONG KONG";
            reqDoc.SelectSingleNode(E2kConstants.E2kRequest_ConsignCountry_Node).InnerText = shipmentDetail.DestinationLocationCountryCode;// "HK";
            reqDoc.SelectSingleNode(E2kConstants.E2kRequest_OriginServiceCenter_Node).InnerText = shipmentDetail.OriginAirport; //"LON";
            reqDoc.SelectSingleNode(E2kConstants.E2kRequest_DestServiceCenter_Node).InnerText = shipmentDetail.DestinationAirport;// "HKG";
            reqDoc.SelectSingleNode(E2kConstants.E2kRequest_PaymentType_Node).InnerText = "PPD";// shipmentDetail.PaymentTermTypeCode;// "PPD";
            reqDoc.SelectSingleNode(E2kConstants.E2kRequest_TotalNumberOfPieces_Node).InnerText = shipmentDetail.WeightByPeice.Count().ToString(); //shipmentDetail.ShipmentQuantity;// "1";
            reqDoc.SelectSingleNode(E2kConstants.E2kRequest_Weight_Node).InnerText = shipmentDetail.TotalWeight;// ShipmentActualWeight;// TotalWeight;// "100.00";actualwt

            foreach (var shipWeightByPiece in shipmentDetail.WeightByPeice)
            {
                XmlElement el = (XmlElement)reqDoc.SelectSingleNode(E2kConstants.E2kRequest_ImportGroupPieces_Node);
                if (el != null)
                {
                    XmlElement elemRow = reqDoc.CreateElement(E2kConstants.E2kRequest_Row_Node);
                    XmlElement elemGrpPieceSumm = reqDoc.CreateElement(E2kConstants.E2kRequest_ImportGrpPieceSummary_Node);
                    XmlElement elemNumberOfPieces = reqDoc.CreateElement(E2kConstants.E2kRequest_NumberOfPieces_Node);
                    XmlElement elemPieceLength = reqDoc.CreateElement(E2kConstants.E2kRequest_PieceLength_Node);
                    XmlElement elemWidth = reqDoc.CreateElement((E2kConstants.E2kRequest_Width_Node));
                    XmlElement elemHeight = reqDoc.CreateElement((E2kConstants.E2kRequest_Height_Node));
                    XmlElement elemUOM = reqDoc.CreateElement((E2kConstants.E2kRequest_UOM_Node));

                    elemNumberOfPieces.InnerText = shipmentDetail.ShipmentQuantity;// "1";
                    elemPieceLength.InnerText = shipWeightByPiece.Length;// "120.0";
                    elemWidth.InnerText = shipWeightByPiece.Width;// "83.0";
                    elemHeight.InnerText = shipWeightByPiece.Height;// "60.0";
                    elemUOM.InnerText = shipWeightByPiece.ShipmentUnitOfMeasureTypeCode;// "IN";

                    elemGrpPieceSumm.AppendChild(elemNumberOfPieces);
                    elemGrpPieceSumm.AppendChild(elemPieceLength);
                    elemGrpPieceSumm.AppendChild(elemWidth);
                    elemGrpPieceSumm.AppendChild(elemHeight);
                    elemGrpPieceSumm.AppendChild(elemUOM);

                    elemRow.AppendChild(elemGrpPieceSumm);
                    el.AppendChild(elemRow);
                }
            }
            
            reqDoc.SelectSingleNode(E2kConstants.E2kRequest_ImpGrpPieceNumberOfPieces_Node).InnerText = shipmentDetail.ShipmentQuantity;// "1";
            foreach (var commodity in shipmentDetail.CommodityNameLists)
            {
                XmlElement elm = (XmlElement)reqDoc.SelectSingleNode(E2kConstants.E2kRequest_ImportCommodityRateQuote_Node);
                if (elm != null)
                {
                    XmlElement elemRow = reqDoc.CreateElement(E2kConstants.E2kRequest_Row_Node);
                    XmlElement elemCommodityDescription = reqDoc.CreateElement(E2kConstants.E2kRequest_CommodityDescription_Node);

                    elemCommodityDescription.InnerText = commodity.CommodityName;// "General Cargo";

                    elemRow.AppendChild(elemCommodityDescription);
                    elm.AppendChild(elemRow);
                }
            }
            reqDoc.SelectSingleNode(E2kConstants.E2kRequest_ServiceLevelRequested_Node).InnerText =  "EC";//shipmentDetail.ServiceTypes;
            reqDoc.SelectSingleNode(E2kConstants.E2kRequest_Flag_Node).InnerText = "Y";
            reqDoc.SelectSingleNode(E2kConstants.E2kRequest_OrigTariffPoint_Node).InnerText = shipmentDetail.OriginAirport;// "LON";
            reqDoc.SelectSingleNode(E2kConstants.E2kRequest_DestTariffPoint_Node).InnerText = shipmentDetail.DestinationAirport; //"HKG";
            return reqDoc;
        }

        private List<QuoteAccessorialDetail> ProcessResponse(string content, AirFreightShipmentDetail shipmentDetail, QuoteDataRequest quoteRequestData)
        {
            List<QuoteAccessorialDetail> quoteAccessorialDetails = new List<QuoteAccessorialDetail>();
            XDocument doc = XDocument.Parse(content);
            XNamespace ns = "http://www.ups.com/XMLSchema/E2kGetValidServicesRspn/v1_0_1";
            IEnumerable<XElement> expGrpTriggeredCharges = doc.Descendants(E2kConstants.E2kResponse_GroupTriggeredCharges_Node).Descendants(E2kConstants.E2kRequest_Row_Node);
            IEnumerable<XElement> expGroupTriggeredCharges = doc.Descendants(E2kConstants.E2kResponse_GroupTriggeredCharges_Node).Descendants(E2kConstants.E2kResponse_ExportGrpIprc1ShpCharge_Node);
            IEnumerable<XElement> expGrpPoint = doc.Descendants(E2kConstants.E2kResponse_ExportGroupPoint_Node).Descendants(E2kConstants.E2kRequest_Row_Node);
            IEnumerable<XElement> expGrpServLevel = doc.Descendants(E2kConstants.E2kResponse_ExportGroupServiceLevel_Node).Descendants(E2kConstants.E2kRequest_Row_Node);
            IEnumerable<XElement> expGrpInclusion = doc.Descendants(E2kConstants.E2kResponse_ExportGroupInclusion_Node).Descendants(E2kConstants.E2kRequest_Row_Node);
            IEnumerable<XElement> expGrpdetails = doc.Descendants(E2kConstants.E2kResponse_ExportGroupDetails_Node).Descendants(E2kConstants.E2kRequest_Row_Node);

            QuoteAccessorialDetail quoteAccessorialDetail;
            foreach (XElement gtc in expGroupTriggeredCharges)
            {
                quoteAccessorialDetail = new QuoteAccessorialDetail();
                quoteAccessorialDetail.DocId = QuotesConsts.PartitionKey + QuotesConsts.Separator + quoteRequestData.QuoteRequestData.QuoteIdentificationNumber +
            QuotesConsts.Separator + shipmentDetail.ShipmentDetailIdentificationNumber + QuotesConsts.Separator + quoteRequestData.QuoteRequestData.BusinessPartyName +
            QuotesConsts.Separator + quoteRequestData.QuoteRequestData.BusinessPartyNumber;
                quoteAccessorialDetail.PartitionKey = QuotesConsts.PartitionKey;
                quoteAccessorialDetail.DocType = QuotesConsts.PartitionKey;
                quoteAccessorialDetail.QuoteIdentificationNumber = quoteRequestData.QuoteRequestData.QuoteIdentificationNumber;
                var groupPoint = expGrpPoint.Where(gp =>
                gp.Element(E2kConstants.E2kResponse_GrpChrRefIprc1ShpCharge_Node) != null && gp.Element(E2kConstants.E2kResponse_GrpChrRefIprc1ShpCharge_Node).Element(E2kConstants.E2kResponse_ChargeCode_Node) != null &&
               (gtc.Element(E2kConstants.E2kResponse_ChargeCode_Node)) != null &&
               ((string)gp.Element(E2kConstants.E2kResponse_GrpChrRefIprc1ShpCharge_Node).Element(E2kConstants.E2kResponse_ChargeCode_Node)).Trim().ToUpper() == ((string)gtc.Element(E2kConstants.E2kResponse_ChargeCode_Node)).Trim().ToUpper()).FirstOrDefault();

                var scalePoint = groupPoint != null ? groupPoint.Descendants(E2kConstants.E2kResponse_GrpPtIprc1RateScalePoints_Node) : null;
                if (scalePoint != null && scalePoint.ToArray().Count() > 0)
                {
                    quoteAccessorialDetail.OriginTypeCode = scalePoint.ToArray()[0].Element(E2kConstants.E2kResponse_OriginType_Node) != null ? ((string)scalePoint.ToArray()[0].Element(E2kConstants.E2kResponse_OriginType_Node)).Trim().ToUpper() : string.Empty;
                    quoteAccessorialDetail.DestinationTypeCode = scalePoint.ToArray()[0].Element(E2kConstants.E2kResponse_DestinationType_Node) != null ? ((string)scalePoint.ToArray()[0].Element(E2kConstants.E2kResponse_DestinationType_Node)).Trim().ToUpper() : string.Empty;
                    quoteAccessorialDetail.DestinationLocationCountryCode = scalePoint.ToArray()[0].Element(E2kConstants.E2kResponse_DestinationPoint_Node) != null ? ((string)scalePoint.ToArray()[0].Element(E2kConstants.E2kResponse_DestinationPoint_Node)).Trim().ToUpper() : string.Empty;
                    quoteAccessorialDetail.OriginZoneIndicator = scalePoint.ToArray()[0].Element(E2kConstants.E2kResponse_OriginIsAZoneInd_Node) != null ? ((string)scalePoint.ToArray()[0].Element(E2kConstants.E2kResponse_OriginIsAZoneInd_Node)).Trim().ToUpper() : string.Empty;
                    quoteAccessorialDetail.DestinationZoneIndicator = scalePoint.ToArray()[0].Element(E2kConstants.E2kResponse_DestinationIsAZoneInd_Node) != null ? ((string)scalePoint.ToArray()[0].Element(E2kConstants.E2kResponse_DestinationIsAZoneInd_Node)).Trim().ToUpper() : string.Empty;
                }

                var groupServLevel = expGrpServLevel.Where(gsl =>
                gsl.Element(E2kConstants.E2kResponse_ExportGrpSvcChgRefIprc1ShpCharge_Node) != null && gsl.Element(E2kConstants.E2kResponse_ExportGrpSvcChgRefIprc1ShpCharge_Node).Element(E2kConstants.E2kResponse_ChargeCode_Node) != null &&
               (gtc.Element(E2kConstants.E2kResponse_ChargeCode_Node)) != null &&
               ((string)gsl.Element(E2kConstants.E2kResponse_ExportGrpSvcChgRefIprc1ShpCharge_Node).Element(E2kConstants.E2kResponse_ChargeCode_Node)).Trim().ToUpper() == ((string)gtc.Element(E2kConstants.E2kResponse_ChargeCode_Node)).Trim().ToUpper()).FirstOrDefault();

                var servLevel = groupServLevel != null ? groupServLevel.Descendants(E2kConstants.E2kResponse_ExportGrpSvcIprc1RateScaleServLvl_Node) : null;
                if (servLevel != null && servLevel.ToArray().Count() > 0)
                {
                    quoteAccessorialDetail.InternationalAirFreightServiceGroupTypeCode = servLevel.ToArray()[0].Element(E2kConstants.E2kResponse_ServiceLevel_Node) != null ? ((string)servLevel.ToArray()[0].Element(E2kConstants.E2kResponse_ServiceLevel_Node)).Trim().ToUpper() : null;
                }
                if (gtc != null)
                {
                    quoteAccessorialDetail.ChargeTypeCode = gtc.Element(E2kConstants.E2kResponse_ChargeCode_Node) != null ? ((string)gtc.Element(E2kConstants.E2kResponse_ChargeCode_Node)).Trim().ToUpper() : string.Empty;
                    quoteAccessorialDetail.ChargeTypeDescriptionText = gtc.Element(E2kConstants.E2kResponse_ShortDescription_Node) != null ? ((string)gtc.Element(E2kConstants.E2kResponse_ShortDescription_Node)).Trim().ToUpper() : string.Empty;
                    quoteAccessorialDetail.UsdCurrencyAmount = gtc.Element(E2kConstants.E2kResponse_ChargeAmount_Node) != null ? ((string)gtc.Element(E2kConstants.E2kResponse_ChargeAmount_Node)).Trim().ToUpper() : null;
                    AccessorialBidCharges[] accBidCharges = { new AccessorialBidCharges { CurrencyCode = gtc.Element(E2kConstants.E2kResponse_ChargeCurrencyCode_Node) != null ? ((string)gtc.Element(E2kConstants.E2kResponse_ChargeCurrencyCode_Node)).Trim().ToUpper() : null } };
                    quoteAccessorialDetail.SetAccessorialBidCharge(accBidCharges);
                }
                if (doc.Descendants(E2kConstants.E2kResponse_ExportOriginIblc1ServiceArea_Node) != null && doc.Descendants(E2kConstants.E2kResponse_ExportOriginIblc1ServiceArea_Node).ToArray().Count() > 0
                    && doc.Descendants(E2kConstants.E2kResponse_ExportOriginIblc1ServiceArea_Node).ToArray()[0].Element(E2kConstants.E2kResponse_DeliveryZoneNbr_Node) != null)
                {
                    quoteAccessorialDetail.BeyondPointCode = ((string)doc.Descendants(E2kConstants.E2kResponse_ExportOriginIblc1ServiceArea_Node).ToArray()[0].Element(E2kConstants.E2kResponse_DeliveryZoneNbr_Node)).Trim().ToUpper();
                }

                var groupInclusion = expGrpInclusion.Where(gInc =>
                gInc.Element(E2kConstants.E2kResponse_ExportGrpIncChgRefIprc1ShpCharge_Node) != null && gInc.Element(E2kConstants.E2kResponse_ExportGrpIncChgRefIprc1ShpCharge_Node).Element(E2kConstants.E2kResponse_ChargeCode_Node) != null &&
                (gtc.Element(E2kConstants.E2kResponse_ChargeCode_Node)) != null &&
                ((string)gInc.Element(E2kConstants.E2kResponse_ExportGrpIncChgRefIprc1ShpCharge_Node).Element(E2kConstants.E2kResponse_ChargeCode_Node)).Trim().ToUpper() == ((string)gtc.Element(E2kConstants.E2kResponse_ChargeCode_Node)).Trim().ToUpper()).FirstOrDefault();

                var incRateScale = groupInclusion != null ? groupInclusion.Descendants(E2kConstants.E2kResponse_ExportGrpIncIprc1RateScale_Node) : null;
                if (incRateScale != null && incRateScale.ToArray().Count() > 0 && incRateScale.ToArray()[0].Element(E2kConstants.E2kResponse_InclusionCode_Node) != null)
                {
                    quoteAccessorialDetail.AdditionalChargesArrayText = ((string)incRateScale.ToArray()[0].Element(E2kConstants.E2kResponse_InclusionCode_Node)).Trim().ToUpper();
                }
                if (doc.Descendants(E2kConstants.E2kResponse_ExportIprc1Shipment_Node) != null && doc.Descendants(E2kConstants.E2kResponse_ExportIprc1Shipment_Node).ToArray().Count() > 0
                    && doc.Descendants(E2kConstants.E2kResponse_ExportIprc1Shipment_Node).ToArray()[0].Element(E2kConstants.E2kResponse_EwwTotalActualWeightUom_Node) != null)
                {
                    quoteAccessorialDetail.ShipmentUnitOfMeasureTypeCode = ((string)doc.Descendants(E2kConstants.E2kResponse_ExportIprc1Shipment_Node).ToArray()[0].Element(E2kConstants.E2kResponse_EwwTotalActualWeightUom_Node)).Trim().ToUpper();
                }

                var groupTrigCharges = expGrpTriggeredCharges.Where(gtc1 =>
                gtc1.Element(E2kConstants.E2kResponse_ExportGrpIprc1ShpCharge_Node) != null && gtc1.Element(E2kConstants.E2kResponse_ExportGrpIprc1ShpCharge_Node).Element(E2kConstants.E2kResponse_ChargeCode_Node) != null &&
                (gtc.Element(E2kConstants.E2kResponse_ChargeCode_Node)) != null &&
                ((string)gtc1.Element(E2kConstants.E2kResponse_ExportGrpIprc1ShpCharge_Node).Element(E2kConstants.E2kResponse_ChargeCode_Node)).Trim().ToUpper() == ((string)gtc.Element(E2kConstants.E2kResponse_ChargeCode_Node)).Trim().ToUpper()).FirstOrDefault();

                var shpParty = groupTrigCharges != null ? groupTrigCharges.Descendants(E2kConstants.E2kResponse_ExportGrpIprc1ShipmentParty_Node) : null;
                if (shpParty != null && shpParty.ToArray().Count() > 0 && shpParty.ToArray()[0].Element(E2kConstants.E2kResponse_RoleTypeCode_Node) != null)
                {
                    quoteAccessorialDetail.BusinessPartyRoleCode = ((string)shpParty.ToArray()[0].Element(E2kConstants.E2kResponse_RoleTypeCode_Node)).Trim().ToUpper();
                }
                var groupDetail = expGrpdetails.Where(gd =>
                gd.Element(E2kConstants.E2kResponse_ExportGrpDtlChgRefIprc1ShpCharge_Node) != null && gd.Element(E2kConstants.E2kResponse_ExportGrpDtlChgRefIprc1ShpCharge_Node).Element(E2kConstants.E2kResponse_ChargeCode_Node) != null &&
                (gtc.Element(E2kConstants.E2kResponse_ChargeCode_Node)) != null &&
                ((string)gd.Element(E2kConstants.E2kResponse_ExportGrpDtlChgRefIprc1ShpCharge_Node).Element(E2kConstants.E2kResponse_ChargeCode_Node)).Trim().ToUpper() == ((string)gtc.Element(E2kConstants.E2kResponse_ChargeCode_Node)).Trim().ToUpper()).FirstOrDefault();

                var grpDetRate = groupDetail != null ? groupDetail.Descendants(E2kConstants.E2kResponse_ExportGrpDetailIprc1Rate_Node) : null;
                if (grpDetRate != null && grpDetRate.ToArray().Count() > 0 && grpDetRate.ToArray()[0].Element(E2kConstants.E2kResponse_ForEach_Node) != null)
                {
                    quoteAccessorialDetail.RateForUnitTypeQuantity = ((string)grpDetRate.ToArray()[0].Element(E2kConstants.E2kResponse_ForEach_Node)).Trim().ToUpper();
                }

                quoteAccessorialDetails.Add(quoteAccessorialDetail);
            }
            return quoteAccessorialDetails;
        }

        public dynamic GetE2kBidCharges(QuoteDataRequest quoteRequestData)
        {
            ResponseModel responseModel = new ResponseModel();
            string url = _appConfig[QuotesConsts.E2kServicesurl];
            int codeCount = 0;
            XmlDocument reqDoc = new XmlDocument();
            reqDoc.Load(@".\Files\BidCharge_Request.xml");
            quoteRequestData.LstShipmentDetail.ForEach(shipmentDetail =>
            {

                reqDoc = GenerateRequest(reqDoc, shipmentDetail);
                var soapString = reqDoc.InnerXml;

                /*START:Call soap ui using RestClient*/

                var client = new RestClient(url);
                var request = new RestRequest();
                request.AddHeader("SOAPAction", "EstRateQuote");
                request.Method = Method.POST;
                request.RequestFormat = DataFormat.Xml;
                request.AddParameter("text/xml", soapString, ParameterType.RequestBody);
                // execute the request
                IRestResponse response = client.Execute(request);
                var content = response.Content;


                content = System.IO.File.ReadAllText(@".\Files\Resp.xml");//as e2k is not accessible from cloud ,loading sample response from file.

                List<QuoteAccessorialDetail> quoteAccessorialDetails = new List<QuoteAccessorialDetail>();

                quoteAccessorialDetails = ProcessResponse(content, shipmentDetail, quoteRequestData);

                _taskRepository.SaveQuoteAccessorialDetail(quoteAccessorialDetails);
                responseModel = new ResponseModel
                {
                    responseData = quoteAccessorialDetails,
                    responseStatus = new Core.Entities.Dtos.ResponseStatus
                    {
                        status = QuotesConsts.RequestSuccess,
                        message = QuotesConsts.SuccessMessage
                    }
                };

            });
            return responseModel;

        }
    }
}
