﻿using System;

namespace Quotes.Integration
{
    public class Class1
    {
        
    }
}
