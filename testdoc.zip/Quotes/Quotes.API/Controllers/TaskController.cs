﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Quotes.Core.Entities;
using Quotes.Core.Entities.Dtos;
using Quotes.Core.Services;
using Quotes.Infrastructure.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Bonsai.Azure.CosmosDb.Models;
using Microsoft.AspNetCore.Http;
using System.Net.Http;
using System.IO;
using System.Net;
using System.Net.Http.Headers;

namespace Quotes.API.Controllers
{
    [AllowAnonymous]
    public class TaskController : ResourceController<MyTaskDto, MyTask>
    {
        private readonly ITaskService _taskService;
        private readonly IMapper _mapper;
        private readonly IE2KServices _e2kService;

        public TaskController(ITaskService service, IMapper mapper, IE2KServices e2k)
            : base(service, mapper)
        {
            _taskService = service;
            _mapper = mapper;
            _e2kService = e2k;
        }

        public void CreateTasks()
        {
            _taskService.CreateTask();
        }

        /// <summary>
        /// Method used to save the quote data
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        public JsonResponseDto SaveQuotesData([FromBody] QuoteDataRequest quoteData) => _taskService.SaveQuoteForLater(quoteData);

        /// <summary>
        /// Method used to save the quote data
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        public ResponseModel GetE2kRates([FromBody] QuoteDataRequest quoteData)
        {
            return _taskService.GetE2KBidCharges(quoteData);
        }

        [HttpPost]
        public Task<QuoteDataRequest> GetQuoteDetails([FromBody] QuoteRequest quoteRequest)
        {
            return _taskService.GetQuoteDetails(quoteRequest.QuoteNumber);
        }
        /// <summary>
        /// To get the quote detials of logged in user for dashboard
        /// </summary>
        /// <param name="quoteRequest"></param>
        /// <returns></returns>
        [HttpPost]
        public Task<ISearchResult<QuoteData>> GetQuoteList([FromBody] QuoteRequest quoteRequest)
        {
            return _taskService.GetQuoteList(quoteRequest.AccountNumber);
        }

        /// <summary>
        /// Get Quote List Internal Portal
        /// </summary>
        /// <param name="quoteRequest"></param>
        /// <returns></returns>
        [HttpPost]
        public Task<ListOfQuoteData> GetQuoteListInternalPortal([FromBody] QuoteRequest quoteRequest)
        {
            return _taskService.GetQuoteListIntPortal(quoteRequest.AccountNumber);
        }

        /// <summary>
        /// Update quote status for Pinned or unpinned
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost]
        public Task<ResponseModel> UpdateQuotePinnedStatus([FromBody] LstOfIdsPinnedOrUnpinned request)
        {
            return _taskService.PinnedOrUnPinnedQuotes(request);
        }

        /// <summary>
        /// create bulk duplicate quote
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        [HttpPost]
        public Task<ResponseModel> CreateBulkDuplicateQuotes([FromBody] ListOfIds request)
        {
            return _taskService.DuplicateMultipleQuotes(request);
        }

        /// <summary>
        /// To get the commodity type list
        /// </summary>
        /// <param></param>
        /// <returns>CommodityTypeList</returns>
        [HttpPost]
        public Task<ISearchResult<CommodityTypeList>> GetCommodityTypeList()
        {
            return _taskService.GetCommodityTypeList();
        }

        /// <summary>
        /// Create Duplicate Quote
        /// </summary>
        /// <param name="quoteRequest"></param>
        /// <returns></returns>
        [HttpPost]
        public Task<ResponseModel> CreateDuplicateQuote([FromBody] QuoteRequest quoteRequest)
        {
            return _taskService.CreateDuplicateQuote(quoteRequest.QuoteNumber);
        }

        [HttpPost]
        public Task<CalculatedMBPResponse> CalculateMBP([FromBody] CalculateMbpRateRequest request)
        {
            return _taskService.CalculateMBP(request);
        }

        [HttpPost]
        public Task<ResponseModel> GetWeightBreaksDetails([FromBody] List<IafRouteDetailRequest> request)
        {
            return _taskService.GetWeightBreaksDetails(request);
        }


        /// <summary>
        /// To get the existing commodity item
        /// </summary>
        /// <param></param>
        /// <returns>CommodityTypeList</returns>
        [HttpPost]
        public Task<CommodityNames> GetCommodityNameList([FromBody] QuoteRequest quoteRequest)
        {
            return _taskService.GetCommodityNameList(quoteRequest.AccountNumber);
        }

        /// <summary>
        /// To upload file
        /// </summary>
        /// <param name="file"></param>
        /// <returns>quote attachment</returns>
        [HttpPost]
        public string FileUpload(IFormFile file)
        {
            file = Request.Form.Files[0];
            if (file == null)
            {
                throw new ArgumentNullException(nameof(file), "Invalid File");
            }
            return _taskService.FileUpload(file);
        }

        /// <summary>
        /// To delete customer quote - quote status changed to delete .
        /// </summary>
        /// <param name = "quoteRequest" ></ param >
        /// < returns ></ returns >
        [HttpPost]
        public Task<ResponseStatus> DeleteCustomerQuote([FromBody] QuoteRequest quoteRequest)
        {
            return _taskService.DeleteCustomerQuote(quoteRequest.QuoteNumber);
        }

        /// <summary>
        /// Get the uploaded file from blob
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public FileResult GetPdf()
        {
            Stream stream = new MemoryStream();
            stream = (MemoryStream)_taskService.GetFile("");

            stream.Position = 0;

            using (var memoryStream = new MemoryStream())
            {
                stream.CopyTo(memoryStream);

                HttpContext.Response.ContentType = "application/pdf";
                FileContentResult result = new FileContentResult(memoryStream.ToArray(), "application/pdf")
                {
                    FileDownloadName = ""
                };
                return result;
            }

        }

        /// <summary>
        /// Download UPS template file
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public FileResult GetUPSTemplateFile()
        {
            Stream stream = new MemoryStream();
            stream = (MemoryStream)_taskService.GetUPSDefaultTemplateFile();

            stream.Position = 0;

            using (var memoryStream = new MemoryStream())
            {
                stream.CopyTo(memoryStream);

                HttpContext.Response.ContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                FileContentResult result = new FileContentResult(memoryStream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
                {
                    FileDownloadName = "P20181116102808663_SCHLUMBERGER.xlsx"
                };
                return result;
            }

        }
    }
}