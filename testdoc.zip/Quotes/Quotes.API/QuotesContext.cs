﻿using Microsoft.Extensions.Logging;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.AspNetCore.Http;

using Quotes.Core.Config;
using Microsoft.Extensions.Options;

namespace Quotes.API
{
    using Infrastructure.Data.Configuration;
    public static class QuotesContext
    {
        private static IDbConfig _dbconfig;
        public static IHttpContextAccessor HttpContextAccessor;

        public static string DbConnectionString()
        {
            IOptions<DbConfig> options = HttpContextAccessor.HttpContext.RequestServices.GetService<IOptions<DbConfig>>();
            _dbconfig = options.Value;
            return @_dbconfig.QuotesConnectionString;
            //return @"mongodb://azure-cosmos123:1hu5nj6Nv8ospkaoTUTh8s5nCgNCEydLJUMxcR8iLlgT6GLjvkqRpa7xx3S5nuSmDT0tcvjB1x5an4xg3epr7A==@azure-cosmos123.documents.azure.com:10255/?ssl=true&replicaSet=globaldb";
        }

        public static string DocumentDbEndpointUrl()
        {
            IOptions<DbConfig> options = HttpContextAccessor.HttpContext.RequestServices.GetService<IOptions<DbConfig>>();
            _dbconfig = options.Value;
            return @_dbconfig.DocumentDbEndpointUrl;
        }

        public static string DocumentDbPrimaryKey()
        {
            IOptions<DbConfig> options = HttpContextAccessor.HttpContext.RequestServices.GetService<IOptions<DbConfig>>();
            _dbconfig = options.Value;
            return @_dbconfig.DocumentDbPrimaryKey;
        }
    }
}
