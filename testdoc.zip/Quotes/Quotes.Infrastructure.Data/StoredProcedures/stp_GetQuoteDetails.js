﻿function stp_GetQuoteDetails(userid) {
    var context = getContext();
    var collection = context.getCollection();
    var response = context.getResponse();
    var body = getContext().getResponse().setBody;
    var result = [];
    var resultJson = {};
    var arraycount = 0;
    var filterQueryQuotes = 'SELECT * FROM c WHERE c.docType="quotes" AND  c.UserName= "' + userid + '"';
    //var filterQueryQuotes = 'SELECT * FROM c WHERE c.docType="quotes"';

    var isAccepted = collection.queryDocuments(collection.getSelfLink(), filterQueryQuotes, {},
        function (err, quotesdocuments, responseOptions) {
            if (err) throw new Error("Error" + err.message);

            var quoteNumberList = quotesdocuments;
            for (var quoteNumber of quotesdocuments) {
                // result.push(quoteNumber);
                //resultJson.push(quoteNumber)
                resultJson["docId"] = quoteNumber.docId;
                resultJson["quoteNumber"] = quoteNumber.quoteNumber;
                resultJson["quoteIdentificationNumber"] = quoteNumber.quoteIdentificationNumber;
                resultJson["businessPartyName"] = quoteNumber.businessPartyName;
                resultJson["businessPartyNumber"] = quoteNumber.businessPartyNumber;
                resultJson["accountNumber"] = quoteNumber.accountNumber;
                resultJson["quoteRequestDate"] = quoteNumber.quoteRequestDate;
                resultJson["quoteStatusCode"] = quoteNumber.quoteStatusCode;
                resultJson["quoteStatusUpdateDate"] = quoteNumber.quoteStatusUpdateDate;
                resultJson["quoteTypeCode"] = quoteNumber.quoteTypeCode;
                resultJson["informationSourceTypeCode"] = quoteNumber.informationSourceTypeCode;
                resultJson["salesSegmentCategoryCode"] = quoteNumber.salesSegmentCategoryCode;
                resultJson["standardIndustrialClassificationCode"] = quoteNumber.standardIndustrialClassificationCode;
                resultJson["projectName"] = quoteNumber.projectName;
                resultJson["regionNumber"] = quoteNumber.regionNumber;
                resultJson["districtNumber"] = quoteNumber.districtNumber;
                resultJson["countryCode"] = quoteNumber.countryCode;
                resultJson["formalRequestForQuoteIndicator"] = quoteNumber.formalRequestForQuoteIndicator;
                resultJson["filingStatusCode"] = quoteNumber.filingStatusCode;
                resultJson["anticipatedProductRevenueAmount"] = quoteNumber.anticipatedProductRevenueAmount;
                resultJson["quoteDueDate"] = quoteNumber.quoteDueDate;
                resultJson["quotePastDueIndicator"] = quoteNumber.quotePastDueIndicator;
                resultJson["specialRequestReviewDate"] = quoteNumber.specialRequestReviewDate;
                resultJson["quoteAttachment"] = quoteNumber.quoteAttachment;
                resultJson["countryCode"] = quoteNumber.countryCode;
                resultJson["formalRequestForQuoteIndicator"] = quoteNumber.formalRequestForQuoteIndicator;
                resultJson["filingStatusCode"] = quoteNumber.filingStatusCode;
                resultJson["anticipatedProductRevenueAmount"] = quoteNumber.anticipatedProductRevenueAmount;
                resultJson["quoteDueDate"] = quoteNumber.quoteDueDate;
                resultJson["quotePastDueIndicator"] = quoteNumber.quotePastDueIndicator;
                resultJson["specialRequestReviewDate"] = quoteNumber.specialRequestReviewDate;
                resultJson["quoteAttachment"] = quoteNumber.quoteAttachment;

                var filterQueryAirFreights = 'SELECT * FROM c WHERE c.docType="airFreightShipmentDetail" AND  c.quoteIdentificationNumber= "' + quoteNumber.quoteIdentificationNumber + '"';
                //var filterQueryAirFreights = 'SELECT * FROM c WHERE c.docType="airFreightShipmentDetail"';
                var subAccepted =
                    collection.queryDocuments(collection.getSelfLink(), filterQueryAirFreights, {},
                        function (err, airfreightdocuments, responseOptions) {
                            if (err) throw new Error("Error" + err.message);
                            if (airfreightdocuments.length > 0)
                                resultJson["airfreight"] = airfreightdocuments;

                        });
                result.push(resultJson);
            }

            // body(quoteNumberList);
            response.setBody(result);
        });
    if (!isAccepted) throw new Error('The query was not accepted by the server.');
}