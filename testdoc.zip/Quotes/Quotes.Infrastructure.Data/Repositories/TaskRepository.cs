﻿using System;
using Quotes.Core.Entities;
using Microsoft.Azure.Documents;
using Microsoft.Extensions.Logging;

namespace Quotes.Infrastructure.Data.Repositories
{
    public class TaskRepository : Repository<MyTask>
    {
        public TaskRepository(IDocumentClient client, ILoggerFactory loggerFactory) : base(client, loggerFactory)
        {

        }

    }
}
