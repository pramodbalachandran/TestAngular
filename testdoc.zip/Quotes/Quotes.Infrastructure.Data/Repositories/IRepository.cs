﻿using System;
using System.Collections.Generic;
using System.Text;
using Quotes.Core.Entities.Abstract;
using Bonsai.Azure.CosmosDb.Abstract;
using Quotes.Core.Entities;
using System.Threading.Tasks;
using Bonsai.Azure.CosmosDb.Models;
using Quotes.Core.Entities.Dtos;

namespace Quotes.Infrastructure.Data.Repositories
{
    public interface IRepository<T> : IBaseRepository<T> where T : IEntity
    {
        QuoteData SaveQuoteForLater(QuoteData quoteData);

        AirFreightShipmentDetail SaveAirFreightShipmentDetail(AirFreightShipmentDetail shipmentDetails);
        QuoteAccessorialDetail SaveQuoteAccessorialDetail(List<QuoteAccessorialDetail> quoteAccessorialDetail);
        Task<QuoteDataRequest> GetQuoteDetails(string quoteNumber);

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        Task<ISearchResult<CommodityTypeList>> GetCommodityTypeList();

        Task<ISearchResult<QuoteData>> GetQuoteList(string accountNumber);

        /// <summary>
        /// Get Quote List Internal Portal
        /// </summary>
        /// <param name="accountNumber"></param>
        /// <returns></returns>
        Task<ListOfQuoteData> GetQuoteListIntPortal(string accountNumber);

        /// <summary>
        /// update quote status for pinned or unpinned
        /// </summary>
        /// <param name="request"></param>
        Task<CountOfRecordsUpdated> PinnedOrUnPinnedQuotes(LstOfIdsPinnedOrUnpinned request);

        /// <summary>
        /// duplicate multiple quotes
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        Task<CountOfRecordsUpdated> DuplicateMultipleQuotes(ListOfIds request);

        Task<CommodityNames> GetCommodityNameList(string accountNumber);

        /// <summary>
        /// To delete the customer quote
        /// </summary>
        /// <param name="quoteNumber"></param>
        /// <returns></returns>
        //ResponseStatus DeleteCustomerQuotes(string quoteNumber);
        ///

        /// <summary>
        /// To get the customer profile details
        /// </summary>
        /// <param name="quoteNumber"></param>
        /// <returns></returns>
        Task<ISearchResult<CustomerProfile>> GetCustomerProfile(string custId);
        /// <summary>
        /// To update customer profile
        /// </summary>
        /// <param name="userProfile"></param>
        /// <returns></returns>
        Task<CustomerProfile> UpdateCustProfile(CustomerProfile userProfile);

        Task<CalculatedMBPResponse> CalculateMBP(CalculateMbpRateRequest request);

        Task<LocationCodeResponse> GetLocationCodes(CalculateMbpRateRequest request);

        Task<QuoteRootLocation> Getquotedatacountrynames(string countryCode);

        /// <summary>
        /// Get all details of route to calculate rate
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        Task<RateCalculatorDetailResponse> GetWeightBreaksDetails(List<IafRouteDetailRequest> request);

        Task<ShipmentDeleteCount> DeleteDuplicateShipmentDetails(string query);
    }
}
