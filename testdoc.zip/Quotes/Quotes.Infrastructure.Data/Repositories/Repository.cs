﻿using System;
using System.Collections.Generic;
using System.Text;

using Quotes.Core.Entities.Abstract;
using Bonsai.Azure.CosmosDb;
using Microsoft.Azure.Documents;
using Microsoft.Extensions.Logging;
using System.Threading.Tasks;
using Quotes.Core.Entities;
using Bonsai.Azure.CosmosDb.Models;
using System.Linq.Expressions;
using System.IO;
using Quotes.Core.Entities.Dtos;
using Newtonsoft.Json;
using System.Linq;

namespace Quotes.Infrastructure.Data.Repositories
{
    public class Repository<T> : GenericRepository<T>, IRepository<T> where T : class, IEntity
    {
        //public Repository() : base(CustomerContext.DbConnectionString(), "Customer")
        //{

        //}

        //public Repository(IDocumentClient client, ILoggerFactory loggerFactory) : base(client, loggerFactory)
        //{

        //}
        private const string quotespartitionKey = "quotes";
        private const string IafMbpPartitionKey = "iafRouteSource";
        private const string StoredProcIdCalculateMbpPrice = "stp_CalculateMBP";
        private const string StoredProcIdGetLocationCode = "stp_GetAirportLocationCode";
        private const string StoredProcIdGetQuotesDetails = "stp_GetQuoteDetails";
        private const string StoredProcIdGetquotedatacountrynames = "procGetquotedatacountrynames";
        private const string PartitionKeyLocationMap = "locationmapping";
        private const string StoredProcIdGetRateCalulatorDetails = "procGetListOfAllRoute";
        private const string StoredProcIdQuotesLstIntPortal = "GetQuoteDetailsListInternalPortal";
        private const string StoredProcIdBulkDelete = "procbulkDelete";
        private const string StoredProcIdPinnedOrUnpinnedQuote = "procPinnedOrUnpinnedQuote";
        private const string StoredProcIdCreateBulkDuplicateQuotes = "procCreateBulkDuplicateQuotes";
        private readonly GenericRepository<QuoteData> quotesdb;
        private readonly GenericRepository<AirFreightShipmentDetail> quotesdb1;
        private readonly GenericRepository<CommodityTypeList> quotesdb2;
        private readonly GenericRepository<QuoteDataRequest> quotesdb4;
        private readonly GenericRepository<QuoteData> quotesdb3;
        private readonly GenericRepository<CommodityNames> quotesdb5;
        private readonly GenericRepository<CustomerProfile> customerdb;
        private readonly GenericRepository<CalculatedMBPResponse> quotesdb6;
        private readonly GenericRepository<LocationCodeResponse> quotesdb7;
        private readonly GenericRepository<QuoteRootLocation> quotesdb8;
        private readonly GenericRepository<RateCalculatorDetailResponse> quotesdb9;
        private readonly GenericRepository<ListOfQuoteData> quotesdb10;
        private readonly GenericRepository<ShipmentDeleteCount> quotesdb11;
        private readonly GenericRepository<CountOfRecordsUpdated> quotesdb12;
        private readonly GenericRepository<QuoteAccessorialDetail> quotesAccessorialdb;
        public Repository(IDocumentClient client, ILoggerFactory loggerFactory)
            : base(client, loggerFactory, "Customer", "external")
        {
            //_docClient = client;
            //_loggerFactory = loggerFactory;
            quotesdb = new GenericRepository<QuoteData>(client, loggerFactory, "Bonsai", "GFF");
            quotesdb1 = new GenericRepository<AirFreightShipmentDetail>(client, loggerFactory, "Bonsai", "GFF");
            quotesdb2 = new GenericRepository<CommodityTypeList>(client, loggerFactory, "Bonsai", "GFF");
            quotesdb3 = new GenericRepository<QuoteData>(client, loggerFactory, "Bonsai", "GFF");
            quotesdb4 = new GenericRepository<QuoteDataRequest>(client, loggerFactory, "Bonsai", "GFF");
            quotesdb5 = new GenericRepository<CommodityNames>(client, loggerFactory, "Bonsai", "GFF");
            quotesdb6 = new GenericRepository<CalculatedMBPResponse>(client, loggerFactory, "Bonsai", "GFF");
            quotesdb7 = new GenericRepository<LocationCodeResponse>(client, loggerFactory, "Bonsai", "GFF");
            quotesdb8 = new GenericRepository<QuoteRootLocation>(client, loggerFactory, "Bonsai", "GFF");
            quotesdb9 = new GenericRepository<RateCalculatorDetailResponse>(client, loggerFactory, "Bonsai", "GFF");
            quotesdb10 = new GenericRepository<ListOfQuoteData>(client, loggerFactory, "Bonsai", "GFF");
            quotesdb11 = new GenericRepository<ShipmentDeleteCount>(client, loggerFactory, "Bonsai", "GFF");
            quotesdb12 = new GenericRepository<CountOfRecordsUpdated>(client, loggerFactory, "Bonsai", "GFF");
            customerdb = new GenericRepository<CustomerProfile>(client, loggerFactory, "Bonsai", "GFF");
            quotesAccessorialdb = new GenericRepository<QuoteAccessorialDetail>(client, loggerFactory, "Bonsai", "GFF");
        }

        public QuoteData SaveQuoteForLater(QuoteData quoteData)
        {
            return quotesdb.Upsert(quoteData).Result;
        }

        public  AirFreightShipmentDetail SaveAirFreightShipmentDetail(AirFreightShipmentDetail shipmentDetails)
        {
            //SaveShipmentAddress(shipmentDetails);
            return quotesdb1.Upsert(shipmentDetails).Result;
            
        }

        public QuoteAccessorialDetail SaveQuoteAccessorialDetail(List<QuoteAccessorialDetail> quoteAccessorialDetails)
        {
            QuoteAccessorialDetail result = new QuoteAccessorialDetail();
            quoteAccessorialDetails.ForEach(quoteAccessorialDetail =>
            {
                result = quotesAccessorialdb.Upsert(quoteAccessorialDetail).Result;
                if (result == null)
                {

                }
            });
            return result;
        }

        public async void SaveShipmentAddress(AirFreightShipmentDetail shipmentDetails)
        {
            var sprocBody = File.ReadAllText(@"..\Quotes.Infrastructure.Data\StoredProcedures\UpdateShippingAddress.js");

            //await quotesdb1.ExecuteStoredProcedure(sprocBody).ConfigureAwait(false); 
        }

        public async Task<QuoteDataRequest> GetQuoteDetails(string quoteNumber)
        {
            SearchModel mod = new SearchModel
            {
                PageSize = 100,
            };
            var lst = await quotesdb4.ExecuteStoredProcedure(quoteNumber, StoredProcIdGetQuotesDetails, quotespartitionKey).ConfigureAwait(false);
            return lst;
        }
        public async Task<QuoteRootLocation> Getquotedatacountrynames(string countryCode)
        {
            
            QuoteRootLocation objQuoteRootLocation = new QuoteRootLocation();
            var lst = await quotesdb8.ExecuteStoredProcedure(countryCode, StoredProcIdGetquotedatacountrynames, PartitionKeyLocationMap).ConfigureAwait(false);

            if(lst!=null)
            {
                objQuoteRootLocation.countryName = lst.countryName;
            }
          return objQuoteRootLocation;

        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public async Task<ISearchResult<CommodityTypeList>> GetCommodityTypeList()
        {
            Expression<Func<CommodityTypeList, bool>> criteria;

            criteria = (d => d.DocType == "commodityType");

            SearchModel mod = new SearchModel
            {
                PageSize = 100,
            };
            var lst = await quotesdb2.Get(criteria, mod).ConfigureAwait(false);
            return lst;

        }
        /// <summary>
        /// To get the quote list of logged in user for dashboard
        /// </summary>
        /// <param name="accountNumber"></param>
        /// <returns></returns>
        public async Task<ISearchResult<QuoteData>> GetQuoteList(string accountNumber)
        {
            //string getQuoteDetailsQuery= "SELECT c.quoteNumber,c.quoteRequestDate,c.quoteStatusCode,c.quoteStatusDescriptionText,c.docId FROM GFF c where c.docType='quotes' and c.accountNumber='" + accountNumber.ToLower() + "' and c.quoteStatusCode not in(6) ";
            string getQuoteDetailsQuery = "SELECT * FROM GFF c where c.docType='quotes' and c.accountNumber='" + accountNumber.ToLower() + "' and c.quoteStatusCode not in(6) ";
            SearchModel mod = new SearchModel
            {
                PageSize = 100,
            };
            return await quotesdb3.Get(getQuoteDetailsQuery, mod).ConfigureAwait(false);
           
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="accountNumber"></param>
        /// <returns></returns>
        public async Task<CommodityNames> GetCommodityNameList(string accountNumber)
        {
            var lst = await quotesdb5.ExecuteStoredProcedure(accountNumber, "procGetCommodityNameList", quotespartitionKey).ConfigureAwait(false);
            CommodityNames comLst = new CommodityNames
            {
                CommodityName = lst.CommodityName.Take(5).ToArray()
            };
            return comLst;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <param name="custId"></param>
        /// <returns></returns>
        public async Task<ISearchResult<CustomerProfile>> GetCustomerProfile(string custId)
        {
           string getcustomerQuery = "SELECT * FROM GFF c where c.docType='customerprofile' and c.userId='" + custId + "' ";
            SearchModel mod = new SearchModel
            {
                PageSize = 100,
            };
            return await customerdb.Get(getcustomerQuery, mod).ConfigureAwait(false);
        }
        /// <summary>
        /// To update customer profile
        /// </summary>
        /// <param name="userProfile"></param>
        /// <returns></returns>
        public Task<CustomerProfile> UpdateCustProfile(CustomerProfile userProfile)
        {
            return customerdb.Upsert(userProfile);
        }

        public async Task<CalculatedMBPResponse> CalculateMBP(CalculateMbpRateRequest request)
        {
            return await quotesdb6.ExecuteStoredProcedure(JsonConvert.SerializeObject(request), StoredProcIdCalculateMbpPrice, IafMbpPartitionKey).ConfigureAwait(false);
        }

        public async Task<LocationCodeResponse> GetLocationCodes(CalculateMbpRateRequest request)
        {
            return await quotesdb7.ExecuteStoredProcedure(JsonConvert.SerializeObject(request), StoredProcIdGetLocationCode, PartitionKeyLocationMap).ConfigureAwait(false);
        }

        public async Task<RateCalculatorDetailResponse> GetWeightBreaksDetails(List<IafRouteDetailRequest> request)
        {
            return await quotesdb9.ExecuteStoredProcedure(JsonConvert.SerializeObject(request), StoredProcIdGetRateCalulatorDetails, IafMbpPartitionKey).ConfigureAwait(false);
        }

        /// <summary>
        /// Get Quote List Internal Portal
        /// </summary>
        /// <param name="accountNumber"></param>
        /// <returns></returns>
        public async Task<ListOfQuoteData> GetQuoteListIntPortal(string accountNumber)
        {
            var lstQuotes= await quotesdb10.ExecuteStoredProcedure(accountNumber, StoredProcIdQuotesLstIntPortal, quotespartitionKey).ConfigureAwait(false);
            return lstQuotes;
        }

        public async Task<ShipmentDeleteCount> DeleteDuplicateShipmentDetails(string query)
        {
            var ConfirmDelete= await quotesdb11.ExecuteStoredProcedure(query, StoredProcIdBulkDelete, quotespartitionKey).ConfigureAwait(false);
            return ConfirmDelete;
        }

        /// <summary>
        /// Update quote status for Pinned or unpinned
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        public async Task<CountOfRecordsUpdated> PinnedOrUnPinnedQuotes(LstOfIdsPinnedOrUnpinned request)
        {
            var response= await quotesdb12.ExecuteStoredProcedure(JsonConvert.SerializeObject(request), StoredProcIdPinnedOrUnpinnedQuote, quotespartitionKey).ConfigureAwait(false);
            return response;
        }

        public async Task<CountOfRecordsUpdated> DuplicateMultipleQuotes(ListOfIds request)
        {
            var response = await quotesdb12.ExecuteStoredProcedure(JsonConvert.SerializeObject(request), StoredProcIdCreateBulkDuplicateQuotes, quotespartitionKey).ConfigureAwait(false);
            return response;
        }
    }
}
