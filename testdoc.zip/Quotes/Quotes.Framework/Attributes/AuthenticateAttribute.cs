﻿using System;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.Mvc.Controllers;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.DependencyInjection;

namespace Quotes.Framework.Attributes
{
    using Extensions;
    using Security;
    using Core.Security;
    using Core.Config;
    public class AuthenticateAttribute :ActionFilterAttribute
    {
        private readonly IConfig _config;
        private readonly ILogger _logger;
        private readonly IServiceProvider _serviceProvider;
        private BonsaiTokenValidator _tokenValidator;

        public AuthenticateAttribute(IServiceProvider serviceProvider, ILoggerFactory loggerFactory)
        {
            _serviceProvider = serviceProvider;
            _config = _serviceProvider.GetService<IConfig>();
            _logger = loggerFactory.CreateLogger("Customer.Framework.Attributes.AuthenticateAttribute");
        }

        public override void OnActionExecuting(ActionExecutingContext actionContext)
        {
            if (actionContext.SkipAuthorization())
            {
                return;
            }
            base.OnActionExecuting(actionContext);
            /*
            if (!IsAuthorized(actionContext))
            {
                return;
            }
            */
            string token = actionContext.GetAuthenticationHeaderValue();
            string email = CurrentPrincipal.GetClaimValue("emails");

            if (string.IsNullOrEmpty(token) || string.IsNullOrEmpty(email))
            {
                actionContext.HandleUnauthorizedRequest();
                return;
            }

            var controllerActionDescriptor = actionContext.ActionDescriptor as ControllerActionDescriptor;
            if ((controllerActionDescriptor.ControllerName == "Users" && controllerActionDescriptor.ActionName == "CreateUser") ||
                (controllerActionDescriptor.ControllerName == "Users" && controllerActionDescriptor.ActionName == "SaveUserInfo"))
            {
                //token is already authenticated. hence returning true.
                return;
            }

            _tokenValidator = _serviceProvider.GetService<BonsaiTokenValidator>();
            // var principal = (PricingPrincipal)_tokenValidator.ValidateUser(token, email);

            var principal = (BonsaiPrincipal)_tokenValidator.ValidateUser(email);

            if (principal == null)
            {
                actionContext.HandleUnauthorizedRequest();
                return;
            }

            SetPrincipal(actionContext, principal);
        }

        private void SetPrincipal(ActionExecutingContext actionContext, BonsaiPrincipal principal)
        {
            actionContext.HttpContext.User = principal;
            CurrentPrincipal.SetCurrentPrincipal(principal);
        }
    }
}
