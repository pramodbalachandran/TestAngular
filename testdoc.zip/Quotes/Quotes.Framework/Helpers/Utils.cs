﻿using System;
using System.Security.Cryptography;
using System.Text.RegularExpressions;

using Quotes.Core.Resources;

namespace Quotes.Framework.Helpers
{
    public static class Utils
    {

        static readonly char[] AvailableCharacters = {
                                                        'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M',
                                                        'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z',
                                                        'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm',
                                                        'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z',
                                                        '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '-', '_'
                                                      };

        /*
        public static bool ValidateFacebookToken(string userToken, string email)
        {
            try
            {
                var fb = new FacebookClient(userToken);
                dynamic faceBookEmail = fb.Get("/me?fields=email");
                if (faceBookEmail != null && (faceBookEmail.id != "" || faceBookEmail.email == email))
                    return true;
                else
                    return false;
            }
            catch
            {
                return false;
            }

        }
        */

        public static int ConvertTimeStampInMilliSecondToSecond(long unixTimeStamp)
        {
            return (int)(unixTimeStamp / 1000);
        }

        public static string GenerateIdentifier(int length)
        {

            char[] identifier = new char[length];
            byte[] randomData = new byte[length];

            using (RNGCryptoServiceProvider rng = new RNGCryptoServiceProvider())
            {
                rng.GetBytes(randomData);
            }

            for (int idx = 0; idx < identifier.Length; idx++)
            {
                int pos = randomData[idx] % AvailableCharacters.Length;
                identifier[idx] = AvailableCharacters[pos];
            }

            return new string(identifier);


        }

        public static string Base64Encode(string plainText)
        {
            var plainTextBytes = System.Text.Encoding.UTF8.GetBytes(plainText);
            return System.Convert.ToBase64String(plainTextBytes);
        }

        public static string Base64Decode(string base64EncodedData)
        {
            var base64EncodedBytes = System.Convert.FromBase64String(base64EncodedData);
            return System.Text.Encoding.UTF8.GetString(base64EncodedBytes);
        }

        public static DateTime UnixTimeStampToDateTime(int unixTimeStamp)
        {
            // Unix timestamp is seconds past epoch
            System.DateTime dtDateTime = new DateTime(1970, 1, 1, 0, 0, 0, 0, System.DateTimeKind.Utc);
            dtDateTime = dtDateTime.AddSeconds(unixTimeStamp).ToUniversalTime();
            return dtDateTime;
        }

        public static DateTime? NullableUnixTimeStampToDateTime(int? unixTimeStamp)
        {
            // Unix timestamp is seconds past epoch
            if (unixTimeStamp != null)
            {
                System.DateTime dtDateTime = new DateTime(1970, 1, 1, 0, 0, 0, 0, System.DateTimeKind.Utc);
                dtDateTime = dtDateTime.AddSeconds((int)unixTimeStamp).ToUniversalTime();
                return dtDateTime;
            }
            else
            {
                return null;
            }
        }

        /// <summary>
        /// Convert If not nullable
        /// </summary>
        /// <param name="DateToConvert"></param>
        /// <returns></returns>
        public static int DateTimeToUnixTimeStamp(DateTime DateToConvert)
        {
            return (Int32)(DateToConvert.Subtract(new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc))).TotalSeconds;
        }

        /// <summary>
        /// Convert If nullable
        /// </summary>
        /// <param name="DateToConvert"></param>
        /// <returns></returns>
        public static int? NullableDateTimeToUnixTimeStamp(DateTime? DateToConvert)
        {
            if (DateToConvert.HasValue)
            {
                return (Int32)(((DateTime)DateToConvert).Subtract(new DateTime(1970, 1, 1, 0, 0, 0, DateTimeKind.Utc))).TotalSeconds;

            }
            else
                return null;
        }
        public static string GetMessage(string messageCode)
        {
            return Messages.ResourceManager.GetString(messageCode);
        }

        public static DateTime GetStartDateForMasterData()
        {
            return DateTime.UtcNow.Date.AddDays(-14);
        }

        public static DateTime GetEndDateForMasterData()
        {
            return DateTime.UtcNow.Date.AddDays(1);
        }

        public static DateTime GetStartDateForMasterData(int day)
        {
            return DateTime.UtcNow.Date.AddDays(-day);
        }

        private static readonly Random random = new Random();
        private static readonly object syncLock = new object();
        public static int GetRandomNum()
        {
            lock (syncLock)
            { // synchronize
                return random.Next();
            }
        }

        public static long GenerateDeviceUniqeId(int UserId)
        {
            string stringNum = UserId + GetRandomNum().ToString();
            return Convert.ToInt64(stringNum);
        }

        public static bool ValidateVIN(string vino)
        {
            bool result = false;

            if (vino.Length != 17 || !IsAlphaNumeric(vino))
            {
                result = false;
            }
            else
            {
                result = true;
            }

            return result;
        }

        public static bool IsAlphaNumeric(string vinToCheck)
        {
            Regex rg = new Regex(@"^[A-HJ-NPR-Z0-9]*$");//0-1,A-Z except I,O,Q 
            return rg.IsMatch(vinToCheck);
        }
    }
}
