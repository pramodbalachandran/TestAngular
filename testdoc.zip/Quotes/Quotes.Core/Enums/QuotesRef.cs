﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Quotes.Core.Enums
{
    public enum QuotesType
    {
        ShortTerm = 1,
        LongTerm=2
    }

    public enum QuotesStatus
    {
        NotSubmitted = 1,
        Completed = 2,
        Submitted=3,
        Declined=4,
        Accepted=5,
        Deleted=6,
        AwaitingUPSResponse=7
    }

    public enum MovementType
    {
        AirportToAirport  = 1,
        DoorToAirport = 2,
        AirportToDoor=3,
        DoorToDoor=4
    }

    public enum ShipmentUnitOfMeasureTypeCode
    {
        CMKG=1,
        INLB=2,
        INKG=3

    }

    public enum ShipmentWeightTypeCode
    {
        WeightByPeice = 1,
        TotalWeight = 2

    }
}
