﻿using System;
using System.Collections.Generic;
using System.Text;

using Quotes.Core.Entities;

namespace Quotes.Core.Repositories
{
    interface ITaskRepository :ICoreRepository<MyTask>
    {
    }
}
