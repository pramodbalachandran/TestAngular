﻿using Bonsai.Azure.CosmosDb.Models;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace Quotes.Core.Services
{
    public interface IBaseService<T>
    {
        Task<T> Get(Guid id);
        Task<ISearchResult<T>> GetAll();
        Task<ISearchResult<T>> Query(Expression<Func<T, bool>> filter);
        Task<T> Add(T item);
        Task<T> Update(T item);
        Task Remove(Guid id);
    }
}
