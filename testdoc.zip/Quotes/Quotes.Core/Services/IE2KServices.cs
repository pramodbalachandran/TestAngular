﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Bonsai.Azure.CosmosDb.Models;
using Quotes.Core.Entities;
using Quotes.Core.Entities.Dtos;

namespace Quotes.Core.Services
{
    public interface IE2KServices
    {
        dynamic GetE2kBidCharges(QuoteDataRequest quoteRequestData);
    }
}