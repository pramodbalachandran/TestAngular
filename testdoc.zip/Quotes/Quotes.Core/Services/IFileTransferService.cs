﻿using Microsoft.AspNetCore.Http;
using Quotes.Core.Entities;
using System.IO;
using System.Threading.Tasks;

namespace Quotes.Core.Services
{
    public interface IFileTransferService
    {
        /// <summary>
        /// Upload file to blob and returns the path
        /// </summary>
        /// <param name="file"></param>
        /// <returns></returns>
        Task<QuoteAttachment[]> FileUpload(IFormFile file);

        /// <summary>
        /// Download file belonging to the specified quote ID, from the blob
        /// </summary>
        /// <param name="quoteId">quote Id</param>
        /// <returns></returns>
        Task<Stream> FileDownload(string quoteId);
    }
}
