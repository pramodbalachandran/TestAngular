﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Quotes.Core.Services
{
    using Bonsai.Azure.CosmosDb.Models;
    using Entities;
    using Microsoft.AspNetCore.Http;
    using Microsoft.AspNetCore.Mvc;
    using Quotes.Core.Entities.Dtos;
    using System.IO;
    using System.Threading.Tasks;

    public interface ITaskService : IBaseService<MyTask>
    {
        void CreateTask();

        JsonResponseDto SaveQuoteForLater(QuoteDataRequest quoteData);

        Task<QuoteDataRequest> GetQuoteDetails(string quoteNumber);
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        Task<ISearchResult<CommodityTypeList>> GetCommodityTypeList();

        Task<ISearchResult<QuoteData>> GetQuoteList(string accountNumber);

        /// <summary>
        /// Get Quote List Int Portal
        /// </summary>
        /// <param name="accountNumber"></param>
        /// <returns></returns>
        Task<ListOfQuoteData> GetQuoteListIntPortal(string accountNumber); 

        /// <summary>
        /// To get the existing commodity item
        /// </summary>
        /// <param></param>
        /// <returns>CommodityTypeList</returns>
        Task<CommodityNames> GetCommodityNameList(string accountNumber);

        /// <summary>
        /// Upload file
        /// </summary>
        /// <param name="file"></param>
        /// <returns>QuoteAttachment info</returns>
        string FileUpload(IFormFile file);

        /// <summary>
        /// Create duplicate Quote
        /// </summary>
        /// <param name="quoteNumber"></param>
        /// <returns></returns>
        Task<ResponseModel> CreateDuplicateQuote(string quoteNumber);

        Task<CalculatedMBPResponse> CalculateMBP(CalculateMbpRateRequest request);

        /// <summary>
        /// To delete customer quote - quote status changed to delete .
        /// </summary>
        /// <param name="quoteNumber"></param>
        /// <returns>ResponseStatus</returns>
        Task<ResponseStatus> DeleteCustomerQuote(string quoteNumber);

        /// <summary>
        /// Download file belonging to the specified quote ID, from the blob
        /// </summary>
        /// <param name="quoteId">quote Id</param>
        /// <returns></returns>
        Stream GetFile(string quoteId);

        /// <summary>
        /// Get PM Weight Breaks Details
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        Task<ResponseModel> GetWeightBreaksDetails(List<IafRouteDetailRequest> request);

        /// <summary>
        /// Download UPS Default Template File
        /// </summary>
        /// <returns></returns>
        Stream GetUPSDefaultTemplateFile();

        ResponseModel GetE2KBidCharges(QuoteDataRequest quoteRequestData);

        /// <summary>
        /// update quote status for pinned or unpinned
        /// </summary>
        /// <param name="request"></param>
        Task<ResponseModel> PinnedOrUnPinnedQuotes(LstOfIdsPinnedOrUnpinned request);

        /// <summary>
        /// duplicate multiple quotes
        /// </summary>
        /// <param name="request"></param>
        /// <returns></returns>
        Task<ResponseModel> DuplicateMultipleQuotes(ListOfIds request);
    }
}
