﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Quotes.Core.Constants
{
    public class QuoteDocumentType
    {
        public const string DocTypeQuotes = "quotes";
        public const string DocTypeAirFreightShipmentDetail = "airFreightShipmentDetail";

    }

    public class QuoteDocumentId
    {
        public const string DocIdQuotes = "quote::quoteIdentificationNumber::businessPartyName::businessPartyNumber";
        public const string DocIdAirFreightShipmentDetail = "airFreightShipmentDetail::shipmentDetailIdentificationNumber";

    }
}
