﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Quotes.Core.Constants
{
    public class QuotesConsts
    {
        public const string Failed = "PRICING_999";

        public const string UpdateFailed = "PRICING_998";

        public const string BadRequest = "PRICING_990";

        public const string LogInToContinue = "PRICING_991";

        public const string AccessDenied = "PRICING_992";

        public const string JsonInputIsIncorrect = "PRICING_993";

        public const string LocalizationSourceName = "PRICING";

        public const string InternalServerError = "PRICING_500";

        public const string DuplicateCarrier = "PRICING_5000";

        public const string LimitCarriers = "PRICING_5002";

        public const string NoCarrier = "PRICING_5001";

        public const string DuplicateEmailAndDotNumber = "PRICING_5003";

        public const string DuplicateDotNumber = "PRICING_5004";

        public const string VehicleIdNotFound = "PRICING_2100";

        public const string DuplicateEmailAddress = "PRICING_1003";

        public const string EmailValidationFailed = "PRICING_1005";

        public const string InvalidFacebookUser = "PRICING_1002";

        public const string NoUserExists = "PRICING_1001";

        public const string FacebookEmail = "PRICING_1006";

        public const string TooManyAttempts = "PRICING_1007";

        public const string TooManyAttemptsFB = "PRICING_1008";

        public const string InvalidEmailOrPassword = "PRICING_1009";

        public const string IftaIdNotFound = "PRICING_1010";

        public const string CDLAlreadyExists = "PRICING_1011";

        public const string ShipmentDetailIdentificationNumber = "QS";

        public const string InternalServerErr = "500";
        
        public const string RequestSuccess = "200";
        
        public const string StatusSuccess = "1";
        
        public const string StatusFailure = "0";
        
        public const string SuccessMessage = "Success";
        
        public const string FailureMessage = "Failed";
        
        public const string E2kServicesurl = "E2KService:E2KServiceURL";
        
        public const string PartitionKey = "quoteaccessorial";
        
        public const string Separator = "::";
    }

    public class E2kConstants
    {
        public const string E2kRequest_DataSource_Node = "//ImportWkSecUserWebservice/DataSource";
        public const string E2kRequest_Domain_Node = "//ImportWkSecUserWebservice/Domain";
        public const string E2kRequest_User_Node = "//ImportWkSecUserWebservice/User";
        public const string E2kRequest_ShipperCity_Node = "//ImportShipperRequestedShipmentParty/City";
        public const string E2kRequest_ShipperCountry_Node = "//ImportShipperRequestedShipmentParty/CountryCode";
        public const string E2kRequest_ConsigneeCity_Node = "//ImportConsigneeRequestedShipmentParty/City";
        public const string E2kRequest_ConsignCountry_Node = "//ImportConsigneeRequestedShipmentParty/CountryCode";
        public const string E2kRequest_OriginServiceCenter_Node = "//ImportShipperIprc1Shipment/OriginServiceCenter";
        public const string E2kRequest_DestServiceCenter_Node = "//ImportConsigneeRequestedShipment/DestinationServiceCenter";
        public const string E2kRequest_PaymentType_Node = "//ImportTypeRequestedShipment/PaymentType";
        public const string E2kRequest_TotalNumberOfPieces_Node = "//ImportTotalPickupRequest/TotalNumberOfPieces";
        public const string E2kRequest_Weight_Node = "//ImportTotalPickupRequest/Weight";
        public const string E2kRequest_ImportGroupPieces_Node = "//ImportGroupPieces";

        public const string E2kRequest_Row_Node = "row";
        public const string E2kRequest_ImportGrpPieceSummary_Node = "ImportGrpPiecePieceSummary";
        public const string E2kRequest_NumberOfPieces_Node = "NumberOfPieces";
        public const string E2kRequest_PieceLength_Node = "PieceLength";
        public const string E2kRequest_Width_Node = "Width";
        public const string E2kRequest_Height_Node = "Height";
        public const string E2kRequest_UOM_Node = "UnitOfMeasure";

        public const string E2kRequest_ImpGrpPieceNumberOfPieces_Node = "//ImportGroupPieces/row/ImportGrpPiecePieceSummary/NumberOfPieces";

        public const string E2kRequest_ImportCommodityRateQuote_Node = "//ImportCommodityRateQuote";
        public const string E2kRequest_CommodityDescription_Node = "CommodityDescription";
        public const string E2kRequest_ServiceLevelRequested_Node = "//ImportIprc1Shipment/ServiceLevelRequested";
        public const string E2kRequest_Flag_Node = "//ImportUseOfferedPaIefSupplied/Flag";
        public const string E2kRequest_OrigTariffPoint_Node = "//ImportIprc1Shipment/OrigTariffPoint";
        public const string E2kRequest_DestTariffPoint_Node = "//ImportIprc1Shipment/DestTariffPoint";

        public const string E2kResponse_GroupTriggeredCharges_Node = "ExportGroupTriggeredCharges";
        public const string E2kResponse_ExportGrpIprc1ShpCharge_Node = "ExportGrpIprc1ShpCharge";
        public const string E2kResponse_ExportGroupPoint_Node = "ExportGroupPoint";
        public const string E2kResponse_ExportGroupServiceLevel_Node = "ExportGroupServiceLevel";
        public const string E2kResponse_ExportGroupInclusion_Node = "ExportGroupInclusion";
        public const string E2kResponse_ExportGroupDetails_Node = "ExportGroupDetails";
                            
        public const string E2kResponse_GrpChrRefIprc1ShpCharge_Node = "ExportGrpChrRefIprc1ShpCharge";
        public const string E2kResponse_ChargeCode_Node = "ChargeCode";
        public const string E2kResponse_GrpPtIprc1RateScalePoints_Node = "ExportGrpPtIprc1RateScalePoints";

        public const string E2kResponse_OriginType_Node = "OriginType";
        public const string E2kResponse_DestinationType_Node = "DestinationType";
        public const string E2kResponse_DestinationPoint_Node = "DestinationPoint";
        public const string E2kResponse_OriginIsAZoneInd_Node = "OriginIsAZoneInd";
        public const string E2kResponse_DestinationIsAZoneInd_Node = "DestinationIsAZoneInd";

        public const string E2kResponse_ExportGrpSvcChgRefIprc1ShpCharge_Node = "ExportGrpSvcChgRefIprc1ShpCharge";
        public const string E2kResponse_ExportGrpSvcIprc1RateScaleServLvl_Node = "ExportGrpSvcIprc1RateScaleServiceLevel";
        public const string E2kResponse_ServiceLevel_Node = "ServiceLevel";
        public const string E2kResponse_ShortDescription_Node = "ShortDescription";
        public const string E2kResponse_ChargeAmount_Node = "ChargeAmount";
        public const string E2kResponse_ChargeCurrencyCode_Node = "ChargeCurrencyCode";
        public const string E2kResponse_ExportOriginIblc1ServiceArea_Node = "ExportOriginIblc1ServiceArea";
        public const string E2kResponse_DeliveryZoneNbr_Node = "DeliveryZoneNbr";
        public const string E2kResponse_ExportGrpIncChgRefIprc1ShpCharge_Node = "ExportGrpIncChgRefIprc1ShpCharge";
        public const string E2kResponse_ExportGrpIncIprc1RateScale_Node = "ExportGrpIncIprc1RateScale";
        public const string E2kResponse_InclusionCode_Node = "InclusionCode";
        public const string E2kResponse_ExportIprc1Shipment_Node = "ExportIprc1Shipment";
        public const string E2kResponse_EwwTotalActualWeightUom_Node = "EwwTotalActualWeightUom";
        public const string E2kResponse_ExportGrpIprc1ShipmentParty_Node = "ExportGrpIprc1ShipmentParty";
        public const string E2kResponse_RoleTypeCode_Node = "RoleTypeCode";
        public const string E2kResponse_ExportGrpDtlChgRefIprc1ShpCharge_Node = "ExportGrpDtlChgRefIprc1ShpCharge";
        public const string E2kResponse_ExportGrpDetailIprc1Rate_Node = "ExportGrpDetailIprc1Rate";
        public const string E2kResponse_ForEach_Node = "ForEach";

    }
}
