﻿using Bonsai.Azure.CosmosDb.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Quotes.Core.Entities
{
    public class IafRouteDetails
    {
        [JsonProperty(PropertyName = "originCode")]
        public string OriginCode { get; set; }      
        
        [JsonProperty(PropertyName = "destinationCode")]
        public string DestinationCode { get; set; }

        [JsonProperty(PropertyName = "originGatewayCode")] 
        public string OriginGatewayCode { get; set; }        

        [JsonProperty(PropertyName = "routeService")]
        public List<RouteService> RouteService { get; set; }

        [JsonProperty(PropertyName = "routeStatusCode")]
        public string RouteStatusCode { get; set; }

    }

    public class RouteWay
    {
        [JsonProperty(PropertyName = "routeWayName")]
        public string RouteWayName { get; set; }

        [JsonProperty(PropertyName = "routeSegmentCountQuantity")]
        public string RouteSegmentCountQuantity { get; set; }
    }

    public class RouteService
    {
        [JsonProperty(PropertyName = "routeServiceCode")]
        public string RouteServiceCode { get; set; }

        [JsonProperty(PropertyName = "u45Original")]
        public string U45Original { get; set; }

        [JsonProperty(PropertyName = "o45Original")]
        public string O45Original { get; set; }

        [JsonProperty(PropertyName = "o100Original")]
        public string O100Original { get; set; }

        [JsonProperty(PropertyName = "o500Original")]
        public string O500Original { get; set; }

        [JsonProperty(PropertyName = "o1000Original")]
        public string O1000Original { get; set; }

        [JsonProperty(PropertyName = "u45OriginalAf")]
        public string U45OriginalAf { get; set; }

        [JsonProperty(PropertyName = "o45OriginalAf")]
        public string O45OriginalAf { get; set; }

        [JsonProperty(PropertyName = "o100OriginalAf")]
        public string O100OriginalAf { get; set; }

        [JsonProperty(PropertyName = "o500OriginalAf")]
        public string O500OriginalAf { get; set; }

        [JsonProperty(PropertyName = "o1000OriginalAf")]
        public string O1000OriginalAf { get; set; }

        [JsonProperty(PropertyName = "u45MarkupOriginal")]
        public string U45MarkupOriginal { get; set; }

        [JsonProperty(PropertyName = "o45MarkupOriginal")]
        public string O45MarkupOriginal { get; set; }

        [JsonProperty(PropertyName = "o100MarkupOriginal")]
        public string O100MarkupOriginal { get; set; }

        [JsonProperty(PropertyName = "o500MarkupOriginal")]
        public string O500MarkupOriginal { get; set; }

        [JsonProperty(PropertyName = "minimumChargeAmount")]
        public string MinimumChargeAmount { get; set; }        

        [JsonProperty(PropertyName = "airFreight")]
        public string AirFreight { get; set; }

        [JsonProperty(PropertyName = "fuel")]
        public string Fuel { get; set; }

        [JsonProperty(PropertyName = "security")]
        public string Security { get; set; }

        [JsonProperty(PropertyName = "fuelMin")]
        public string FuelMin { get; set; }

        [JsonProperty(PropertyName = "securityYMin")]
        public string SecurityYMin { get; set; }

        [JsonProperty(PropertyName = "currency")]
        public string Currency { get; set; }

        [JsonProperty(PropertyName = "u45Stc")]
        public string U45Stc { get; set; }

        [JsonProperty(PropertyName = "o45Stc")]
        public string O45Stc { get; set; }

        [JsonProperty(PropertyName = "o100Stc")]
        public string O100Stc { get; set; }

        [JsonProperty(PropertyName = "o500Stc")]
        public string O500Stc { get; set; }

        [JsonProperty(PropertyName = "o1000Stc")]
        public string O1000Stc { get; set; }

        [JsonProperty(PropertyName = "allInCost")]
        public string AllInCost { get; set; }

        [JsonProperty(PropertyName = "allInCostStc")]
        public string AllInCostStc { get; set; }

        [JsonProperty(PropertyName = "routeWayName")]
        public RouteWay RouteWay { get; set; }
    }

    public class RateCalculatorDetailResponse : IModel
    {
        [JsonProperty(PropertyName = "weightBreakDetailList")]
        public List<IafRouteDetails> WeightBreakDetailList { get; set; }

        public Guid? Id { get; set; }
        public string PartitionKey { get; set; }
        public string lastContinuationToken { get; set; }
    }
}
