﻿using Bonsai.Azure.CosmosDb.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Quotes.Core.Entities
{
    public class CalculatedMBPResponse: IModel
    {
        [JsonProperty(PropertyName = "MbpPrice")]
        public string CalculatedMbpPrice { get; set; }
        public Guid? Id { get; set ; }
        public string PartitionKey { get; set; }

        public string lastContinuationToken { get; set; }
    }

    public class LocationCodeResponse : IModel
    {
        [JsonProperty(PropertyName = "origin")]
        public string Origin { get; set; }

        [JsonProperty(PropertyName = "destination")]
        public string Destination { get; set; }
        public Guid? Id { get; set; }
        public string PartitionKey { get; set; }

        public string lastContinuationToken { get; set; }
    }
}
