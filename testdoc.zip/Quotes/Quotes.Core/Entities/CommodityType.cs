﻿using Newtonsoft.Json;
using Quotes.Core.Entities.Abstract;
using System;
using System.Collections.Generic;
using System.Text;

namespace Quotes.Core.Entities
{
    public class CommodityTypeList :IEntity
    {
        [JsonProperty(PropertyName = "id")]
        public Guid? Id { get; set; }

        [JsonProperty(PropertyName = "docType")]
        public string DocType { get; set; }

        [JsonProperty(PropertyName = "partitionkey")]
        public string PartitionKey { get; set; }

        [JsonProperty(PropertyName = "commodityTypeList")]
        public CommodityType[] CommodityTypeLists { get; set; }

        public string lastContinuationToken { get; set; }


    }

    public class CommodityType
    {
        [JsonProperty(PropertyName = "commodityTypeCode")]
        public string CommodityTypeCode { get; set; }

        [JsonProperty(PropertyName = "commodityTypeDescriptionText")]
        public string CommodityTypeDescriptionText { get; set; }

    }
}
