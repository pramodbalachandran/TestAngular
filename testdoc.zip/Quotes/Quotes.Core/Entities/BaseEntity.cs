﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Quotes.Core.Entities
{
    using Entities.Abstract;
    public class BaseEntity :IEntity
    {
        public BaseEntity()
        {
            CreatedDate = DateTime.UtcNow;
        }

        public Guid? Id { get; set; }
        //public string[] ItemType { get; }
        public int Version { get; set; }

       public  string PartitionKey { get; set; }
        public int? CreatedById { get; set; }
        public virtual User CreatedBy { get; set; }
        [Required]
        public DateTime CreatedDate { get; set; }

        public int? ModifiedById { get; set; }
        public virtual User ModifiedBy { get; set; }
        public DateTime? ModifiedDate { get; set; }

        public string lastContinuationToken { get; set; }
    }
}
