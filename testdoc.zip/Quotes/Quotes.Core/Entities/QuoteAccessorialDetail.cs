﻿using Newtonsoft.Json;
using Quotes.Core.Entities.Abstract;
using System;
using System.Collections.Generic;
using System.Text;

namespace Quotes.Core.Entities
{
    
    public class QuoteAccessorialDetail : IEntity
    {
        [JsonProperty(PropertyName = "docId")]
        public string DocId { get; set; }

        [JsonProperty(PropertyName = "docType")]
        public string DocType { get; set; }

        public string lastContinuationToken { get; set; }

        [JsonProperty(PropertyName = "docStructureVersion")]
        public Int32 DocStructureVersion { get; set; }

        [JsonProperty(PropertyName = "partitionkey")]
        public string PartitionKey { get; set; }

        [JsonProperty(PropertyName = "id")]
        public Guid? Id { get; set; }

        [JsonProperty(PropertyName = "chargeTypeCode")]
        public string ChargeTypeCode { get; set; }
        [JsonProperty(PropertyName = "chargeTypeDescriptionText")]
        public string ChargeTypeDescriptionText { get; set; }
        [JsonProperty(PropertyName = "usdCurrencyAmount")]
        public string UsdCurrencyAmount { get; set; }
        [JsonProperty(PropertyName = "originTypeCode")]
        public string OriginTypeCode { get; set; }
        [JsonProperty(PropertyName = "destinationTypeCode")]
        public string DestinationTypeCode { get; set; }
        [JsonProperty(PropertyName = "internationalAirFreightServiceGroupTypeCode")]
        public string InternationalAirFreightServiceGroupTypeCode { get; set; }
        public string CostBasisDescriptionText { get; set; }
        [JsonProperty(PropertyName = "beyondPointCode")]
        public string BeyondPointCode { get; set; }
        [JsonProperty(PropertyName = "additionalChargesArrayText")]
        public string AdditionalChargesArrayText { get; set; }
        [JsonProperty(PropertyName = "rateScaleDescriptionText")]
        public string RateScaleDescriptionText { get; set; }
        [JsonProperty(PropertyName = "paymentTermMnemonicText")]
        public string PaymentTermMnemonicText { get; set; }
        [JsonProperty(PropertyName = "paymentTermTypeCode")]
        public string PaymentTermTypeCode { get; set; }
        [JsonProperty(PropertyName = "shipmentUnitOfMeasureTypeCode")]
        public string ShipmentUnitOfMeasureTypeCode { get; set; }
        [JsonProperty(PropertyName = "businessPartyRoleCode")]
        public string BusinessPartyRoleCode { get; set; }
        [JsonProperty(PropertyName = "rateForUnitTypeQuantity")]
        public string RateForUnitTypeQuantity { get; set; }
        [JsonProperty(PropertyName = "originZoneIndicator")]
        public string OriginZoneIndicator { get; set; }
        [JsonProperty(PropertyName = "destinationZoneIndicator")]
        public string DestinationZoneIndicator { get; set; }
        [JsonProperty(PropertyName = "destinationLocationCode")]
        public string DestinationLocationCode { get; set; }
        [JsonProperty(PropertyName = "destinationLocationCountryCode")]
        public string DestinationLocationCountryCode { get; set; }

        [JsonProperty(PropertyName = "quoteIdentificationNumber")]
        public string QuoteIdentificationNumber { get; set; }

        [JsonProperty(PropertyName = "accessorialBidCharge")]
        private AccessorialBidCharges[] accessorialBidCharge;

        public AccessorialBidCharges[] GetAccessorialBidCharge()
        {
            return accessorialBidCharge;
        }

        public void SetAccessorialBidCharge(AccessorialBidCharges[] value)
        {
            accessorialBidCharge = value;
        }
    }

    public class AccessorialBidCharges
    {
        [JsonProperty(PropertyName = "currencyCode")]
        public string CurrencyCode { get; set; }
        [JsonProperty(PropertyName = "minimumChargeAmount")]
        public string MinimumChargeAmount { get; set; }
        [JsonProperty(PropertyName = "maximumChargeAmount")]
        public string MaximumChargeAmount { get; set; }
        [JsonProperty(PropertyName = "originalChargeAmount")]
        public string OriginalChargeAmount { get; set; }
        [JsonProperty(PropertyName = "costBasisDescriptionText")]
        public string CostBasisDescriptionText { get; set; }
    }

}
