﻿using Bonsai.Azure.CosmosDb.Models;
using Newtonsoft.Json;
using Quotes.Core.Entities.Abstract;
using System;
using System.Collections.Generic;
using System.Text;

namespace Quotes.Core.Entities
{
    public class AirFreightShipmentDetail : IEntity
    {   
        [JsonProperty(PropertyName = "docId")]
        public string DocId { get; set; }

        [JsonProperty(PropertyName = "docType")]
        public string DocType { get; set; }
        public string lastContinuationToken { get; set; }

        [JsonProperty(PropertyName = "docStructureVersion")]
        public Int32 DocStructureVersion { get; set; }

        [JsonProperty(PropertyName = "partitionkey")]
        public string PartitionKey { get; set; }

        //[JsonProperty(PropertyName = "quoteByProductDocId")]
        //public string QuoteByProductDocId { get; set; }

        /// <summary>
        /// movementTypeDescriptionText  shipmentUnitOfMeasureTypeCode
        /// </summary>
        [JsonProperty(PropertyName = "shipmentDetailIdentificationNumber")]
        public string ShipmentDetailIdentificationNumber { get; set; }

        [JsonProperty(PropertyName = "shipmentActualWeightQuantity")]
        public string ShipmentActualWeightQuantity { get; set; }

        /// <summary>
        /// shipment Dimensional Weight Quantity
        /// </summary>
        [JsonProperty(PropertyName = "shipmentDimensionalWeightQuantity")]
        public string ShipmentDimensionalWeightQuantity { get; set; }

        /// <summary>
        /// movementTypeDescriptionText  shipmentUnitOfMeasureTypeCode
        /// </summary>
        [JsonProperty(PropertyName = "quoteIdentificationNumber")]
        public string QuoteIdentificationNumber { get; set; }

        /// <summary>
        /// movementTypeDescriptionText  shipmentUnitOfMeasureTypeCode
        /// </summary>
        [JsonProperty(PropertyName = "productIdentificationNumber")]
        public string ProductIdentificationNumber { get; set; }

        /// <summary>
        /// movementTypeDescriptionText  shipmentUnitOfMeasureTypeCode
        /// </summary>
        [JsonProperty(PropertyName = "productName")]
        public string ProductName { get; set; }

        /// <summary>
        /// movementTypeDescriptionText  shipmentUnitOfMeasureTypeCode
        /// </summary>
        [JsonProperty(PropertyName = "originLocationCode")]
        public string OriginLocationCode { get; set; }

        /// <summary>
        /// movementTypeDescriptionText  shipmentUnitOfMeasureTypeCode
        /// </summary>
        [JsonProperty(PropertyName = "originBeyondPointCode")]
        public string OriginBeyondPointCode { get; set; }

        /// <summary>
        /// movementTypeDescriptionText  shipmentUnitOfMeasureTypeCode
        /// </summary>
        [JsonProperty(PropertyName = "originLocationCountryCode")]
        public string OriginLocationCountryCode { get; set; }

        [JsonProperty(PropertyName = "OriginLocationCountryName")]
        public string OriginLocationCountryName { get; set; }

        /// <summary>
        /// movementTypeDescriptionText  shipmentUnitOfMeasureTypeCode
        /// </summary>
        [JsonProperty(PropertyName = "originLocationPoliticalDivsion2Code")]
        public string OriginLocationPoliticalDivsion2Code { get; set; }

        /// <summary>
        /// movementTypeDescriptionText  shipmentUnitOfMeasureTypeCode
        /// </summary>
        [JsonProperty(PropertyName = "originLocationPostalCode")]
        public string OriginLocationPostalCode { get; set; }
        /// <summary>
        /// movementTypeDescriptionText  shipmentUnitOfMeasureTypeCode
        /// </summary>
        [JsonProperty(PropertyName = "originRegion")]
        public string OriginRegion { get; set; }

        /// <summary>
        /// movementTypeDescriptionText  shipmentUnitOfMeasureTypeCode
        /// </summary>
        [JsonProperty(PropertyName = "destinationLocationCode")]
        public string DestinationLocationCode { get; set; }

        /// <summary>
        /// movementTypeDescriptionText  shipmentUnitOfMeasureTypeCode
        /// </summary>
        [JsonProperty(PropertyName = "destinationBeyondPointCode")]
        public string DestinationBeyondPointCode { get; set; }

        /// <summary>
        /// movementTypeDescriptionText  shipmentUnitOfMeasureTypeCode
        /// </summary>
        [JsonProperty(PropertyName = "destinationLocationCountryCode")]
        public string DestinationLocationCountryCode { get; set; }

        [JsonProperty(PropertyName = "destinationLocationCountryName")]
        public string DestinationLocationCountryName { get; set; }
        /// <summary>
        /// movementTypeDescriptionText  shipmentUnitOfMeasureTypeCode
        /// </summary>
        [JsonProperty(PropertyName = "destinationLocationPoliticalDivsion2Code")]
        public string DestinationLocationPoliticalDivsion2Code { get; set; }

        /// <summary>
        /// movementTypeDescriptionText  shipmentUnitOfMeasureTypeCode
        /// </summary>
        [JsonProperty(PropertyName = "destinationLocationPostalCode")]
        public string DestinationLocationPostalCode { get; set; }
        /// <summary>
        /// movementTypeDescriptionText  shipmentUnitOfMeasureTypeCode
        /// </summary>
        [JsonProperty(PropertyName = "destinationRegion")]
        public string DestinationRegion { get; set; }

        /// <summary>
        /// movementTypeDescriptionText  shipmentUnitOfMeasureTypeCode
        /// </summary>
        [JsonProperty(PropertyName = "internationalAirFreightServiceGroupCode")]
        public string InternationalAirFreightServiceGroupCode { get; set; }


        /// <summary>
        /// movementTypeDescriptionText
        /// </summary>
        [JsonProperty(PropertyName = "movementTypeCode")]
        public Int32 MovementTypeCode { get; set; }

        /// <summary>
        /// movementTypeDescriptionText  shipmentUnitOfMeasureTypeCode
        /// </summary>
        [JsonProperty(PropertyName = "movementTypeDescriptionText")]
        public string MovementTypeDescriptionText { get; set; }

        /// <summary>
        /// movementTypeDescriptionText
        /// </summary>
        [JsonProperty(PropertyName = "paymentTermTypeCode")]
        public string PaymentTermTypeCode { get; set; }

        /// <summary>
        /// movementTypeDescriptionText  shipmentUnitOfMeasureTypeCode
        /// </summary>
        [JsonProperty(PropertyName = "paymentTermTypeDescriptionText")]
        public string PaymentTermTypeDescriptionText { get; set; }

        /// <summary>
        /// movementTypeDescriptionText  shipmentUnitOfMeasureTypeCode
        /// </summary>
        [JsonProperty(PropertyName = "paymentTermTypeMnemonicText")]
        public string PaymentTermTypeMnemonicText { get; set; }

        /// <summary>
        /// movementTypeDescriptionText  shipmentUnitOfMeasureTypeCode
        /// </summary>
        [JsonProperty(PropertyName = "shipmentQuantity")]
        public string ShipmentQuantity { get; set; }

        /// <summary>
        /// shipmentUnitOfMeasureTypeCode  
        /// </summary>
        [JsonProperty(PropertyName = "shipmentUnitOfMeasureTypeCode")]
        public Int32 ShipmentUnitOfMeasureTypeCode { get; set; }

        /// <summary>
        /// Shipment Method 
        /// </summary>
        [JsonProperty(PropertyName = "shipmentMethod")]
        public string ShipmentMethod { get; set; }

        /// <summary>
        /// movementTypeDescriptionText  shipmentUnitOfMeasureTypeCode
        /// </summary>
        [JsonProperty(PropertyName = "shipmentFrequencyTimePeriodDescriptionText")]
        public string ShipmentFrequencyTimePeriodDescriptionText { get; set; }

        [JsonProperty(PropertyName = "shipmentFrequency")]
        public int ShipmentFrequency { get; set; }

        /// <summary>
        /// movementTypeDescriptionText  shipmentUnitOfMeasureTypeCode
        /// </summary>
        [JsonProperty(PropertyName = "shipmentPalletQuantity")]
        public string ShipmentPalletQuantity { get; set; }

        /// <summary>
        /// movementTypeDescriptionText  shipmentUnitOfMeasureTypeCode
        /// </summary>
        [JsonProperty(PropertyName = "shipmentLooseUnitQUantity")]
        public string ShipmentLooseUnitQUantity { get; set; }

        /// <summary>
        /// movementTypeDescriptionText  shipmentUnitOfMeasureTypeCode
        /// </summary>
        [JsonProperty(PropertyName = "commodityTypeCode")]
        public string CommodityTypeCode { get; set; }

        /// <summary>
        /// Page 5 commodity Name List
        /// </summary>
        [JsonProperty(PropertyName = "commodityNameList")]
        public List<CommodityNameList> CommodityNameLists { get; set; }
        /// <summary>
        /// movementTypeDescriptionText  shipmentUnitOfMeasureTypeCode
        /// </summary>
        [JsonProperty(PropertyName = "commodityTypeDescriptionText")]
        public string CommodityTypeDescriptionText { get; set; }

        /// <summary>
        /// movementTypeDescriptionText  shipmentUnitOfMeasureTypeCode
        /// </summary>
        [JsonProperty(PropertyName = "commentText")]
        public string CommentText { get; set; }
        /// <summary>
        /// movementTypeDescriptionText  shipmentUnitOfMeasureTypeCode
        /// </summary>
        [JsonProperty(PropertyName = "customerOriginLocationCode")]
        public string CustomerOriginLocationCode { get; set; }

        /// <summary>
        /// movementTypeDescriptionText  shipmentUnitOfMeasureTypeCode
        /// </summary>
        [JsonProperty(PropertyName = "customerDestinationLocationCode")]
        public string CustomerDestinationLocationCode { get; set; }


        /// <summary>
        /// movementTypeDescriptionText
        /// </summary>
        [JsonProperty(PropertyName = "customerAveraegActualWeightQuantity")]
        public string CustomerAveraegActualWeightQuantity { get; set; }

        /// <summary>
        /// movementTypeDescriptionText  shipmentUnitOfMeasureTypeCode
        /// </summary>
        [JsonProperty(PropertyName = "customerAverageDimensionalWeightQuantity")]
        public string CustomerAverageDimensionalWeightQuantity { get; set; }

        /// <summary>
        /// movementTypeDescriptionText 
        /// </summary>
        [JsonProperty(PropertyName = "hazardousMaterialsIndicator")]
        public Int32 HazardousMaterialsIndicator { get; set; }

        /// <summary>
        /// Page 6 Does this shipment contains anything perishable
        /// </summary>
        [JsonProperty(PropertyName = "perishableShipmentIndicator")]
        public Int32 PerishableShipmentIndicator { get; set; }

        /// <summary>
        /// movementTypeDescriptionText  shipmentUnitOfMeasureTypeCode
        /// </summary>
        [JsonProperty(PropertyName = "hazardousMaterialName")]
        public string HazardousMaterialName { get; set; }

        /// <summary>
        /// movementTypeDescriptionText  shipmentUnitOfMeasureTypeCode
        /// </summary>
        [JsonProperty(PropertyName = "hazardousMaterialUnitedNationsNumber")]
        public string HazardousMaterialUnitedNationsNumber { get; set; }

        /// <summary>
        /// shipmentUnitOfMeasureTypeCode  
        /// </summary>
        [JsonProperty(PropertyName = "hazardousMaterialUnitedNationsClassificationCode")]
        public string HazardousMaterialUnitedNationsClassificationCode { get; set; }
        /// <summary>
        /// movementTypeDescriptionText  shipmentUnitOfMeasureTypeCode
        /// </summary>
        [JsonProperty(PropertyName = "hazardousMaterialPackagingGroupText")]
        public string HazardousMaterialPackagingGroupText { get; set; }

        /// <summary>
        /// movementTypeDescriptionText  shipmentUnitOfMeasureTypeCode
        /// </summary>
        [JsonProperty(PropertyName = "shipmentOversizeIndicator")]
        public string ShipmentOversizeIndicator { get; set; }

        /// <summary>
        /// movementTypeDescriptionText  shipmentUnitOfMeasureTypeCode
        /// </summary>
        [JsonProperty(PropertyName = "upperDeckIndicator")]
        public string UpperDeckIndicator { get; set; }

        /// <summary>
        /// movementTypeDescriptionText  shipmentUnitOfMeasureTypeCode
        /// </summary>
        [JsonProperty(PropertyName = "originAccountNumber")]
        public string OriginAccountNumber { get; set; }

        /// <summary>
        /// movementTypeDescriptionText  shipmentUnitOfMeasureTypeCode
        /// </summary>
        [JsonProperty(PropertyName = "originBusinessPartyName")]
        public string OriginBusinessPartyName { get; set; }

        /// <summary>
        /// movementTypeDescriptionText  shipmentUnitOfMeasureTypeCode
        /// </summary>
        [JsonProperty(PropertyName = "originBusinessPartySecondName")]
        public string OriginBusinessPartySecondName { get; set; }

        /// <summary>
        /// movementTypeDescriptionText  shipmentUnitOfMeasureTypeCode
        /// </summary>
        [JsonProperty(PropertyName = "originAddressLine1Text")]
        public string originAddressLine1Text { get; set; }

        /// <summary>
        /// movementTypeDescriptionText  shipmentUnitOfMeasureTypeCode
        /// </summary>
        [JsonProperty(PropertyName = "originAddressLine2Text")]
        public string originAddressLine2Text { get; set; }

        /// <summary>
        /// movementTypeDescriptionText  shipmentUnitOfMeasureTypeCode
        /// </summary>
        [JsonProperty(PropertyName = "originAddressLine3Text")]
        public string originAddressLine3Text { get; set; }
        /// <summary>
        /// movementTypeDescriptionText  shipmentUnitOfMeasureTypeCode
        /// </summary>
        [JsonProperty(PropertyName = "originPoliticalDivision1Name")]
        public string OriginPoliticalDivision1Name { get; set; }

        /// <summary>
        /// movementTypeDescriptionText  shipmentUnitOfMeasureTypeCode
        /// </summary>
        [JsonProperty(PropertyName = "destinationAccountNumber")]
        public string DestinationAccountNumber { get; set; }

        /// <summary>
        /// movementTypeDescriptionText  shipmentUnitOfMeasureTypeCode
        /// </summary>
        [JsonProperty(PropertyName = "destinationBusinessPartyName")]
        public string DestinationBusinessPartyName { get; set; }

        /// <summary>
        /// movementTypeDescriptionText  shipmentUnitOfMeasureTypeCode
        /// </summary>
        [JsonProperty(PropertyName = "destinationBusinessPartySecondName")]
        public string DestinationBusinessPartySecondName { get; set; }

        /// <summary>
        /// movementTypeDescriptionText  shipmentUnitOfMeasureTypeCode
        /// </summary>
        [JsonProperty(PropertyName = "destinationAddressLine1Text")]
        public string DestinationAddressLine1Text { get; set; }

        /// <summary>
        /// movementTypeDescriptionText  shipmentUnitOfMeasureTypeCode
        /// </summary>
        [JsonProperty(PropertyName = "destinationAddressLine2Text")]
        public string DestinationAddressLine2Text { get; set; }

        /// <summary>
        /// movementTypeDescriptionText  shipmentUnitOfMeasureTypeCode
        /// </summary>
        [JsonProperty(PropertyName = "destinationAddressLine3Text")]
        public string DestinationAddressLine3Text { get; set; }
        /// <summary>
        /// movementTypeDescriptionText  shipmentUnitOfMeasureTypeCode
        /// </summary>
        [JsonProperty(PropertyName = "destinationPoliticalDivision1Name")]
        public string DestinationPoliticalDivision1Name { get; set; }

        /// <summary>
        /// movementTypeDescriptionText  shipmentUnitOfMeasureTypeCode
        /// </summary>
        [JsonProperty(PropertyName = "shipmentInsuredValueAmount")]
        public string ShipmentInsuredValueAmount { get; set; }


        /// <summary>
        /// movementTypeDescriptionText
        /// </summary>
        [JsonProperty(PropertyName = "shipmentCurrencyCode")]
        public string ShipmentCurrencyCode { get; set; }

        /// <summary>
        /// movementTypeDescriptionText  shipmentUnitOfMeasureTypeCode
        /// </summary>
        [JsonProperty(PropertyName = "shipmentStackableIndicator")]
        public string ShipmentStackableIndicator { get; set; }

        /// <summary>
        /// movementTypeDescriptionText
        /// </summary>
        [JsonProperty(PropertyName = "originContactName")]
        public string OriginContactName { get; set; }

        /// <summary>
        /// movementTypeDescriptionText  shipmentUnitOfMeasureTypeCode
        /// </summary>
        [JsonProperty(PropertyName = "originContactEmailText")]
        public string OriginContactEmailText { get; set; }

        /// <summary>
        /// movementTypeDescriptionText  shipmentUnitOfMeasureTypeCode
        /// </summary>
        [JsonProperty(PropertyName = "originContactPhoneNumber")]
        public string OriginContactPhoneNumber { get; set; }

        /// <summary>
        /// movementTypeDescriptionText  shipmentUnitOfMeasureTypeCode
        /// </summary>
        [JsonProperty(PropertyName = "originContactFaxLineNumber")]
        public string OriginContactFaxLineNumber { get; set; }

        /// <summary>
        /// movementTypeDescriptionText
        /// </summary>
        [JsonProperty(PropertyName = "destinationContactName")]
        public string DestinationContactName { get; set; }

        /// <summary>
        /// movementTypeDescriptionText  shipmentUnitOfMeasureTypeCode
        /// </summary>
        [JsonProperty(PropertyName = "destinationContactEmailText")]
        public string DestinationContactEmailText { get; set; }

        /// <summary>
        /// movementTypeDescriptionText  shipmentUnitOfMeasureTypeCode
        /// </summary>
        [JsonProperty(PropertyName = "destinationContactPhoneNumber")]
        public string DestinationContactPhoneNumber { get; set; }

        /// <summary>
        /// movementTypeDescriptionText  shipmentUnitOfMeasureTypeCode
        /// </summary>
        [JsonProperty(PropertyName = "destinationContactFaxLineNumber")]
        public string DestinationContactFaxLineNumber { get; set; }

        /// <summary>
        /// Page6 Does this shipment requires temperature control
        /// </summary>
        [JsonProperty(PropertyName = "temperatureControlShipmentIndicator")]
        public Int32 TemperatureControlShipmentIndicator { get; set; }

        /// <summary>
        /// movementTypeDescriptionText  shipmentUnitOfMeasureTypeCode
        /// </summary>
        [JsonProperty(PropertyName = "pricingIndicator")]
        public string PricingIndicator { get; set; }

        /// <summary>
        /// movementTypeDescriptionText  shipmentUnitOfMeasureTypeCode
        /// </summary>
        [JsonProperty(PropertyName = "shipmentPivotWeightQuantity")]
        public string ShipmentPivotWeightQuantity { get; set; }
        /// <summary>
        /// movementTypeDescriptionText  shipmentUnitOfMeasureTypeCode
        /// </summary>
        [JsonProperty(PropertyName = "bidChargesPendingIndicator")]
        public string BidChargesPendingIndicator { get; set; }

        /// <summary>
        /// movementTypeDescriptionText  shipmentUnitOfMeasureTypeCode
        /// </summary>
        [JsonProperty(PropertyName = "bulkUplaodIndicator")]
        public string BulkUplaodIndicator { get; set; }

        /// <summary>
        /// movementTypeDescriptionText  shipmentUnitOfMeasureTypeCode
        /// </summary>
        [JsonProperty(PropertyName = "requestStatusCode")]
        public string RequestStatusCode { get; set; }

        /// <summary>
        /// movementTypeDescriptionText  shipmentUnitOfMeasureTypeCode
        /// </summary>
        [JsonProperty(PropertyName = "requestErrorCode")]
        public string RequestErrorCode { get; set; }

        /// <summary>
        /// movementTypeDescriptionText  shipmentUnitOfMeasureTypeCode
        /// </summary>
        [JsonProperty(PropertyName = "requestErrorDescriptionText")]
        public string RequestErrorDescriptionText { get; set; }
        /// <summary>
        /// movementTypeDescriptionText  shipmentUnitOfMeasureTypeCode
        /// </summary>
        [JsonProperty(PropertyName = "exchangeRateAmount")]
        public string ExchangeRateAmount { get; set; }

        /// <summary>
        /// movementTypeDescriptionText  shipmentUnitOfMeasureTypeCode
        /// </summary>
        [JsonProperty(PropertyName = "shipmentsPerYearQuantity")]
        public string ShipmentsPerYearQuantity { get; set; }
        /// <summary>
        /// movementTypeDescriptionText  shipmentUnitOfMeasureTypeCode
        /// </summary>
        [JsonProperty(PropertyName = "annualChargeWeightAmount")]
        public string AnnualChargeWeightAmount { get; set; }

        /// <summary>
        /// movementTypeDescriptionText  shipmentUnitOfMeasureTypeCode
        /// </summary>
        [JsonProperty(PropertyName = "annualActualWeightAmount")]
        public string AnnualActualWeightAmount { get; set; }

        /// <summary>
        /// movementTypeDescriptionText  shipmentUnitOfMeasureTypeCode
        /// </summary>
        [JsonProperty(PropertyName = "localCurrencyAmount")]
        public string LocalCurrencyAmount { get; set; }

        /// <summary>
        /// movementTypeDescriptionText  shipmentUnitOfMeasureTypeCode
        /// </summary>
        [JsonProperty(PropertyName = "USDCurrencyAmount")]
        public string USDCurrencyAmount { get; set; }

        /// <summary>
        /// movementTypeDescriptionText  shipmentUnitOfMeasureTypeCodeshipmentSpeedType
        /// </summary>
        [JsonProperty(PropertyName = "shipmentSpeedType")]
        public string ShipmentSpeedType { get; set; }

        /// <summary>
        /// movementTypeDescriptionText  shipmentUnitOfMeasureTypeCode
        /// </summary>
        [JsonProperty(PropertyName = "timeInTransitLowTimestamp")]
        public string TimeInTransitLowTimestamp { get; set; }

        /// <summary>
        /// movementTypeDescriptionText  shipmentUnitOfMeasureTypeCode
        /// </summary>
        [JsonProperty(PropertyName = "timeInTransitHighTimestamp")]
        public string TimeInTransitHighTimestamp { get; set; }

        /// <summary>
        /// movementTypeDescriptionText  shipmentUnitOfMeasureTypeCode
        /// </summary>
        [JsonProperty(PropertyName = "shipmentPalletPercent")]
        public string ShipmentPalletPercent { get; set; }

        /// <summary>
        /// movementTypeDescriptionText  shipmentUnitOfMeasureTypeCode
        /// </summary>
        [JsonProperty(PropertyName = "shipmentLooseUnitPercent")]
        public string ShipmentLooseUnitPercent { get; set; }

        /// <summary>
        /// movementTypeDescriptionText  shipmentUnitOfMeasureTypeCode
        /// </summary>
        [JsonProperty(PropertyName = "bidWonIndicator")]
        public string BidWonIndicator { get; set; }

        /// <summary>
        /// movementTypeDescriptionText  shipmentUnitOfMeasureTypeCode
        /// </summary>
        [JsonProperty(PropertyName = "bidWonByResourceName")]
        public string BidWonByResourceName { get; set; }
        /// <summary>
        /// movementTypeDescriptionText  shipmentUnitOfMeasureTypeCode
        /// </summary>
        [JsonProperty(PropertyName = "bidWonOnDate")]
        public string BidWonOnDate { get; set; }

        /// <summary>
        /// movementTypeDescriptionText  shipmentUnitOfMeasureTypeCode
        /// </summary>
        [JsonProperty(PropertyName = "fuelChargeAmount")]
        public string FuelChargeAmount { get; set; }

        /// <summary>
        /// movementTypeDescriptionText  shipmentUnitOfMeasureTypeCode
        /// </summary>
        [JsonProperty(PropertyName = "securityChargeAmount")]
        public string SecurityChargeAmount { get; set; }

        /// <summary>
        /// movementTypeDescriptionText  shipmentUnitOfMeasureTypeCode
        /// </summary>
        [JsonProperty(PropertyName = "originAirport")]
        public string OriginAirport { get; set; }

        /// <summary>
        /// movementTypeDescriptionText  shipmentUnitOfMeasureTypeCode
        /// </summary>
        [JsonProperty(PropertyName = "originAirportName")]
        public string OriginAirportName { get; set; }

        /// <summary>
        /// movementTypeDescriptionText  shipmentUnitOfMeasureTypeCode
        /// </summary>
        [JsonProperty(PropertyName = "destinationAirport")]
        public string DestinationAirport { get; set; }

        /// <summary>
        /// movementTypeDescriptionText  shipmentUnitOfMeasureTypeCode
        /// </summary>
        [JsonProperty(PropertyName = "destinationAirportName")]
        public string DestinationAirportName { get; set; }





        /// <summary>
        /// movementTypeDescriptionText  shipmentUnitOfMeasureTypeCode
        /// </summary>
        [JsonProperty(PropertyName = "originLocationCity")]
        public string OriginLocationCity { get; set; }

        /// <summary>
        /// movementTypeDescriptionText  shipmentUnitOfMeasureTypeCode
        /// </summary>
        [JsonProperty(PropertyName = "OriginLocationState")]
        public string OriginLocationState { get; set; }



        /// <summary>
        /// movementTypeDescriptionText  shipmentUnitOfMeasureTypeCode
        /// 0-false,1-true,2-disable
        /// </summary>
        [JsonProperty(PropertyName = "shipmentOriginAddressProfileSaveIndicator")]
        public bool ShipmentOriginAddressProfileSaveIndicator { get; set; }

        /// <summary>
        /// movementTypeDescriptionText  shipmentUnitOfMeasureTypeCode
        /// 0-false,1-true,2-disable
        /// </summary>
        [JsonProperty(PropertyName = "shipmentDestinationAddressProfileSaveIndicator")]
        public bool ShipmentDestinationAddressProfileSaveIndicator { get; set; }

        /// <summary>
        /// movementTypeDescriptionText  shipmentUnitOfMeasureTypeCode
        /// </summary>
        [JsonProperty(PropertyName = "DestinationLocationCity")]
        public string DestinationLocationCity { get; set; }

        /// <summary>
        /// movementTypeDescriptionText  shipmentUnitOfMeasureTypeCode
        /// </summary>
        [JsonProperty(PropertyName = "DestinationLocationState")]
        public string DestinationLocationState { get; set; }

       
        /// <summary>
        /// shipmentUnitOfMeasureTypeCode  
        /// </summary>
        [JsonProperty(PropertyName = "shipmentWeightTypeCode")]
        public Int32 ShipmentWeightTypeCode { get; set; }

        /// <summary>
        /// shipmentUnitOfMeasureTypeCode  
        /// </summary>
        [JsonProperty(PropertyName = "totalWeight")]
        public string TotalWeight { get; set; }

        /// <summary>
        /// Page 7 - Shipment Ready Date
        /// </summary>
        [JsonProperty(PropertyName = "shipmentReadyDate")]
        public DateTime? ShipmentReadyDate { get; set; }

    ///// <summary>
    ///// 
    ///// </summary>
    //[JsonProperty(PropertyName = "weightBreakRangeRate")]
    //    public WeightBreakRangeRate[] WeightBreakRangeRateDetails { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [JsonProperty(PropertyName = "shipmentWeightByPeice")]
        public ShipmentWeightByPeice[] WeightByPeice { get; set; }

        [JsonProperty(PropertyName = "id")]
        public Guid? Id { get; set; }
        
        //**Page 5

        [JsonProperty(PropertyName = "shipmentValueIndicator")]
        public bool ShipmentValueIndicator { get; set; }

        [JsonProperty(PropertyName = "shipmentValue")]
        public string shipmentValue { get; set; }

        //** Page9
        [JsonProperty(PropertyName = "isCustomerBroker")]
        public Int32 IsCustomerBroker { get; set; }

        [JsonProperty(PropertyName = "shipmentInsuranceIndicator")]
        public Int32? ShipmentInsuranceIndicator { get; set; }
        /// <summary>
        /// Service Types
        /// </summary>
        [JsonProperty(PropertyName = "serviceTypes")]
        public ServiceTypes ServiceTypes { get; set; }

        /// <summary>
        ///Terms Of Sale
        /// </summary>
        [JsonProperty(PropertyName = "termsOfSale")]
        public string TermsOfSale { get; set; }

        /// <summary>
        /// quote Validity Period
        /// </summary>
        [JsonProperty(PropertyName = "quoteValidityPeriod")]
        public string QuoteValidityPeriod { get; set; }

        /// <summary>
        /// Quote Validity StartDate
        /// </summary>
        [JsonProperty(PropertyName = "quoteValidityStartDate")]
        public string QuoteValidityStartDate { get; set; }

        /// <summary>
        /// Quote Validity EndDate
        /// </summary>
        [JsonProperty(PropertyName = "quoteValidityEndDate")]
        public string QuoteValidityEndDate { get; set; }

        /// <summary>
        /// Quote Notes
        /// </summary>
        [JsonProperty(PropertyName = "quoteNotes")]
        public string QuoteNotes { get; set; }

        /// <summary>
        /// Quote Notes
        /// </summary>
        [JsonProperty(PropertyName = "shipmentLaneActiveIndicator")]
        public bool ShipmentLaneActiveIndicator { get; set; }

        /// <summary>
        /// Quote Notes
        /// </summary>
        [JsonProperty(PropertyName = "originAutopopulationFormat")]
        public string OriginAutopopulationFormat { get; set; }

        /// <summary>
        /// Quote Notes
        /// </summary>
        [JsonProperty(PropertyName = "destinationAutopopulationFormat")]
        public string DestinationAutopopulationFormat { get; set; }

        /// <summary>
        /// customes Brokerage
        /// </summary>
        [JsonProperty(PropertyName = "customesBrokerage")]
        public string CustomesBrokerage { get; set; }
    }

    public class AirFreightShipmentDetailInternalPortal : IEntity
    {
        public string lastContinuationToken { get; set; }

        [JsonProperty(PropertyName = "partitionkey")]
        public string PartitionKey { get; set; }

        /// <summary>
        /// origin Location Code
        /// </summary>
        [JsonProperty(PropertyName = "originLocationCode")]
        public string OriginLocationCode { get; set; }

        /// <summary>
        /// destination Location Code
        /// </summary>
        [JsonProperty(PropertyName = "destinationLocationCode")]
        public string DestinationLocationCode { get; set; }

        /// <summary>
        /// shipment GAD weight
        /// </summary>
        [JsonProperty(PropertyName = "shipmentGadWt")]
        public string ShipmentGadWt { get; set; }

       

        public Guid? Id { get; set; }
    }

    public class ShipmentWeightByPeice
    {
        /// <summary>
        /// shipmentUnitOfMeasureTypeCode  
        /// </summary>
        [JsonProperty(PropertyName = "packageType")]
        public string PackageType { get; set; }

        /// <summary>
        /// shipmentUnitOfMeasureTypeCode  
        /// </summary>
        [JsonProperty(PropertyName = "quantity")]
        public string Quantity { get; set; }

        /// <summary>
        /// shipmentUnitOfMeasureTypeCode  
        /// </summary>
        [JsonProperty(PropertyName = "length")]
        public string Length { get; set; }

        /// <summary>
        /// shipmentUnitOfMeasureTypeCode  
        /// </summary>
        [JsonProperty(PropertyName = "width")]
        public string Width { get; set; }

        /// <summary>
        /// shipmentUnitOfMeasureTypeCode  
        /// </summary>
        [JsonProperty(PropertyName = "height")]
        public string Height { get; set; }

        /// <summary>
        /// shipmentUnitOfMeasureTypeCode  
        /// </summary>
        [JsonProperty(PropertyName = "weight")]
        public string Weight { get; set; }

        /// <summary>
        /// shipment Volume Quantity
        /// </summary>
        [JsonProperty(PropertyName = "shipmentVolumeQuantity")]
        public string ShipmentVolumeQuantity { get; set; }

        /// <summary>
        /// shipment Unit Of Measure TypeCode
        /// </summary>
        [JsonProperty(PropertyName = "shipmentUnitOfMeasureTypeCode")]
        public string ShipmentUnitOfMeasureTypeCode { get; set; }

        /// <summary>
        /// shipment Weight Unit Of Measure TypeCode
        /// </summary>
        [JsonProperty(PropertyName = "shipmentWeightUnitOfMeasureTypeCode")]
        public string ShipmentWeightUnitOfMeasureTypeCode { get; set; }

        /// <summary>
        /// shipment Actual Weight Quantity
        /// </summary>
        [JsonProperty(PropertyName = "shipmentActualWeightQuantity")]
        public string ShipmentActualWeightQuantity { get; set; }

        /// <summary>
        /// Shipment Actual Weight
        /// </summary>
        [JsonProperty(PropertyName = "shipmentActualWeight")]
        public string ShipmentActualWeight { get; set; }

        /// <summary>
        /// shipment Dimensional Weight
        /// </summary>
        [JsonProperty(PropertyName = "shipmentDimensionalWeight")]
        public string ShipmentDimensionalWeight { get; set; }

        /// <summary>
        /// Shipment Actual Weight Unit Of Measure TypeCode
        /// </summary>
        [JsonProperty(PropertyName = "shipmentActualWeightUnitOfMeasureTypeCode")]
        public string shipmentActualWeightUnitOfMeasureTypeCode { get; set; }

        /// <summary>
        /// Shipment Dimensional Weight Unit Of Measure TypeCode
        /// </summary>
        [JsonProperty(PropertyName = "shipmentDimensionalWeightUnitOfMeasureTypeCode")]
        public string ShipmentDimensionalWeightUnitOfMeasureTypeCode { get; set; }

        /// <summary>
        /// shipment Dimensional Unit Of Measure TypeCode
        /// </summary>
        [JsonProperty(PropertyName = "shipmentDimensionalUnitOfMeasureTypeCode")]
        public string ShipmentDimensionalUnitOfMeasureTypeCode { get; set; }

        /// <summary>
        /// shipment Dimensional Weight Quantity
        /// </summary>
        [JsonProperty(PropertyName = "shipmentDimensionalWeightQuantity")]
        public string ShipmentDimensionalWeightQuantity { get; set; }

   }

    public class WeightBreakRangeRate
    {
        /// <summary>
        /// shipmentUnitOfMeasureTypeCode  
        /// </summary>
        [JsonProperty(PropertyName = "weightBreakRangeName")]
        public string WeightBreakRangeName { get; set; }

        /// <summary>
        /// shipmentUnitOfMeasureTypeCode  
        /// </summary>
        [JsonProperty(PropertyName = "weightBreakRangeStateTypeCode")]
        public string WeightBreakRangeStateTypeCode { get; set; }
        /// <summary>
        /// shipmentUnitOfMeasureTypeCode  
        /// </summary>
        [JsonProperty(PropertyName = "weightBreakRangeStateTypeDescriptionText")]
        public string WeightBreakRangeStateTypeDescriptionText { get; set; }

        /// <summary>
        /// shipmentUnitOfMeasureTypeCode  
        /// </summary>
        [JsonProperty(PropertyName = "measurementUnitTypeCode")]
        public string MeasurementUnitTypeCode { get; set; }
        /// <summary>
        /// shipmentUnitOfMeasureTypeCode  
        /// </summary>
        [JsonProperty(PropertyName = "weightBreakRangeRateAmount")]
        public string WeightBreakRangeRateAmount { get; set; }

        /// <summary>
        /// shipmentUnitOfMeasureTypeCode  
        /// </summary>
        [JsonProperty(PropertyName = "weightBreakRangeSelectionIndicator")]
        public string weightBreakRangeSelectionIndicator { get; set; }

    }

    public class CommodityNames: IModel
    {
        /// <summary>
        /// Page 5 commodity name
        /// </summary>
        [JsonProperty(PropertyName = "commodityName")]
        public string[] CommodityName { get; set; }
        public Guid? Id { get; set; }
        public string PartitionKey { get; set; }
        public string lastContinuationToken { get; set; }
        
    }

    public class CommodityNameList
    {/// <summary>
     /// Page 5 commodity name
     /// </summary>
        [JsonProperty(PropertyName = "commodityName")]
        public string CommodityName { get; set; }
    }
}
