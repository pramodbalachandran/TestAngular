﻿using Quotes.Core.Entities.Abstract;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Quotes.Core.Entities
{
    public class CustomerProfile : IEntity
    {
        public CustomerProfile()
        {

        }

        [JsonProperty(PropertyName = "partitionkey")]
        public string PartitionKey { get; set; }

        [JsonProperty(PropertyName = "id")]
        public Guid? Id { get; set; }

        [JsonProperty(PropertyName = "docId")]
        public string DocId { get; set; }

        [JsonProperty(PropertyName = "docType")]
        public string DocType { get; set; }

        [JsonProperty(PropertyName = "docStructureVersion")]
        public string DocStructureVersion { get; set; }

        [JsonProperty(PropertyName = "businessPartyName")]
        public string BusinessPartyName { get; set; }

        [JsonProperty(PropertyName = "businessPartyNumber")]
        public string BusinessPartyNumber { get; set; }

        [JsonProperty(PropertyName = "accountNumber")]
        public string AccountNumber { get; set; }

        [JsonProperty(PropertyName = "tempAccountNumber")]
        public string TempAccountNumber { get; set; }

        [JsonProperty(PropertyName = "companyName")]
        public string CompanyName { get; set; }

        [JsonProperty(PropertyName = "contactName")]
        public string ContactName { get; set; }

        [JsonProperty(PropertyName = "contactType")]
        public string ContactType { get; set; }

        [JsonProperty(PropertyName = "phoneNumber")]
        public string PhoneNumber { get; set; }

        [JsonProperty(PropertyName = "phoneCountryCode")]
        public string PhoneCountryCode { get; set; }

        [JsonProperty(PropertyName = "extension")]
        public string Extension { get; set; }

        [JsonProperty(PropertyName = "emailAddress")]
        public string EmailAddress { get; set; }

        [JsonProperty(PropertyName = "userId")]
        public string UserId { get; set; }

        [JsonProperty(PropertyName = "termsAccepted")]
        public bool TermsAccepted { get; set; }

        [JsonProperty(PropertyName = "contactAddressName")]
        public string ContactAddressName { get; set; }

        [JsonProperty(PropertyName = "contactAddress")]
        public string ContactAddress { get; set; }

        [JsonProperty(PropertyName = "contactAddressLine1")]
        public string ContactAddressLine1 { get; set; }

        [JsonProperty(PropertyName = "contactAddressLine2")]
        public string ContactAddressLine2 { get; set; }

        [JsonProperty(PropertyName = "countryCode")]
        public string CountryCode { get; set; }

        [JsonProperty(PropertyName = "countryName")]
        public string CountryName { get; set; }

        [JsonProperty(PropertyName = "politicalDivision1Code")]
        public string PoliticalDivision1Code { get; set; }

        [JsonProperty(PropertyName = "politicalDivision1Name")]
        public string PoliticalDivision1Name { get; set; }

        [JsonProperty(PropertyName = "politicalDivision2Name")]
        public string PoliticalDivision2Name { get; set; }

        [JsonProperty(PropertyName = "postalCode")]
        public string PostalCode { get; set; }

        //[JsonProperty(PropertyName = "BillingAddress")]
        //public string BillingAddress { get; set; }

        [JsonProperty(PropertyName = "contactAsBillingAddressIndicator")]
        public bool ContactAsBillingAddressIndicator { get; set; }

        [JsonProperty(PropertyName = "BillingAddressLine2")]
        public string BillingAddressLine2 { get; set; }

        [JsonProperty(PropertyName = "BillingCountryId")]
        public string BillingCountryId { get; set; }

        [JsonProperty(PropertyName = "BillingStateId")]
        public string BillingStateId { get; set; }

        [JsonProperty(PropertyName = "BillingCity")]
        public string BillingCity { get; set; }

        [JsonProperty(PropertyName = "BillingPostalCode")]
        public string BillingPostalCode { get; set; }

        [JsonProperty(PropertyName = "password")]
        public string Password { get; set; }

        [JsonProperty(PropertyName = "confirmPassword")]
        public string ConfirmPassword { get; set; }

        [JsonProperty(PropertyName = "notificationSettings")]
        public NotificationSettings NotificationSettings { get; set; }

        [JsonProperty(PropertyName = "shippingAddress")]
        public ShipingAddress[] ShippingAddress { get; set; }

        [JsonProperty(PropertyName = "billingAddress")]
        public BillingAdress[] BillingAddress { get; set; }

        [JsonProperty(PropertyName = "contactsDetails")]
        public ContactDetails[] ContactsDetails { get; set; }

        public string lastContinuationToken { get; set; }

    }
}
