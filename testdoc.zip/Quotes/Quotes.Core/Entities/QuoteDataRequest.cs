﻿using Bonsai.Azure.CosmosDb.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Quotes.Core.Entities
{
    public class QuoteDataRequest : IModel
    {
        /// <summary>
        /// 
        /// </summary>
        [JsonProperty(PropertyName = "quoteRequestData")]
        public QuoteData QuoteRequestData { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty(PropertyName = "airFreightShipmentDetail")]
        public List<AirFreightShipmentDetail> LstShipmentDetail { get; set; }

        /// <summary>
        /// GAD weight
        /// </summary>
        [JsonProperty(PropertyName = "gadWeight")]
        public string GADWeight { get; set; }

        public Guid? Id { get; set; }
        public string PartitionKey { get; set; }
        public string lastContinuationToken { get; set; }

    }

    public class QuoteDataRequestInternalPortal : IModel
    {
        /// <summary>
        /// 
        /// </summary>
        [JsonProperty(PropertyName = "quoteRequestData")]
        public QuoteData QuoteRequestData { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty(PropertyName = "airFreightShipmentDetail")]
        public List<AirFreightShipmentDetailInternalPortal> LstShipmentDetail { get; set; }

        /// <summary>
        /// GAD weight
        /// </summary>
        [JsonProperty(PropertyName = "gadWeight")]
        public string GADWeight { get; set; }

        /// <summary>
        /// quote value (GAD wt * Rate)
        /// </summary>
        [JsonProperty(PropertyName = "quoteValue")]
        public string QuoteValue { get; set; }

        public Guid? Id { get; set; }
        public string PartitionKey { get; set; }
        public string lastContinuationToken { get; set; }

    }

    public class ListOfQuoteData : IModel
    {
        [JsonProperty(PropertyName = "listOfQuotes")]
        public List<QuoteDataRequestInternalPortal> ListOfQuotes { get; set; }
        public Guid? Id { get; set; }
        public string PartitionKey { get; set; }
        public string lastContinuationToken { get; set; }
    }

    public class LstOfIdsPinnedOrUnpinned
    {
        [JsonProperty(PropertyName = "isRequestForPinned")]
        public bool IsRequestForPinned { get; set; }

        [JsonProperty(PropertyName = "ids")]
        public List<GuidOfQuote> ListOfIds { get; set; }
    }

    public class ListOfIds
    {
        [JsonProperty(PropertyName = "ids")]
        public List<GuidOfQuote> LstOfIds { get; set; }
    }

    public class GuidOfQuote
    {
        [JsonProperty(PropertyName = "id")]
        public Guid? Id { get; set; }
    }

    public class CountOfRecordsUpdated : IModel
    {
        public Guid? Id { get; set; }
        public string PartitionKey { get; set; }
        public string lastContinuationToken { get; set; }

        [JsonProperty(PropertyName = "continuation")]
        public bool ContinuationToken { get; set; }

        [JsonProperty(PropertyName = "count")]
        public string NoOfRecordUpdated { get; set; }

        [JsonProperty(PropertyName = "newQuotesDetail")]
        public List<NewQuotesDetail> NewQuotesDetail { get; set; }
    }

    public class NewQuotesDetail
    {
        [JsonProperty(PropertyName = "dupRefId")]
        public Guid? DupRefId { get; set; }

        [JsonProperty(PropertyName = "id")]
        public Guid? Id { get; set; }

        [JsonProperty(PropertyName = "quoteNumber")]
        public string QuoteNumber { get; set; }
    }

    public class ShipmentDeleteCount : IModel
    {
        public Guid? Id { get; set; }
        public string PartitionKey { get; set; }
        public string lastContinuationToken { get; set; }

        [JsonProperty(PropertyName = "continuation")]
        public bool ContinuationToken { get; set; }

        [JsonProperty(PropertyName = "deleted")]
        public string NoOfRecordsDeleted { get; set; }
    }
}
