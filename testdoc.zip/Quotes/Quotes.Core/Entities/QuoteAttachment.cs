﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Quotes.Core.Entities
{
    public class QuoteAttachment
    {
        /// <summary>
        /// 
        /// </summary>
        [JsonProperty(PropertyName = "fileName")]
        public string FileName { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty(PropertyName = "fileLocationName")]
        public string FileLocationName { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty(PropertyName = "filePathName")]
        public string FilePathName { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty(PropertyName = "fileOpportunityProductDescriptionText")]
        public string FileOpportunityProductDescriptionText { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty(PropertyName = "fileStatusCode")]
        public string FileStatusCode { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty(PropertyName = "fileCategoryCode")]
        public string FileCategoryCode { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty(PropertyName = "fileCategoryDescriptionText")]
        public string FileCategoryDescriptionText { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty(PropertyName = "financialContentIndicator")]
        public string FinancialContentIndicator { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty(PropertyName = "availableIndicator")]
        public string AvailableIndicator { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty(PropertyName = "fileSize")]
        public Decimal FileSize { get; set; }

    }
}
