﻿using Newtonsoft.Json;

namespace Quotes.Core.Entities
{
    public class CalculateMbpRateRequest
    {
        /// <summary>
        /// Shipment Origin Code
        /// </summary>
        [JsonProperty(PropertyName = "OriginCode")]
        public string OriginCode { get; set; }

        /// <summary>
        /// Shipment Destination Code
        /// </summary>
        [JsonProperty(PropertyName = "DestinationCode")]
        public string DestinationCode { get; set; }

        /// <summary>
        /// Shipment Weight
        /// </summary>
        [JsonProperty(PropertyName = "ShipmentWeight")]
        public double ShipmentWeight { get; set; }

        /// <summary>
        /// Service Type
        /// </summary>
        [JsonProperty(PropertyName = "ServiceType")]
        public string ServiceType { get; set; }

        [JsonProperty(PropertyName = "MovementTypeCode")]
        public int MovementTypeCode { get; set; }
    }
}
