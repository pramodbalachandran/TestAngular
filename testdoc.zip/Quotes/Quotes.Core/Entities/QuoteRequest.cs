﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Quotes.Core.Entities
{
    public class QuoteRequest
    {
        /// <summary>
        /// QuoteNumber
        /// </summary>
        [JsonProperty(PropertyName = "quoteNumber")]
        public string QuoteNumber { get; set; }

        [JsonProperty(PropertyName = "accountNumber")]
        public string AccountNumber { get; set; }


    }
}
