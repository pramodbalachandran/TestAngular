﻿using System;
using System.Collections.Generic;
using System.Text;
using Bonsai.Azure.CosmosDb.Models;

namespace Quotes.Core.Entities.Abstract
{
    public interface IEntity :IModel
    {
    }
}
