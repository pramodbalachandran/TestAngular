﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Quotes.Core.Entities.Dtos
{
    public class Customer :IDto
    {

        public Guid Id { get; set; }

        [JsonProperty(PropertyName = "customerId")]
        public string CustomerId { get; set; }
    }
}
