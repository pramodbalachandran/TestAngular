﻿using Bonsai.Azure.CosmosDb.Models;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Quotes.Core.Entities.Dtos
{
    public class QuoteResponceDto :IModel
    {
        /// <summary>
        /// QuoteNumber  "quoteNumber": "QuoteS09142018093202",
    
        /// </summary>
        [JsonProperty(PropertyName = "quoteNumber")]
        public string QuoteNumber { get; set; }

        /// <summary>
        /// QuoteRequestDate
        /// </summary>
        [JsonProperty(PropertyName = "quoteRequestDate")]
        public string QuoteRequestDate { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty(PropertyName = "quoteStatusCode")]
        public Int32 QuoteStatusCode { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty(PropertyName = "quoteStatusDescriptionText")]
        public string QuoteStatusDescriptionText { get; set; }

        [JsonProperty(PropertyName = "docId")]
        public string DocId { get; set; }
        public Guid? Id { get; set; }
        public string PartitionKey { get; set; }

        public string lastContinuationToken { get; set; }
    }
    public class QuoteResponceDto1
    {
        /// <summary>
        /// QuoteNumber  "quoteNumber": "QuoteS09142018093202",

        /// </summary>
        [JsonProperty(PropertyName = "quoteNumber")]
        public string QuoteNumber { get; set; }

        /// <summary>
        /// QuoteRequestDate
        /// </summary>
        [JsonProperty(PropertyName = "quoteRequestDate")]
        public string QuoteRequestDate { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty(PropertyName = "quoteStatusCode")]
        public Int32 QuoteStatusCode { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty(PropertyName = "quoteStatusDescriptionText")]
        public string QuoteStatusDescriptionText { get; set; }
    }
}
