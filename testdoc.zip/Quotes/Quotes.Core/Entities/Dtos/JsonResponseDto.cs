﻿using System;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding;

namespace Quotes.Core.Entities.Dtos
{
    public class JsonResponseDto
    {

        public JsonResponseDto()
        {
            Random generator = new Random();
            responseData = "";
            requestId = generator.Next(0, 100000000).ToString("D6");
        }
        public Object responseData { get; set; }
        public ResponseStatus responseStatus { get; set; }
        public string requestId { get; set; }

        //public ResponseModel responseModel { get; set; }
        //public JsonResponseDto() : base("Result")
        //{

        //}
    }

    public class ResponseModel
    {
        public ResponseModel()
        {
            Random generator = new Random();
            responseData = "";
            requestId = generator.Next(0, 100000000).ToString("D6");
        }
        public Object responseData { get; set; }
        public ResponseStatus responseStatus { get; set; }
        public string requestId { get; set; }
    }

    public class ResponseStatus
    {
        public string status { get; set; }
        public string message { get; set; }
    }
}
