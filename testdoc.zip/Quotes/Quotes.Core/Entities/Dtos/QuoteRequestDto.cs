﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Quotes.Core.Entities.Dtos
{
    class QuoteRequestDto
    {
    }
}
