﻿using System;
using System.Collections.Generic;
using System.Text;
using Newtonsoft.Json;
using Quotes.Core.Entities.Abstract;

namespace Quotes.Core.Entities
{
    public class QuoteData :IEntity
    {

        [JsonProperty(PropertyName = "docType")]
        public string DocType { get; set; }  

        [JsonProperty(PropertyName = "docId")]
        public string DocId { get; set; }

        [JsonProperty(PropertyName = "partitionkey")]
        public string PartitionKey { get; set; }        

        [JsonProperty(PropertyName = "quoteIdentificationNumber")]
        public string QuoteIdentificationNumber { get; set; }

        [JsonProperty(PropertyName = "docStructureVersion")]
        public Int32 DocStructureVersion { get; set; }

        [JsonProperty(PropertyName = "businessPartyNumber")]
        public string BusinessPartyNumber { get; set; }

        [JsonProperty(PropertyName = "businessPartyName")]
        public string BusinessPartyName { get; set; }

        [JsonProperty(PropertyName = "id")]
        public Guid? Id { get; set; }

        /// <summary>
        /// QuoteNumber
        /// </summary>
        [JsonProperty(PropertyName = "accountNumber")]
        public string AccountNumber { get; set; }

        [JsonProperty(PropertyName = "UserName")]
        public string UserName { get; set; }
        /// <summary>
        /// QuoteNumber
        /// </summary>
        [JsonProperty(PropertyName = "quoteNumber")]
        public string QuoteNumber { get; set; }

        /// <summary>
        /// Quote Request Date
        /// </summary>
        [JsonProperty(PropertyName = "quoteRequestDate")]
        public string QuoteRequestDate { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty(PropertyName = "quoteStatusCode")]
        public Int32 QuoteStatusCode { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty(PropertyName = "quoteStatusDescriptionText")]
        public string QuoteStatusDescriptionText { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty(PropertyName = "quoteStatusUpdateDate")]
        public string QuoteStatusUpdateDate { get; set; }
        
        /// <summary>
        /// 
        /// </summary>
        [JsonProperty(PropertyName = "quoteServiceType")]
        public string QuoteServiceType { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty(PropertyName = "quoteTypeCode")]
        public Int32 QuoteTypeCode { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty(PropertyName = "quoteTypeDescriptionText")]
        public string QuoteTypeDescriptionText { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty(PropertyName = "informationSourceTypeCode")]
        public Int32 InformationSourceTypeCode { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty(PropertyName = "informationSourceTypeDescriptionText")]
        public string InformationSourceTypeDescriptionText { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty(PropertyName = "salesSegmentCategoryCode")]
        public Int32 SalesSegmentCategoryCode { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty(PropertyName = "salesSegmentCategoryDescriptionText")]
        public string SalesSegmentCategoryDescriptionText { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty(PropertyName = "standardIndustrialClassificationCode")]
        public string StandardIndustrialClassificationCode { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty(PropertyName = "standardIndustrialClassificationDescriptionText")]
        public string StandardIndustrialClassificationDescriptionText { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty(PropertyName = "projectName")]
        public string ProjectName { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty(PropertyName = "regionNumber")]
        public string RegionNumber { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty(PropertyName = "districtNumber")]
        public string DistrictNumber { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty(PropertyName = "countryCode")]
        public string CountryCode { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty(PropertyName = "formalRequestForQuoteIndicator")]
        public string FormalRequestForQuoteIndicator { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty(PropertyName = "filingStatusCode")]
        public string FilingStatusCode { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty(PropertyName = "filingStatusDescriptionText")]
        public string FilingStatusDescriptionText { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty(PropertyName = "anticipatedProductRevenueAmount")]
        public string AnticipatedProductRevenueAmount { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty(PropertyName = "quoteDueDate")]
        public string QuoteDueDate { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty(PropertyName = "quotePastDueIndicator")]
        public string QuotePastDueIndicator { get; set; }

        /// <summary>
        /// 
        /// </summary>
        [JsonProperty(PropertyName = "specialRequestReviewDate")]
        public string SpecialRequestReviewDate { get; set; }

        /// <summary>
        /// quoteDeclineReasonTypeCode
        /// </summary>
        [JsonProperty(PropertyName = "quoteDeclineReasonTypeCode")]
        public Int32 QuoteDeclineReasonTypeCode { get; set; }

        /// <summary>
        /// quoteDeclineReasonTypeCode
        /// </summary>
        [JsonProperty(PropertyName = "quoteDeclineReasonTypeNote")]
        public string QuoteDeclineReasonTypeNote { get; set; }

        /// <summary>
        /// quoteDeclineReasonTypeCode
        /// </summary>
        [JsonProperty(PropertyName = "quoteRate")]
        public string QuoteRate { get; set; }

        /// <summary>
        /// lastVisitedPagemarketRate  
        /// </summary>
        [JsonProperty(PropertyName = "lastVisitedPage")]
        public string LastVisitedPage { get; set; }

        /// <summary>
        /// marketRate
        /// </summary>
        [JsonProperty(PropertyName = "marketRate")]
        public string MarketRate { get; set; }

        /// <summary>
        /// rateTabIndicator   
        /// </summary>
        [JsonProperty(PropertyName = "rateTabIndicator")]
        public Int32 RateTabIndicator { get; set; }

        [JsonProperty(PropertyName = "ContactName")]
        public string ContactName { get; set; }

        [JsonProperty(PropertyName = "PhoneNo")]
        public string PhoneNo { get; set; }

        [JsonProperty(PropertyName = "EmailAddress")]
        public string EmailAddress { get; set; }

        [JsonProperty(PropertyName = "Comments")]
        public string Comments { get; set; }

        [JsonProperty(PropertyName = "contactAddressSaveProfileIndicator")]
        public Int32 ContactAddressSaveProfileIndicator { get; set; }
        /// <summary>
        /// 
        /// </summary>
        [JsonProperty(PropertyName = "quoteAttachment")]
        public QuoteAttachment[] QuoteAttachmentData { get; set; }

        public string lastContinuationToken { get; set; }

        [JsonProperty(PropertyName = "quoteName")]
        public string QuoteName { get; set; }

        /// <summary>
        /// ShipmentReadyDate
        /// </summary>
        [JsonProperty(PropertyName = "shipmentReadyDate")]
        public string ShipmentReadyDate { get; set; }

        /// <summary>
        /// customes Brokerage
        /// </summary>
        [JsonProperty(PropertyName = "customesBrokerage")]
        public string CustomesBrokerage { get; set; }

        /// <summary>
        /// service Types
        /// </summary>
        [JsonProperty(PropertyName = "serviceTypes")]
        public ServiceTypes ServiceTypes { get; set; }

        [JsonProperty(PropertyName = "termsOfSale")]
        public string TermsOfSale { get; set; }

        [JsonProperty(PropertyName = "insuranceRequiredIndicator")]
        public bool InsuranceRequiredIndicator { get; set; }

        [JsonProperty(PropertyName = "shipmentInsuranceAmount")]
        public string ShipmentInsuranceAmount { get; set; }

        [JsonProperty(PropertyName = "defaultCurrency")]
        public string DefaultCurrency { get; set; }

        [JsonProperty(PropertyName = "quoteNotes")]
        public string QuoteNotes { get; set; }

        [JsonProperty(PropertyName = "quoteValidityPeriod")]
        public string QuoteValidityPeriod { get; set; }

        /// <summary>
        /// analyst Level
        /// </summary>
        [JsonProperty(PropertyName = "analystLevel")]
        public string AnalystLevel { get; set; }

        /// <summary>
        /// quote Validity Start Date
        /// </summary>
        [JsonProperty(PropertyName = "quoteValidityStartDate")]
        public string QuoteValidityStartDate { get; set; }

        /// <summary>
        /// quote Validity End Date
        /// </summary>
        [JsonProperty(PropertyName = "quoteValidityEndDate")]
        public string QuoteValidityEndDate { get; set; }

        /// <summary>
        /// Determine if quote is pinned or not
        /// </summary>
        [JsonProperty(PropertyName = "isQuotePinned")]
        public bool IsQuotePinned { get; set; }

    }

    public class ServiceTypes
    {
        [JsonProperty(PropertyName = "consolidatedECSelected")]
        public bool ConsolidatedECSelected { get; set; }

        [JsonProperty(PropertyName = "directCASelected")]
        public bool DirectCASelected { get; set; }

        [JsonProperty(PropertyName = "premiumDirectCXSelected")]
        public bool PremiumDirectCXSelected { get; set; }

        [JsonProperty(PropertyName = "tempTrueSelected")]
        public bool TempTrueSelected { get; set; }

        [JsonProperty(PropertyName = "isModified")]
        public bool IsModified { get; set; }
    }
}
