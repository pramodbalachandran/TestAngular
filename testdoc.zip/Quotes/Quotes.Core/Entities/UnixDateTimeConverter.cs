﻿using Newtonsoft.Json;
using System;


namespace Quotes.Core.Entities
{
    public class UnixDateTimeConverter : JsonConverter
    {
        public override bool CanConvert(Type objectType) => true;

        public override object ReadJson(JsonReader reader,
            Type objectType, object existingValue, JsonSerializer serializer)
        {
            if (!string.IsNullOrEmpty(Convert.ToString(reader.Value)))
            {
                long utcSeconds = serializer.Deserialize<long>(reader);
                return DateTimeOffset.FromUnixTimeSeconds(utcSeconds)
                    .DateTime.ToUniversalTime().ToString();
            }
            else
            {
                return reader.Value;
            }
        }

        public override void WriteJson(JsonWriter writer,
            object value, JsonSerializer serializer)
        {
            if (!string.IsNullOrEmpty(Convert.ToString(value)))
            {
                DateTimeOffset dateTimeOffset = new DateTimeOffset((Convert.ToDateTime(value)).ToUniversalTime());
                serializer.Serialize(writer, dateTimeOffset.ToUnixTimeSeconds());
            }
            else
            {
                serializer.Serialize(writer, string.Empty);
            }
        }

    }
}
