﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Quotes.Core.Entities
{
    public class IafRouteDetailRequest
    {
        [JsonProperty(PropertyName = "OriginCode")]
        public string OriginCode { get; set; }       

        [JsonProperty(PropertyName = "DestinationCode")]
        public string DestinationCode { get; set; }
    }
}
