﻿using Newtonsoft.Json;
using Quotes.Core.Entities.Abstract;
using System;
using System.Collections.Generic;
using System.Text;

namespace Quotes.Core.Entities
{
    public class ShipingAddress 
    {
        //[JsonProperty(PropertyName = "id")]
        //public Guid? Id { get; set; }

        //public string PartitionKey { get; set; }

        [JsonProperty(PropertyName = "UserId")]
        public string UserId { get; set; }
        [JsonProperty(PropertyName = "addressLine1")]
        public string AddressLine1 { get; set; }

        [JsonProperty(PropertyName = "addressLine2")]
        public string AddressLine2 { get; set; }

        [JsonProperty(PropertyName = "addressLine3")]
        public string AddressLine3 { get; set; }

        [JsonProperty(PropertyName = "addressLine4")]
        public string AddressLine4 { get; set; }

        [JsonProperty(PropertyName = "politicalDivision2Name")]
        public string PoliticalDivision2Name { get; set; }

        [JsonProperty(PropertyName = "politicalDivision1Code")]
        public string PoliticalDivision1Code { get; set; }

        [JsonProperty(PropertyName = "politicalDivision1Name")]
        public string PoliticalDivision1Name { get; set; }

        [JsonProperty(PropertyName = "postalCode")]
        public string PostalCode { get; set; }

        [JsonProperty(PropertyName = "countryCode")]
        public string CountryCode { get; set; }

        [JsonProperty(PropertyName = "countryName")]
        public string CountryName { get; set; }

        [JsonProperty(PropertyName = "DoShowEditShippingForm")]
        public bool DoShowEditShippingForm { get; set; }

        ////Last visited date time
        //[JsonProperty(PropertyName = "lastVisitedDate")]
        //public DateTime? LastVisitedDate { get; set; }
    }

    public class BillingAdress
    {
        [JsonProperty(PropertyName = "contactName")]
        public string ContactName { get; set; }

        [JsonProperty(PropertyName = "addressLine1")]
        public string AddressLine1 { get; set; }

        [JsonProperty(PropertyName = "addressLine2")]
        public string AddressLine2 { get; set; }

        [JsonProperty(PropertyName = "addressLine3")]
        public string AddressLine3 { get; set; }

        [JsonProperty(PropertyName = "addressLine4")]
        public string AddressLine4 { get; set; }

        [JsonProperty(PropertyName = "politicalDivision2Name")]
        public string PoliticalDivision2Name { get; set; }

        [JsonProperty(PropertyName = "politicalDivision1Code")]
        public string PoliticalDivision1Code { get; set; }

        [JsonProperty(PropertyName = "politicalDivision1Name")]
        public string PoliticalDivision1Name { get; set; }

        [JsonProperty(PropertyName = "postalCode")]
        public string PostalCode { get; set; }

        [JsonProperty(PropertyName = "countryCode")]
        public string CountryCode { get; set; }

        [JsonProperty(PropertyName = "countryName")]
        public string CountryName { get; set; }

        ////Last visited date time
        //[JsonProperty(PropertyName = "lastVisitedDate")]
        //public DateTime? LastVisitedDate { get; set; }

    }

    public class ContactDetails
    {
        [JsonProperty(PropertyName = "contactName")]
        public string ContactName { get; set; }

        [JsonProperty(PropertyName = "emailAddress")]
        public string EmailAddress { get; set; }

        [JsonProperty(PropertyName = "phoneNumber")]
        public string PhoneNumber { get; set; }

        //Last visited date time
        [JsonProperty(PropertyName = "lastUsedDate")]
        public DateTime? LastUsedDate { get; set; }


    }

    public class NotificationSettings
    {
        [JsonProperty(PropertyName = "emailQuoteStatusExpiring")]
        public bool QuoteStatusExpiringRequiredEmailIndicator { get; set; }

        [JsonProperty(PropertyName = "emailQuoteRespondByUSP")]
        public bool QuoteRespondByUPSRequiredEmailIndicator { get; set; }

        [JsonProperty(PropertyName = "emailPickupRequest")]
        public bool PickupRequestRequiredEmailIndicator { get; set; }

        [JsonProperty(PropertyName = "emailPreApprovedRate")]
        public bool PreApprovedRateRequiredEmailIndicator { get; set; }

        [JsonProperty(PropertyName = "emailResetPassword")]
        public bool ResetPasswordRequiredEmailIndicator { get; set; }
    }
}
