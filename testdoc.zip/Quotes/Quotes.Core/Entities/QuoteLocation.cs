﻿using Bonsai.Azure.CosmosDb.Models;
using Newtonsoft.Json;
using Quotes.Core.Entities.Abstract;
using System;
using System.Collections.Generic;
using System.Text;

namespace Quotes.Core.Entities
{
    public class QuoteLocation
    {
        [JsonProperty(PropertyName = "originLocationCountryCode")]
        public string OriginLocationCountryCode { get; set; }
        [JsonProperty(PropertyName = "destinationLocationCountryCode")]
        public string DestinationLocationCountryCode { get; set; }
    }
    public class QuoteRootLocation: IEntity
    {
        [JsonProperty(PropertyName = "countryCode")]
        public string countryCode { get; set; }
        [JsonProperty(PropertyName = "countryName")]
        public string countryName { get; set; }
        public Guid? Id { get; set; }
        public string PartitionKey { get; set; }
        public string lastContinuationToken { get; set; }
    }
}
