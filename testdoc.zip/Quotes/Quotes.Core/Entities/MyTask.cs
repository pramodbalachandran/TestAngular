﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Quotes.Core.Entities
{
    using Entities.Abstract;
    public class MyTask : IEntity
    {
        public Guid? Id { get; set; }

        //public string[] ItemType { get; }
        public string PartitionKey { get; set; }
        public int Version { get; set; }

        public string Name { get; set; }

        public string Category { get; set; }

        public DateTime Date { get; set; }

        public DateTime CreatedDate { get; set; }

        public string lastContinuationToken { get; set; }
    }
}
