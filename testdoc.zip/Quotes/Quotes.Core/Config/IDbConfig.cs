﻿namespace Quotes.Core.Config
{
    public interface IDbConfig
    {
        string QuotesConnectionString { get; }
        string DocumentDbEndpointUrl { get; }
        string DocumentDbPrimaryKey { get; }
        string CacheServerConnectionString { get; }
    }
}
