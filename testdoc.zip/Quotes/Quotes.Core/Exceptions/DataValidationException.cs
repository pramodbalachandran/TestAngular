﻿using System;
namespace Quotes.Core.Exceptions
{
    [Serializable]
    public class DataValidationException :ApplicationException
    {
        public string ExceptionKey { get; set; }
        public DataValidationException(string message) : base(message)
        {

        }
    }
}
