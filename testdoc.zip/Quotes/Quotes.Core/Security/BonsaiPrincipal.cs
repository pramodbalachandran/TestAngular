﻿using System;
using System.Security.Claims;

namespace Quotes.Core.Security
{
    using Entities;
    public class BonsaiPrincipal :ClaimsPrincipal
    {
        public BonsaiPrincipal(User currentUser)
        {
            CurrentUser = currentUser;
        }

        public User CurrentUser { get; private set; }
    }
}
