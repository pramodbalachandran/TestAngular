﻿using System;
using System.Security.Claims;

namespace Quotes.Core.Security
{
    public interface ITokenValidator
    {
        //ClaimsPrincipal ValidateUser(string token, string email);
        ClaimsPrincipal ValidateUser(string email);
    }
}
