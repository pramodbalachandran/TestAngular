
export interface ICustomer {
  id:string,
  docType: string,
  docId: string,
  docStructureVersion: number,
  partitionkey: string,
  businessPartyName: string,
  businessPartyNumber: string,
  accountNumber: string,
  tempAccountNumber: string,
  companyName: string,
  contactName: string,
  contactType:string,
  phoneNumber: string,
  phoneCountryCode: string,
  extension: string,
  password: string;
  confirmPassword: string;
  emailAddress: string,
  userId: string,
  termsAccepted: boolean,
  contactAddressName: string,
  contactAddress: string,
  contactAddressLine1: string,
  contactAddressLine2: string,
  countryCode: string,//country
  countryName:string;
  politicalDivision1Code: string;
  politicalDivision1Name: string; //state
  politicalDivision2Name: string; //city
  postalCode: string,
  contactAsBillingAddressIndicator: boolean,
  defaultCurrency:string;
  contactsDetails: IContactsDetails[],
  billingAddress: IBillingAddress[],
  shippingAddress: IShippingAddress[],
  notificationSettings: INotificationSettings
}

export interface IUpser {
  id:string,
  docType: string,
  docId: string,
  docStructureVersion: number,
  partitionkey: string,
  businessPartyName: string,
  businessPartyNumber: string,
  accountNumber: string,
  emailAddress: string,
  userId: string,
  defaultCurrency: string,
  conversionFactor: string
}

export class Upser implements IUpser {
  id:string;
  docType: string;
  docId: string;
  docStructureVersion: number;
  partitionkey: string;
  businessPartyName: string;
  businessPartyNumber: string;
  accountNumber: string;
  emailAddress: string;
  userId: string;
  defaultCurrency: string;
  conversionFactor: string;
}

export class Customer implements ICustomer {
  id: string;
  docType: string;
  docId: string;
  docStructureVersion: number;
  partitionkey: string;
  businessPartyName: string;
  businessPartyNumber: string;
  accountNumber: string;
  tempAccountNumber: string;
  companyName: string;
  contactName: string;
  contactType: string;
  phoneCountryCode: string;
  phoneNumber: string;
  extension: string;
  password: string;
  confirmPassword: string;
  emailAddress: string;
  userId: string;
  termsAccepted: boolean;
  contactAddressName: string;
  contactAddress: string;
  contactAddressLine1: string;
  contactAddressLine2: string;
  countryCode: string;//country
  countryName:string;
  politicalDivision1Code: string; //state
  politicalDivision1Name: string;
  politicalDivision2Name: string; //city
  postalCode: string;
  contactAsBillingAddressIndicator: boolean;
  defaultCurrency:string;
  contactsDetails: IContactsDetails[];
  billingAddress: IBillingAddress[];
  shippingAddress: IShippingAddress[];
  notificationSettings: INotificationSettings;
}

export interface IContactsDetails {
  contactName: string,
  emailAddress: string,
  phoneNumber: string,
  lastUsedDate:Date,
  doShowEditContactForm:boolean
}

export class ContactsDetails implements IContactsDetails {
  contactName: string;
  emailAddress: string;
  phoneNumber: string;
  lastUsedDate:Date;
  doShowEditContactForm: boolean;
  
}

export interface IBillingAddress {
  contactName:string;
  addressLine1: string;
  addressLine2: string;
  addressLine3: string;
  countryCode: string;
  countryName:string;
  politicalDivision1Name: string; //state
  politicalDivision1Code: string; //state
  politicalDivision2Name: string; // city
  postalCode: string
}

export class BillingAddress implements IBillingAddress {
  contactName:string;
  addressLine1: string;
  addressLine2: string;
  addressLine3: string;
  countryCode: string;
  countryName:string;
  politicalDivision1Name: string; //state
  politicalDivision1Code: string; //state
  politicalDivision2Name: string; //city
  postalCode: string;
}

export interface IShippingAddress {
  addressLine1: string;
  addressLine2: string;
  addressLine3: string;
  countryCode: string;
  countryName:string;
  politicalDivision1Name: string; //state
  politicalDivision1Code:string ;
  politicalDivision2Name: string; // city
  postalCode: string;
  doShowEditShippingForm:Boolean;
}

export class ShippingAddress implements IShippingAddress {
  addressLine1: string;
  addressLine2: string;
  addressLine3: string;
  countryCode: string;
  countryName:string;
  politicalDivision1Name: string; //state
  politicalDivision1Code:string ;
  politicalDivision2Name: string; // city
  postalCode: string;
  doShowEditShippingForm:Boolean;
}
export interface INotificationSettings {
  emailQuoteStatusExpiring: boolean,
  emailQuoteRespondByUSP: boolean,
  emailPickupRequest: boolean,
  emailPreApprovedRate: boolean,
  emailResetPassword: boolean
}

export class NotificationSettings implements INotificationSettings {
  emailQuoteStatusExpiring: boolean;
  emailQuoteRespondByUSP: boolean;
  emailPickupRequest: boolean;
  emailPreApprovedRate: boolean;
  emailResetPassword: boolean;
}


