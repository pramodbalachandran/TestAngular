
export interface ICurrencyData {

  currencyData: ICurrencyDetailData[];

}

export interface ICurrencyDetailData{
  
  countryCode: string;
  countryName: string;
  currencyName: string;
  decimalPlacesQuantity: number
  exchangeRateAmount: number
  localConversionToUsdAmount: number
  localCurrencyCode: string
  localeCodes: string
  roundingDirectionText: string

}






