export interface airportDetails {
    autopopulateformat: string;
    autopopulateformat1: string;
    autopopulateformat2: string;
    airportCode: string;
    airportName: string;
    countryCode: string;
    countryName: string;
    politicalDivision2Name: string;
    postalCode: string;
    isCustomerData: string;
    autopopulateformathighlight: string;
    region?: string;
  
  }
  export interface airportDetailsDes {
    autopopulateformat: string;
    airportCode: string;
    airportName: string;
    countryCode: string;
    countryName: string;
    politicalDivision2Name: string;
    isCustomerData: string;
  
  }
  export interface shipmentServiceType {
    shipmentservicetype: string;  
    shipmentservicetypeHighlight: string; 
    value:number;
  }
