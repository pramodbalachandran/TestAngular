export interface IAirFreightShipmentCharacteristics{
    shipmentMethod:string; //SM001 -Weight per Shipment ,SM001 -Weight Over Time ,SM001 -Typical Cargo Information
}