import { PackageType } from '@app/shared/enums/PackageType';
import { ShipmentUnit  } from './ShipmentUnit';
export class Package {
  type: PackageType;
  quantity: number;
  volume: number;
  length: number;
  breadth: number;
  height: number;
  weight: number;
  dimensionUnit: ShipmentUnit;
  actualWeight: number;
  actualWeightUnit: ShipmentUnit;
  dimensionalWeight: number;
}
