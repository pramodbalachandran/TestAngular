import { ShipmentUnitType } from '@app/shared/enums/ShipmentUnitType';
import { ShipmentUnitName } from '@app/shared/enums/ShipmentUnitName';


export class ShipmentUnit {
  Name: ShipmentUnitName = ShipmentUnitName.Kg;
  Type: ShipmentUnitType = ShipmentUnitType.Weight;
}
