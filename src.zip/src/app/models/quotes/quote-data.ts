
import {IQuoteDetails} from './quotes-details';
import {IAirFreightShipmentDetail} from './airfreightshipment-detail';

export interface IQuoteData{
  
  quoteRequestData: IQuoteDetails;
  airFreightShipmentDetail: IAirFreightShipmentDetail[];

}

export class QuoteData{
  
  quoteRequestData: IQuoteDetails;
  airFreightShipmentDetail:IAirFreightShipmentDetail;

}

export interface IQuoteListDetails{
  quoteNumber: string;
  quoteRequestDate: string;
  quoteStatusCode: number;
  quoteStatusDescriptionText: string;
  docId: string;
  id:any;
  partitionKey: any;
}

export class QuoteListDetails{
  quoteNumber: string;
  quoteRequestDate: string;
  quoteStatusCode: number;
  quoteStatusDescriptionText: string;
  docType: string;
  id:any;
  partitionKey: any;
}

export interface IMBPRequest {
  OriginCode: string;
  DestinationCode: string;
  ShipmentWeight: number;
  ServiceType: string;
  MovementTypeCode: number;
}

export class MBPRequest {
  OriginCode: string;
  DestinationCode: string;
  ShipmentWeight: number;
  ServiceType: string;
  MovementTypeCode: number;
}


