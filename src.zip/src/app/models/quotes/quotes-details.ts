
export interface IQuoteDetails {
  id:string;
  docId: string;
  quoteNumber: string;
  businessPartyName: string; //Customer name
  businessPartyNumber: string;//User Id
  accountNumber: string; //CMF account number
  quoteRequestDate: Date;//current date for first time
  quoteStatusCode: number;//1-Unsubmitted, 2-submitted(completed)
  quoteStatusUpdateDate: string;//currentdate
  quoteServiceType:string ;//Page 1 - Service type 002- Air
  quoteTypeCode: number;//Page 2  1-one time(short term ) 2-Many time(Long term )
  quoteDeclineReasonTypeCode: number; // 1=> prefer competitor's rate, 2 => not shipment yet , 3 => other
  quoteDeclineReasonTypeNote: string; // quoteDeclineReason for 'other'
  quoteRate: string; // if Existing rate page active
  marketRate: string; // if market rate page active
  rateTabIndicator: number;
  // informationSourceTypeCode: number;//0-as of now
  // salesSegmentCategoryCode: number;//0-as of now  
  // standardIndustrialClassificationCode: string;
  // projectName: string;
  // regionNumber: string;
  // districtNumber: string;
  // countryCode: string;
  // formalRequestForQuoteIndicator: string;
  // filingStatusCode: string;
  // anticipatedProductRevenueAmount: string;
  // quoteDueDate: string;
  // quotePastDueIndicator: string;
  // specialRequestReviewDate: string;
   quoteAttachment: QuoteAttachment[];
   //----below fields for contact details------------//
  ContactName: string;
  PhoneNo: string;
  EmailAddress: string;
  Comments: string;
  lastVisitedPage: string;
  contactAddressSaveProfileIndicator:number;
  quoteName :string;
  shipmentReadyDate: Date;//customer due date in case of long term
  serviceTypes:ServiceTypes;//Service type
  customesBrokerage:string;//cb001 -ups will serve the custom brokerage cb002-customer has their own ,cb003-Customer dont know
  termsOfSale:string;
  insuranceRequiredIndicator:boolean;
  shipmentInsuranceAmount:string;
  defaultCurrency:string;
  quoteNotes:string;
  quoteValidityPeriod:string;
  quoteValidityStartDate:Date;
  quoteValidityEndDate: Date;
  customerTemplateIndicator: boolean;
}
export class QuoteDetails implements IQuoteDetails {
  id:string;
  docId: string;
  quoteNumber: string;
  businessPartyName: string; //Customer name
  businessPartyNumber: string;//User Id
  accountNumber: string; //CMF account number
  quoteRequestDate: Date;//current date for first time
  quoteStatusCode: number;//0-Unsubmitted
  quoteStatusUpdateDate: string;//currentdate
  quoteServiceType:string ;//Page 1 - Service type 002- Air
  quoteTypeCode: number;//1-one time
  quoteDeclineReasonTypeCode: number; // 0=> 'not selected' 1=> prefer competitor's rate, 2 => not shipment yet , 3 => other
  quoteDeclineReasonTypeNote: string; // quoteDeclineReason for 'other'
  quoteRate: string; // if Existing rate page active
  marketRate: string; // if market rate page active
  rateTabIndicator: number;
  // informationSourceTypeCode: number;//0-as of now
  // salesSegmentCategoryCode: number;//0-as of now  
  // standardIndustrialClassificationCode: string;
  // projectName: string;
  // regionNumber: string;
  // districtNumber: string;
  // countryCode: string;
  // formalRequestForQuoteIndicator: string;
  // filingStatusCode: string;
  // anticipatedProductRevenueAmount: string;
  // quoteDueDate: string;
  // quotePastDueIndicator: string;
  // specialRequestReviewDate: string;
   quoteAttachment: QuoteAttachment[];
   //----below fields for contact details------------//
   ContactName:string;
   PhoneNo:  string;
   EmailAddress:string;
   Comments: string;
  lastVisitedPage: string;
  contactAddressSaveProfileIndicator:number;
  quoteName :string;
  shipmentReadyDate: Date;//customer due date in case of long term
  serviceTypes:ServiceTypes;//Service type
  customesBrokerage:string;//cb001 -ups will serve the custom brokerage cb002-customer has their own ,cb003-Customer dont know
  termsOfSale:string;
  insuranceRequiredIndicator:boolean;
  shipmentInsuranceAmount:string;
  defaultCurrency:string;
  quoteNotes:string;
  quoteValidityPeriod:string;
  quoteValidityStartDate:Date;
  quoteValidityEndDate: Date;
  customerTemplateIndicator: boolean;
}

export class QuoteAttachment {
  fileName: string;
  fileLocationName: string;
  filePathName: string;
  fileOpportunityProductDescriptionText: string;
  fileStatusCode: string;
  fileCategoryCode: string;
  financialContentIndicator: string;
  availableIndicator: string;
  fileSize:number
}

export interface ServiceTypes{
  directCASelected:boolean;
  consolidatedECSelected:boolean;
  premiumDirectCXSelected:boolean;
  tempTrueSelected: boolean;
  isModified:boolean
}
