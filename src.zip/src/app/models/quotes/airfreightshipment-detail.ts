import { DecimalNumberOnlyDirective } from "@app/directives/decimal-numbers-only.directive";
import {ServiceTypes} from   './quotes-details';

export interface IAirFreightShipmentDetail{
  id:string;
  docId: string;
  //quoteByProductDocId:string;
  shipmentDetailIdentificationNumber: string;
  quoteIdentificationNumber: string;//quotenumber
  // productIdentificationNumber: string;
  // productName: string;
  destinationAirport:string;//Page3 origin airport code
  originAirport:string;//Page3 destination airport code
  // originLocationCode: string;
  // originBeyondPointCode: string;
 originLocationCountryCode: string;//page3 origin country
  originLocationPoliticalDivsion2Code: string;//page3 origin city
  originLocationPostalCode: string;//page3origin postal code
  // originRegion: string;
  // destinationLocationCode: string;
  // destinationBeyondPointCode: string;
  destinationLocationCountryCode: string;//page 3 destination country
  destinationLocationPoliticalDivsion2Code: string;//page 3 destination city
  destinationLocationPostalCode: string;//page 3 destination postal code
  // destinationRegion: string;
  // internationalAirFreightServiceGroupCode: string;
  movementTypeCode: number;//page 3 movement type 1-ATAstring; 2-ATDstring;3-DTAstring;4-DTD
  paymentTermTypeCode: string;//Page9 How do you plan to pay -P001/P002/P003 => page 9
  // paymentTermTypeMnemonicText: string;
  // shipmentQuantity: string;
  shipmentUnitOfMeasureTypeCode:number;//Page 4 unit of measurement type 1-cm/kgstring;2-in/lbstring;3-in/kg
  shipmentPalletQuantity: string;//PALLETIZED_ANNUAL_SHIPMENTS
  shipmentLooseUnitQUantity: string;//LOOSE_ANNUAL_SHIPMENTS
   commodityTypeCode: string;//Page 5 commodity type
   commodityTypeDescriptionText:string;//Page 5 commodity type desc
   commodityNameList :CommodityNameList[];//page5 commoditynamelist
  // commentText: string;
  // customerOriginLocationCode: string;
  // customerDestinationLocationCode: string;
  // customerAveraegActualWeightQuantity: string;
  // customerAverageDimensionalWeightQuantity: string;
  hazardousMaterialsIndicator: number;//Page 6 - first question
  hazardousMaterialName: string;
  hazardousMaterialUnitedNationsNumber: string;
  hazardousMaterialUnitedNationsClassificationCode: string;
  hazardousMaterialPackagingGroupText: string;
   shipmentOversizeIndicator: boolean;//Page 4
  // upperDeckIndicator: string;
  // originAccountNumber: string;
  // originBusinessPartyName: string;
  // originBusinessPartySecondName: string;
  originAddressLine1Text: string;//page 3
  originAddressLine2Text: string;//page3
  originAddressLine3Text: string;//page3
  originPoliticalDivision1Name: string;//page 3 origin state/province
  // destinationAccountNumber: string;
  // destinationBusinessPartyName: string;
  // destinationBusinessPartySecondName: string;
  destinationAddressLine1Text: string;//page 3 destination
  destinationAddressLine2Text: string;//page 3 destination
  destinationAddressLine3Text: string;//page 3 destination
  destinationPoliticalDivision1Name: string;//page 3 destination state/province
  shipmentInsuredValueAmount: string;
  shipmentValueIndicator: boolean;//Page 5
  shipmentCurrencyCode: string;//Page 5
  shipmentValue: string;//Page 5
  // shipmentStackableIndicator: string;
  // originContactName: string;
  // originContactEmailText: string;
  // originContactPhoneNumber: string;
  // originContactFaxLineNumber: string;
  // destinationContactName: string;
  // destinationContactEmailText: string;
  // destinationContactPhoneNumber: string;
  // destinationContactFaxLineNumber: string;
   temperatureControlShipmentIndicator: number;//Page6 Question3
  perishableShipmentIndicator: number;//Page6 Question2
  // pricingIndicator: string;
  // shipmentPivotWeightQuantity: string;
  // bidChargesPendingIndicator: string;
  // bulkUplaodIndicator: string;
  // requestStatusCode: string;
  // requestErrorCode: string;
  // exchangeRateAmount: string;
  // shipmentsPerYearQuantity: string;
  // annualChargeWeightAmount: string;
  // annualActualWeightAmount: string;
  // localCurrencyAmount: string;
  // USDCurrencyAmount: string;
  // timeInTransitLowTimestamp: string;
  // timeInTransitHighTimestamp: string;
  shipmentPalletPercent: string;//PALLETIZED_UNITS_PER_SHIPMENT
  shipmentLooseUnitPercent: string;//LOOSE_UNITS_PER_SHIPMENT
  // bidWonIndicator: string;
  // bidWonByResourceName: string;
  // bidWonOnDate: string;
  // fuelChargeAmount: string;
  // securityChargeAmount: string;
  shipmentOriginAddressProfileSaveIndicator:boolean;//page 3 save profile indicator origin
  shipmentDestinationAddressProfileSaveIndicator:boolean;//page 3 save profile indicator destination
  shipmentWeightTypeCode:number;//page 4 1-weight by peicestring;2-total weight
  totalWeight:string;//page4 total weight
  shipmentWeightByPeice:ShipmentWeightByPeice[]//page 4 shipmnt by peice details
  isCustomerBroker: number;//Is ups serving as a  customer broker => page 9
  shipmentInsuranceIndicator: number;//Do you need insurance of this shipment
  shipmentReadyDate: Date;//Page7 shipment ready date
  shipmentSpeedType: string; // Page 8 CX or CA or EC
  originAirportName:string;
  destinationAirportName:string;
  shipmentMethod:string; //SM001 -Weight per Shipment ,SM001 -Weight Over Time ,SM001 -Typical Cargo Information
  shipmentFrequencyTimePeriodDescriptionText: string;//Internal portal shipment frequencyyear,month,week,day
  shipmentFrequency :number;
  shipmentActualWeight:string;
  shipmentDimensionalWeight:string;
  shipmentActualWeightUnitOfMeasureTypeCode:string;//kg/lb
  shipmentDimensionalWeightUnitOfMeasureTypeCode:string;//kg/lb/etc
  shipmentActualWeightQuantity:string;
  shipmentDimensionalWeightQuantity:string;
  serviceTypes:ServiceTypes;//Service type
  termsOfSale: string;
  TOSModified: boolean;
  quoteValidityPeriod:string;
  quoteValidityStartDate:Date;
  quoteValidityEndDate: Date;
  quoteValidityModified: boolean;
  quoteNotes:string;
  shipmentLaneActiveIndicator:boolean;
  MovementTypeDescriptionText:string;
  originAutopopulationFormat:string;
  destinationAutopopulationFormat :string;
  customesBrokerage:string;
  shipmentCommodity:ShipmentCommodity[];

  
  quoteBrokeragdeModified:boolean
}


export class AirFreightShipmentDetail{
  id:string;
  docId: string;
  //quoteByProductDocId:string;
  shipmentDetailIdentificationNumber: string;
  quoteIdentificationNumber: string;//quotenumber
  // productIdentificationNumber: string;
  // productName: string;
  destinationAirport:string;//Page3 origin airport code
  originAirport:string;//Page3 destination airport code
  // originLocationCode: string;
  // originBeyondPointCode: string;
 originLocationCountryCode: string;//page3 origin country
  originLocationPoliticalDivsion2Code: string;//page3 origin city
  originLocationPostalCode: string;//page3origin postal code
  // originRegion: string;
  // destinationLocationCode: string;
  // destinationBeyondPointCode: string;
  destinationLocationCountryCode: string;//page 3 destination country
  destinationLocationPoliticalDivsion2Code: string;//page 3 destination city
  destinationLocationPostalCode: string;//page 3 destination postal code
  // destinationRegion: string;
  // internationalAirFreightServiceGroupCode: string;
  movementTypeCode: number;//page 3 movement type 1-ATAstring; 2-ATDstring;3-DTAstring;4-DTD
  paymentTermTypeCode: string;//Page9 How do you plan to pay -P001/P002/P003 => page 9
  // paymentTermTypeMnemonicText: string;
  // shipmentQuantity: string;
  shipmentUnitOfMeasureTypeCode:number;//Page 4 unit of measurement type 1-cm/kgstring;2-in/lbstring;3-in/kg
  shipmentPalletQuantity: string;//PALLETIZED_ANNUAL_SHIPMENTS
  shipmentLooseUnitQUantity: string;//LOOSE_ANNUAL_SHIPMENTS
   commodityTypeCode: string;//Page 5 commodity type
   commodityTypeDescriptionText:string;//Page 5 commodity type desc
   commodityNameList :CommodityNameList[];//page5 commoditynamelist
  // commentText: string;
  // customerOriginLocationCode: string;
  // customerDestinationLocationCode: string;
  // customerAveraegActualWeightQuantity: string;
  // customerAverageDimensionalWeightQuantity: string;
  hazardousMaterialsIndicator: number;//Page 6 - first question
  hazardousMaterialName: string;
  hazardousMaterialUnitedNationsNumber: string;
  hazardousMaterialUnitedNationsClassificationCode: string;
  hazardousMaterialPackagingGroupText: string;
   shipmentOversizeIndicator: boolean;//Page 4
  // upperDeckIndicator: string;
  // originAccountNumber: string;
  // originBusinessPartyName: string;
  // originBusinessPartySecondName: string;
  originAddressLine1Text: string;//page 3
  originAddressLine2Text: string;//page3
  originAddressLine3Text: string;//page3
  originPoliticalDivision1Name: string;//page 3 origin state/province
  // destinationAccountNumber: string;
  // destinationBusinessPartyName: string;
  // destinationBusinessPartySecondName: string;
  destinationAddressLine1Text: string;//page 3 destination
  destinationAddressLine2Text: string;//page 3 destination
  destinationAddressLine3Text: string;//page 3 destination
  destinationPoliticalDivision1Name: string;//page 3 destination state/province
  shipmentInsuredValueAmount: string;
  shipmentValueIndicator: boolean;//Page 5
  shipmentCurrencyCode: string;//Page 5
  shipmentValue: string;//Page 5
  // shipmentStackableIndicator: string;
  // originContactName: string;
  // originContactEmailText: string;
  // originContactPhoneNumber: string;
  // originContactFaxLineNumber: string;
  // destinationContactName: string;
  // destinationContactEmailText: string;
  // destinationContactPhoneNumber: string;
  // destinationContactFaxLineNumber: string;
   temperatureControlShipmentIndicator: number;//Page6 Question3
  perishableShipmentIndicator: number;//Page6 Question2
  // pricingIndicator: string;
  // shipmentPivotWeightQuantity: string;
  // bidChargesPendingIndicator: string;
  // bulkUplaodIndicator: string;
  // requestStatusCode: string;
  // requestErrorCode: string;
  // exchangeRateAmount: string;
  // shipmentsPerYearQuantity: string;
  // annualChargeWeightAmount: string;
  // annualActualWeightAmount: string;
  // localCurrencyAmount: string;
  // USDCurrencyAmount: string;
  // timeInTransitLowTimestamp: string;
  // timeInTransitHighTimestamp: string;
  shipmentPalletPercent: string;//PALLETIZED_UNITS_PER_SHIPMENT
  shipmentLooseUnitPercent: string;//LOOSE_UNITS_PER_SHIPMENT
  // bidWonIndicator: string;
  // bidWonByResourceName: string;
  // bidWonOnDate: string;
  // fuelChargeAmount: string;
  // securityChargeAmount: string;
  shipmentOriginAddressProfileSaveIndicator:boolean;//page 3 save profile indicator origin
  shipmentDestinationAddressProfileSaveIndicator:boolean;//page 3 save profile indicator destination
  shipmentWeightTypeCode:number;//page 4 1-weight by peicestring;2-total weight
  totalWeight:string;//page4 total weight
  shipmentWeightByPeice:ShipmentWeightByPeice[]//page 4 shipmnt by peice details
  isCustomerBroker: number;//Is ups serving as a  customer broker => page 9
  shipmentInsuranceIndicator: number;//Do you need insurance of this shipment
  shipmentReadyDate: Date;//Page7 shipment ready date
  shipmentSpeedType: string; // Page 8 CX or CA or EC
  originAirportName:string;
  destinationAirportName:string;
  shipmentMethod:string; //SM001 -Weight per Shipment ,SM001 -Weight Over Time ,SM001 -Typical Cargo Information
  shipmentFrequencyTimePeriodDescriptionText: string;//Internal portal shipment frequencyyear,month,week,day
  shipmentFrequency :number;
  shipmentActualWeight:string;
  shipmentDimensionalWeight:string;
  shipmentActualWeightUnitOfMeasureTypeCode:string;//kg/lb
  shipmentDimensionalWeightUnitOfMeasureTypeCode:string;//kg/lb/etc
  shipmentActualWeightQuantity:string;
  shipmentDimensionalWeightQuantity:string;
  serviceTypes:ServiceTypes;//Service type
  termsOfSale:string;
  quoteValidityPeriod:string;
  quoteValidityStartDate:Date;
  quoteValidityEndDate:Date;
  quoteNotes:string;
  shipmentCommodity:ShipmentCommodity[];

}

export class ShipmentCommodity {
  commodityType: string;
  hazardousMaterialsIndicator: number;
  temperatureControlShipmentIndicator: number;//Page6 Question3
  perishableShipmentIndicator: number;//Page6 Question2
  highValueRiskIndicator: boolean;
  specialSecurityIndicator: boolean;
  shipmentStackableIndicator: boolean;
  otherSpecialIndicator: boolean;
  commodityNames: CommodityNameList[];
  hazardousMaterialUnitedNationsNumber: string;
  hazardousMaterialPackagingGroup: string;
  hazardousMaterialPackagingInstructions: string;
  shipmentTemperatureRangeFromValue: string;
  shipmentTemperatureRangeToValue: string;
  shipmentTemperatureControlUnitOfMeasurement: string;
  commentText: string;
}


export class ShipmentWeightByPeice
{
  packageType:string;
  quantity:string;
  length:string;
  width:string;
  height:string;
  weight:	string;
  shipmentVolumeQuantity:string;
  shipmentUnitOfMeasureTypeCode:string;
  shipmentWeightUnitOfMeasureTypeCode:string;
  shipmentActualWeightQuantity:string;
  shipmentDimensionalUnitOfMeasureTypeCode:string;
  shipmentDimensionalWeightQuantity:string;


}


export class CommodityNameList
{
  commodityName:string;
}

export interface CurrencyFormat {
  countryCode: string;

  countryName: string;

  currencyName: string;

  decimalPlacesQuantity: number

  exchangeRateAmount: number;

  localConversionToUsdAmount: number;

  localCurrencyCode: string;

  localeCodes: string;

  roundingDirectionText: string;

}

