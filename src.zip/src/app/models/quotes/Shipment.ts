import { ShipmentType } from '@app/shared/enums/ShipmentType';
import { ShipmentFrequencyPeriod } from '@app/shared/enums/ShipmentFrequencyPeriod';
import { ShipmentPeriod } from '@app/shared/enums/ShipmentPeriod';
import { Package } from './Package';
import { ShipmentUnit  } from './ShipmentUnit';


export class Shipment {
  type: ShipmentType = ShipmentType.WeightPerShipment;
  frequency: number;
  frequencyPeriod: ShipmentFrequencyPeriod = ShipmentFrequencyPeriod.Year;
  period: ShipmentPeriod = ShipmentPeriod.Year;
  actualWeight: number;
  dimensionalWeight: number;
  actualWeightUnit: ShipmentUnit;
  dimensionalUnit: ShipmentUnit;
  packages: Package[];
}
