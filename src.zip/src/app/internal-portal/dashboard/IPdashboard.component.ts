import { Component, OnInit,AfterViewInit, ViewChild, ElementRef, Renderer2 } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { DatePipe } from "@angular/common";
import { DataTableModule } from 'angular-6-datatable';

import { QuoteService } from '@app/shared/services/quote.service';
import { IQuoteStrcuture, IQUOTE, ShippingAddress, LoggedInUser, QuoteDetail } from '@app/shared/interfaces/entities.interface';
import { QuoteAPI, LocalStorageService, CustomerAPI, GeaographyAPI } from '@app/shared/services';
import { getMatIconFailedToSanitizeLiteralError } from '@angular/material';
import { IQuoteData,IQuoteListDetails} from '@app/models/quotes/quote-data'
import { IQuoteDetails} from '@app/models/quotes/quotes-details'
import { IAirFreightShipmentDetail } from '@app/models/quotes/airfreightshipment-detail'
import { PageState } from '@app/shared/services/shared/enum';
import { ApplicationUrls, RoutingKey, monthNames } from '@app/shared/services/shared/config.const';
import { UtilitiesService } from '@app/shared/services/shared/utilities.service';
import { ToasterService } from '@app/shared/services';
import * as _ from 'lodash';
import { ICurrencyData,ICurrencyDetailData } from '@app/models';

@Component({
    selector: 'UPSers-pricing-dashboard',
    templateUrl: './IPdashboard.component.html',
    styleUrls: ['./IPdashboard.component.scss'],
    providers: [DataTableModule],
  
})

export class IPDashboardComponent implements OnInit,AfterViewInit {

      data: IQuoteListDetails[];
      quotedataList:IQuoteListDetails[];
      master: IQuoteListDetails[];   
      isDataAvailable: boolean = false;
      isSearchDataAvailable: boolean = false;
      keyshipmentAddress = 'Shipmentaddressselectedfromddl';
      keyshipmentAddressd2d = 'Shipmentaddressselectedfromddld2d';
      isNewQuote: boolean = false;
      userId: string = "";
      body: HTMLBodyElement = document.getElementsByTagName('body')[0];
      classes: string[]=[];
      show: boolean = false;
      lastVisitedPage: string = "";
      shipmentCurrencyCodeData: ICurrencyDetailData[];
      @ViewChild('dashboardLoader') dashboardLoader: ElementRef;

  constructor(private renderer: Renderer2, private helper: UtilitiesService, private localStorageService: LocalStorageService, private quoteService: QuoteAPI<IQuoteData>, private qouteAPI: QuoteAPI<IQUOTE>, private customerAPI: CustomerAPI<LoggedInUser>, private toastr: ToasterService, private geoGraphyService: GeaographyAPI<ICurrencyData>) {
   
  }

  ngOnInit() {
    this.body.classList.remove('login-logo');  
  }

  ngAfterViewInit() {
    //console.log("ngAfterViewInit");        
  }
}

