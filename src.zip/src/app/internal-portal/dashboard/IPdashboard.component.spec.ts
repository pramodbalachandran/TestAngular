import { async, ComponentFixture, TestBed, getTestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing'
import { By } from '@angular/platform-browser';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { DebugElement } from '@angular/core';
import { combineAll, expand } from 'rxjs/operators';
import { by } from 'protractor';
import { Router } from '@angular/router';


import { IPDashboardComponent } from './IPdashboard.component';
import { IQuoteData, IQuoteListDetails } from '@app/models/quotes/quote-data'
import { QuoteAPI, LocalStorageService, ToasterService } from '@app/shared/services';
import { Enviorment } from '@app/services/shared/config.const';
import { UtilitiesService } from '@app/shared/services/shared/utilities.service';
import { RoutingKey } from '@app/services/shared/config.const';
import { PageState, shipmentFrequencyType } from '@app/services/shared/enum';
import { ConfigService } from '@app/shared/services/shared/config.service';



describe('IPDashboardComponent', () => {
  let component: IPDashboardComponent;
    let fixture: ComponentFixture<IPDashboardComponent>;

  beforeEach(async(() => {

    let injector;
    let service: QuoteAPI<IQuoteData>;

    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, RouterTestingModule],
      declarations: [IPDashboardComponent],
      providers: [QuoteAPI, UtilitiesService, ConfigService, LocalStorageService, ToasterService],
      schemas: [NO_ERRORS_SCHEMA]
    })
      .compileComponents();

    injector = getTestBed();
    service = injector.get(QuoteAPI);

  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IPDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  ////The Dashboard component should be define.
  it("should have a defined component ", () => {
    expect(component).toBeDefined();
  });

  ////The Dashboard component should exist.
  it('should have a Component', () => {
    expect(component).toBeTruthy();
  });

});
