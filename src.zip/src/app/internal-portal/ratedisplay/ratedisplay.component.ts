import { Component, OnInit, ViewChild, HostListener, AfterViewInit, ElementRef } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { MsAdalAngular6Service } from 'microsoft-adal-angular6';



import { PageState } from '@app/shared/services/shared/enum';
import { RoutingKey } from '@app/shared/services/shared/config.const';
import { ShipmentSpeedType, shipmentServiceType } from '@app/services/shared/enum';
import { UtilitiesService } from '@app/shared/services/shared/utilities.service';
import { LocalStorageService, QuoteAPI, GeaographyAPI } from '@app/shared/services';
import { CustomModalComponent } from '@app/shared/components/custom-modal/custom-modal.component';
import { ICurrencyDetails } from '@app/shared/interfaces/entities.interface';
enum RouteServiceType { 'EC' = 'EC', 'CA'="CA" };
import { IUpser } from '@app/models';
import { ToasterService,CustomerAPI } from '@app/shared/services';

@Component({
  selector: 'UPSers-ratedisplay',
  templateUrl: './ratedisplay.component.html',
  styleUrls: ['./ratedisplay.component.css']
})
export class RateDisplayComponent implements OnInit, AfterViewInit {
  body: HTMLBodyElement = document.getElementsByTagName('body')[0];
  @ViewChild('customExitRateCalculatorAlert') modalExitRateCalculatorAlert: CustomModalComponent;
  @ViewChild('customLaneListPopup') modalLaneListPopup: CustomModalComponent;
  @ViewChild('selectedCurrencySymbolInput')
  selectedCurrencySymbolVariable: ElementRef; 


  constructor(private router: Router, private helper: UtilitiesService, private localStorageService:LocalStorageService, private quoteService: QuoteAPI<any>, private geographyService: GeaographyAPI<any>,private adalSvc: MsAdalAngular6Service,private customerAPI: CustomerAPI<any>, private toastr: ToasterService) { }

  selectedServiceType: string = "EC"; // select Consolidated(EC) by default
  selectedFrequencyType: number; 
  rateText: string;
  routeFormattedText: string = "";
  arrowFormat: string = "";
  isCA: boolean = false;
  showOrigiAndDestinationDetails: boolean = false;
  showWeightBreaksDetails: boolean = false;
  showChargeBreakdownDetails: boolean = false;
  routeDetailsClass: string = "fa fa-angle-down fa-lg fwBold cursorPointer";
  weightBreaksDetailsClass: string = "fa fa-angle-down fa-lg fwBold cursorPointer";
  chargeBreakdownDetailsClass: string = "fa fa-angle-down fa-lg fwBold cursorPointer";
  //routeTextCA = "ABE-NYC-JNB-ELS-ABE-NYC-JNB-ELS-ABE-NYC-JNB-ELS";
  routeTextCA = "";
  routeText = "";
  laneTextOrigin = "";
  laneTextDestination = "";
  routeTextEC = "";
  routeValuesCA: string[] = [];
  routeValuesEC: string[] = [];
  routeValues: string[] = [];
  ratePerKgCA: string;
  ratePerKgEC: string;
  selectedWeightBlockValue: number = 0;
  weightRateMin: string ;
  weightRateMinus45: string;
  weightRatePlus45: string;
  weightRate100: string;
  weightRate500: string;
  weightRate1000: string;
  airFreightChargeAmount: string = '';
  fuelChargeAmount: string = '';
  securityChargeAmount: string = '';
  AFAmountInDefaultCurrency: string = '';
  fuelAmountInDefaultCurrency: string = '';
  securityAmountInDefaultCurrency: string = '';
  isPricingTeam: boolean = false;  // TODO - get this value from API
  defaultWeight100: string;
  defaultWeight1000: string;
  rightContainerActionText: string = "MORE";
  rightContainerActionClass: string = "col-lg-2 col-md-2 col-sm-12 col-xs-12 rightContainer pull-right"; 
  leftContainerActionClass: string = "col-lg-10 col-md-10 col-sm-12 col-xs-12 contentContainer"; 
  isRightContainerExpanded: boolean = false;
  isLongTermServiceType: boolean = false;
  rateUnitText: string = "/kg";
  rateUnitSign: string = "$";   // TODO - get this value from API
  weightBreaksDetails: any[] = [];
  weightBreaksDetailsOfAllLanes: any[] = [];
  weightBreaksDetailsOfAllLanesToDisplay: any[] = [];
  checkBoxListOfAllLanesToDisplay: any[] = [];
  airportODPairLaneDetails: any[] = []; 
  expandCurrencyPanel:boolean;
  expandClass:string ="fa fa-angle-up";
  collapseClass:string = "fa fa-angle-down";
  expandCollapseCurrencyClass:string = this.collapseClass;
  currencyConversionData:any[];
  currencyList:any[];
  PMCurrency: string = "";
  PMCurrencyConversionFactor: number;
  selectedCurrency: string = "USD";
  selectedCurrencySymbol: string = "";
  previouslySelectedCurrency: string = "USD";
  previouslySelectedConversionFactor: number = 1;
  suggestedCurrency: string;
  currencyLocalCode: string;
  conversionFactor: number = 1;						   
  currencySelected: boolean;  
  currencySetDefault: boolean = true;
  selectedMenuItem: string = "";
  navigateRoute: string = "";
  originCity: string;
  originCountry: string;
  originRegion: string;
  destinationCity: string;
  destinationCountry: string;
  destinationRegion: string;
  currencyDetail:ICurrencyDetails;
  usDollar: string = "USD";
  selectedRowIndex: number = 0;
  longTermLaneCount: number = 0;
  selectedRowItem: any[] = [];
  showThisItem: boolean;
  showAlertPopup = false;
  showLaneListPopup = false;
  upserDetails: IUpser;
  loading = false;
  selectAllLine: boolean = false;

  ngOnInit() {
    this.body.classList.remove('login-logo');
    this.selectedRowIndex = 0;

    this.airportODPairLaneDetails = this.quoteService.getAirportODPairLaneDetail();
    this.setWeightBreaksDetailsOfAllLanes();



    this.longTermLaneCount = this.airportODPairLaneDetails.length;
    this.currencyDetail = this.quoteService.getCurrencyDetails();
    if (!this.currencyDetail) {
      this.getCurrencyDetailsFrmUsrInfo();
    }

    this.suggestedCurrency = this.currencyDetail.defaultCurrency;

    if (this.quoteService.getAirportODPairLaneDetail() && this.quoteService.getAirportODPairLaneDetail().length > 0) {
      this.selectedFrequencyType = this.quoteService.getAirportODPairLaneDetail()[0].quoteType;
    }

    //this.selectedWeightBlockValue = 4; // +100kg as active by default
    this.selectWeightBlock(4);
    this.defaultWeight100 = this.isPricingTeam ? "" : "selected";
    this.defaultWeight1000 = this.isPricingTeam ? "selected" : "";

    if (this.currencyDetail && this.currencyDetail.defaultCurrency !== this.usDollar) {
      this.selectedCurrency = this.currencyDetail.defaultCurrency;
      this.suggestedCurrency = this.currencyDetail.defaultCurrency;
      this.previouslySelectedCurrency = this.currencyDetail.defaultCurrency;
      this.conversionFactor = this.currencyDetail.conversionFactor;
      this.currencySetDefault = this.currencyDetail.currencySetDefault;
    }

    this.convertRatesToChosenCurrency();
    this.weightBreaksDetailsOfAllLanes.map(item => item.highlightedWeight = 4);    

    // This list is to just display in right side lane list. Don't use for any other purpose.
    // All updates should be done against 'weightBreaksDetailsOfAllLanes'.
    this.weightBreaksDetailsOfAllLanesToDisplay = this.weightBreaksDetailsOfAllLanes.filter(item => item.isActive == true);

    this.onServiceTypeSelect("EC");  // To select Consolidated(EC) as default

    this.getCurrencyDetails();
  }

  ngAfterViewInit() {
    setTimeout(() => {
      this.showAlertPopup = true;
      this.showLaneListPopup = true;
    });

    // To retain selectd curreny on page load after all initialization of all views
    var currencyText = (document.getElementById("hiddenCurrencyField") as HTMLInputElement).value;
    this.selectedCurrencySymbol = currencyText.substring(0, currencyText.indexOf("0"));
  }




  //handle currency popup display

  @HostListener('window:click', ['$event']) clickedOutside1($event) {

    //alert((<HTMLElement>event.target).className);
    this.controlCurrencyPickerVisibility($event);  
  }  

  displayLongTermLanes: boolean;
  laneNotFoundTooltip: string = 'Rates for this lane are not available in the rate calculator. Create a new quote to see a rate.';

  @HostListener('document:click', ['$event']) clickedOutside($event) {

    //alert((<HTMLElement>event.target).className);
    this.controlCurrencyPickerVisibility($event);    
  }


  controlCurrencyPickerVisibility($event) {
    if ((<HTMLElement>event.target).className == "fa fa-angle-up") {
      localStorage.setItem("popupOpen", (<HTMLElement>event.target).className);     }
  
    if ((<HTMLElement>event.target).className != "fa fa-angle-up" && (<HTMLElement>event.target).className != "fa fa-angle-down" &&
      !((<HTMLElement>event.target).className.includes('customcheck')) && !((<HTMLElement>event.target).className.includes('tBoxBor pSearch'))
      && !((<HTMLElement>event.target).className.includes('dropdown-menu tableDown')) && !((<HTMLElement>event.target).className.includes('input-append has-feedback')) && !((<HTMLElement>event.target).className.includes('ng-untouched ng-pristine ng-valid'))
      && !((<HTMLElement>event.target).className.includes('input-append has-feedback')) && !((<HTMLElement>event.target).className.includes('checkmark')) && !((<HTMLElement>event.target).className.includes('ng-valid ng-dirty ng-touched')) &&  !((<HTMLElement>event.target).className.includes('ng-untouched ng-valid ng-dirty'))
      && !((<HTMLElement>event.target).className.includes('ng-pristine ng-valid ng-touched')) && !((<HTMLElement>event.target).className.includes('ng-valid ng-touched ng-dirty')) && !((<HTMLElement>event.target).className.includes('dummy'))) {

      if (localStorage.getItem("popupOpen") == "fa fa-angle-up") {
        if (document.getElementsByClassName('dropdown-menu tableDown').length > 0) {
          document.getElementsByClassName('dropdown-menu tableDown')[0].remove();
          localStorage.removeItem("popupOpen");
          this.toggleCurrencyPanel();
        }
      }
      return;
    }   
  }

  getlaneNotFoundTooltip(item) {
    return item.notfound ? this.laneNotFoundTooltip : '';
  }

  getCurrencyDetailsFrmUsrInfo(){
    this.upserDetails = this.customerAPI.getUpserProfileDetails();
    this.currencyDetail = {
      conversionFactor: Number(this.upserDetails.conversionFactor),
      defaultCurrency: this.upserDetails.defaultCurrency,
      currencySetDefault: true,
      localeCodes:''
    }; 
  }

  /**
   * Update active lane details based on service type select
   * 'this.weightBreaksDetails' will be first set here, and will use the currently selected lane details to print the entire page, irrespective of the service type.
   * */
  updateLaneListOnSeviceTypeToggle() {
    let origin = this.weightBreaksDetailsOfAllLanesToDisplay.length > 0 ? this.weightBreaksDetailsOfAllLanesToDisplay[this.selectedRowIndex].originCode : '';
    let destination = this.weightBreaksDetailsOfAllLanesToDisplay.length > 0 ? this.weightBreaksDetailsOfAllLanesToDisplay[this.selectedRowIndex].destinationCode : '';

    for (let i = 0; i < this.weightBreaksDetailsOfAllLanes.length; i++) {
      if (this.weightBreaksDetailsOfAllLanes[i].originCode == origin && this.weightBreaksDetailsOfAllLanes[i].destinationCode == destination) {
          if (this.weightBreaksDetailsOfAllLanes[i].routeServiceCode == this.selectedServiceType) {
            this.weightBreaksDetailsOfAllLanes[i].isActive = true;
            this.weightBreaksDetails = this.weightBreaksDetailsOfAllLanes[i]; //lane details of the currently selected lane with selected service type
          } else {
            this.weightBreaksDetailsOfAllLanes[i].isActive = false;
          }
      }
    }

    this.weightBreaksDetailsOfAllLanesToDisplay = this.weightBreaksDetailsOfAllLanes.filter(item => item.isActive == true);
    this.displayLongTermLanes = this.weightBreaksDetailsOfAllLanesToDisplay.length > 0 ? true : false;
  }


  setWeightBreaksDetailsOfAllLanes() {
    this.weightBreaksDetailsOfAllLanes = [];
    var rateInfo = this.quoteService.getRateCalculatorDetail();
    for (let item of this.airportODPairLaneDetails) {
      this.addweightBreaksItem(item);
    }
  }

  addweightBreaksItem(laneInfo) {
    var result = this.quoteService.getRateCalculatorDetail().filter(item => item.originCode == laneInfo.originCode && item.destinationCode == laneInfo.destinationCode);

    // If any of the data EC/CA retrieved for the origin and destination pair is not there, then insert that set of values with empty data
    if (result.length > 0) {
      var route = result[0].routeService.filter(item => item.routeServiceCode == RouteServiceType.EC);
      if (route.length > 0) {
        route[0].originCode = laneInfo.originCode;
        route[0].destinationCode = laneInfo.destinationCode;
        this.weightBreaksDetailsOfAllLanes.push(route[0]);
      }
      else {
        this.addEmptyDataWithOriginAndDestination(RouteServiceType.EC, laneInfo);
      }

      route = result[0].routeService.filter(item => item.routeServiceCode == RouteServiceType.CA);
      if (route.length > 0) {
        route[0].originCode = laneInfo.originCode;
        route[0].destinationCode = laneInfo.destinationCode;
        this.weightBreaksDetailsOfAllLanes.push(route[0]);
      }
      else {
        this.addEmptyDataWithOriginAndDestination(RouteServiceType.CA, laneInfo);
      }
    } else {
      // If there are no data retrieved for the origin and destination pair, then insert both CA & EC values with empty data
      this.addEmptyDataWithOriginAndDestination(RouteServiceType.EC, laneInfo);
      this.addEmptyDataWithOriginAndDestination(RouteServiceType.CA, laneInfo);
    }
  }

  /**
   * This method is used to insert empty data into CA or EC set of lane values for a given pair of origin and destination.
   * @param serviceType - for EC/CA
   * @param laneInfo - for origin/destination
   */
  addEmptyDataWithOriginAndDestination(serviceType, laneInfo) {
    this.weightBreaksDetailsOfAllLanes.push({
      minimumChargeAmount: 0, u45Original: 0, o45Original: 0,
      o100Original: 0, o500Original: 0, o1000Original: 0,
      fuel: 0, security: 0, airFreight: 0, routeServiceCode: serviceType.toString(), isActive: false,
      originCode: laneInfo.originCode, destinationCode: laneInfo.destinationCode,
      notfound: true
    });
  }

  /**
   * Get any one lane details based on origin and destination. 
   */
  getRouteDetails() {
    this.routeText = this.weightBreaksDetails && this.weightBreaksDetails['routeWayName'] && this.weightBreaksDetails['routeWayName'].routeWayName ? this.weightBreaksDetails['routeWayName'].routeWayName : "N/A";
    this.laneTextOrigin = this.airportODPairLaneDetails.length > 0 && this.airportODPairLaneDetails[this.selectedRowIndex].originCode ? this.airportODPairLaneDetails[this.selectedRowIndex].originCode : "N/A";
    this.laneTextDestination = this.airportODPairLaneDetails.length > 0 && this.airportODPairLaneDetails[this.selectedRowIndex].destinationCode ? this.airportODPairLaneDetails[this.selectedRowIndex].destinationCode : "N/A";

    
    //origin and destination section values
    this.originCity = this.airportODPairLaneDetails.length > 0 && this.airportODPairLaneDetails[this.selectedRowIndex].originCity ? this.airportODPairLaneDetails[this.selectedRowIndex].originCity : '';
    this.originCountry = this.airportODPairLaneDetails.length > 0 && this.airportODPairLaneDetails[this.selectedRowIndex].originCountry ? this.airportODPairLaneDetails[this.selectedRowIndex].originCountry : '';
    this.originRegion = this.airportODPairLaneDetails.length > 0 && this.airportODPairLaneDetails[this.selectedRowIndex].originRegion ? this.airportODPairLaneDetails[this.selectedRowIndex].originRegion : '';

    this.destinationCity = this.airportODPairLaneDetails.length > 0 && this.airportODPairLaneDetails[this.selectedRowIndex].destinationCity ? this.airportODPairLaneDetails[this.selectedRowIndex].destinationCity : '';
    this.destinationCountry = this.airportODPairLaneDetails.length > 0 && this.airportODPairLaneDetails[this.selectedRowIndex].destinationCountry ? this.airportODPairLaneDetails[this.selectedRowIndex].destinationCountry : '';
    this.destinationRegion = this.airportODPairLaneDetails.length > 0 && this.airportODPairLaneDetails[this.selectedRowIndex].destinationRegion ? this.airportODPairLaneDetails[this.selectedRowIndex].destinationRegion : '';
    
  }

  /**
  * This method is used set the weight breakdown dropdown value.
  **/
  selectWeightBlock(value) {
    this.selectedWeightBlockValue = value;
    this.getRateValue(this.selectedRowIndex);
    this.getChargeBreakdown();
  }

  /**
   * Get highlighted weight break rate for each selected line from lane list
   * @param result
   */
  getHighlightedWeight(result) {
    let ratePerKgValue = "0.00";

    switch (this.selectedWeightBlockValue.toString()) {
      case "1":
        ratePerKgValue = result[0].minimumChargeAmount;
        break;
      case "2":
        ratePerKgValue = result[0].u45Original;
        break;
      case "3":
        ratePerKgValue = result[0].o45Original;
        break;
      case "4":
        ratePerKgValue = result[0].o100Original;
        break;
      case "5":
        ratePerKgValue = result[0].o500Original;
        break;
      case "6":
        ratePerKgValue = result[0].o1000Original;
        break;
    }
    return ratePerKgValue;
  }

  /**
  * This method is used to highlight the weight break section based on the drop down selection
  **/
  weightBlockActive(weightValue) {
    return this.selectedWeightBlockValue == weightValue ? true : false;
  }

  /**
   * This method will return the route map for both service types
   **/
  getRouteText() {
    this.routeFormattedText = "";

    if (this.routeText && this.routeText.length > 0) {
      this.routeValues = this.routeText.split('-');
      for (var i = 0; i < this.routeValues.length; i++) {
        this.arrowFormat = "<span>" + this.routeValues[i] + " <i class=\"fa fa-arrow-right rightArrow\" aria-hidden=\"true\"></i></span>";
        this.routeFormattedText = (i == this.routeValues.length - 1) ? this.routeFormattedText + this.routeValues[i] : this.routeFormattedText + this.arrowFormat;
      }
    }
  }

  /**
   * This method is used to update contents in the page with respect to service type selection.
   * This will be called on ngInit for default service type selection
   * Also this will be called on table row click of long-term view
   **/
  onServiceTypeSelect(serviceType) {
    this.selectedServiceType = serviceType;
    this.updateLaneListOnSeviceTypeToggle();
    this.getRouteDetails();
    this.populateWeightBreaks(this.selectedRowIndex);
    this.weightBlockActive(4);    // To select +100kg as default
    this.getRateValue(this.selectedRowIndex);
    this.getRouteText();
    this.getChargeBreakdown();
  }

  /**
   * This method is used to check which of the service type is active.
   **/
  isDirectCASelected(serviceType) {
    return this.selectedServiceType == serviceType;
  }

  /**
   * This method is used to change weight break contents on service type selection.
   **/
  populateWeightBreaks(index) {
    if (this.selectedServiceType) {
      // TODO - Round all rate values to 2 fraction points
      
      this.weightRateMin = this.weightBreaksDetails && this.weightBreaksDetails['minimumChargeAmount'] ? this.weightBreaksDetails['minimumChargeAmount'] : 0;
      this.weightRateMinus45 = this.weightBreaksDetails && this.weightBreaksDetails['u45Original'] ? this.weightBreaksDetails['u45Original'] : 0;
      this.weightRatePlus45 = this.weightBreaksDetails && this.weightBreaksDetails['o45Original'] ? this.weightBreaksDetails['o45Original'] : 0;
      this.weightRate100 = this.weightBreaksDetails && this.weightBreaksDetails['o100Original'] ? (this.weightBreaksDetails['o100Original'] == -1? 0:this.weightBreaksDetails['o100Original'])  : 0;
      this.weightRate500 = this.weightBreaksDetails && this.weightBreaksDetails['o500Original'] ? this.weightBreaksDetails['o500Original'] : 0;
      this.weightRate1000 = this.weightBreaksDetails && this.weightBreaksDetails['o1000Original'] ? this.weightBreaksDetails['o1000Original'] : 0;

    }
  }
  
  /**
   * This method is used to change rate value based on weight break dropdown value selection.
   **/
  getRateValue(index) {
    if (this.selectedWeightBlockValue) {
      this.rateUnitText = '/kg';
      switch (this.selectedWeightBlockValue.toString()) {
        case "1":
          this.rateText = this.weightRateMin;
          this.airFreightChargeAmount = this.weightBreaksDetails && this.weightBreaksDetails['u45OriginalAf'] ? this.weightBreaksDetails['u45OriginalAf'] : "0.00";     // TODO : Confirm this value 
          this.rateUnitText = '';
          break;
        case "2":
          this.rateText = this.weightRateMinus45;
          this.airFreightChargeAmount = this.weightBreaksDetails && this.weightBreaksDetails['u45OriginalAf'] ? this.weightBreaksDetails['u45OriginalAf'] : "0.00";
          break;
        case "3":
          this.rateText = this.weightRatePlus45;
          this.airFreightChargeAmount = this.weightBreaksDetails && this.weightBreaksDetails['o45OriginalAf'] ? this.weightBreaksDetails['o45OriginalAf'] : "0.00";          
          break;
        case "4":
          this.rateText = this.weightRate100;
          this.airFreightChargeAmount = this.weightBreaksDetails && this.weightBreaksDetails['o100OriginalAf'] ? this.weightBreaksDetails['o100OriginalAf'] : "0.00";
          break;
        case "5":
          this.rateText = this.weightRate500;
          this.airFreightChargeAmount = this.weightBreaksDetails && this.weightBreaksDetails['o500OriginalAf'] ? this.weightBreaksDetails['o500OriginalAf'] : "0.00";
          break;
        case "6":
          this.rateText = this.weightRate1000;
          this.airFreightChargeAmount = this.weightBreaksDetails && this.weightBreaksDetails['o1000OriginalAf'] ? this.weightBreaksDetails['o1000OriginalAf'] : "0.00";
          break;
      }
    }
  }

  /**
   * This method is used to navigate to the previous page on back button click.
   **/
  onBackClick() {
    this.helper.navigateTo(RoutingKey[PageState.RATECALCULATOR]);
  }

  /**
   * This method is used to show hide 'route' details section on expand/collapse button click.
   **/
  expandCollapseRouteDetails() {
    this.showOrigiAndDestinationDetails = !this.showOrigiAndDestinationDetails;
    this.routeDetailsClass = this.showOrigiAndDestinationDetails ? "fa fa-angle-up fa-lg fwBold cursorPointer" : "fa fa-angle-down fa-lg fwBold cursorPointer";
  }

  /**
   * This method is used to show hide 'weight breaks' details section on expand/collapse button click.
   **/
  expandCollapseWeightBreaksDetails() {
    this.showWeightBreaksDetails = !this.showWeightBreaksDetails;
    this.weightBreaksDetailsClass = this.showWeightBreaksDetails ? "fa fa-angle-up fa-lg fwBold cursorPointer" : "fa fa-angle-down fa-lg fwBold cursorPointer";
  }

  /**
   * This method is used to show hide 'charge breakdown' details section on expand/collapse button click.
   **/
  expandCollapseChargeBreakdownDetails() {
    this.showChargeBreakdownDetails = !this.showChargeBreakdownDetails;
    this.chargeBreakdownDetailsClass = this.showChargeBreakdownDetails ? "fa fa-angle-up fa-lg fwBold cursorPointer" : "fa fa-angle-down fa-lg fwBold cursorPointer";
  }

  /**
   * This method is used to get the charge breakdown details on service type selection.
   **/
  getChargeBreakdown() {
    //The rate shown in chargeable weight section column "Charge Amount" should be in the currency pulled in from PM
    this.PMCurrency = this.weightBreaksDetails['currency'];
    this.PMCurrencyConversionFactor = this.currencyConversionData && this.currencyConversionData.filter(item => item.localCurrencyCode == this.PMCurrency)[0].localConversionToUsdAmount;

    this.fuelChargeAmount = this.weightBreaksDetails && this.weightBreaksDetails['fuel'] ? this.weightBreaksDetails['fuel'] : "0.00";
    this.securityChargeAmount = this.weightBreaksDetails && this.weightBreaksDetails['security'] ? this.weightBreaksDetails['security'] : "0.00";

    if (this.PMCurrencyConversionFactor && this.airFreightChargeAmount !== "0.00" && this.PMCurrency !== this.selectedCurrency) {
        this.AFAmountInDefaultCurrency = ((parseFloat(this.airFreightChargeAmount) / this.PMCurrencyConversionFactor) * this.conversionFactor).toFixed(2);
        this.fuelAmountInDefaultCurrency = ((parseFloat(this.fuelChargeAmount) / this.PMCurrencyConversionFactor) * this.conversionFactor).toFixed(2);
        this.securityAmountInDefaultCurrency = ((parseFloat(this.securityChargeAmount) / this.PMCurrencyConversionFactor) * this.conversionFactor).toFixed(2);
    } else {
        this.AFAmountInDefaultCurrency = parseFloat(this.airFreightChargeAmount).toFixed(2);
        this.fuelAmountInDefaultCurrency = parseFloat(this.fuelChargeAmount).toFixed(2);
        this.securityAmountInDefaultCurrency = parseFloat(this.securityChargeAmount).toFixed(2);
    }

    this.AFAmountInDefaultCurrency = this.AFAmountInDefaultCurrency == "0" ? "0.00" : this.AFAmountInDefaultCurrency;
    this.fuelAmountInDefaultCurrency = this.fuelAmountInDefaultCurrency == "0" ? "0.00" : this.fuelAmountInDefaultCurrency;
    this.securityAmountInDefaultCurrency = this.securityAmountInDefaultCurrency == "0" ? "0.00" : this.securityAmountInDefaultCurrency;

    if (this.weightBreaksDetailsOfAllLanesToDisplay.length > 0) {
      for (let i = 0; i < this.weightBreaksDetailsOfAllLanesToDisplay.length; i++) {
        var result = this.weightBreaksDetailsOfAllLanes.filter(item => item.originCode == this.weightBreaksDetailsOfAllLanesToDisplay[i].originCode
                                                                        && item.destinationCode == this.weightBreaksDetailsOfAllLanesToDisplay[i].destinationCode
                                                                        && item.routeServiceCode == this.weightBreaksDetailsOfAllLanesToDisplay[i].routeServiceCode);

        this.weightBreaksDetailsOfAllLanesToDisplay[i].ratePerKg = this.getHighlightedWeight(result);
      }
    }
  }

  /**
   * Convert all rate values except 'charge in amount' column to the currently selected currency values
   * */
  convertRatesToChosenCurrency() {
    for (let i = 0; i < this.weightBreaksDetailsOfAllLanes.length; i++) {
      this.weightBreaksDetailsOfAllLanes[i].minimumChargeAmount = this.weightBreaksDetailsOfAllLanes[i].minimumChargeAmount == 0 ? 0 :
                                        ((parseFloat(this.weightBreaksDetailsOfAllLanes[i].minimumChargeAmount) / this.previouslySelectedConversionFactor) * this.conversionFactor).toFixed(2);
      this.weightBreaksDetailsOfAllLanes[i].u45Original = this.weightBreaksDetailsOfAllLanes[i].u45Original == 0 ? 0 :
                                        ((parseFloat(this.weightBreaksDetailsOfAllLanes[i].u45Original) / this.previouslySelectedConversionFactor) * this.conversionFactor).toFixed(2);
      this.weightBreaksDetailsOfAllLanes[i].o45Original = this.weightBreaksDetailsOfAllLanes[i].o45Original == 0 ? 0 :
                                        ((parseFloat(this.weightBreaksDetailsOfAllLanes[i].o45Original) / this.previouslySelectedConversionFactor) * this.conversionFactor).toFixed(2);
      this.weightBreaksDetailsOfAllLanes[i].o100Original = this.weightBreaksDetailsOfAllLanes[i].o100Original == 0 ? 0 :
                                        ((parseFloat(this.weightBreaksDetailsOfAllLanes[i].o100Original) / this.previouslySelectedConversionFactor) * this.conversionFactor).toFixed(2);
      this.weightBreaksDetailsOfAllLanes[i].o500Original = this.weightBreaksDetailsOfAllLanes[i].o500Original == 0 ? 0 :
                                        ((parseFloat(this.weightBreaksDetailsOfAllLanes[i].o500Original) / this.previouslySelectedConversionFactor) * this.conversionFactor).toFixed(2);
      this.weightBreaksDetailsOfAllLanes[i].o1000Original = this.weightBreaksDetailsOfAllLanes[i].o1000Original == 0 ? 0 :
                                        ((parseFloat(this.weightBreaksDetailsOfAllLanes[i].o1000Original) / this.previouslySelectedConversionFactor) * this.conversionFactor).toFixed(2);

      this.weightBreaksDetailsOfAllLanes[i].fuel = parseFloat(this.weightBreaksDetailsOfAllLanes[i].fuel).toFixed(2);
      this.weightBreaksDetailsOfAllLanes[i].security = parseFloat(this.weightBreaksDetailsOfAllLanes[i].security).toFixed(2);
      this.weightBreaksDetailsOfAllLanes[i].airFreight = parseFloat(this.weightBreaksDetailsOfAllLanes[i].airFreight).toFixed(2);
      this.weightBreaksDetailsOfAllLanes[i].isActive = this.weightBreaksDetailsOfAllLanes[i].routeServiceCode == 'EC' ? true : false;
    }

    this.onServiceTypeSelect(this.selectedServiceType);
  }							 
  /**
   * This methos is used to toggle collape/expand of Origin and Destination Information Section(right container).
   **/
  expandCollapseRightContainer() {
    this.isRightContainerExpanded = !this.isRightContainerExpanded;
    this.leftContainerActionClass = this.isRightContainerExpanded ? "col-lg-8 col-md-8 col-sm-12 col-xs-12 contentContainer" : "col-lg-10 col-md-10 col-sm-12 col-xs-12 contentContainer";
    this.rightContainerActionClass = this.isRightContainerExpanded ? "col-lg-4 col-md-4 col-sm-12 col-xs-12 rightContainer pull-right" : "col-lg-2 col-md-2 col-sm-12 col-xs-12 rightContainer pull-right";


  }

  /**
   * This methos will return the text, either MORE or LESS for long-term right container
   **/
  getRightContainerActionClass() {
    return this.rightContainerActionClass;
  }

  toggleCurrencyPanel() {
    this.resetCurrency();
    this.expandCurrencyPanel = !this.expandCurrencyPanel;
    this.expandCollapseCurrencyClass = this.expandCurrencyPanel? this.expandClass : this.collapseClass;
  }

  getCurrencyDetails() {
  this.geographyService.getCurrencyDetailList().subscribe(
  data => 
  {
    var result = data.result;
    var resultNotEmpty = result !== null && result !== undefined && result.results !== null &&
    result.results !== undefined && result.results.length > 0;

    if(resultNotEmpty && result.results[0].currencyConversion !== null && result.results[0].currencyConversion !== undefined &&
    result.results[0].currencyConversion.length > 0){
      this.currencyConversionData = result.results[0].currencyConversion;

      this.getChargeBreakdown();
    }
  });
  }

  countryValueChanged(event){
    let input = event.target.value;
    this.currencySelected = false;
    if(this.currencyConversionData !== null && this.currencyConversionData !== undefined &&
      this.currencyConversionData.length > 0)
      {
        this.currencyList = this.currencyConversionData.filter(currencyData => currencyData.countryName === input.trim().toUpperCase() || 
        currencyData.localCurrencyCode === input.trim().toUpperCase() || currencyData.currencyDescription === input.trim().toUpperCase());
        if(this.currencyList && this.currencyList.length > 0){
          this.suggestedCurrency = this.currencyList[0].localCurrencyCode; 
          this.conversionFactor = this.currencyList[0].localConversionToUsdAmount;
          this.currencyLocalCode = this.currencyList[0].localeCodes;
        }
      }   
  }

  selectCurrency(){
    if( this.previouslySelectedCurrency !== this.suggestedCurrency){
      this.currencySetDefault = false;
    }
    this.selectedCurrency = this.suggestedCurrency;
    this.selectedCurrencySymbol = this.selectedCurrencySymbolVariable.nativeElement.value.substring(0, this.selectedCurrencySymbolVariable.nativeElement.value.indexOf("0"));

    this.previouslySelectedCurrency = this.suggestedCurrency;
    this.previouslySelectedConversionFactor = this.currencyDetail.conversionFactor;
    this.currencyList = [];
    this.currencySelected = true;     

    this.currencyDetail = {
      conversionFactor: this.conversionFactor,
      defaultCurrency: this.selectedCurrency,
        currencySetDefault: this.currencySetDefault,
        localeCodes: this.currencyLocalCode
    };

    this.localStorageService.setItem('UserDefaultCurrency', this.currencyDetail);
    this.quoteService.setCurrencyDetails(this.currencyDetail);
    this.convertRatesToChosenCurrency();
  }

  resetCurrency(){
    if(!this.currencySelected){
      this.selectedCurrency = this.previouslySelectedCurrency;
      this.suggestedCurrency = "";
      this.currencyList = [];
      this.localStorageService.clearItem('UserDefaultCurrency');
    }
  }

  onSetDefaultChange() {
    this.currencySetDefault = !this.currencySetDefault;
    if(this.currencyDetail ){
      this.currencyDetail.currencySetDefault = this.currencySetDefault; 
    }
    if(this.currencySetDefault){            
      this.updateUser(); 
    }
  }

  displayMessageAlert(navigate: string) {

    this.navigateRoute = navigate;

    this.modalExitRateCalculatorAlert.show();
   
  }

  updateUser() {
    if(this.currencySetDefault){ 
      this.upserDetails =  this.customerAPI.getUpserProfileDetails();
      this.upserDetails.defaultCurrency = this.previouslySelectedCurrency;
      this.upserDetails.conversionFactor = this.conversionFactor.toString();
      this.customerAPI.setUpserProfileDetails(this.upserDetails);
      this.customerAPI.updateUpserProfile(this.upserDetails)
      .subscribe(
        data => {
          if (data == null || data == undefined) {
            this.toastr.error('User Updation failed');
            return;
          }
        },
        error => {
          this.loading = false;
        });
    }
  }

  exit() {
    //will modify code later once all navigation details are in hand 
    if (this.navigateRoute == "RATECALCULATOR")
      this.helper.navigateTo(RoutingKey[PageState.RATECALCULATOR]);
    if (this.navigateRoute == "IPQUOTE")
      this.helper.navigateTo(RoutingKey[PageState.IPQUOTE]);
    if (this.navigateRoute == "IPDASHBOARD")
      this.helper.navigateTo(RoutingKey[PageState.IPDASHBOARD]);
    if (this.navigateRoute == "USERSETTINGS")
      this.helper.navigateTo(RoutingKey[PageState.USERSETTINGS]);
    if (this.navigateRoute == "LOGOUT") {
      localStorage.clear();     
      this.adalSvc.logout();
    } 

}

  goBack(){
    this.modalExitRateCalculatorAlert.hide();
  }

  onNewQuote() {
    let item = { 'originCode': '', 'destinationCode': '', 'ratePerKg': '' };
    this.selectAllLine = false;
    this.checkBoxListOfAllLanesToDisplay = [];

    // Get list to display on checkbox list popup
    for (let i = 0; i < this.weightBreaksDetailsOfAllLanesToDisplay.length; i++) {
      this.checkBoxListOfAllLanesToDisplay.push({
        'originCode': this.weightBreaksDetailsOfAllLanesToDisplay[i].originCode,
        'destinationCode': this.weightBreaksDetailsOfAllLanesToDisplay[i].destinationCode,
        'ratePerKg': this.weightBreaksDetailsOfAllLanesToDisplay[i].ratePerKg,
        'checked': false
      });
    }

    if (this.selectedFrequencyType == 1) {
        this.quoteService.resetAirportODPairLaneDetail();
        this.localStorageService.setItem('isFromRateDisplay', true);
        this.helper.navigateTo(RoutingKey[PageState.IPQUOTE]);
    } else if (this.selectedFrequencyType == 2) {
        this.showLaneListPopup = true;
        this.modalLaneListPopup.show();
    }
  }

  /**
   * Return specific css class for table rows
   * @param index
   */
  tableRowClass(index) {
    return index == this.selectedRowIndex ? "tableBGA cursorPointer" : 'cursorPointer';
  }

  /**
   * Set selected item details on table row click
   * @param selectedItem
   * @param index
   */
  onTableRowClick(selectedItem, index) {
    this.selectedRowIndex = index;
    this.selectedRowItem = selectedItem;
    this.onServiceTypeSelect(selectedItem.routeServiceCode);

  }

  onCancelCheckBoxListPopup() {
    this.modalLaneListPopup.hide();
    //for (let i = 0; i < this.checkBoxListOfAllLanesToDisplay.length; i++) {
    //  this.checkBoxListOfAllLanesToDisplay[i].checked = false;
    //}
  }

  onSelectAll(event) {
    for (let i = 0; i < this.checkBoxListOfAllLanesToDisplay.length; i++) {
      this.checkBoxListOfAllLanesToDisplay[i].checked = event.target.checked;
    }
  }

  isStartAQuoteButtonDisabled() {
    var isValid = false;


    if (this.checkBoxListOfAllLanesToDisplay.length > 0) {
      for (let i = 0; i < this.checkBoxListOfAllLanesToDisplay.length; i++) {
        if (this.checkBoxListOfAllLanesToDisplay[i].checked == true) {
          isValid = true;
          break;
        }
      }
    }
    return isValid;
  }

  onOverlayStartANewQuote() {
    this.quoteService.resetAirportODPairLaneDetail();
    //this.localStorageService.setItem('isFromRateDisplay', true);
    this.helper.navigateTo(RoutingKey[PageState.IPQUOTE]);
  }
}
