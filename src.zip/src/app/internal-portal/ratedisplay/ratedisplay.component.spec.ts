import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';

import { RateDisplayComponent } from './ratedisplay.component';
import { UtilitiesService } from '@app/services/shared/utilities.service';

describe('RatecalculatorComponent', () => {
  let component: RateDisplayComponent;
  let fixture: ComponentFixture<RateDisplayComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule],
      declarations: [RateDisplayComponent],
      providers: [UtilitiesService],
      schemas: [NO_ERRORS_SCHEMA]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RateDisplayComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  //******************** EC CHECKING STARTS HERE **********************

  it('Consolidated(EC) service type should be selected by default..', () => {
    expect(component.selectedServiceType).toEqual('2');
  });

  it('Consolidated(EC) - +100kg weight breakdown should be selected by default..', () => {
    expect(component.selectedWeightBlockValue).toEqual(4);
  });

  it('Consolidated(EC) - +100kg weight breakdown section should be active..', () => {
    expect(component.weightBlockActive(4)).toEqual(true);
  });

  it('Consolidated(EC) - rate value check..', () => {
    component.onServiceTypeSelect(2);
    expect(component.rateText).toEqual('$52.34');

  });

  it('Consolidated(EC) - weight breakdowns section check..', () => {
    component.onServiceTypeSelect(2);
    expect(component.weightRateMin).toEqual('$2.34');
    expect(component.weightRateMinus45).toEqual('$72.34');
    expect(component.weightRatePlus45).toEqual('$62.34');
    expect(component.weightRate100).toEqual('$52.34');
    expect(component.weightRate500).toEqual('$42.34');
    expect(component.weightRate1000).toEqual('$622.34');

  });

  it('Consolidated(EC) - Origin and destination section is not collapsed initially..', () => {
    //component.onServiceTypeSelect(2);
    expect(component.showOrigiAndDestinationDetails).toEqual(false);
  });

  it('Consolidated(EC) - Weight breakdown details section is not collapsed initially..', () => {
    //component.onServiceTypeSelect(2);
    expect(component.showWeightBreaksDetails).toEqual(false);
  });

  it('Consolidated(EC) - Charge Breakdown Details section is not collapsed initially..', () => {
    //component.onServiceTypeSelect(2);
    expect(component.showChargeBreakdownDetails).toEqual(false);
  });

  //******************** EC CHECKING ENDS HERE **********************

  //******************** CA CHECKING STARTS HERE **********************

  it('Direct(CA) service type should be selected on clicking first service type button..', () => {
    component.onServiceTypeSelect(1);
    expect(component.selectedServiceType).toEqual('1');
  });

  it('Direct(CA) - +100kg weight breakdown value should retain on toggling servive type to CA..', () => {
    expect(component.selectedWeightBlockValue).toEqual(4);
  });

  it('Direct(CA) - +100kg weight breakdown section should be active..', () => {
    expect(component.weightBlockActive(4)).toEqual(true);
  });

  it('Direct(CA) - rate value check..', () => {
    component.onServiceTypeSelect(1);
    expect(component.rateText).toEqual('$142.34');
  });

  it('Direct(CA) - weight breakdowns section check..', () => {
    component.onServiceTypeSelect(1);
    expect(component.weightRateMin).toEqual('$12.34');
    expect(component.weightRateMinus45).toEqual('$22.34');
    expect(component.weightRatePlus45).toEqual('$32.34');
    expect(component.weightRate100).toEqual('$142.34');
    expect(component.weightRate500).toEqual('$52.34');
    expect(component.weightRate1000).toEqual('$62.34');
  });

  it('Direct(CA) - change weight dropdown value check..', () => {
    component.onServiceTypeSelect(1);
    component.selectWeightBlock(5);
    expect(component.weightBlockActive(5)).toEqual(true);
    expect(component.weightBlockActive(6)).toEqual(false);
    expect(component.rateText).toEqual('$52.34');
  });

  it('Direct(CA) - Origin and destination section is not collapsed initially..', () => {
    component.onServiceTypeSelect(1);
    expect(component.showOrigiAndDestinationDetails).toEqual(false);
  });

  it('Direct(CA) - Weight breakdown details section is not collapsed initially..', () => {
    component.onServiceTypeSelect(1);
    expect(component.showWeightBreaksDetails).toEqual(false);
  });

  it('Direct(CA) - Charge Breakdown Details section is not collapsed initially..', () => {
    component.onServiceTypeSelect(1);
    expect(component.showChargeBreakdownDetails).toEqual(false);
  });

  it('Direct(CA) - Origin and destination section should be expanded on toggling..', () => {
    component.onServiceTypeSelect(1);
    component.expandCollapseRouteDetails();
    expect(component.showOrigiAndDestinationDetails).toEqual(true);
  });

  it('Direct(CA) - Weight breakdown details section should be expanded on toggling..', () => {
    component.onServiceTypeSelect(1);
    component.expandCollapseWeightBreaksDetails();
    expect(component.showWeightBreaksDetails).toEqual(true);
  });

  it('Direct(CA) - Charge Breakdown Details section should be expanded on toggling..', () => {
    component.onServiceTypeSelect(1);
    component.expandCollapseChargeBreakdownDetails();
    expect(component.showChargeBreakdownDetails).toEqual(true);
  });

  //******************** CA CHECKING ENDS HERE **********************

});
