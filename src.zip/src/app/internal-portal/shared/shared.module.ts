import { NgModule, ModuleWithProviders, CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { IPHeaderComponent } from '@app/shared/components/internalportal-header/IPheader.component';
import { SideNavbarComponent } from '@app/shared/components/internalportal-sidenavbar/sidenavbar.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

@NgModule({
  imports: [
    NgbModule
  ],
  declarations: [
    IPHeaderComponent,
    SideNavbarComponent
  ],
  entryComponents: [],
  exports: [
    IPHeaderComponent,
    SideNavbarComponent
  ],
  providers: [],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA,
    NO_ERRORS_SCHEMA
  ]
})

export class InternalPortalSharedModule {
  static forRoot(): ModuleWithProviders {
    return {
      ngModule: InternalPortalSharedModule,
    };
  }
}
