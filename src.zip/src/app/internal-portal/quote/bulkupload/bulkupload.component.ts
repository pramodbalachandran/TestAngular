import { Component, OnInit, ViewChild, ElementRef, Input, Output, Injectable, EventEmitter, HostListener } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { LocalStorageService, QuoteAPI, GeaographyAPI } from '@app/shared/services';
import { IAirFreightShipmentDetail } from '@app/models/quotes/airfreightshipment-detail';
import { ServiceTypes } from '@app/models/quotes/quotes-details';
import { RoutingKey } from '@app/shared/services/shared/config.const';
import { UtilitiesService } from '@app/shared/services/shared/utilities.service';
import { IDraggableItem, IDroppableItem } from '@app/shared/interfaces/entities.interface';
import { PageState } from '@app/shared/services/shared/enum';
import { FileUploader, FileItem } from 'ng2-file-upload';
import { IQuoteData } from '@app/models/quotes/quote-data';
import { airportDetails } from '@app/models/autopopulate/autopopulate-data';
import { CustomModalComponent } from '@app/shared/components/custom-modal/custom-modal.component';
import * as XLSX from 'xlsx';


enum QuotePackageTypeOptiopns { Roll = 'Roll', Drum = 'Drum', Carton = 'Carton', Packets = 'Packets', PalletSkid = 'Pallet/Skid', Piece = 'Piece', Loose = 'Loose' }
const UPSStandardFileMismatchMessage = "This file doesn't appear to be in the UPS standard format.";
const NonUPSStandardFileMismatchMessage = "This file looks like a UPS template. What do you want to do?";
const lanesAlreadyAddeddMessage = "You've already added lanes to this quote. What would you like to do?";
const cargoShipmentMethod = 'SM001';
enum FileTemplateOptions { "UPS" = 1, "NONUPS" = 2 };
const fileCategoryCode = 'QA002';
const availableIndicator = '1';
const fileStatusCode = '1';

enum UPSStandardColumnOptions {
  'ORIGIN_CODE' = 'Origin CODE','ORIGIN_COUNTRY' = 'Origin Country',
  'ORIGIN_CITY' = 'Origin City','ORIGIN_POSTAL' = 'Origin Zip Code',
  'DESTINATION_CODE' = 'Destination CODE','DESTINATION_COUNTRY' = 'Destination Country',
  'DESTINATION_CITY' = 'Destination City','DESTINATION_POSTAL' = 'Destination Zip Code',
  'SERVICE'='Service', 'MOVEMENT_TYPE' = 'Movement Type',
  'TERMS_OF_SALE' = 'Terms Of Sale Type',
  'COMMODITY' = 'Commodity',
  'IS_HAZMAT' = 'Is Hazmat',
  'HAZMAT_NAME' = 'Hazmat Name',
  'HAZMAT_UN_NUMBER' = 'Hazmat UN Number',
  'HAZMAT_UN_CLASS' = 'Hazmat UN Class',
  'HAZMAT_PACKAGE_GROUP' = 'Hazmat Package Group',
  'PALLETIZED_ANNUAL_SHIPMENTS' = 'Palletized Annual Shipments',
  'LOOSE_ANNUAL_SHIPMENTS' = 'Looase Annual Shipments',
  'PALLETIZED_UNITS_PER_SHIPMENT' = 'Palletized Unit Per Shipment',
  'PALLET_LENGTH' = 'Pallet Length',
  'PALLET_WIDTH' = 'Pallet Width',
  'PALLET_HEIGHT' = 'Pallet Height',
  'PALLET_WEIGHT' = 'Operations Special Notes',
  'PALLET_DIM_UOM' = 'Pallet Dimensional UOM',
  'PALLET_WEIGHT_UOM' = 'Pallet Weight UOM',
  'LOOSE_UNITS_PER_SHIPMENT' = 'Loose Unit Per Shipment',
  'LOOSE_LENGTH' = 'Loose Length',
  'LOOSE_WIDTH' = 'Loose Width',
  'LOOSE_HEIGHT' = 'Loose Height',
  'LOOSE_WEIGHT' = 'Loose Weight Type',
  'LOOSE_DIM_UOM' = 'Loose Dimensional UOM',
  'LOOSE_WEIGHT_UOM' = 'Loose Weight UOM',
  'COMMENTS' = 'Comments',
};

@Component({
  selector: 'pricing-quote-bulkupload',
  templateUrl: './bulkupload.component.html',
  styleUrls: ['./bulkupload.component.css'],
})

export class BulkUploadComponent implements OnInit {
  body: HTMLBodyElement = document.getElementsByTagName('body')[0];
  @ViewChild('customModalFileMismatch') modalFileMismatch: CustomModalComponent;
  @ViewChild('customModalLanesAlreadyAdded') modalLanesAlreadyAdded: CustomModalComponent;
  @ViewChild('bulkFileUploadInput')
  fileUploadInputVariable: ElementRef;
  quoteModel: IQuoteData;
  uploader: FileUploader;
  uploadURL: string;
  hasBaseDropZoneOver: boolean;
  downloadUrl: string;
  fileUploaded: boolean = false;
  nonUPSfileUploaded: boolean = false;

  file: any;
  fileTemplateSelected: number = 1;
  UPSTemplateHeaderFields = ['ORIGIN_CODE', 'ORIGIN_COUNTRY', 'ORIGIN_CITY', 'ORIGIN_POSTAL', 'DESTINATION_CODE', 'DESTINATION_COUNTRY', 'DESTINATION_CITY', 'DESTINATION_POSTAL', 'SERVICE', 'MOVEMENT_TYPE', 'TERMS_OF_SALE', 'COMMODITY', 'IS_HAZMAT', 'HAZMAT_NAME', 'HAZMAT_UN_NUMBER', 'HAZMAT_UN_CLASS', 'HAZMAT_PACKAGE_GROUP', 'PALLETIZED_ANNUAL_SHIPMENTS', 'LOOSE_ANNUAL_SHIPMENTS', 'PALLETIZED_UNITS_PER_SHIPMENT', 'PALLET_LENGTH', 'PALLET_WIDTH', 'PALLET_HEIGHT', 'PALLET_DIM_UOM', 'PALLET_WEIGHT', 'PALLET_WEIGHT_UOM', 'LOOSE_UNITS_PER_SHIPMENT', 'LOOSE_LENGTH', 'LOOSE_WIDTH', 'LOOSE_HEIGHT', 'LOOSE_DIM_UOM', 'LOOSE_WEIGHT', 'LOOSE_WEIGHT_UOM', 'COMMENTS', 'SERVICES', 'MOVEMENT TYPES', 'TOS', 'HAZMAT CHOICES', 'WEIGHT UOM', 'DIM UOM', 'COUNTRY', 'COUNTRYNAME'];
  fileMismatchErrorMessages = [];
  workSheet: any;
  fileRowData = [];
  fileHeaderData: any;
  fileMismatchMessage: string = '';
  uploadedFileUrl: string;
  uploadAsUPSTemplate: boolean;
  fileReaderResult: any;

  airportDetails: airportDetails[] = [];
  headerRowNumber: string='';
  dataRowStart: string='';
  dataRowEnd: string = '';
  customerTemplateMappingFieldsExist: boolean = false;
  customerTemplateLineData = [];
  hideMatchedFields: boolean = false;

  UPSStandardFields: IDraggableItem[] = this.getUPSStandardFields();
  customerUploadedFileFields: IDroppableItem[] = [];
  uploadedFileFields= [];

  droppedItems: IDroppableItem[] = [];

  reader = new FileReader();

  constructor(private helper: UtilitiesService, private quoteService: QuoteAPI<any>,
    private localStorageService: LocalStorageService) {
    this.quoteModel = quoteService.getQuoteDetails();
    this.fileTemplateSelected = this.quoteModel.quoteRequestData.customerTemplateIndicator ? FileTemplateOptions.NONUPS : FileTemplateOptions.UPS;
  }

  ngOnInit() {
    this.body.classList.remove('login-logo');
    this.setupFileUpload();
    this.downloadUrl = this.quoteService.getUPSStandardTemplateURL();
  }

  getUPSStandardFields(): IDraggableItem[] {
    var fields:IDraggableItem[] = [];
    for (let column in UPSStandardColumnOptions) {
      fields.push({ name: UPSStandardColumnOptions[column], key: column, type: 'UPS', dragEnabled: true });
    }
    return fields;
  }

  setupFileUpload() {
    this.uploadURL = this.quoteService.getFileUploadURL();

    this.uploader = new FileUploader({
      url: this.uploadURL,
      autoUpload: true,
      allowedMimeType: ['text/csv', 'application/csv', 'application/vnd.ms-excel',
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'application/vnd.ms-excel.sheet.macroEnabled.12'
      ]
    });

    this.hasBaseDropZoneOver = false;

    this.uploader.response.subscribe(
      data => {
        console.log(data);
      },
      error => {
        console.log(error);
      });

    this.uploader.onSuccessItem = (item: FileItem, response: any, status: any, headers: any) => {
      this.onUploadSuccess(item, response);
    };

    this.uploader.onAfterAddingFile = (item: any) => {
      item.withCredentials = false;
    };
  }

  readerLoad() {
    this.readFile(this.reader);
  }

  onUploadSuccess(item: FileItem, response: any) {
    this.addToAttachamnt();
    item.formData = response;
    this.file = item._file;
    this.reader.onload = (e) => { this.readerLoad() };
    if (this.reader.readAsBinaryString) {
      this.reader.readAsBinaryString(this.file);
    }
    else {
      this.reader.readAsArrayBuffer(this.file);
    }
  }

  readFile(reader) {
    this.fileReaderResult = reader.result;
    var data = reader.result;
    if (!reader.readAsBinaryString) data = new Uint8Array(data);
    var workbook = XLSX.read(data, { type: reader.readAsBinaryString ? 'binary' : 'array' });
    var first_sheet_name = workbook.SheetNames[0];
    this.workSheet = workbook.Sheets[first_sheet_name];
    this.fileUploaded = true;
    this.setupHeaderData();
  }

  setupHeaderData() {
    this.fileHeaderData = '';
    this.uploadedFileFields = [];
    var headerIndex = 4; //UPS template header starting
    var range = XLSX.utils.decode_range(this.workSheet['!ref']);
    range.s.r = headerIndex == 0 ? 0 : headerIndex - 1;
    var C, R = range.s.r;
    for (C = range.s.c; C <= range.e.c; ++C) {
      var cell = this.workSheet[XLSX.utils.encode_cell({ c: C, r: R })];
      /* find the cell in the first row */
      var hdr = "UNKNOWN " + C; // <-- replace with your desired default
      if (cell && cell.t) {
        hdr = XLSX.utils.format_cell(cell);
      }
      if (this.fileHeaderData == '') {
        this.fileHeaderData = hdr;
        this.uploadedFileFields.push(hdr);
      }
      else {
        this.fileHeaderData = this.fileHeaderData + "," + hdr;
        this.uploadedFileFields.push(hdr);
      }
    }
  }

  setupUPSFileLaneData() {
    var range = XLSX.utils.decode_range(this.workSheet['!ref']);
    this.fileRowData = this.constructLaneData(FileTemplateOptions.UPS,4, range.e.r);
  }

  readHeaderFromFile(fileContent) {
    var allTextLines = fileContent.split(/\r\n|\n/);
    var headers = allTextLines[0].split(',');
    if (headers[headers.length - 1] == '') {
      headers = headers.slice(0, -1);
    }
    return headers;
  }

  resetFileInput() {
    console.log(this.fileUploadInputVariable.nativeElement.files);
    this.fileUploadInputVariable.nativeElement.value = "";
  }

  isValidData() {
    return this.fileUploaded;
  }

  fileOverBase(e: any): void {
    this.hasBaseDropZoneOver = e;
  }

  getBulkUploadAttachment() {
    return this.quoteModel.quoteRequestData.quoteAttachment.filter(x => x.fileCategoryCode == fileCategoryCode);
  }

  onFileRemove(item: FileItem) {
    if (item) {
      item.remove();
    }
    
    this.removeBulkUploadAttachment();
    this.quoteModel.airFreightShipmentDetail = [];
    this.fileUploaded = false;
    this.nonUPSfileUploaded = false;
    this.resetFileInput();
    this.resetTextFields();
  }

  removeBulkUploadAttachment() {
    var arr = [];
    this.quoteModel.quoteRequestData.quoteAttachment.map(function (e, i) {
      if (e.fileCategoryCode == fileCategoryCode) { //checking QA002
        arr.push(i);
      }
    });

    for (let index of arr) {
      this.quoteModel.quoteRequestData.quoteAttachment.splice(index, 1);
    }
  }

  resetTextFields() {
    this.headerRowNumber = '';
    this.dataRowStart = '';
    this.dataRowEnd = '';
  }

  isUPSStandardFormat(fileContent) {
    return this.isValidUPSTemplateHeaderColumns(fileContent);
  }

  isValidUPSTemplateHeaderColumns(fileContent) {
    this.fileMismatchErrorMessages = [];
    this.UPSTemplateHeaderFields.forEach((headerField, index) => {
      var isfieldExist = this.findIndex(fileContent, headerField) > -1;
      if (!isfieldExist) { //checking column existing or not
        this.fileMismatchErrorMessages.push(headerField + ' not exist');
      }
      if (isfieldExist && (headerField != fileContent[index].trim())) { //checking column order is correct or not
        this.fileMismatchErrorMessages.push('Column order for ' + headerField + ' is invalid');
      }
    });
    return this.fileMismatchErrorMessages.length == 0;
  }

  findIndex(data, value) {
    var result = -1;
    data.some(function (item, i) {
      if (item.trim() === value.trim()) {
        result = i;
        return true;
      }
    });
    return result;
  }

  getShipmentMovementType(movementType) {
    switch (movementType) {
      case "ATA":
        return 1;
      case "DTA":
        return 2;
      case "ATD":
        return 3;
      case "DTD":
        return 4;
      default:
        return 1;
    }
  }

  getShipmentMovementTypeText(movementType: number) {
    switch (movementType) {
      case 1:
        return 'ATA,Airport-To-Airport';
      case 2:
        return 'DTA,Door-To-Airport';
      case 3:
        return 'ATD,Airport-To-Door';
      case 4:
        return 'DTD,Door-To-Door';
      default:
        return 'DTD,Door-To-Door';
    }
  }

  getServiceType(serviceTypeText): ServiceTypes {
    var serviceType: ServiceTypes = {
      consolidatedECSelected: false, directCASelected: false,
      premiumDirectCXSelected: false, tempTrueSelected: false,
      isModified:false
    }

    switch (serviceTypeText) {
      case "CA":
        serviceType.directCASelected = true;
        break;
      case "EC":
        serviceType.consolidatedECSelected = true;
        break;
    }

    return serviceType;
  }

  onBackClick() {
    this.gotoLaneTab();
  }

  onModalGoBack() {
    this.fileUploaded = false;
    this.nonUPSfileUploaded = false;
    this.uploader.queue = [];
    this.resetFileInput();
    this.modalFileMismatch.close();
  }

  addToAttachamnt(replace: boolean = true) {
    if (replace) {
      this.removeBulkUploadAttachment();
    }
    
    for (let item of this.uploader.queue) {
      if (item.isSuccess) {
        this.quoteModel.quoteRequestData.quoteAttachment.push({
          fileName: item.file.name, fileSize: item.file.size,
          fileOpportunityProductDescriptionText: '', availableIndicator: availableIndicator, fileCategoryCode: fileCategoryCode,
          fileLocationName: '', filePathName: item.formData, fileStatusCode: fileStatusCode, financialContentIndicator: ''
        });
      }
    }
  }

  onModalUploadMapFields() {
    if (this.fileTemplateSelected == FileTemplateOptions.UPS) {
      this.fileTemplateSelected = FileTemplateOptions.NONUPS;
      this.quoteModel.quoteRequestData.customerTemplateIndicator = true;
      this.modalFileMismatch.close();
      this.gotoNonUPSTemplatePath();
    }
    else if (this.fileTemplateSelected == FileTemplateOptions.NONUPS) {
      this.fileTemplateSelected = FileTemplateOptions.UPS;
      this.quoteModel.quoteRequestData.customerTemplateIndicator = false;
      this.modalFileMismatch.close();
      this.nonUPSfileUploaded = false;
      this.resetTextFields();
      this.gotoUPSTemplatePath();
    }
  }

  gotoUPSTemplatePath() {
    this.mapUPSTemplateToQuoteModel();
    this.gotoLaneTab();
  }

  gotoNonUPSTemplatePath() {
    this.droppedItems = [];
    this.resetTextFields();
    this.nonUPSfileUploaded = true;
  }

  onTemplateChange() {
    this.quoteModel.quoteRequestData.customerTemplateIndicator = (this.fileTemplateSelected == FileTemplateOptions.UPS ? false : true);
    this.nonUPSfileUploaded = false;
    this.customerTemplateMappingFieldsExist = false;
    this.resetTextFields();
  }

  onUploadLanes() {
    this.uploadAsUPSTemplate = false;
    this.customerTemplateMappingFieldsExist = false;

    switch (this.fileTemplateSelected.toString()) {
      case "1":
        this.setupUPSFileLaneData();
        if (!this.isUPSStandardFormat(this.readHeaderFromFile(this.fileHeaderData))) {
          this.fileMismatchMessage = UPSStandardFileMismatchMessage;
          this.modalFileMismatch.show();
          return;
        }

        if (this.airFreightDataExist()) {
          this.modalLanesAlreadyAdded.show();
          return;
        }
        else {
          this.gotoUPSTemplatePath();
        }
        break;
      case "2":
        if (this.isUPSStandardFormat(this.readHeaderFromFile(this.fileHeaderData))) {
          this.fileMismatchMessage = NonUPSStandardFileMismatchMessage;
          this.uploadAsUPSTemplate = true;
          this.modalFileMismatch.show();
          return;
        }

        this.gotoNonUPSTemplatePath();
        break;
    }
  }

  onCustomerTemplateLanesUpload() {
    if (this.airFreightDataExist()) {
      this.modalLanesAlreadyAdded.show();
      return;
    }
    else {
      this.mapCustomerTemplateToQuoteModel();
    }
  }

  mapUPSTemplateToQuoteModel(replace: boolean = true) {
    var rowIndex: number = 0;
    if (replace) {
      this.quoteModel.airFreightShipmentDetail = [];
    }

    this.airportDetails = this.localStorageService.getItem('Airportdetails');

    var airportFreightData = this.quoteModel.airFreightShipmentDetail;

    for (let item of this.fileRowData) {
      if (!item.ORIGIN_CODE || item.ORIGIN_CODE.trim() === '') {
        break;
      }


      var airFreightObj = this.quoteService.getEmptyAirFreightShipmentDetail();

      rowIndex++;
      airFreightObj.id = Math.floor(Date.now() / 1000).toString() + rowIndex.toString();
      airFreightObj.originAirport = item.ORIGIN_CODE ? item.ORIGIN_CODE : '';
      var originAirportInfo = this.airportDetails.filter(f => f.airportCode == airFreightObj.originAirport)[0];
      airFreightObj.originAirportName = originAirportInfo ? originAirportInfo.airportName : '';
      airFreightObj.originAutopopulationFormat = originAirportInfo ? originAirportInfo.autopopulateformat : '';
      airFreightObj.originLocationCountryCode = item.ORIGIN_COUNTRY ? item.ORIGIN_COUNTRY : '';
      airFreightObj.destinationLocationPostalCode = item.ORIGIN_POSTAL ? item.ORIGIN_POSTAL : '';
      airFreightObj.originLocationPoliticalDivsion2Code = item.ORIGIN_CITY ? item.ORIGIN_CITY : '';
      airFreightObj.originPoliticalDivision1Name = '';

      airFreightObj.destinationAirport = item.DESTINATION_CODE ? item.DESTINATION_CODE : '';
      var destinationAirportInfo = this.airportDetails.filter(f => f.airportCode == airFreightObj.destinationAirport)[0];
      airFreightObj.destinationAirportName = destinationAirportInfo ? destinationAirportInfo.airportName : '';
      airFreightObj.destinationAutopopulationFormat = destinationAirportInfo ? destinationAirportInfo.autopopulateformat : '';
      airFreightObj.destinationLocationCountryCode = item.DESTINATION_COUNTRY ? item.DESTINATION_COUNTRY : '';
      airFreightObj.destinationLocationPostalCode = item.DESTINATION_POSTAL ? item.DESTINATION_POSTAL : '';
      airFreightObj.destinationLocationPoliticalDivsion2Code = item.DESTINATION_CITY ? item.DESTINATION_CITY : '';
      airFreightObj.destinationPoliticalDivision1Name = '';

      airFreightObj.serviceTypes = this.getServiceType(item.SERVICE);
      airFreightObj.movementTypeCode = this.getShipmentMovementType(item.MOVEMENT_TYPE);
      airFreightObj.MovementTypeDescriptionText = this.getShipmentMovementTypeText(airFreightObj.movementTypeCode);
      airFreightObj.termsOfSale = item.TERMS_OF_SALE ? item.TERMS_OF_SALE : '';
      airFreightObj.commodityTypeDescriptionText = item.COMMODITY ? item.COMMODITY : '';


      airFreightObj.hazardousMaterialName = item.HAZMAT_NAME ? item.HAZMAT_NAME : '';
      airFreightObj.hazardousMaterialsIndicator = item.IS_HAZMAT ? item.IS_HAZMAT == 'YES' ? 1 : 0 : 0;
      airFreightObj.hazardousMaterialUnitedNationsNumber = item.HAZMAT_UN_NUMBER ? item.HAZMAT_UN_NUMBER : '';
      airFreightObj.hazardousMaterialUnitedNationsClassificationCode = item.HAZMAT_UN_CLASS ? item.HAZMAT_UN_CLASS : '';
      airFreightObj.hazardousMaterialPackagingGroupText = item.HAZMAT_PACKAGE_GROUP ? item.HAZMAT_PACKAGE_GROUP : '';

      airFreightObj.shipmentPalletQuantity = item.PALLETIZED_ANNUAL_SHIPMENTS ? item.PALLETIZED_ANNUAL_SHIPMENTS : '';
      airFreightObj.shipmentLooseUnitQUantity = item.LOOSE_ANNUAL_SHIPMENTS ? item.LOOSE_ANNUAL_SHIPMENTS : '';

      airFreightObj.shipmentWeightByPeice = [];
      if (item.PALLET_LENGTH && item.PALLET_LENGTH.trim() != "") {
        airFreightObj.shipmentWeightByPeice.push({
          height: item.PALLET_HEIGHT ? item.PALLET_HEIGHT : '',
          packageType: QuotePackageTypeOptiopns["Pallet/Skid"],
          length: item.PALLET_LENGTH ? item.PALLET_LENGTH : '',
          quantity: item.PALLETIZED_UNITS_PER_SHIPMENT ? item.PALLETIZED_UNITS_PER_SHIPMENT : '',
          shipmentActualWeightQuantity: '',
          shipmentDimensionalUnitOfMeasureTypeCode: item.PALLET_DIM_UOM ? item.PALLET_DIM_UOM : '',
          shipmentDimensionalWeightQuantity: item.PALLET_WEIGHT_UOM ? item.PALLET_WEIGHT_UOM : '',
          shipmentUnitOfMeasureTypeCode: '',
          shipmentVolumeQuantity: '',
          shipmentWeightUnitOfMeasureTypeCode: '',
          weight: item.PALLET_WEIGHT ? item.PALLET_WEIGHT : '',
          width: item.PALLET_WIDTH ? item.PALLET_WIDTH : '',
        });
      }

      if (item.LOOSE_LENGTH && item.LOOSE_LENGTH.trim() != "") {
        airFreightObj.shipmentWeightByPeice.push({
          height: item.LOOSE_HEIGHT ? item.LOOSE_HEIGHT : '',
          packageType: QuotePackageTypeOptiopns.Loose,
          length: item.LOOSE_LENGTH ? item.LOOSE_LENGTH : '',
          quantity: item.LOOSE_UNITS_PER_SHIPMENT ? item.LOOSE_UNITS_PER_SHIPMENT : '',
          shipmentActualWeightQuantity: '',
          shipmentDimensionalUnitOfMeasureTypeCode: item.LOOSE_DIM_UOM ? item.LOOSE_DIM_UOM : '',
          shipmentDimensionalWeightQuantity: item.LOOSE_WEIGHT_UOM ? item.LOOSE_WEIGHT_UOM : '',
          shipmentUnitOfMeasureTypeCode: '',
          shipmentVolumeQuantity: '',
          shipmentWeightUnitOfMeasureTypeCode: '',
          weight: item.LOOSE_WEIGHT ? item.LOOSE_WEIGHT : '',
          width: item.LOOSE_WIDTH ? item.LOOSE_WIDTH : '',
        });
      }

      airFreightObj.quoteNotes = item.COMMENTS ? item.COMMENTS : '';

      //airFreightObj.isCustomerBroker = this.quoteModel.quoteRequestData.customesBrokerage != '' ? 1 : 0;
      //airFreightObj.quoteNotes = this.quoteModel.quoteRequestData.quoteNotes;
      //airFreightObj.quoteValidityEndDate = this.quoteModel.quoteRequestData.quoteValidityEndDate;;
      //airFreightObj.quoteValidityPeriod = this.quoteModel.quoteRequestData.quoteValidityPeriod;;
      //airFreightObj.quoteValidityStartDate = this.quoteModel.quoteRequestData.quoteValidityStartDate;;
      //airFreightObj.shipmentReadyDate = this.quoteModel.quoteRequestData.shipmentReadyDate;

      airFreightObj.shipmentActualWeight = '';
      airFreightObj.shipmentActualWeightQuantity = '';
      airFreightObj.shipmentActualWeightUnitOfMeasureTypeCode = '';
      airFreightObj.shipmentCurrencyCode = '';
      airFreightObj.shipmentDestinationAddressProfileSaveIndicator = false;
      airFreightObj.shipmentDetailIdentificationNumber = '';
      airFreightObj.shipmentDimensionalWeight = '';
      airFreightObj.shipmentDimensionalWeightQuantity = '';
      airFreightObj.shipmentDimensionalWeightUnitOfMeasureTypeCode = '';
      airFreightObj.shipmentFrequency = 0;
      airFreightObj.shipmentFrequencyTimePeriodDescriptionText = '';
      airFreightObj.shipmentInsuranceIndicator = 0;
      airFreightObj.shipmentInsuredValueAmount = '';
      airFreightObj.shipmentLooseUnitPercent = '';
      airFreightObj.shipmentMethod = cargoShipmentMethod;
      airFreightObj.shipmentOriginAddressProfileSaveIndicator = false;
      airFreightObj.shipmentOversizeIndicator = false;
      airFreightObj.shipmentPalletPercent = '';
      airFreightObj.shipmentSpeedType = '';
      airFreightObj.shipmentUnitOfMeasureTypeCode = 0;
      airFreightObj.shipmentValue = '';
      airFreightObj.shipmentValueIndicator = false;
      airFreightObj.shipmentWeightTypeCode = 0;
      airFreightObj.temperatureControlShipmentIndicator = 0;
      airFreightObj.totalWeight = '';

      airportFreightData.push(airFreightObj);
    }
  }

  mapCustomerTemplateToQuoteModel(replace: boolean = true) {
    var rowIndex: number = 0;
    if (replace) {
      this.quoteModel.airFreightShipmentDetail = [];
    }

    var airportFreightData = this.quoteModel.airFreightShipmentDetail;
    this.airportDetails = this.localStorageService.getItem('Airportdetails');

    for (let item of this.customerTemplateLineData) {
      var airFreightObj = this.quoteService.getEmptyAirFreightShipmentDetail();
      rowIndex++;
      airFreightObj.id = Math.floor(Date.now() / 1000).toString() + rowIndex.toString();

      airFreightObj.originAirport = this.getCustomerFieldValue(item,UPSStandardColumnOptions.ORIGIN_CODE);
      var originAirportInfo = this.airportDetails.filter(f => f.airportCode == airFreightObj.originAirport)[0];
      airFreightObj.originAirportName = originAirportInfo ? originAirportInfo.airportName : '';
      airFreightObj.originAutopopulationFormat = originAirportInfo ? originAirportInfo.autopopulateformat : '';
      airFreightObj.originLocationCountryCode = this.getCustomerFieldValue(item,UPSStandardColumnOptions.ORIGIN_COUNTRY);
      airFreightObj.destinationLocationPostalCode = this.getCustomerFieldValue(item,UPSStandardColumnOptions.ORIGIN_POSTAL);
      airFreightObj.originLocationPoliticalDivsion2Code = this.getCustomerFieldValue(item,UPSStandardColumnOptions.ORIGIN_CITY);
      airFreightObj.originPoliticalDivision1Name = '';

      airFreightObj.destinationAirport = this.getCustomerFieldValue(item,UPSStandardColumnOptions.DESTINATION_CODE);
      var destinationAirportInfo = this.airportDetails.filter(f => f.airportCode == airFreightObj.destinationAirport)[0];
      airFreightObj.destinationAirportName = destinationAirportInfo ? destinationAirportInfo.airportName : '';
      airFreightObj.destinationAutopopulationFormat = destinationAirportInfo ? destinationAirportInfo.autopopulateformat : '';
      airFreightObj.destinationLocationCountryCode = this.getCustomerFieldValue(item,UPSStandardColumnOptions.DESTINATION_COUNTRY);
      airFreightObj.destinationLocationPostalCode = this.getCustomerFieldValue(item,UPSStandardColumnOptions.DESTINATION_POSTAL);
      airFreightObj.destinationLocationPoliticalDivsion2Code = this.getCustomerFieldValue(item,UPSStandardColumnOptions.DESTINATION_CITY);
      airFreightObj.destinationPoliticalDivision1Name = '';

      airFreightObj.serviceTypes = this.getServiceType(this.getCustomerFieldValue(item, UPSStandardColumnOptions.SERVICE));
      airFreightObj.movementTypeCode = this.getShipmentMovementType(this.getCustomerFieldValue(item, UPSStandardColumnOptions.MOVEMENT_TYPE));
      airFreightObj.MovementTypeDescriptionText = this.getShipmentMovementTypeText(airFreightObj.movementTypeCode);
      airFreightObj.termsOfSale = this.getCustomerFieldValue(item, UPSStandardColumnOptions.TERMS_OF_SALE);
      airFreightObj.commodityTypeDescriptionText = this.getCustomerFieldValue(item, UPSStandardColumnOptions.COMMODITY);


      airFreightObj.hazardousMaterialName = this.getCustomerFieldValue(item, UPSStandardColumnOptions.HAZMAT_NAME);
      airFreightObj.hazardousMaterialsIndicator = this.getCustomerFieldValue(item, UPSStandardColumnOptions.IS_HAZMAT)== 'YES' ? 1 : 0;
      airFreightObj.hazardousMaterialUnitedNationsNumber = this.getCustomerFieldValue(item, UPSStandardColumnOptions.HAZMAT_UN_NUMBER);
      airFreightObj.hazardousMaterialUnitedNationsClassificationCode = this.getCustomerFieldValue(item, UPSStandardColumnOptions.HAZMAT_UN_CLASS);
      airFreightObj.hazardousMaterialPackagingGroupText = this.getCustomerFieldValue(item, UPSStandardColumnOptions.HAZMAT_PACKAGE_GROUP);

      airFreightObj.shipmentPalletQuantity = this.getCustomerFieldValue(item, UPSStandardColumnOptions.PALLETIZED_ANNUAL_SHIPMENTS); 
      airFreightObj.shipmentLooseUnitQUantity = this.getCustomerFieldValue(item, UPSStandardColumnOptions.LOOSE_ANNUAL_SHIPMENTS);

      airFreightObj.shipmentWeightByPeice = [];
      var palletLength = this.getCustomerFieldValue(item, UPSStandardColumnOptions.PALLET_LENGTH);
      if (palletLength && palletLength.trim() != "") {
          airFreightObj.shipmentWeightByPeice.push({
          height: this.getCustomerFieldValue(item, UPSStandardColumnOptions.PALLET_HEIGHT),
          packageType: QuotePackageTypeOptiopns["Pallet/Skid"],
          length: palletLength,
          quantity: this.getCustomerFieldValue(item, UPSStandardColumnOptions.PALLETIZED_UNITS_PER_SHIPMENT),
          shipmentActualWeightQuantity: '',
          shipmentDimensionalUnitOfMeasureTypeCode: this.getCustomerFieldValue(item, UPSStandardColumnOptions.PALLET_DIM_UOM),
          shipmentDimensionalWeightQuantity: this.getCustomerFieldValue(item, UPSStandardColumnOptions.PALLET_WEIGHT_UOM),  
          shipmentUnitOfMeasureTypeCode: '',
          shipmentVolumeQuantity: '',
          shipmentWeightUnitOfMeasureTypeCode: '',
          weight: this.getCustomerFieldValue(item, UPSStandardColumnOptions.PALLET_WEIGHT),
          width: this.getCustomerFieldValue(item, UPSStandardColumnOptions.PALLET_WIDTH),
        });
      }

      var looseLength = this.getCustomerFieldValue(item, UPSStandardColumnOptions.PALLET_LENGTH);
      if (looseLength && looseLength.trim() != "") {
          airFreightObj.shipmentWeightByPeice.push({
          height: this.getCustomerFieldValue(item, UPSStandardColumnOptions.LOOSE_HEIGHT),
          packageType: QuotePackageTypeOptiopns.Loose,
          length: looseLength,
          quantity: this.getCustomerFieldValue(item, UPSStandardColumnOptions.LOOSE_UNITS_PER_SHIPMENT),
          shipmentActualWeightQuantity: '',
          shipmentDimensionalUnitOfMeasureTypeCode: this.getCustomerFieldValue(item, UPSStandardColumnOptions.LOOSE_DIM_UOM),
          shipmentDimensionalWeightQuantity: this.getCustomerFieldValue(item, UPSStandardColumnOptions.LOOSE_WEIGHT_UOM),
          shipmentUnitOfMeasureTypeCode: '',
          shipmentVolumeQuantity: '',
          shipmentWeightUnitOfMeasureTypeCode: '',
          weight: this.getCustomerFieldValue(item, UPSStandardColumnOptions.LOOSE_WEIGHT),
          width: this.getCustomerFieldValue(item, UPSStandardColumnOptions.LOOSE_WIDTH),
        });
      }

      airFreightObj.quoteNotes = item.COMMENTS ? item.COMMENTS : '';

      airportFreightData.push(airFreightObj);
    }

    this.gotoLaneTab();
  }

  getCustomerFieldValue(item: any, column: UPSStandardColumnOptions): any {
    var result;
    var fieldsInfo: IDroppableItem = this.customerUploadedFileFields.find(x => x.mappedColumnName == column.toString());
    if (fieldsInfo) {
      result=item[fieldsInfo.name];
    }
    return result;
  }

  onAddToLaneList() {
    if (this.fileTemplateSelected == FileTemplateOptions.UPS) {
      this.mapUPSTemplateToQuoteModel(false);
    }
    else {
      this.mapCustomerTemplateToQuoteModel(false);
    }
    this.gotoLaneTab();
  }

  onReplaceLaneList() {
    if (this.fileTemplateSelected == FileTemplateOptions.UPS) {
      this.mapUPSTemplateToQuoteModel();
    }
    else {
      this.mapCustomerTemplateToQuoteModel();
    }
    this.gotoLaneTab();
  }

  gotoLaneTab() {
    this.quoteService.setQuoteDetails(this.quoteModel);
    this.localStorageService.setItem('isFromRateDisplay', true);
    this.helper.navigateTo(RoutingKey[PageState.IPQUOTE]);
  }

  airFreightDataExist() {
    if (this.quoteModel.airFreightShipmentDetail.length > 0) {
      return this.quoteModel.airFreightShipmentDetail[0].originLocationCountryCode != "" && this.quoteModel.airFreightShipmentDetail[0].destinationLocationCountryCode != "";
    }
    return false;
  }

  isValidCustomerTemplateRowData() {
    return parseInt(this.headerRowNumber) > 0 && parseInt(this.dataRowStart) > 0 && parseInt(this.dataRowEnd)>0;
  }

  readCustomerTemplateHeader(headerIndex) {
    var headers:IDroppableItem[] = [];
    var sheet = this.workSheet; // workbook.Sheets[workbook.SheetNames[0]];
    var range = XLSX.utils.decode_range(this.workSheet['!ref']);
    //var range = { s: { c: 0, r: 3 }, e: { c: 0, r: 6 } }
    range.s.r = headerIndex == 0 ? 0 : headerIndex - 1;
    var C, R = range.s.r;
    /* start in the first row */
    /* walk every column in the range */
    for (C = range.s.c; C <= range.e.c; ++C) {
      var cell = sheet[XLSX.utils.encode_cell({ c: C, r: R })];
      /* find the cell in the first row */
      var hdr = "UNKNOWN " + C; // <-- replace with your desired default
      if (cell && cell.t) {
        hdr = XLSX.utils.format_cell(cell);
      }
      headers.push({ name: hdr, mappedColumnName: "", type: 'FILE', hide:false,dropEnabled:true });
    }
    return headers;
  }

  mapMatchingHeaderFields(headers: IDroppableItem[]) {
    for (let item of headers) {
      var matchedColumns = this.UPSStandardFields.filter(x => x.key.toLocaleLowerCase().trim() == item.name.toLocaleLowerCase().trim());
      if (matchedColumns.length > 0) {
        item.mappedColumnName = matchedColumns[0].name;
      }
    }
    return headers;
  }

  constructLaneData(templateSelected :FileTemplateOptions, rowStart:number,rowEnd:number) {
    var laneData = [];
    var colValues = [];

    var range = XLSX.utils.decode_range(this.workSheet['!ref']);
    var C, R = range.s.r;

    range.s.r = rowStart <= 0 ? 0 : rowStart;
    range.e.r = rowEnd <= 0 ? 0 : rowEnd;
    R = range.s.r;
    for (var R = range.s.r; R <= range.e.r; ++R) {
      for (C = range.s.c; C <= range.e.c; ++C) {
        var cell = this.workSheet[XLSX.utils.encode_cell({ c: C, r: R })];
        var hdr = "";
        if (cell && cell.t) {
          hdr = XLSX.utils.format_cell(cell);
        }
        colValues.push({ name: templateSelected == FileTemplateOptions.UPS ? this.uploadedFileFields[C] : this.customerUploadedFileFields[C].name, value: hdr });
      }

      var obj = {};
      for (var j = 0; j < colValues.length; j++) {
        var key = colValues[j].name;
        obj[key] = colValues[j].value;
      }
      laneData.push(obj);
    }
    return laneData;
  }

  onCustomerTemplateMapFields() {
    this.customerUploadedFileFields = this.mapMatchingHeaderFields(this.readCustomerTemplateHeader(parseInt(this.headerRowNumber)));
    this.customerTemplateMappingFieldsExist = this.customerUploadedFileFields.length > 0;
    this.customerTemplateLineData = this.constructLaneData(FileTemplateOptions.NONUPS,parseInt(this.dataRowStart) - 1, parseInt(this.dataRowEnd)-1);
  }

  removeDroppedItem(item: any, list: Array<any>) {
    let index = list.map(function (e) {
      return e.name
    }).indexOf(item.name);
    list.splice(index, 1);
  }

  removeMappedField(item: IDroppableItem) {
    this.removeDroppedItem(item, this.customerUploadedFileFields);
  }

  onShowHideMatchedFields(isHide) {
    this.customerUploadedFileFields.filter(x => x.mappedColumnName != '').forEach(x => x.hide = isHide);
  }

  onDrop(item: IDroppableItem, e: any) {
    this.droppedItems.push(e.dragData);
    item.mappedColumnName = e.dragData.name;
  }

  isMappedCustomFields() {
    return this.customerUploadedFileFields.length>0 && (this.customerUploadedFileFields.filter(x => x.mappedColumnName != '').length == this.customerUploadedFileFields.length);
  }

}

