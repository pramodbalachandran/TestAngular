import { NgModule, CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { routing } from './quote.routing';
import { HttpModule } from '@angular/http';
import { SharedModule } from '@app/shared/shared.module';
import { InternalPortalSharedModule } from '@app/internal-portal/shared/shared.module';
import { LongTermQuoteComponent } from './long-term-quote/long-term-quote.component';
import { QuoteLanesComponent } from './quotelane/quotelanes.component';
import { QuoteLanesShipmentComponent } from './quotelanesshipment/quotelanesshipment.component';
import { QuoteOverViewComponent } from './quoteoverview/quoteoverview.component';
import { BulkUploadComponent } from './bulkupload/bulkupload.component';
import { QuoteLaneCommodityComponent } from './quotelanecommodity/quotelanecommodity.component';

@NgModule({
  imports: [routing, SharedModule, InternalPortalSharedModule, HttpModule],
  providers: [],
  declarations:
    [
      LongTermQuoteComponent,
      QuoteLanesComponent,
      QuoteLanesShipmentComponent,
      QuoteOverViewComponent,
      BulkUploadComponent,
      QuoteLaneCommodityComponent
    ],
  entryComponents: [QuoteLaneCommodityComponent],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA,
    NO_ERRORS_SCHEMA
  ]
})
export class QuoteInternalPortalModule {}
