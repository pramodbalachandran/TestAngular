import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LongTermQuoteComponent } from './long-term-quote/long-term-quote.component';
import { BulkUploadComponent } from './bulkupload/bulkupload.component';

const routes: Routes = [
    { path: '', component: LongTermQuoteComponent },
    { path: 'shipment', component: LongTermQuoteComponent },
    { path: 'bulkupload', component: BulkUploadComponent },
];
export const routing: ModuleWithProviders = RouterModule.forChild(routes);
