import { CommodityNameList } from './../../../models/quotes/airfreightshipment-detail';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { TemperatureUnit } from '@app/shared/enums/TemperatureUnit';
import { ShipmentCommodity } from '@app/models';

export class CommodityViewModel {
  specialRequirements = {
    hazardous: false,
    perishable: false,
    temperatureControlled: false,
    highValueHighRisk: false,
    specialSecurityRequired: false,
    doNotStack: false,
    others: false
  };
  commodities = '';
  selectedTempUnit = TemperatureUnit.Farenheit;
  selectedCommodityType: string;
  unNumber = '';
  packingGroup = '';
  packingInstructionSet = '';
  temperatureFrom = '';
  temperatureTo = '';
  notes = '';
}


@Component({
  selector: 'pricing-quotelanecommodity',
  templateUrl: './quotelanecommodity.component.html',
  styleUrls: ['./quotelanecommodity.component.css']
})
export class QuoteLaneCommodityComponent implements OnInit {

  @Input()
  commodityTypes: any[];
  @Output()
  closeCommodityOverlay = new EventEmitter<any>();
  shipmentCommodities: ShipmentCommodity[];
  commodityArray: CommodityViewModel[] = [];
  keys = Object.keys;
  tempUnits = TemperatureUnit;

  constructor( private activeModal: NgbActiveModal) { }

  ngOnInit() {
    this.initializeCommodities();
  }

  initializeCommodities() {
    this.commodityArray.push(new CommodityViewModel());
  }

  addCommodity() {
    this.commodityArray.push(new CommodityViewModel());
  }

  removeCommodity(index: number) {
    this.commodityArray.splice(index, 1);
  }

  isAddOrDelete(index): boolean {
    const len = this.commodityArray.length;
    return (((len === 1) || (index === (len - 1))));
  }

  isPrimaryOrDanger(index) {
    return (this.isAddOrDelete(index) ? 'btn-primary' : 'btn-danger');
  }

  isPlusOrTrash(index) {
    return (this.isAddOrDelete(index) ? 'fas fa-plus' : 'far fa-trash-alt');
  }

  addOrDelete(index) {
    if (this.isAddOrDelete(index)) {
      this.addCommodity();
    } else {
       this.removeCommodity(index);
    }
  }

  getToggleClass(val: boolean) {
    return (val ? 'btn-primary btn-toggled' : 'btn-default');
  }


  closePopup(save?: boolean) {
    const commodities: ShipmentCommodity[] = [];
    this.commodityArray.forEach(commodityVm => {
      const commodity = new ShipmentCommodity();
      commodity.commodityType = commodityVm.selectedCommodityType;
      const commodityNames = commodityVm.commodities.split(',').map(item => item.trim());
      commodity.commodityNames = [];
      commodityNames.forEach( name => {
        const cmName = new CommodityNameList();
        cmName.commodityName = name;
        commodity.commodityNames.push(cmName);
      });
      commodity.hazardousMaterialsIndicator = commodityVm.specialRequirements.hazardous ? 1 : 2;
      commodity.temperatureControlShipmentIndicator = commodityVm.specialRequirements.temperatureControlled ? 1 : 2;
      commodity.perishableShipmentIndicator = commodityVm.specialRequirements.perishable ? 1 : 2;
      commodity.shipmentStackableIndicator = !commodityVm.specialRequirements.doNotStack;
      commodity.highValueRiskIndicator = commodityVm.specialRequirements.highValueHighRisk;
      commodity.otherSpecialIndicator = commodityVm.specialRequirements.others;
      commodity.specialSecurityIndicator = commodityVm.specialRequirements.specialSecurityRequired;
      commodity.hazardousMaterialUnitedNationsNumber = commodityVm.unNumber;
      commodity.hazardousMaterialPackagingGroup = commodityVm.packingGroup;
      commodity.hazardousMaterialPackagingInstructions = commodityVm.packingInstructionSet;
      commodity.shipmentTemperatureRangeFromValue = commodityVm.temperatureFrom;
      commodity.shipmentTemperatureRangeToValue = commodityVm.temperatureTo;
      commodity.shipmentTemperatureControlUnitOfMeasurement = commodityVm.selectedTempUnit;
      commodity.commentText = commodityVm.notes;
      commodities.push(commodity);
    });

    this.closeCommodityOverlay.emit( save ? commodities : null);
    this.activeModal.close();
  }

  displayNotes(commodity: CommodityViewModel): boolean {
    return (commodity.specialRequirements.doNotStack ||
    commodity.specialRequirements.hazardous ||
    commodity.specialRequirements.highValueHighRisk ||
    commodity.specialRequirements.others ||
    commodity.specialRequirements.perishable ||
    commodity.specialRequirements.specialSecurityRequired ||
    commodity.specialRequirements.temperatureControlled);
  }
}
