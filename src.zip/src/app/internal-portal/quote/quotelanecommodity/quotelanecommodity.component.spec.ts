import { NgbModule, NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { map } from 'rxjs/operators';
import { NgSelectModule } from '@ng-select/ng-select';
import { FormsModule } from '@angular/forms';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { QuoteLaneCommodityComponent } from './quotelanecommodity.component';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { TemperatureUnit } from '@app/shared/enums/TemperatureUnit';
import { SharedModule } from '@app/shared/shared.module';

describe('QuotelanecommodityComponent', () => {
  let component: QuoteLaneCommodityComponent;
  let fixture: ComponentFixture<QuoteLaneCommodityComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, HttpClientTestingModule, FormsModule, NgSelectModule, SharedModule, NgbModule],
      providers: [NgbActiveModal],
      declarations: [ QuoteLaneCommodityComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(QuoteLaneCommodityComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  describe('getToggleClass', () => {
    it('should return appropriate class based on the given value', () => {
      expect(component.getToggleClass(true)).toEqual('btn-primary btn-toggled');
      expect(component.getToggleClass(false)).toEqual('btn-default');
    });
  });
  describe('closePopup', () => {
    it('emit closeCommodityOverlay with appropriate parameter based on given value', () => {
      const emitSpy = spyOn(component.closeCommodityOverlay, 'emit');
      component.closePopup();
      expect(emitSpy).toHaveBeenCalledWith(null);
      component.commodities = 'abc';
      component.selectedCommodityType = '123';
      component.specialRequirements.doNotStack = true;
      component.specialRequirements.hazardous = true;
      component.specialRequirements.highValueHighRisk = true;
      component.specialRequirements.perishable = true;
      component.unNumber = '1';
      component.packingGroup = 'grp';
      component.packingInstructionSet = `pack
      inst`;
      component.temperatureFrom = '43';
      component.temperatureTo = '44';
      component.selectedTempUnit = TemperatureUnit.Celsius;
      component.notes = `notes
      notes notes`;
      component.closePopup(true);
      expect(emitSpy).toHaveBeenCalledWith({
        commodityTypeCode: component.selectedCommodityType,
        specialRequirements: component.specialRequirements,
        commodities: component.commodities,
        unNumber: component.unNumber,
        packingGroup: component.packingGroup,
        packingInstructionSet: component.packingInstructionSet,
        temperatureFrom: component.temperatureFrom,
        temperatureTo: component.temperatureTo,
        temperatureUnit: component.selectedTempUnit,
        notes: component.notes
      });
    });
  });
  describe('displayNotes', () => {
    it('should return true if any of the special requirements are selected.', () => {
      component.specialRequirements.doNotStack = false;
      component.specialRequirements.hazardous = false;
      component.specialRequirements.highValueHighRisk = false;
      component.specialRequirements.others = false;
      component.specialRequirements.perishable = false;
      component.specialRequirements.specialSecurityRequired = false;
      component.specialRequirements.temperatureControlled = false;
      expect(component.displayNotes()).toBeFalsy();
      component.specialRequirements.doNotStack = true;
      expect(component.displayNotes()).toBeTruthy();
      component.specialRequirements.doNotStack = false;
      component.specialRequirements.hazardous = true;
      expect(component.displayNotes()).toBeTruthy();
      component.specialRequirements.hazardous = false;
      component.specialRequirements.highValueHighRisk = true;
      expect(component.displayNotes()).toBeTruthy();
      component.specialRequirements.highValueHighRisk = false;
      component.specialRequirements.others = true;
      expect(component.displayNotes()).toBeTruthy();
      component.specialRequirements.others = false;
      component.specialRequirements.perishable = true;
      expect(component.displayNotes()).toBeTruthy();
      component.specialRequirements.perishable = false;
      component.specialRequirements.specialSecurityRequired = true;
      expect(component.displayNotes()).toBeTruthy();
      component.specialRequirements.specialSecurityRequired = false;
      component.specialRequirements.temperatureControlled = true;
      expect(component.displayNotes()).toBeTruthy();

    });
  });
});
