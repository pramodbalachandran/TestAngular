import { ShipmentCommodity } from './../../../models/quotes/airfreightshipment-detail';
import { QuoteLaneCommodityComponent } from './../quotelanecommodity/quotelanecommodity.component';
import { Component, OnInit, Input, ViewChild, HostListener, ElementRef } from '@angular/core';
import { retry } from 'rxjs/operators';
import { DataTableModule } from 'angular-6-datatable';
import { RoutingKey } from '@app/shared/services/shared/config.const';
import { UtilitiesService } from '@app/shared/services/shared/utilities.service';
import { airportDetails, shipmentServiceType } from '@app/models/autopopulate/autopopulate-data';
import { LocalStorageService, QuoteAPI, GeaographyAPI } from '@app/shared/services';
import { PageState } from '@app/shared/services/shared/enum';
import { FormGroup, FormBuilder, FormControl } from '@angular/forms';
import { Observable } from 'rxjs';
import { DomSanitizer } from '@angular/platform-browser';
import { map, startWith } from 'rxjs/operators';
import { IAirportODPair } from '@app/shared/interfaces/entities.interface';
import { AutocompleteComponent } from '@app/shared/helper/autocomplete.component';
import { MatAutocompleteSelectedEvent, MatAutocomplete } from '@angular/material';
import { QuoteLanesShipmentComponent } from './quotelanesshipment/quotelanesshipment.component';
import { ModalComponent } from '@app/shared/helper/modalpopup.component';
import { IQuoteData } from '@app/models/quotes/quote-data';
import { MovementTypeConst, MovementTypeVal } from '@app/shared/enums/MovementType';
import { SalesTermConst } from '@app/shared/enums/SalesTerms';
import { NgbDatepickerConfig, NgbCalendar, NgbDateStruct, NgbDateParserFormatter, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { NgbDateFormatter } from '@app/shared/helper/ngb-datepicker-formatter.component';
import { trigger, transition, animate, style } from '@angular/animations';
import { ServiceTypes, AirFreightShipmentDetail, IAirFreightShipmentDetail, CommodityNameList } from '@app/models';

import { ApplicationUrls } from '@app/shared/services/shared/config.const';
import { CustomModalComponent } from '@app/shared/components/custom-modal/custom-modal.component';

enum QuoteRequestValidityOptions { '1Month' = '1 month', '3months' = '3 months', '6months' = '6 months', '1year' = '1 year', 'Other' = 'Other' }
@Component({
  selector: 'pricing-quotelanes',
  templateUrl: './quotelanes.component.html',
  styleUrls: ['./quotelanes.component.css'],
  providers: [DataTableModule, { provide: NgbDateParserFormatter, useClass: NgbDateFormatter }],
  animations: [
    trigger('slideInOut', [
      transition(':enter', [
        style({ transform: 'translateY(100%)' }),
        animate('1ms ease-in', style({ transform: 'translateY(100%)' }))
      ]),
      transition(':leave', [
        animate('1ms ease-in', style({ transform: 'translateY(100%)' }))
      ])
    ])
  ]
})
/*Drop 2 Feature 22(TFS Task:804609,804613,827205) :This component is for "Create Long Term Quote" "LANES" Tab */
export class QuoteLanesComponent implements OnInit {
  body: HTMLBodyElement = document.getElementsByTagName('body')[0];
  @ViewChild('modalOriginpopup') modalOriginpopup: ModalComponent;
  @Input('quotemodel') quoteModel: IQuoteData;
  @ViewChild('popupInput') popupInput: ElementRef;
  @ViewChild('termsofsalesOverLay') termsofsalesOverLay: CustomModalComponent;
  /*START: material auto complete forms and array declarations  */
  myFormOrg: FormGroup;
  filteredairportdetails: Observable<airportDetails[]>;
  filteredairportdetailsDes: Observable<airportDetails[]>;
  airportDetailsArray: airportDetails[];
  airportDetailsArrayHighlight = [];
  intermediatefilteredairportdetails: airportDetails[];
  finalfilteredairportdetails: airportDetails[];
  airportdetailsforadditionalformats: airportDetails[] = [];
  movementArray: any = [];
  movementArrayFilter = [];
  FilteredshipmentServiceTypeArray: Observable<shipmentServiceType[]>;
  shipmentServiceTypeArray: shipmentServiceType[];
  intermediatefilteredshipmentServiceType: shipmentServiceType[];
  finalfilteredshipmentServiceType: shipmentServiceType[];
  shipmentServiceTypeArr: shipmentServiceType;
  isA2Aoption = false;
  isOriginTextboxauotopopulatechangeneeded = false;
  isDestinationTextboxauotopopulatechangeneeded = false;
  currentrowno = 0;
  inputvaluelength = 3;/*Default value is 3 */
  quotemarginDynamicvalue: string = "-60";
  showCommodity = false;
  /*END: material auto complete forms and array declarations  */

  /*START : API object and array declarations */
  objshipmentServiceType: string = "D2D";
  movementTypeDefault: string;
  objorginCity: string;
  objdestinationCity: string;
  objorginStreetAddress: string;
  objdestinationStreetAddress: string;
  lanedataArray = [];
  laneDataGrid = [];
  customesBrokerage: string;
  /*END : API object and array declarations */

  /*START : date validation parameters */
  quotevalidityperiod: string = "1 year";
  validityEndPeriod: NgbDateStruct;
  validityStartPeriod: NgbDateStruct;
  modelValidityStartDate: Date = null;
  modelValidityEndDate: Date = null;
  /*END : date validation parameters */

  /*START : grid lane edit objects */
  objgridmovementtype: string;
  objgridorigincity: string;
  objgriddescity: string;
  objgriddesstreetaddress: string;
  objgridorginStreetAddress: string;
  objpopgridorigincity: string;
  objpopgriddescity: string;
  objpopgridorginStreetAddress: string;
  objpopgriddestinationStreetAddress: string;
  isgridOriginTextboxauotopopulatechangeneeded = false;
  isgridDestinationTextboxauotopopulatechangeneeded = false;
  griddisplayDestinationpopup = false;
  griddisplayOriginnpopup = false;
  gridquotemarginDynamicvalue: string = "-150";
  gridcurrentrowno = 0;
  griddisplaydesmaterialauto = false;
  gridchildcomponentmargintop = "-60";
  griddisplayoriginmaterialauto = false;
  gridautoselectionchanged = false;
  griddisplayShipmentdetails: number = 0;
  grideditclicked = false;
  grideditrowno = 0;
  /*END : grid lane edit objects */

  /*START : Page load and validation parameters */
  displayDestinationpopup = false;
  selectedlanecount = 0;
  isLongtermquote = false;
  servicetypedirect = false;
  servicetypeconsolidated = false;
  servicetypepremium = false;
  servicetypetemp = false;
  sliderowno = "0";
  enablesavebutton = false;
  chkSelectallvalue = false;
  defaulttermsOfSale: string;
  /*END :  Page load and validation parameters */

  /*Grid Validation parameters*/
  gridvalidationtype = 0;
  gridoriginerror = false;
  griddesterror = false;
  gridmovementtypeerror = false;
  selectedmovementType = MovementTypeConst.DTD;
  selectedmovementVal = MovementTypeVal.DTD;
  selectedmovementTyperowno: string;

  /*START : Input variable declarations for child components */
  objshipmentweightArray: any = [];
  displayShipmentdetails: number = 0;
  displaydesmaterialauto = false;
  childcomponentmargintop = "-60";
  displayoriginmaterialauto = false;
  displayOriginnpopup = false;
  autoselectionchanged = false;
  isFocused = false;
  commodityTypes: any[];
  /*END :  Input variable declarations for child components */
  termsofsaleKeys = Object.keys(SalesTermConst);
  termsOfSaleOptions = [
    { name: 'Choose terms of sale', value: '' },
    { name: SalesTermConst.EXW, value: this.termsofsaleKeys[0] },
    { name: SalesTermConst.CPT, value: this.termsofsaleKeys[1] },
    { name: SalesTermConst.CIP, value: this.termsofsaleKeys[2] },
    { name: SalesTermConst.DAT, value: this.termsofsaleKeys[3] },
    { name: SalesTermConst.DAP, value: this.termsofsaleKeys[4] },
    { name: SalesTermConst.DOP, value: this.termsofsaleKeys[5] },
    { name: SalesTermConst.FCA, value: this.termsofsaleKeys[6] },
  ];
  constructor(private helper: UtilitiesService, private localStorageService: LocalStorageService,
    public sanitizer: DomSanitizer, private quoteService: QuoteAPI<any>,
    private geoGraphyService: GeaographyAPI<any>, private fb: FormBuilder, private modalService: NgbModal) {
    this.myFormOrg = fb.group({
    });
    this.myFormOrg.addControl("movementCtrl", new FormControl());
    this.myFormOrg.addControl("airportCtrl", new FormControl());
    this.myFormOrg.addControl("airportCtrlDes", new FormControl());
    this.FilteredshipmentServiceTypeArray = this.myFormOrg.get("movementCtrl").valueChanges
      .pipe(
        startWith(''),
        map(state => this.shipmentServiceTypeArray.slice(0, 0))
      );
    this.filteredairportdetails = this.myFormOrg.get("airportCtrl").valueChanges
      .pipe(
        startWith(''),
        map(state => this._filterAirportArray(state).slice(0, 0))
      );
    this.filteredairportdetailsDes = this.myFormOrg.get("airportCtrlDes").valueChanges
      .pipe(
        startWith(''),
        map(state => this._filterAirportArray(state).slice(0, 0)));
  }

  ngOnInit() {
    this.body.classList.remove('login-logo');
    this.clearModel();
    this.createShipmentServiceTypearray();
    this.setshipmentweightArray();
    //this.getAirportdetails(null);
    this.setlanedataArray(MovementTypeConst.DTD);
    this.getCommodityTypeList();
  }

  /*
 * @ngdoc function
 * @name clearModel
 * @methodOf QuoteLanesComponent
 * @description Method for clear model
 * @public
 */
  clearModel() {
    if (this.quoteModel.airFreightShipmentDetail.length == 1) {
      if (this.quoteModel.airFreightShipmentDetail[0].MovementTypeDescriptionText == "") {
        this.quoteModel.airFreightShipmentDetail = [];
      }
    }
  }
  /*
  * @ngdoc function
  * @name getAirportdetails
  * @methodOf QuoteLanesComponent
  * @description Method for getting origin and destination airport details from geography service
  * @public
  */
  getAirportdetails(businessPartyNumber: string, isTabswitch: boolean = false) {

    this.geoGraphyService.getAirportdetails(businessPartyNumber)
      .subscribe(
        data => {
          if (data != null && data['Airportdetails'] != null) {
            this.airportDetailsArray = data["Airportdetails"];
            this.localStorageService.setItem('Airportdetails', this.airportDetailsArray);
            this.setlanedataArray(MovementTypeConst.DTD);
          }
        },
        error => {

        });
  }

  getCommodityTypeList() {
    const self = this;
    this.quoteService.getCommodityTypeList().subscribe(
      resdata => {

        if (resdata['results'] != null && resdata['results'].length > 0) {
          self.commodityTypes = resdata['results'][0].commodityTypeList as any[];
        }
      }
    );
  }

  /*
  * @ngdoc function
  * @name createShipmentServiceTypearray
  * @methodOf QuoteLanesComponent
  * @description Method for initializing the shipment service type array
  * @public
  */
  createShipmentServiceTypearray() {
    this.movementArray = [{ shipmentservicetype: MovementTypeConst.ATA, shipmentservicetypeHighlight: MovementTypeConst.ATA, value: MovementTypeVal.ATA }, { shipmentservicetype: MovementTypeConst.DTA, shipmentservicetypeHighlight: MovementTypeConst.DTA, value: MovementTypeVal.DTA }, { shipmentservicetype: MovementTypeConst.ATD, shipmentservicetypeHighlight: MovementTypeConst.ATD, value: MovementTypeVal.ATD }, { shipmentservicetype: MovementTypeConst.DTD, shipmentservicetypeHighlight: MovementTypeConst.DTD, value: MovementTypeVal.DTD }];
    this.shipmentServiceTypeArray = this.movementArray;
    // this.FilteredshipmentServiceTypeArray=   this.movementCtrl.valueChanges
    //   .pipe(
    //   startWith(''),
    //   map(state =>   this.shipmentServiceTypeArray.slice(0, 6))
    //   );
  }

  /*
  * @ngdoc function
  * @name _filterAirportArray
  * @methodOf QuoteLanesComponent
  * @description Method for filtering the origin and destination auto populate data
  * @public
  */
  _filterAirportArray(value: string): airportDetails[] {
    const filterValue = value.toLowerCase();
    this.airportDetailsArrayHighlight = [];
    this.finalfilteredairportdetails = [];
    this.airportdetailsforadditionalformats = [];
    if (filterValue.length >= this.inputvaluelength) {
      this.intermediatefilteredairportdetails = this.airportDetailsArray;
      this.finalfilteredairportdetails = this.intermediatefilteredairportdetails.filter(state => state.isCustomerData === "0" && state.autopopulateformat.split(',')[0].toLowerCase().indexOf(filterValue) == 0).slice(0, 6);

      this.intermediatefilteredairportdetails = this.intermediatefilteredairportdetails.filter(f => !this.finalfilteredairportdetails.includes(f));
      if (this.finalfilteredairportdetails.length < 6) {
        this.finalfilteredairportdetails = this.finalfilteredairportdetails.concat(this.intermediatefilteredairportdetails.filter(state => state.isCustomerData === "0" && state.autopopulateformat.split(',')[0].split(" ")[1].toLowerCase().indexOf(filterValue) == 0));
        this.intermediatefilteredairportdetails = this.intermediatefilteredairportdetails.filter(f => !this.finalfilteredairportdetails.includes(f));
        if (this.finalfilteredairportdetails.length < 6) {
          this.finalfilteredairportdetails = this.finalfilteredairportdetails.concat(this.intermediatefilteredairportdetails.filter(state => state.isCustomerData === "0" && state.autopopulateformat.toLowerCase().indexOf(filterValue) > -1));
        }
      }
      if (((!this.grideditclicked && this.isOriginTextboxauotopopulatechangeneeded) || (!this.grideditclicked && this.isDestinationTextboxauotopopulatechangeneeded)
        || (this.grideditclicked && this.isgridOriginTextboxauotopopulatechangeneeded) || (this.grideditclicked && this.isgridDestinationTextboxauotopopulatechangeneeded))
        && this.finalfilteredairportdetails.length < 6) {

        for (var j = 0; j < this.finalfilteredairportdetails.length; j++) {
          this.airportdetailsforadditionalformats.push({
            autopopulateformat: this.finalfilteredairportdetails[j].autopopulateformat,
            autopopulateformat1: this.finalfilteredairportdetails[j].autopopulateformat1,
            autopopulateformat2: this.finalfilteredairportdetails[j].autopopulateformat1,
            airportCode: this.finalfilteredairportdetails[j].airportCode,
            airportName: this.finalfilteredairportdetails[j].airportName,
            countryCode: this.finalfilteredairportdetails[j].countryCode,
            countryName: this.finalfilteredairportdetails[j].countryName,
            politicalDivision2Name: this.finalfilteredairportdetails[j].politicalDivision2Name,
            postalCode: this.finalfilteredairportdetails[j].postalCode,
            isCustomerData: this.finalfilteredairportdetails[j].isCustomerData,
            autopopulateformathighlight: ""
          });
        }
        var existinglength = this.finalfilteredairportdetails.length;
        this.finalfilteredairportdetails = [];
        this.intermediatefilteredairportdetails = this.airportDetailsArray;
        this.finalfilteredairportdetails = this.intermediatefilteredairportdetails.filter(state => state.isCustomerData === "0" && state.autopopulateformat1.split(',')[0].toLowerCase().indexOf(filterValue) == 0).slice(0, (6 - existinglength));
        for (var j = 0; j < this.finalfilteredairportdetails.length; j++) {
          this.airportdetailsforadditionalformats.push({
            autopopulateformat: this.finalfilteredairportdetails[j].autopopulateformat1,
            autopopulateformat1: this.finalfilteredairportdetails[j].autopopulateformat1,
            autopopulateformat2: this.finalfilteredairportdetails[j].autopopulateformat1,
            airportCode: this.finalfilteredairportdetails[j].airportCode,
            airportName: this.finalfilteredairportdetails[j].airportName,
            countryCode: this.finalfilteredairportdetails[j].countryCode,
            countryName: this.finalfilteredairportdetails[j].countryName,
            politicalDivision2Name: this.finalfilteredairportdetails[j].politicalDivision2Name,
            postalCode: this.finalfilteredairportdetails[j].postalCode,
            isCustomerData: this.finalfilteredairportdetails[j].isCustomerData,
            autopopulateformathighlight: ""
          });
        }
        this.intermediatefilteredairportdetails = this.intermediatefilteredairportdetails.filter(f => !this.finalfilteredairportdetails.includes(f));
        this.finalfilteredairportdetails = [];
        if (this.airportdetailsforadditionalformats.length < 6) {
          this.finalfilteredairportdetails = this.intermediatefilteredairportdetails.filter(state => state.isCustomerData === "0" && state.autopopulateformat2.split(',')[0].toLowerCase().indexOf(filterValue) == 0).slice(0, 6);
          this.intermediatefilteredairportdetails = this.intermediatefilteredairportdetails.filter(f => !this.finalfilteredairportdetails.includes(f));
          for (var k = 0; k < this.finalfilteredairportdetails.length; k++) {
            this.airportdetailsforadditionalformats.push({
              autopopulateformat: this.finalfilteredairportdetails[k].autopopulateformat2,
              autopopulateformat1: this.finalfilteredairportdetails[k].autopopulateformat2,
              autopopulateformat2: this.finalfilteredairportdetails[k].autopopulateformat2,
              airportCode: this.finalfilteredairportdetails[k].airportCode,
              airportName: this.finalfilteredairportdetails[k].airportName,
              countryCode: this.finalfilteredairportdetails[k].countryCode,
              countryName: this.finalfilteredairportdetails[k].countryName,
              politicalDivision2Name: this.finalfilteredairportdetails[k].politicalDivision2Name,
              postalCode: this.finalfilteredairportdetails[k].postalCode,
              isCustomerData: this.finalfilteredairportdetails[k].isCustomerData,
              autopopulateformathighlight: ""
            });
          }
          this.finalfilteredairportdetails = [];
          if (this.airportdetailsforadditionalformats.length < 6) {
            this.finalfilteredairportdetails = this.intermediatefilteredairportdetails.filter(state => state.isCustomerData === "0" && state.autopopulateformat1.toLowerCase().indexOf(filterValue) > -1);
            this.intermediatefilteredairportdetails = this.intermediatefilteredairportdetails.filter(f => !this.finalfilteredairportdetails.includes(f));
            for (var m = 0; m < this.finalfilteredairportdetails.length; m++) {
              this.airportdetailsforadditionalformats.push({
                autopopulateformat: this.finalfilteredairportdetails[m].autopopulateformat1,
                autopopulateformat1: this.finalfilteredairportdetails[m].autopopulateformat1,
                autopopulateformat2: this.finalfilteredairportdetails[m].autopopulateformat1,
                airportCode: this.finalfilteredairportdetails[m].airportCode,
                airportName: this.finalfilteredairportdetails[m].airportName,
                countryCode: this.finalfilteredairportdetails[m].countryCode,
                countryName: this.finalfilteredairportdetails[m].countryName,
                politicalDivision2Name: this.finalfilteredairportdetails[m].politicalDivision2Name,
                postalCode: this.finalfilteredairportdetails[m].postalCode,
                isCustomerData: this.finalfilteredairportdetails[m].isCustomerData,
                autopopulateformathighlight: ""
              });
            }
            this.finalfilteredairportdetails = [];
            if (this.airportdetailsforadditionalformats.length < 6) {
              this.finalfilteredairportdetails = this.intermediatefilteredairportdetails.filter(state => state.isCustomerData === "0" && state.autopopulateformat2.toLowerCase().indexOf(filterValue) > -1);
              this.intermediatefilteredairportdetails = this.intermediatefilteredairportdetails.filter(f => !this.finalfilteredairportdetails.includes(f));
              for (var n = 0; n < this.finalfilteredairportdetails.length; n++) {
                this.airportdetailsforadditionalformats.push({
                  autopopulateformat: this.finalfilteredairportdetails[n].autopopulateformat2,
                  autopopulateformat1: this.finalfilteredairportdetails[n].autopopulateformat2,
                  autopopulateformat2: this.finalfilteredairportdetails[n].autopopulateformat2,
                  airportCode: this.finalfilteredairportdetails[n].airportCode,
                  airportName: this.finalfilteredairportdetails[n].airportName,
                  countryCode: this.finalfilteredairportdetails[n].countryCode,
                  countryName: this.finalfilteredairportdetails[n].countryName,
                  politicalDivision2Name: this.finalfilteredairportdetails[n].politicalDivision2Name,
                  postalCode: this.finalfilteredairportdetails[n].postalCode,
                  isCustomerData: this.finalfilteredairportdetails[n].isCustomerData,
                  autopopulateformathighlight: ""
                });
              }
            }
          }
        }
        this.finalfilteredairportdetails = [];
        this.finalfilteredairportdetails = this.airportdetailsforadditionalformats;
      }
    }
    return this.finalfilteredairportdetails;
  }

  /*
   * @ngdoc function
   * @name modelOnChangeAirportArrayFilter
   * @methodOf QuoteLanesComponent
   * @description Method for filtering the airport details array onchange
   * @public
   */
  modelOnChangeAirportArrayFilter(val: string) {
    this.isDestinationTextboxauotopopulatechangeneeded = false;
    this.isOriginTextboxauotopopulatechangeneeded = false;
    if (this.displayOriginnpopup)
      this.isOriginTextboxauotopopulatechangeneeded = true;
    if (this.displayDestinationpopup)
      this.isDestinationTextboxauotopopulatechangeneeded = true;

    if (val) {
      this.filteredairportdetails = this.filteredairportdetails
        .pipe(
          startWith(''),
          map(state => this._filterAirportArray(val).slice(0, 6))
        );
    }


    return this.filteredairportdetails;
  }

  /*
   * @ngdoc function
   * @name modelOnChangefilterShipmentServiceArray
   * @methodOf QuoteLanesComponent
   * @description Method for filtering the shipment details array
   * @public
   */
  modelOnChangefilterShipmentServiceArray(val: string) {
    if (val == "" || val == null) {
      this.enablesavebutton = false;
    }
    else {
      this.FilteredshipmentServiceTypeArray = this.FilteredshipmentServiceTypeArray
        .pipe(
          startWith(''),
          map(state => this._filterShipmentServiceArray(val).slice(0, 6))
        );
    }
    return this.FilteredshipmentServiceTypeArray;
  }

  /*
  * @ngdoc textbox focus function
  * @name movementfocusFunction
  * @methodOf QuoteLanesComponent
  * @description  Method for setting the location autopoulate data on the focus of the origin and destination textboxes
  * @public
  */
  movementfocusFunction(val) {
    this.displayOriginnpopup = false;
    this.displayDestinationpopup = false;
    this.displayShipmentdetails = 0;
    this.FilteredshipmentServiceTypeArray = this.myFormOrg.get("movementCtrl").valueChanges
      .pipe(
        startWith(''),
        map(state => this.shipmentServiceTypeArray.slice(0, 0))
      );

  }
  /*
 * @ngdoc textbox focus function
 * @name movementchangevalidation
 * @methodOf QuoteLanesComponent
 * @description  Method for validating the selected movement type
 * @public
 */
  movementchangevalidation(val, rowno) {
    var shipmentservicetype = this.shipmentServiceTypeArray.filter(x => x.shipmentservicetype == val);
    if (shipmentservicetype.length == 0) {
      this.lanedataArray.find(item => item.rowno == rowno).movementType = this.movementTypeDefault;
    }
  }
  /*
  * @ngdoc textbox focus function
  * @name gridmovementchangevalidation
  * @methodOf QuoteLanesComponent
  * @description  Method for validating the selected movement type in grid
  * @public
  */
  gridmovementchangevalidation(val, rowno) {
    var shipmentservicetype = this.shipmentServiceTypeArray.filter(x => x.shipmentservicetype == val);
    if (shipmentservicetype.length == 0) {
      this.objgridmovementtype = this.movementTypeDefault;
    }
  }
  /*
 * @ngdoc textbox focus function
 * @name gridmovementfocusFunction
 * @methodOf QuoteLanesComponent
 * @description  Method for setting the location autopoulate data on the focus of the origin and destination textboxes in grid
 * @public
 */
  gridmovementfocusFunction(val) {
    this.griddisplayOriginnpopup = false;
    this.griddisplayDestinationpopup = false;
    this.griddisplayShipmentdetails = 0;
    this.FilteredshipmentServiceTypeArray = this.myFormOrg.get("movementCtrl").valueChanges
      .pipe(
        startWith(''),
        map(state => this.shipmentServiceTypeArray.slice(0, 0))
      );

  }
  /*
  * @ngdoc textbox focus function
  * @name airportfocusFunction
  * @methodOf QuoteLanesComponent
  * @description  Method for setting the shipment service type autopoulate data on the focus of the shipment service type textboxes
  * @public
  */
  airportfocusFunction() {
    // this.isFocused=false;
    // this.isDestinationTextboxauotopopulatechangeneeded = false;
    // if (movementType == this.constD2D || movementType == this.constD2A)
    //   this.isOriginTextboxauotopopulatechangeneeded = true;
    // else
    //   this.isOriginTextboxauotopopulatechangeneeded = false;
    this.filteredairportdetails = this.myFormOrg.get("airportCtrl").valueChanges
      .pipe(
        startWith(''),
        map(state => this.airportDetailsArray.filter(x => x.isCustomerData == "0").slice(0, 0))
      );

  }

  /*
   * @ngdoc textbox focus function
   * @name airportfocusFunction
   * @methodOf QuoteLanesComponent
   * @description  Method for setting the shipment service type autopoulate data on the focus of the shipment service type textboxes
   * @public
   */
  airportfocusFunctionDes(val, name, movementType) {
    // this.isOriginTextboxauotopopulatechangeneeded = false;
    // if (movementType == this.constD2D || movementType == this.constA2D)
    //   this.isDestinationTextboxauotopopulatechangeneeded = true;
    // else
    //   this.isDestinationTextboxauotopopulatechangeneeded = false;
    this.filteredairportdetailsDes = this.myFormOrg.get("airportCtrlDes").valueChanges
      .pipe(
        startWith(''),
        map(state => state ? this._filterAirportArray(state).slice(0, 6) : this.airportDetailsArray.filter(x => x.isCustomerData == "1").slice(0, 6))
      );
  }
  /*
  * @ngdoc function
  * @name _filterShipmentServiceArray
  * @methodOf QuoteLanesComponent
  * @description  Method is for filtering the shipment service type autopopulate data
  * @public
  */
  _filterShipmentServiceArray(value: string): shipmentServiceType[] {
    const filterValue = value.toLowerCase();
    this.movementArrayFilter = [];
    this.finalfilteredshipmentServiceType = [];
    this.intermediatefilteredshipmentServiceType = this.shipmentServiceTypeArray.filter(state => state.shipmentservicetype.toLowerCase().indexOf(filterValue) > -1);
    /*This code can use whenever we need to highlight text without using pipes */
    // for (var i = 0; i < this.intermediatefilteredshipmentServiceType.length; i++)
    // {

    //   var data = this.intermediatefilteredshipmentServiceType[i].shipmentservicetype;
    //   var highlightedvalue = this.transform(data,filterValue).toString();
    //   this.movementArrayFilter.push({
    //     shipmentservicetype: data,
    //     shipmentservicetypeHighlight:highlightedvalue
    // });
    // }
    // this.finalfilteredshipmentServiceType=this.movementArrayFilter;
    this.finalfilteredshipmentServiceType = this.intermediatefilteredshipmentServiceType;
    return this.finalfilteredshipmentServiceType;
  }
  /*
  * @ngdoc function
  * @name transform
  * @methodOf QuoteLanesComponent
  * @description  Method  for highlighting the search text in autopopulate textboxes
  * @public
  */
  transform(text: string, search): string {
    var pattern = search.replace(/[\-\[\]\/\{\}\(\)\*\+\?\.\\\^\$\|]/g, "\\$&");
    pattern = pattern.split(' ').filter((t) => {
      return t.length > 0;
    }).join('|');
    var regex = new RegExp(pattern, 'gi');

    return search ? text.replace(regex, (match) => `<span class="highlight">${match}</span>`) : text;
  }
  /*
 * @ngdoc function
 * @name setshipmentweightArray
 * @methodOf QuoteLanesComponent
 * @description  Method  for initializing shipment weight array
 * @public
 */
  setshipmentweightArray() {
    this.objshipmentweightArray = [{ type: 'Weight per Shipment', value: '1' }, { type: 'Weight Over Time', value: '2' }, { type: 'Typical Cargo Information', value: '3' }];
  }
  /*
  * @ngdoc textbox focus function
  * @name shipmentDetailsFocusFunction
  * @methodOf QuoteLanesComponent
  * @description  Method  for display shipment details
  * @public
  */
  shipmentDetailsFocusFunction(rowno) {
    this.displayShipmentdetails = rowno;
    this.displayDestinationpopup = false;
    this.displayOriginnpopup = false;
    this.grideditrowno = 0;
    var index = this.lanedataArray.length;
    var diff = (index - rowno);
    // if (diff > 0) {
    //   var margintop = diff >= 1 ? -(60 * diff)  : -(60);
    //   this.childcomponentmargintop = margintop.toString();
    // }
    // else
    // {
    //   this.childcomponentmargintop="-60";
    // }
  }

  /*
* @ngdoc textbox focus function
* @name shipmentDetailsFocusFunction
* @methodOf QuoteLanesComponent
* @description  Method  for display shipment details
* @public
*/
  gridshipmentDetailsFocusFunction(rowno) {
    this.griddisplayShipmentdetails = rowno;
    this.griddisplayDestinationpopup = false;
    this.griddisplayOriginnpopup = false;

    // var index = this.lanedataArray.length;
    // var diff = (index - rowno);
    // if (diff > 0) {
    //   var margintop = diff >= 1 ? -(60 * diff)  : -(60);
    //   this.childcomponentmargintop = margintop.toString();
    // }
    // else
    // {
    //   this.childcomponentmargintop="-60";
    // }
  }


  /*
 * @ngdoc  destination textbox focus  function
 * @name destinationtextboxFocusFunction
 * @methodOf QuoteLanesComponent
 * @description  Method  for showing destination text box popup
 * @public
 */
  destinationtextboxFocusFunction(rowno, streetaddress, city, movementType) {
    this.displayDestinationpopup = true;
    this.displayOriginnpopup = false;
    this.displayShipmentdetails = 0;
    this.grideditclicked = false;
    this.currentrowno = rowno;
    this.grideditrowno = 0;
    this.griddisplayOriginnpopup = false;
    this.griddisplayDestinationpopup = false;
    //this.inputvaluelength=2;
    this.isOriginTextboxauotopopulatechangeneeded = false;
    this.objdestinationCity = city;
    this.objdestinationStreetAddress = streetaddress;
    if (movementType == MovementTypeConst.DTD || movementType == MovementTypeConst.ATD)
      this.isDestinationTextboxauotopopulatechangeneeded = true;
    else
      this.isDestinationTextboxauotopopulatechangeneeded = false;

    /*Set margin dynamically */
    var index = this.lanedataArray.length;
    var currentindex = this.lanedataArray.indexOf(this.lanedataArray.find(x => x.rowno == rowno)) + 1;
    var diff = (index - currentindex);
    if (diff > 0) {
      var margintop = diff >= 1 ? -(70 * diff) + - 94 : -(60);
      this.quotemarginDynamicvalue = margintop.toString();
    }
    else {
      this.quotemarginDynamicvalue = "-94";
    }
    this.setFocus();
  }
  /*
* @ngdoc  destination textbox focus  function
* @name griddestinationtextboxFocusFunction
* @methodOf QuoteLanesComponent
* @description  Method  for showing destination text box popup in grid
* @public
*/
  griddestinationtextboxFocusFunction(rowno, streetaddress, city, movementType) {
    this.griddisplayDestinationpopup = true;
    this.griddisplayOriginnpopup = false;
    this.griddisplayShipmentdetails = 0;
    this.grideditclicked = true;
    this.gridcurrentrowno = rowno;
    //this.inputvaluelength=2;
    this.isgridOriginTextboxauotopopulatechangeneeded = false;
    this.objpopgriddescity = city;
    this.objpopgriddestinationStreetAddress = streetaddress;
    if (movementType == MovementTypeConst.DTD || movementType == MovementTypeConst.ATD)
      this.isgridDestinationTextboxauotopopulatechangeneeded = true;
    else
      this.isgridDestinationTextboxauotopopulatechangeneeded = false;

    /*Set margin dynamically */
    // var index = this.lanedataArray.length;
    // var modalindex=this.quoteModel.airFreightShipmentDetail.indexOf(this.quoteModel.airFreightShipmentDetail.find(x=>x.id==rowno))+1;
    // var total = index+modalindex;
    // if (total > 0) {
    //   var margintop = -(total * 40) + - 20+-150 ;
    //   this.gridquotemarginDynamicvalue = margintop.toString();
    // }
    // else {
    //   this.gridquotemarginDynamicvalue = "-150";
    // }
    this.setFocus();
  }
  /*
* @ngdoc  origin textbox focus  function
* @name origintextboxFocusFunction
* @methodOf QuoteLanesComponent
* @description  Method  for showing origin text box popup
* @public
*/
  origintextboxFocusFunction(rowno, streetaddress, city, movementType) {
    this.displayOriginnpopup = true;
    this.displayDestinationpopup = false;
    this.displayShipmentdetails = 0;
    this.grideditclicked = false;
    //this.inputvaluelength=2;
    this.currentrowno = rowno;
    this.grideditrowno = 0;
    this.griddisplayOriginnpopup = false;
    this.griddisplayDestinationpopup = false;
    this.objorginCity = city;
    this.objorginStreetAddress = streetaddress;
    this.isDestinationTextboxauotopopulatechangeneeded = false;
    if (movementType == MovementTypeConst.DTD || movementType == MovementTypeConst.DTA)
      this.isOriginTextboxauotopopulatechangeneeded = true;
    else
      this.isOriginTextboxauotopopulatechangeneeded = false;

    /*Set margin dynamically */
    var index = this.lanedataArray.length;
    var currentindex = this.lanedataArray.indexOf(this.lanedataArray.find(x => x.rowno == rowno)) + 1;
    var diff = (index - currentindex);
    if (diff > 0) {
      var margintop = diff >= 1 ? -(70 * diff) + - 94 : -(60);
      this.quotemarginDynamicvalue = margintop.toString();
    }
    else {
      this.quotemarginDynamicvalue = "-94";
    }
    this.setFocus();
  }
  /*
  * @ngdoc  grid origin textbox focus  function
  * @name gridorigintextboxFocusFunction
  * @methodOf QuoteLanesComponent
  * @description  Method  for showing origin text box popup on lane grid edit
  * @public
  */
  gridorigintextboxFocusFunction(rowno, streetaddress, city, movementType, event, loopindex) {
    this.griddisplayOriginnpopup = true;
    this.griddisplayDestinationpopup = false;
    this.griddisplayShipmentdetails = 0;
    this.grideditclicked = true;
    //this.inputvaluelength=2;
    this.gridcurrentrowno = rowno;
    this.objpopgridorigincity = city;
    this.objpopgridorginStreetAddress = streetaddress;
    this.isgridDestinationTextboxauotopopulatechangeneeded = false;
    if (movementType == MovementTypeConst.DTD || movementType == MovementTypeConst.DTA)
      this.isgridOriginTextboxauotopopulatechangeneeded = true;
    else
      this.isgridOriginTextboxauotopopulatechangeneeded = false;

    /*Set margin dynamically */
    // var index = this.lanedataArray.length>1?this.lanedataArray.length-1:0;
    // var currentindex=this.quoteModel.airFreightShipmentDetail.indexOf(this.quoteModel.airFreightShipmentDetail.find(x=>x.id==rowno))+1;
    // var modalindex=this.quoteModel.airFreightShipmentDetail.length - currentindex;
    // var total =modalindex;
    // var margintop=0;
    // if (index > 0) {
    //    margintop = -(80 * index) ;
    // }
    // if (total > 0) {
    //   var addedvalue=total>currentindex?currentindex*5:total;
    //   margintop =margintop+ -((total) *40 -(total*6) )  +-150;
    //   if(modalindex>15&&margintop<-640)
    //     margintop=-(640-(loopindex*40));
    //   this.gridquotemarginDynamicvalue = "-50%";
    // }
    // else {
    //   this.gridquotemarginDynamicvalue = (margintop+-150).toString();
    // }
    // let offsetLeft = 0;
    // let offsetTop = 0;

    // let el = event.srcElement;

    // while(el){
    //     offsetLeft += el.offsetLeft;
    //     offsetTop += el.offsetTop;
    //     el = el.parentElement;
    // }
    // //this.gridquotemarginDynamicvalue=event.srcElement.parentElement.attributes['top'].value;
    // this.gridquotemarginDynamicvalue = (-(offsetTop-(500))).toString();
    this.setFocus();
  }
  /*
  * @ngdoc textbox focus out function
  * @name shipmentDetailsfocusOutFunction
  * @methodOf QuoteLanesComponent
  * @description  Method  for hide shipment details
  * @public
  */
  shipmentDetailsfocusOutFunction() {
    this.displayShipmentdetails = 0;
  }


  /*
 * @ngdoc  function
 * @name setlanedataArray
 * @methodOf QuoteLanesComponent
 * @description  Method  for set default value for lane data array.
 * @public
 */
  setlanedataArray(movementType) {
    this.enablesavebutton = true;
    if (this.localStorageService.getItem('Airportdetails') != null) {
      this.airportDetailsArray = this.localStorageService.getItem('Airportdetails');
    }
    else {
      this.getAirportdetails(null);
    }
    this.customesBrokerage = this.quoteModel.quoteRequestData.customesBrokerage;
    this.defaulttermsOfSale = this.quoteModel.quoteRequestData.termsOfSale;
    if (this.quoteModel.quoteRequestData.quoteTypeCode == 2) {
      this.isLongtermquote = true;
      this.quotevalidityperiod = this.quoteModel.quoteRequestData.quoteValidityPeriod;
      this.modelValidityStartDate = this.quoteModel.quoteRequestData.quoteValidityStartDate;
      this.modelValidityEndDate = this.quoteModel.quoteRequestData.quoteValidityEndDate;
    }
    else
      this.isLongtermquote = false;

    switch (this.quoteModel.quoteRequestData.termsOfSale) {
      case this.termsofsaleKeys[0]: this.movementTypeDefault = MovementTypeConst.DTD;
        this.displayoriginmaterialauto = false;
        this.displaydesmaterialauto = false;
        break;
      case this.termsofsaleKeys[1]: this.movementTypeDefault = MovementTypeConst.DTD;
        this.displayoriginmaterialauto = false;
        this.displaydesmaterialauto = false;
        break;
      case this.termsofsaleKeys[2]: this.movementTypeDefault = MovementTypeConst.DTA;
        this.displayoriginmaterialauto = false;
        this.displaydesmaterialauto = true;
        break;
      case this.termsofsaleKeys[3]: this.movementTypeDefault = MovementTypeConst.DTA;
        this.displayoriginmaterialauto = false;
        this.displaydesmaterialauto = true;
        break;
      case this.termsofsaleKeys[4]: this.movementTypeDefault = MovementTypeConst.DTA;
        this.displayoriginmaterialauto = false;
        this.displaydesmaterialauto = true;
        break;
      case this.termsofsaleKeys[5]: this.movementTypeDefault = MovementTypeConst.DTD;
        this.displayoriginmaterialauto = false;
        this.displaydesmaterialauto = false;
        break;
      case this.termsofsaleKeys[6]: this.movementTypeDefault = MovementTypeConst.DTD;
        this.displayoriginmaterialauto = false;
        this.displaydesmaterialauto = false;
        break;
      default: this.movementTypeDefault = MovementTypeConst.DTD;
        break;
    }
    this.servicetypedirect = this.quoteModel.quoteRequestData.serviceTypes.directCASelected;
    this.servicetypeconsolidated = this.quoteModel.quoteRequestData.serviceTypes.consolidatedECSelected;
    this.servicetypepremium = this.quoteModel.quoteRequestData.serviceTypes.premiumDirectCXSelected;
    this.servicetypetemp = this.quoteModel.quoteRequestData.serviceTypes.tempTrueSelected;
    if (!this.servicetypedirect && !this.servicetypeconsolidated && !this.servicetypepremium && !this.servicetypetemp) {
      this.servicetypedirect = true;
      this.servicetypeconsolidated = true;
    }
    var laneGridslidedata = { directCASelected: this.servicetypedirect, consolidatedECSelected: this.servicetypeconsolidated, premiumDirectCXSelected: this.servicetypepremium, tempTrueSelected: this.servicetypetemp };
    //laneGridslidedata.push({directCASelected:this.servicetypedirect,consolidatedECSelected: this.servicetypeconsolidated,premiumDirectCXSelected:this.servicetypepremium,tempTrueSelected: this.servicetypetemp});
    var index = this.quoteModel.airFreightShipmentDetail.length + 1;
    var timestamp = Math.floor(Date.now() / 1000).toString() + index.toString();
    this.lanedataArray.push({ rowno: timestamp, isdeleted: false, movementType: this.movementTypeDefault, originCityActual: "", desCityActual: "", streetaddressActual: "", streetaddressDesActual: "", displayoriginmaterialauto: this.displayoriginmaterialauto, displaydesmaterialauto: this.displaydesmaterialauto, shipmentdetails: {}, laneGridslidedata: laneGridslidedata });

  }
  /*
  * @ngdoc  function
  * @name addlanedataArray
  * @methodOf QuoteLanesComponent
  * @description  Method  for add values in lane data array.
  * @public
  */
  addlanedataArray() {
    var index = this.quoteModel.airFreightShipmentDetail.length + this.lanedataArray.length + 1;
    var timestamp = Math.floor(Date.now() / 1000).toString() + index.toString();
    var laneGridslidedata = { directCASelected: this.servicetypedirect, consolidatedECSelected: this.servicetypeconsolidated, premiumDirectCXSelected: this.servicetypepremium, tempTrueSelected: this.servicetypetemp };
    //laneGridslidedata.push({directCASelected:this.servicetypedirect,consolidatedECSelected: this.servicetypeconsolidated,premiumDirectCXSelected:this.servicetypepremium,tempTrueSelected: this.servicetypetemp});
    this.lanedataArray.push({ rowno: timestamp, isdeleted: false, movementType: this.movementTypeDefault, originCityActual: "", desCityActual: "", streetaddressActual: "", streetaddressDesActual: "", displayoriginmaterialauto: this.displayoriginmaterialauto, displaydesmaterialauto: this.displaydesmaterialauto, shipmentdetails: {}, laneGridslidedata: laneGridslidedata });
  }
  /*
  * @ngdoc  function
  * @name removelanedataArray
  * @methodOf QuoteLanesComponent
  * @description  Method  for remove row from lane data array.
  * @public
  */
  removelanedataArray(rowno) {
    this.lanedataArray.splice(this.lanedataArray.indexOf(rowno), 1);
  }
  /*
  * @ngdoc  function
  * @name deletelaneDatafromService
  * @methodOf QuoteLanesComponent
  * @description  Method  for delete lane data from data base.
  * @public
  */
  deletelaneDatafromdb() {
    this.selectedlanecount = 0;
    this.quoteModel.airFreightShipmentDetail = this.quoteModel.airFreightShipmentDetail.filter(item => !item.shipmentLaneActiveIndicator);
    if (this.quoteModel.airFreightShipmentDetail.length > 0 && (this.quoteModel.airFreightShipmentDetail.filter(item => item.shipmentLaneActiveIndicator).length == this.quoteModel.airFreightShipmentDetail.length)) {
      this.chkSelectallvalue = true;
    }
    else {
      this.chkSelectallvalue = false;
    }
    //this.setModelValues();
  }
  /*
 * @ngdoc  function
 * @name duplicatelaneData
 * @methodOf QuoteLanesComponent
 * @description  Method  for duplicate lane data in grid.
 * @public
 */
  duplicatelaneData() {
    var duplicatedata = this.quoteModel.airFreightShipmentDetail.filter(item => item.shipmentLaneActiveIndicator);
    this.duplicateModelValues(duplicatedata);
  }
  /*
  * @ngdoc  function
  * @name duplicateindividuallane
  * @methodOf QuoteLanesComponent
  * @description  Method  for duplicate individual lane data.
  * @public
  */
  duplicateindividuallane(rowno) {
    var duplicatedata = this.quoteModel.airFreightShipmentDetail.filter(item => item.id == rowno);
    this.duplicateModelValues(duplicatedata);
    //this.setModelValues();
  }
  /*
  * @ngdoc  function
  * @name deletelaneDatafromService
  * @methodOf QuoteLanesComponent
  * @description  Method  for delete lane data from data base.
  * @public
  */
  deleteindividuallane(rowno) {
    if (this.selectedlanecount > 0)
      this.selectedlanecount--;
    this.quoteModel.airFreightShipmentDetail = this.quoteModel.airFreightShipmentDetail.filter(item => item.id != rowno);
    if (this.quoteModel.airFreightShipmentDetail.length > 0 && (this.quoteModel.airFreightShipmentDetail.filter(item => item.shipmentLaneActiveIndicator).length == this.quoteModel.airFreightShipmentDetail.length)) {
      this.chkSelectallvalue = true;
    }
    else {
      this.chkSelectallvalue = false;
    }
    //this.setModelValues();
  }

  /*
* @ngdoc  function
* @name checkboxchangeCount
* @methodOf QuoteLanesComponent
* @description  Method  to find the selected lanes count.
* @public
*/
  checkboxchangeCount(e) {
    // this.selectedlanecount=0 ;
    if (e.target.checked) {
      this.selectedlanecount++;
    }
    else if (this.selectedlanecount != 0) {
      this.selectedlanecount--;
    }
    if (this.selectedlanecount === 0) {
      this.chkSelectallvalue = false;
    }
    if (this.quoteModel.airFreightShipmentDetail.length > 0 && (this.quoteModel.airFreightShipmentDetail.filter(item => item.shipmentLaneActiveIndicator).length == this.quoteModel.airFreightShipmentDetail.length)) {
      this.chkSelectallvalue = true;
    }
    else {
      this.chkSelectallvalue = false;
    }
  }
  /*
  * @ngdoc  function
  * @name checkallcheckbox
  * @methodOf QuoteLanesComponent
  * @description  Method  to to select or unselect all checkbox in the grid.
  * @public
  */
  checkallcheckbox(e) {
    this.selectedlanecount = 0;
    this.chkSelectallvalue = e.target.checked;
    for (let object of this.quoteModel.airFreightShipmentDetail) {
      object.shipmentLaneActiveIndicator = e.target.checked;
    }
    if (e.target.checked) {
      this.selectedlanecount = this.quoteModel.airFreightShipmentDetail.length;
    }
    else {
      this.selectedlanecount = 0;
    }
  }
  /*
  * @ngdoc  function
  * @name savelanedataArray
  * @methodOf QuoteLanesComponent
  * @description  Method  for save lane data array.
  * @public
  */
  savelanedataArray() {
    var index = this.quoteModel.airFreightShipmentDetail.length;
    for (let data of this.lanedataArray) {
      index++;
      var timestamp = Math.floor(Date.now() / 1000).toString() + index.toString();
      this.laneDataGrid.push(
        { rowno: timestamp,
          status: data.isdeleted,
          movementType: data.movementType,
          originCityActual: data.originCityActual,
          desCityActual: data.desCityActual,
          streetaddressActual: data.streetaddressActual,
          streetaddressDesActual: data.streetaddressDesActual,
          shipmentdetails: data.shipmentdetails,
          laneGridslidedata:
          data.laneGridslidedata,
          shipmentCommodity:[]
        });
    }
    this.quotevalidityperiod=this.quoteModel.quoteRequestData.quoteValidityPeriod;
    if(this.modelValidityStartDate!=null&&this.modelValidityEndDate!=null&& this.isLongtermquote) {
      this.validityStartPeriod = {
        year: this.modelValidityStartDate.getFullYear(),
        month: this.modelValidityStartDate.getMonth() + 1,
        day: this.modelValidityStartDate.getDate()
      };
      this.validityEndPeriod = {
        year: this.modelValidityEndDate.getFullYear(),
        month: this.modelValidityEndDate.getMonth() + 1,
        day: this.modelValidityEndDate.getDate()
      };
    }
    this.setModelValues();
    this.lanedataArray = [];
    this.laneDataGrid = [];
    // this.setlanedataArray(MovementTypeConst.DTD);
  }

  /*
 * @ngdoc  function
 * @name setModelValues
 * @methodOf QuoteLanesComponent
 * @description  Method  for save lane data to the service model.
 * @public
 */
  setModelValues() {


    //this.quoteModel.airFreightShipmentDetail = [];
    for (let data of this.laneDataGrid) {
      // var index=1;
      // if(this.quoteModel.airFreightShipmentDetail.length>0)
      // {
      //   index =Math.max.apply(Math, this.quoteModel.airFreightShipmentDetail.map(function(o) { return Number(o.id); }))+1;
      // }

      var selectedmovementType = 0;
      var originLocationCountryCode = "";
      var originLocationPostalCode = "";
      var originAirportName = "";
      var originPoliticalDivision1Name = "";
      var desLocationCountryCode = "";
      var desLocationPostalCode = "";
      var desAirportName = "";
      var desPoliticalDivision1Name = "";
      var selectedmovementtypejson = this.shipmentServiceTypeArray.filter(item => item.shipmentservicetype == data.movementType);
      if (selectedmovementtypejson.length > 0)
        selectedmovementType = selectedmovementtypejson[0].value;
      var selectedoriginairport = this.airportDetailsArray.filter(item => item.autopopulateformat == data.originCityActual);
      if (selectedoriginairport.length == 0) {
        selectedoriginairport = this.airportDetailsArray.filter(item => item.autopopulateformat1 == data.originCityActual);
      }
      if (selectedoriginairport.length == 0) {
        selectedoriginairport = this.airportDetailsArray.filter(item => item.autopopulateformat2 == data.originCityActual);
      }
      if (selectedoriginairport.length > 0) {
        originLocationCountryCode = selectedoriginairport[0].countryCode;
        originLocationPostalCode = selectedoriginairport[0].postalCode;
        originAirportName = selectedoriginairport[0].airportName;
        originPoliticalDivision1Name = selectedoriginairport[0].politicalDivision2Name;
      }
      var selecteddestinationairport = this.airportDetailsArray.filter(item => item.autopopulateformat == data.desCityActual);
      if (selecteddestinationairport.length == 0) {
        selecteddestinationairport = this.airportDetailsArray.filter(item => item.autopopulateformat1 == data.desCityActual);
      }
      if (selecteddestinationairport.length == 0) {
        selecteddestinationairport = this.airportDetailsArray.filter(item => item.autopopulateformat2 == data.desCityActual);
      }
      if (selecteddestinationairport.length > 0) {
        desLocationCountryCode = selecteddestinationairport[0].countryCode;
        desLocationPostalCode = selecteddestinationairport[0].postalCode;
        desAirportName = selecteddestinationairport[0].airportName;
        desPoliticalDivision1Name = selecteddestinationairport[0].politicalDivision2Name;
      }
      this.quoteModel.airFreightShipmentDetail.push({
        id: data.rowno, docId: "",
        shipmentDetailIdentificationNumber: "", quoteIdentificationNumber: "",
        destinationAirport: "", originAirport: "",
        originLocationCountryCode: originLocationCountryCode, originLocationPoliticalDivsion2Code: "",
        originLocationPostalCode: originLocationPostalCode,
        destinationLocationCountryCode: desLocationCountryCode,
        destinationLocationPoliticalDivsion2Code: "", destinationLocationPostalCode: "",
        movementTypeCode: selectedmovementType, paymentTermTypeCode: "",
        shipmentUnitOfMeasureTypeCode: 0,
        shipmentPalletQuantity: "",
        shipmentLooseUnitQUantity: '',
        commodityTypeCode: "", commodityTypeDescriptionText: "", commodityNameList: [],
        hazardousMaterialsIndicator: 0,
        hazardousMaterialName: '',
        hazardousMaterialUnitedNationsNumber: '',
        hazardousMaterialUnitedNationsClassificationCode: '',
        hazardousMaterialPackagingGroupText: '',
        shipmentOversizeIndicator: false,
        originAddressLine1Text: data.streetaddressActual, originAddressLine2Text: "",
        originAddressLine3Text: "", originPoliticalDivision1Name: originPoliticalDivision1Name,
        destinationAddressLine1Text: data.streetaddressDesActual, destinationAddressLine2Text: "",
        destinationAddressLine3Text: "", destinationPoliticalDivision1Name: desPoliticalDivision1Name,
        shipmentInsuredValueAmount: "", shipmentValueIndicator: false,
        shipmentCurrencyCode: "", shipmentValue: "",
        temperatureControlShipmentIndicator: 0, perishableShipmentIndicator: 0,
        shipmentPalletPercent: "",
        shipmentLooseUnitPercent: "",
        shipmentOriginAddressProfileSaveIndicator: false,
        shipmentDestinationAddressProfileSaveIndicator: false,
        shipmentWeightTypeCode: 0,
        totalWeight: "",
        shipmentWeightByPeice: data.shipmentdetails.shipmentWeightByPeice,
        isCustomerBroker: 0,
        shipmentInsuranceIndicator: null,
        shipmentReadyDate: null,
        shipmentSpeedType: null,
        originAirportName: originAirportName,
        destinationAirportName: desAirportName,
        shipmentMethod: data.shipmentdetails.shipmentMethod,
        shipmentFrequencyTimePeriodDescriptionText: data.shipmentdetails.shipmentFrequencyTimePeriodDescriptionText,
        shipmentFrequency: data.shipmentdetails.shipmentFrequency,
        shipmentActualWeight: '',
        shipmentDimensionalWeight: '',
        shipmentActualWeightUnitOfMeasureTypeCode: data.shipmentdetails.shipmentActualWeightUnitOfMeasureTypeCode,
        shipmentDimensionalWeightUnitOfMeasureTypeCode: data.shipmentdetails.shipmentDimensionalWeightUnitOfMeasureTypeCode,
        shipmentActualWeightQuantity: data.shipmentdetails.shipmentActualWeightQuantity,
        shipmentDimensionalWeightQuantity: data.shipmentdetails.shipmentDimensionalWeightQuantity,
        serviceTypes: data.laneGridslidedata,
        termsOfSale: this.defaulttermsOfSale,
        TOSModified: data.shipmentdetails.TOSModified,
        quoteValidityPeriod: this.quotevalidityperiod,
        quoteValidityStartDate: this.modelValidityStartDate,
        quoteValidityEndDate: this.modelValidityEndDate,
        quoteValidityModified: data.shipmentdetails.quoteValidityModified,
        quoteNotes: '',
        shipmentLaneActiveIndicator: this.chkSelectallvalue,
        MovementTypeDescriptionText: data.movementType,
        originAutopopulationFormat: data.originCityActual,
        destinationAutopopulationFormat: data.desCityActual,
        customesBrokerage: this.customesBrokerage,
        quoteBrokeragdeModified: data.shipmentdetails.quoteBrokeragdeModified,
        
        shipmentCommodity: data.shipmentCommodity
      });
    }

  }
  duplicateModelValues(duplicatearray) {
    var index = this.quoteModel.airFreightShipmentDetail.length;
    //this.quoteModel.airFreightShipmentDetail = [];
    for (let data of duplicatearray) {
      if (this.chkSelectallvalue) {
        this.selectedlanecount++;
      }
      index++;
      var timestamp = Math.floor(Date.now() / 1000).toString() + index.toString();
      // if(this.quoteModel.airFreightShipmentDetail.length>0)
      // {
      //   index =Math.max.apply(Math, this.quoteModel.airFreightShipmentDetail.map(function(o) { return Number(o.id); }))+1;
      // }
      this.quoteModel.airFreightShipmentDetail.push({
        id: timestamp, docId: "",
        shipmentDetailIdentificationNumber: "", quoteIdentificationNumber: "",
        destinationAirport: "", originAirport: "",
        originLocationCountryCode: data.originLocationCountryCode, originLocationPoliticalDivsion2Code: "",
        originLocationPostalCode: data.originLocationPostalCode,
        destinationLocationCountryCode: data.destinationLocationCountryCode,
        destinationLocationPoliticalDivsion2Code: "", destinationLocationPostalCode: "",
        movementTypeCode: data.movementTypeCode, paymentTermTypeCode: "",
        shipmentUnitOfMeasureTypeCode: 0,
        shipmentPalletQuantity: "",
        shipmentLooseUnitQUantity: '',
        commodityTypeCode: "", commodityTypeDescriptionText: "", commodityNameList: [],
        hazardousMaterialsIndicator: 0,
        hazardousMaterialName: '',
        hazardousMaterialUnitedNationsNumber: '',
        hazardousMaterialUnitedNationsClassificationCode: '',
        hazardousMaterialPackagingGroupText: '',
        shipmentOversizeIndicator: false,
        originAddressLine1Text: data.originAddressLine1Text, originAddressLine2Text: "",
        originAddressLine3Text: "", originPoliticalDivision1Name: data.originPoliticalDivision1Name,
        destinationAddressLine1Text: data.destinationAddressLine1Text, destinationAddressLine2Text: "",
        destinationAddressLine3Text: "", destinationPoliticalDivision1Name: data.destinationPoliticalDivision1Name,
        shipmentInsuredValueAmount: "", shipmentValueIndicator: false,
        shipmentCurrencyCode: "", shipmentValue: "",
        temperatureControlShipmentIndicator: 0, perishableShipmentIndicator: 0,
        shipmentPalletPercent: "",
        shipmentLooseUnitPercent: "",
        shipmentOriginAddressProfileSaveIndicator: false,
        shipmentDestinationAddressProfileSaveIndicator: false,
        shipmentWeightTypeCode: 0,
        totalWeight: "",
        shipmentWeightByPeice: data.shipmentWeightByPeice,
        isCustomerBroker: 0, shipmentInsuranceIndicator: null, shipmentReadyDate: null, shipmentSpeedType: null, originAirportName: data.originAirportName, destinationAirportName: data.destinationAirportName,
        shipmentMethod: data.shipmentMethod,
        shipmentFrequencyTimePeriodDescriptionText: data.shipmentFrequencyTimePeriodDescriptionText,
        shipmentFrequency: data.shipmentFrequency,
        shipmentActualWeight: '',
        shipmentDimensionalWeight: '',
        shipmentActualWeightUnitOfMeasureTypeCode: data.shipmentActualWeightUnitOfMeasureTypeCode,
        shipmentDimensionalWeightUnitOfMeasureTypeCode: data.shipmentDimensionalWeightUnitOfMeasureTypeCode,
        shipmentActualWeightQuantity: data.shipmentActualWeightQuantity,
        shipmentDimensionalWeightQuantity: data.shipmentDimensionalWeightQuantity,
        serviceTypes: data.serviceTypes,
        termsOfSale: data.termsOfSale,
        TOSModified: data.shipmentdetails.TOSModified,
        quoteValidityPeriod: data.quoteValidityPeriod,
        quoteValidityStartDate: data.quoteValidityStartDate,
        quoteValidityEndDate: data.quoteValidityEndDate,
        quoteValidityModified: data.quoteValidityModified,
        quoteNotes: '',
        shipmentLaneActiveIndicator: this.chkSelectallvalue,
        MovementTypeDescriptionText: data.MovementTypeDescriptionText,
        originAutopopulationFormat: data.originAutopopulationFormat,
        destinationAutopopulationFormat: data.destinationAutopopulationFormat,
        customesBrokerage:data.customesBrokerage,
        shipmentCommodity: data.shipmentCommodity,
       
        quoteBrokeragdeModified: data.shipmentdetails.quoteBrokeragdeModified
      });
    }

  }

  /*
 * @ngdoc Material auto complete option selected change function
 * @name validationclassforgrid
 * @methodOf QuoteLanesComponent
 * @description  dynamically apply the grid row class name based on the validation
 * @public
 */
  validationclassforgrid(movementtype, origin, destination, shipmentfreq, weight, dimension, consolidatedECSelected, directCASelected, premiumDirectCXSelected,
    tempTrueSelected, customesBrokerage, quoteValidityPeriod, termsOfSale, originLocationCountryCode, destinationLocationCountryCode, commodityNameListCount) {
    this.gridvalidationtype = 0;
    this.gridoriginerror = false;
    this.griddesterror = false;
    this.gridmovementtypeerror = false;
    if (movementtype != undefined && movementtype != "" && origin != undefined && origin != "" && destination != undefined && destination != "" && shipmentfreq != undefined && shipmentfreq != "" &&
      weight != undefined && weight != "" && dimension != undefined && dimension != "" && (consolidatedECSelected || directCASelected || premiumDirectCXSelected || tempTrueSelected)) {
      var shipmentservicetype = this.shipmentServiceTypeArray.filter(x => x.shipmentservicetype == movementtype);
      var originloc = this.airportDetailsArray.filter(x => x.autopopulateformat == origin || x.autopopulateformat1 == origin || x.autopopulateformat2 == origin);
      var destloc = this.airportDetailsArray.filter(x => x.autopopulateformat == destination || x.autopopulateformat1 == destination || x.autopopulateformat2 == destination);
      if (originloc.length == 0 || originLocationCountryCode == destinationLocationCountryCode)
        this.gridoriginerror = true;
      if (destloc.length == 0 || originLocationCountryCode == destinationLocationCountryCode)
        this.griddesterror = true;
      if (shipmentservicetype.length == 0)
        this.gridmovementtypeerror = true;
      if (originLocationCountryCode == destinationLocationCountryCode || originloc.length == 0 || shipmentservicetype.length == 0
        || destloc.length == 0) {
        return "bgtableTRR";
      }
      else if (customesBrokerage != undefined && customesBrokerage != "" && quoteValidityPeriod != undefined && quoteValidityPeriod != ""
        && termsOfSale != undefined && termsOfSale != "" && commodityNameListCount > 0) {
        this.gridvalidationtype = 0;
        return "bgtableTRG";
      }
      else {
        this.gridvalidationtype = 2;
        return "bgtableTRG";
      }
    }


    else {
      if (origin != "" && destination != "") {
        var originloc = this.airportDetailsArray.filter(x => x.autopopulateformat == origin || x.autopopulateformat1 == origin || x.autopopulateformat2 == origin);
        var destloc = this.airportDetailsArray.filter(x => x.autopopulateformat == destination || x.autopopulateformat1 == destination || x.autopopulateformat2 == destination);
        if (originloc.length == 0 || originLocationCountryCode == destinationLocationCountryCode)
          this.gridoriginerror = true;
        if (destloc.length == 0 || originLocationCountryCode == destinationLocationCountryCode)
          this.griddesterror = true;
      }

      if (movementtype != undefined && movementtype != "") {
        var shipmentservicetype = this.shipmentServiceTypeArray.filter(x => x.shipmentservicetype == movementtype);
        if (shipmentservicetype.length == 0)
          this.gridmovementtypeerror = true;
      }
      this.gridvalidationtype = 1;
      return "bgtableTRR";
    }

  }
  /*
  * @ngdoc Material auto complete option selected change function
  * @name onMatSelectionChanged
  * @methodOf QuoteLanesComponent
  * @description  Method  for identifying movement service type change
  * @public
  */
  onMatSelectionChanged(event: MatAutocompleteSelectedEvent, rowno) {
    // this.displaydesmaterialauto = false;
    // this.displayoriginmaterialauto = false;
    this.displayDestinationpopup = false;
    this.displayOriginnpopup = false;
    this.inputvaluelength = 3/*Set back to default value */;
    this.enablesavebutton = true;
    this.lanedataArray.find(item => item.rowno == rowno).desCityActual = "";
    this.lanedataArray.find(item => item.rowno == rowno).originCityActual = "";
    if (event.option.value == MovementTypeConst.ATA) {
      this.lanedataArray.find(item => item.rowno == rowno).displaydesmaterialauto = true;
      this.lanedataArray.find(item => item.rowno == rowno).displayoriginmaterialauto = true;
    }
    else if (event.option.value == MovementTypeConst.DTD) {
      this.lanedataArray.find(item => item.rowno == rowno).displayoriginmaterialauto = false;
      this.lanedataArray.find(item => item.rowno == rowno).displaydesmaterialauto = false;
    }
    else if (event.option.value == MovementTypeConst.DTA) {
      this.lanedataArray.find(item => item.rowno == rowno).displayoriginmaterialauto = false;
      this.lanedataArray.find(item => item.rowno == rowno).displaydesmaterialauto = true;
    }
    else if (event.option.value == MovementTypeConst.ATD) {
      this.lanedataArray.find(item => item.rowno == rowno).displayoriginmaterialauto = true;
      this.lanedataArray.find(item => item.rowno == rowno).displaydesmaterialauto = false;
    }
  }
  /*
 * @ngdoc Material auto complete option selected change function
 * @name gridonMatSelectionChanged
 * @methodOf QuoteLanesComponent
 * @description  Method  for identifying movement service type change in grid
 * @public
 */
  gridonMatSelectionChanged(event: MatAutocompleteSelectedEvent, rowno) {
    // this.displaydesmaterialauto = false;
    // this.displayoriginmaterialauto = false;
    this.griddisplayDestinationpopup = false;
    this.griddisplayOriginnpopup = false;
    this.inputvaluelength = 3/*Set back to default value */;
    //this.enablesavebutton = true;
    this.objgriddescity = "";
    this.objgridorigincity = "";
    if (event.option.value == MovementTypeConst.ATA) {
      this.griddisplaydesmaterialauto = true;
      this.griddisplayoriginmaterialauto = true;
    }
    else if (event.option.value == MovementTypeConst.DTD) {
      this.griddisplayoriginmaterialauto = false;
      this.griddisplaydesmaterialauto = false;
    }
    else if (event.option.value == MovementTypeConst.DTA) {
      this.griddisplayoriginmaterialauto = false;
      this.griddisplaydesmaterialauto = true;
    }
    else if (event.option.value == MovementTypeConst.ATD) {
      this.griddisplayoriginmaterialauto = true;
      this.griddisplaydesmaterialauto = false;
    }
  }
  /*
  * @ngdoc Material auto complete option selected change function
  * @name onMatDesSelectionChanged
  * @methodOf QuoteLanesComponent
  * @description  Method  for identifying destination city change
  * @public
  */
  onMatDesSelectionChanged(event: MatAutocompleteSelectedEvent) {
    this.autoselectionchanged = true;
    this.lanedataArray.find(item => item.rowno == this.currentrowno).desCityActual = event.option.value;
  }
  /*
  * @ngdoc Material auto complete option selected change function
  * @name gridonMatDesSelectionChanged
  * @methodOf QuoteLanesComponent
  * @description  Method  for identifying destination city change in grid popup
  * @public
  */
  gridonMatDesSelectionChanged(event: MatAutocompleteSelectedEvent) {
    this.gridautoselectionchanged = true;
    this.objgriddescity = event.option.value;
  }
  /*
   * @ngdoc function
   * @name streetaddressUpdate
   * @methodOf QuoteLanesComponent
   * @description  Method  for updating the street address value
   * @public
   */
  streetaddressUpdate(val) {
    this.lanedataArray.find(item => item.rowno == this.currentrowno).streetaddressActual = val;
  }
  /*
   * @ngdoc function
   * @name gridstreetaddressUpdate
   * @methodOf QuoteLanesComponent
   * @description  Method  for updating the street address value in grid
   * @public
   */
  gridstreetaddressUpdate(val) {
    this.objgridorginStreetAddress = val;
  }
  /*
  * @ngdoc function
  * @name desstreetaddressUpdate
  * @methodOf QuoteLanesComponent
  * @description  Method  for updating the destination street address value
  * @public
  */
  desstreetaddressUpdate(val) {
    this.lanedataArray.find(item => item.rowno == this.currentrowno).streetaddressDesActual = val;
  }
  /*
   * @ngdoc function
   * @name desstreetaddressUpdate
   * @methodOf QuoteLanesComponent
   * @description  Method  for updating the destination street address value in grid
   * @public
   */
  griddesstreetaddressUpdate(val) {
    this.objgriddesstreetaddress = val;
  }
  /*
* @ngdoc Material auto complete option selected change function
* @name onMatOriginSelectionChanged
* @methodOf QuoteLanesComponent
* @description  Method  for identifying origin city change
* @public
*/
  onMatOriginSelectionChanged(event: MatAutocompleteSelectedEvent) {
    this.autoselectionchanged = true;
    this.lanedataArray.find(item => item.rowno == this.currentrowno).originCityActual = event.option.value;
  }
  /*
* @ngdoc Material auto complete option selected change function
* @name onMatOriginSelectionChanged
* @methodOf QuoteLanesComponent
* @description  Method  for identifying origin city change
* @public
*/
  gridonMatOriginSelectionChanged(event: MatAutocompleteSelectedEvent) {
    this.gridautoselectionchanged = true;
    this.objgridorigincity = event.option.value;
  }
  /*
* @ngdoc function
* @name closeDoorPopup
* @methodOf QuoteLanesComponent
* @description  Method  for closing  destination popup
* @public
*/
  closeDesPopup() {
    if (!this.autoselectionchanged)
      this.displayDestinationpopup = false;
    this.autoselectionchanged = false;
  }
  /*
* @ngdoc function
* @name closeOriginPopup
* @methodOf QuoteLanesComponent
* @description  Method  for closing origin  popup
* @public
*/
  closeOriginPopup() {
    if (!this.autoselectionchanged)
      this.displayOriginnpopup = false;
    this.autoselectionchanged = false;
  }

  /*
 * @ngdoc function
 * @name onHideshipmentdetails
 * @methodOf QuoteLanesComponent
 * @description  Method  for hiding child component onclick
 * @public
 */
  onHideshipmentdetails(val: boolean) {
    this.displayShipmentdetails = 0;
  }

  /*
* @ngdoc function
* @name gridHideShipmentDetails
* @methodOf QuoteLanesComponent
* @description  Method  for hiding child component onclick
* @public
*/
  gridHideShipmentDetails(val: boolean) {
    this.griddisplayShipmentdetails = 0;
  }

  /*
 * @ngdoc function
 * @name clickedInside
 * @methodOf QuoteLanesComponent
 * @description  Method  for handling the div inside and outside click events
 * @public
 */
  clickedInside($event: Event) {
    $event.preventDefault();
    $event.stopPropagation();  // <- that will stop propagation on lower layers
    //console.log("CLICKED INSIDE, MENU WON'T HIDE");
  }

  @HostListener('document:click', ['$event']) clickedOutside($event) {
    // console.log("CLICKED OUTSIDE");
    if (this.displayOriginnpopup && !this.autoselectionchanged) {
      this.displayOriginnpopup = false;
    }
    else if (this.displayDestinationpopup && !this.autoselectionchanged) {
      this.displayDestinationpopup = false;
    }
    else if (this.griddisplayDestinationpopup && !this.gridautoselectionchanged) {
      this.griddisplayDestinationpopup = false;
    }
    else if (this.griddisplayOriginnpopup && !this.gridautoselectionchanged) {
      this.griddisplayOriginnpopup = false;
    }
    this.autoselectionchanged = false;
    this.gridautoselectionchanged = false;
  }
  /*
* @ngdoc function
* @name setFocus
* @methodOf QuoteLanesComponent
* @description  Method  for setting  autofocus dynamically across all browsers
* @public
*/
  setFocus() {
    //this.popupInput.nativeElement.focus();
  }
  /*
  * @ngdoc function
  * @name slideoutrow
  * @methodOf QuoteLanesComponent
  * @description  Method  for slide in and out grid row
  * @public
  */
  slideoutrow(rowno) {
    this.grideditrowno = 0;
    if (rowno == this.sliderowno)
      this.sliderowno = "0";
    else
      this.sliderowno = rowno.toString();
    // this.setModelValues();
    this.validityStartPeriod = null;
    this.validityEndPeriod = null;
    var startDate = this.quoteModel.airFreightShipmentDetail.find(item => item.id == rowno).quoteValidityStartDate;
    var endDate = this.quoteModel.airFreightShipmentDetail.find(item => item.id == rowno).quoteValidityEndDate;
    if (startDate == null && endDate == null) {
      if (this.modelValidityStartDate != null && this.modelValidityEndDate != null) {
        this.validityStartPeriod = { year: this.modelValidityStartDate.getFullYear(), month: this.modelValidityStartDate.getMonth() + 1, day: this.modelValidityStartDate.getDate() };
        this.validityEndPeriod = { year: this.modelValidityEndDate.getFullYear(), month: this.modelValidityEndDate.getMonth() + 1, day: this.modelValidityEndDate.getDate() };
      }
    }
    else {
      this.validityStartPeriod = { year: startDate.getFullYear(), month: startDate.getMonth() + 1, day: startDate.getDate() };
      this.validityEndPeriod = { year: endDate.getFullYear(), month: endDate.getMonth() + 1, day: endDate.getDate() };

    }

  }
  /*
  * @ngdoc function
  * @name gotoBulkUpload
  * @methodOf QuoteLanesComponent
  * @description  Method  for redirecting to bulk upload page
  * @public
  */
  gotoBulkUpload() {
    this.helper.navigateTo(RoutingKey[PageState.BULKUPLOAD]);
  }
  /*
  * @ngdoc function
  * @name gridLaneEdit
  * @methodOf QuoteLanesComponent
  * @description  Method  for editing individual lane in grid
  * @public
  */
  gridLaneEdit(rowno, movementtype, origincity, descity) {
    this.grideditrowno = rowno;
    this.objgridmovementtype = movementtype;
    this.objgridorigincity = origincity;
    this.objgriddescity = descity;
    this.sliderowno = "";
    if (movementtype == MovementTypeConst.ATA) {
      this.griddisplayoriginmaterialauto = true;
      this.griddisplaydesmaterialauto = true;
    }
    else if (movementtype == MovementTypeConst.ATD) {
      this.griddisplayoriginmaterialauto = true;
      this.griddisplaydesmaterialauto = false;
    }
    else if (movementtype == MovementTypeConst.DTA) {
      this.griddisplayoriginmaterialauto = false;
      this.griddisplaydesmaterialauto = true;
    }
    else if (movementtype == MovementTypeConst.DTD) {
      this.griddisplayoriginmaterialauto = false;
      this.griddisplaydesmaterialauto = false;
    }
  }
  /*
 * @ngdoc function
 * @name gridLaneEdit
 * @methodOf QuoteLanesComponent
 * @description  Method  for editing individual lane in grid
 * @public
 */
  gridRowUpadte(rowno) {
    this.grideditrowno = 0;
    var selectedmovementType = 0;
    var originLocationCountryCode = "";
    var originLocationPostalCode = "";
    var originAirportName = "";
    var originPoliticalDivision1Name = "";
    var desLocationCountryCode = "";
    var desLocationPostalCode = "";
    var desAirportName = "";
    var desPoliticalDivision1Name = "";
    var selectedmovementtypejson = this.shipmentServiceTypeArray.filter(item => item.shipmentservicetype == this.objgridmovementtype);
    if (selectedmovementtypejson.length > 0)
      selectedmovementType = selectedmovementtypejson[0].value;
    var selectedoriginairport = this.airportDetailsArray.filter(item => item.autopopulateformat == this.objgridorigincity);
    if (selectedoriginairport.length == 0) {
      selectedoriginairport = this.airportDetailsArray.filter(item => item.autopopulateformat1 == this.objgridorigincity);
    }
    if (selectedoriginairport.length == 0) {
      selectedoriginairport = this.airportDetailsArray.filter(item => item.autopopulateformat2 == this.objgridorigincity);
    }
    if (selectedoriginairport.length > 0) {
      originLocationCountryCode = selectedoriginairport[0].countryCode;
      originLocationPostalCode = selectedoriginairport[0].postalCode;
      originAirportName = selectedoriginairport[0].airportName;
      originPoliticalDivision1Name = selectedoriginairport[0].politicalDivision2Name;
    }
    var selecteddestinationairport = this.airportDetailsArray.filter(item => item.autopopulateformat == this.objgriddescity);
    if (selecteddestinationairport.length == 0) {
      selecteddestinationairport = this.airportDetailsArray.filter(item => item.autopopulateformat1 == this.objgriddescity);
    }
    if (selecteddestinationairport.length == 0) {
      selecteddestinationairport = this.airportDetailsArray.filter(item => item.autopopulateformat2 == this.objgriddescity);
    }
    if (selecteddestinationairport.length > 0) {
      desLocationCountryCode = selecteddestinationairport[0].countryCode;
      desLocationPostalCode = selecteddestinationairport[0].postalCode;
      desAirportName = selecteddestinationairport[0].airportName;
      desPoliticalDivision1Name = selecteddestinationairport[0].politicalDivision2Name;
    }
    this.quoteModel.airFreightShipmentDetail.find(x => x.id == rowno).originAddressLine1Text = this.objpopgridorginStreetAddress;
    this.quoteModel.airFreightShipmentDetail.find(x => x.id == rowno).destinationAddressLine1Text = this.objpopgriddestinationStreetAddress;

    this.quoteModel.airFreightShipmentDetail.find(x => x.id == rowno).originLocationCountryCode = originLocationCountryCode;
    this.quoteModel.airFreightShipmentDetail.find(x => x.id == rowno).originLocationPostalCode = originLocationPostalCode;
    this.quoteModel.airFreightShipmentDetail.find(x => x.id == rowno).destinationLocationCountryCode = desLocationCountryCode;
    this.quoteModel.airFreightShipmentDetail.find(x => x.id == rowno).movementTypeCode = selectedmovementType;
    this.quoteModel.airFreightShipmentDetail.find(x => x.id == rowno).destinationAddressLine1Text = this.objpopgriddestinationStreetAddress;
    this.quoteModel.airFreightShipmentDetail.find(x => x.id == rowno).originAirportName = originAirportName;
    this.quoteModel.airFreightShipmentDetail.find(x => x.id == rowno).destinationAirportName = desAirportName;

    this.quoteModel.airFreightShipmentDetail.find(x => x.id == rowno).destinationPoliticalDivision1Name = desPoliticalDivision1Name;
    this.quoteModel.airFreightShipmentDetail.find(x => x.id == rowno).originPoliticalDivision1Name = originPoliticalDivision1Name;

    this.quoteModel.airFreightShipmentDetail.find(x => x.id == rowno).MovementTypeDescriptionText = this.objgridmovementtype;
    this.quoteModel.airFreightShipmentDetail.find(x => x.id == rowno).originAutopopulationFormat = this.objgridorigincity;
    this.quoteModel.airFreightShipmentDetail.find(x => x.id == rowno).destinationAutopopulationFormat = this.objgriddescity;

  }
  /*
 * @ngdoc function
 * @name termsofsaleChange
 * @methodOf QuoteLanesComponent
 * @description  Method  for showing alert message while changing terms of sale options
 * @public
 */
  termsofsaleChange(rowno, termsofsale, movementtype) {
    this.selectedmovementType = movementtype;
    this.selectedmovementTyperowno = rowno;
    switch (termsofsale) {
      case this.termsofsaleKeys[0]: this.selectedmovementType = MovementTypeConst.DTD;
                                    this.selectedmovementVal = MovementTypeVal.DTD;
                                    break;
      case this.termsofsaleKeys[1]: this.selectedmovementType = MovementTypeConst.DTD;
                                    this.selectedmovementVal = MovementTypeVal.DTD;
                                    break;
      case this.termsofsaleKeys[2]: this.selectedmovementType = MovementTypeConst.DTA;
                                    this.selectedmovementVal = MovementTypeVal.DTA;
                                    break;
      case this.termsofsaleKeys[3]: this.selectedmovementType = MovementTypeConst.DTA;
                                    this.selectedmovementVal = MovementTypeVal.DTA;
                                    break;
      case this.termsofsaleKeys[4]: this.selectedmovementType = MovementTypeConst.DTA;
                                    this.selectedmovementVal = MovementTypeVal.DTD;
                                    break;
      case this.termsofsaleKeys[5]: this.selectedmovementType = MovementTypeConst.DTD;
                                    this.selectedmovementVal = MovementTypeVal.DTD;
                                    break;
      case this.termsofsaleKeys[6]: this.selectedmovementType = MovementTypeConst.DTD;
                                    this.selectedmovementVal = MovementTypeVal.DTD;
                                    break;
      default: this.selectedmovementType = MovementTypeConst.DTD;
               this.selectedmovementVal = MovementTypeVal.DTD;
                break;
    }
    if (this.selectedmovementType != movementtype) {
      this.termsofsalesOverLay.show();
    }
  }
  modifyLane(val) {
    if (val == 1)
      this.termsofsalesOverLay.hide();
    else {
      this.termsofsalesOverLay.hide();
      this.quoteModel.airFreightShipmentDetail.find(x => x.id == this.selectedmovementTyperowno).movementTypeCode=this.selectedmovementVal;
      this.quoteModel.airFreightShipmentDetail.find(x => x.id == this.selectedmovementTyperowno).MovementTypeDescriptionText=this.selectedmovementType;
    }
  }
  /*START: validity period date selection logic copied from quote overview component */

  /*
  * @ngdoc function
  * @name getRequestValidityOptions
  * @methodOf QuoteLanesComponent
  * @description  Method  for displaying validity period opions
  * @public
  */
  getRequestValidityOptions() {
    var arr = [];
    for (let item in QuoteRequestValidityOptions) {
      arr.push(QuoteRequestValidityOptions[item]);
    }
    return arr;
  }

  onRequestValidityOptionsChange(e, rowno) {
    var date = this.quoteModel.airFreightShipmentDetail.find(item => item.id == rowno).quoteValidityStartDate;
    this.quoteModel.airFreightShipmentDetail.find(item => item.id == rowno).quoteValidityModified = true;

    this.validityStartPeriod = { year: date.getFullYear(), month: date.getMonth() + 1, day: date.getDate() };
    if (this.validityStartPeriod != null) {
      var dt: NgbDateStruct = { year: this.validityStartPeriod.year, day: this.validityStartPeriod.day, month: this.validityStartPeriod.month - 1 };
      this.setEndDate(dt, rowno);
    }

  }
  dateDiffInDays(a, b) {
    const _MS_PER_DAY = 1000 * 60 * 60 * 24;
    const utc1 = Date.UTC(a.getFullYear(), a.getMonth(), a.getDate());
    const utc2 = Date.UTC(b.getFullYear(), b.getMonth(), b.getDate());
    return Math.floor((utc2 - utc1) / _MS_PER_DAY);
  }
  onStartDateSelect(e: NgbDateStruct, rowno) {
    var dt: NgbDateStruct = { year: e.year, day: e.day, month: e.month - 1 };
    this.validityStartPeriod = e;
    this.setEndDate(dt, rowno);
    this.quoteModel.airFreightShipmentDetail.find(item => item.id == rowno).quoteValidityStartDate = new Date(this.validityStartPeriod.year, this.validityStartPeriod.month - 1, this.validityStartPeriod.day);
    this.quoteModel.airFreightShipmentDetail.find(item => item.id == rowno).quoteValidityModified = true;
  }

  onEndDateSelect(e: NgbDateStruct, rowno) {
    if (this.validityStartPeriod == null || this.validityStartPeriod == undefined) {
      return;
    }
    var dt: NgbDateStruct = { year: e.year, day: e.day, month: e.month - 1 };
    var endDt = new Date(e.year, e.month - 1, e.day);
    var startDt = new Date(this.validityStartPeriod.year, this.validityStartPeriod.month - 1, this.validityStartPeriod.day);
    this.quoteModel.airFreightShipmentDetail.find(item => item.id == rowno).quoteValidityEndDate =endDt;
    this.quoteModel.airFreightShipmentDetail.find(item => item.id == rowno).quoteValidityModified = true;
    if (endDt < startDt) {
      setTimeout(() => {
        this.validityEndPeriod = null;
        this.quoteModel.airFreightShipmentDetail.find(item => item.id == rowno).quoteValidityEndDate = null;
        this.quoteModel.airFreightShipmentDetail.find(item => item.id == rowno).quoteValidityModified = false;
      }, 200);
    }
  }

  setEndDate(e: NgbDateStruct, rowno) {
    var validityperiod = this.quoteModel.airFreightShipmentDetail.find(item => item.id == rowno).quoteValidityPeriod;
    var dt = new Date(e.year, e.month, e.day - 1);
    var endDate = new Date();
    this.quotevalidityperiod = this.quoteModel.airFreightShipmentDetail.find(item => item.id == rowno).quoteValidityPeriod;
    switch (validityperiod) {
      case QuoteRequestValidityOptions["1Month"]:
        endDate = this.addMonths(dt, 1);
        this.validityEndPeriod = { year: endDate.getFullYear(), month: endDate.getMonth() + 1, day: endDate.getDate() };
        break;
      case QuoteRequestValidityOptions["3months"]:
        endDate = this.addMonths(dt, 3);
        this.validityEndPeriod = { year: endDate.getFullYear(), month: endDate.getMonth() + 1, day: endDate.getDate() };
        break;
      case QuoteRequestValidityOptions["6months"]:
        endDate = this.addMonths(dt, 6);
        this.validityEndPeriod = { year: endDate.getFullYear(), month: endDate.getMonth() + 1, day: endDate.getDate() };
        break;
      case QuoteRequestValidityOptions["1year"]:
        endDate = this.addMonths(dt, 12);
        this.validityEndPeriod = { year: endDate.getFullYear(), month: endDate.getMonth() + 1, day: endDate.getDate() };
        break;
      case QuoteRequestValidityOptions.Other:
        this.validityEndPeriod = null;
        break;
    }

    if (this.validityEndPeriod == null) {
      this.quoteModel.airFreightShipmentDetail.find(item => item.id == rowno).quoteValidityEndDate = null;
    }
    else {
      this.quoteModel.airFreightShipmentDetail.find(item => item.id == rowno).quoteValidityEndDate = new Date(this.validityEndPeriod.year, this.validityEndPeriod.month - 1, this.validityEndPeriod.day);
      this.quoteModel.airFreightShipmentDetail.find(item => item.id == rowno).quoteValidityModified = true;
    }
  }

  isDisableEndDate(rowno) {
    return this.quoteModel.airFreightShipmentDetail.find(item => item.id == rowno).quoteValidityPeriod != QuoteRequestValidityOptions.Other;
  }

  isLeapYear(year) {
    return (((year % 4 === 0) && (year % 100 !== 0)) || (year % 400 === 0));
  }

  getDaysInMonth(year, month) {
    return [31, (this.isLeapYear(year) ? 29 : 28), 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][month];
  }

  addMonths(date, value) {
    var d = new Date(date), n = date.getDate();
    d.setDate(1);
    d.setMonth(d.getMonth() + value);

    if ((n == this.getDaysInMonth(date.getFullYear(), date.getMonth())) && (this.getDaysInMonth(d.getFullYear(), d.getMonth()) == 31 || this.getDaysInMonth(d.getFullYear(), d.getMonth()) == 29)) {
      d.setDate(this.getDaysInMonth(d.getFullYear(), d.getMonth()));
    }
    else {
      d.setDate(Math.min(n, this.getDaysInMonth(d.getFullYear(), d.getMonth())));
    }
    return d;
  }
  /*END: validity period date selection logic copied from quote overview component */

  /*
* @ngdoc function
* @name onNavigateForInCoterms
* @methodOf QuoteLanesComponent
* @description  Method  for open incoterms url in new tab
* @public
*/
  onNavigateForInCoterms() {
    window.open(ApplicationUrls[2].viewIncoterms, "_blank");
  }
  //check modified lane level service type compared to quote level service type

  laneServiceUpdate(serviceTypeObj: ServiceTypes) {

    if (serviceTypeObj.consolidatedECSelected != this.quoteModel.quoteRequestData.serviceTypes.consolidatedECSelected ||
      serviceTypeObj.directCASelected != this.quoteModel.quoteRequestData.serviceTypes.directCASelected ||
      serviceTypeObj.premiumDirectCXSelected != this.quoteModel.quoteRequestData.serviceTypes.premiumDirectCXSelected ||
      serviceTypeObj.tempTrueSelected != this.quoteModel.quoteRequestData.serviceTypes.tempTrueSelected
    ) {
      serviceTypeObj.isModified = true;
    }
    else {
      serviceTypeObj.isModified = false;

  }
  }
  laneBrokerageUpdate(quoteLaneModel: IAirFreightShipmentDetail) {

    if (quoteLaneModel.customesBrokerage != this.quoteModel.quoteRequestData.customesBrokerage
      
    ) {
      quoteLaneModel.quoteBrokeragdeModified = true;
      alert(quoteLaneModel.quoteBrokeragdeModified);
    }
    else {
      quoteLaneModel.quoteBrokeragdeModified = true;      

    }
  }

  laneTOSUpdate(quoteLaneModel: IAirFreightShipmentDetail) {

    if (quoteLaneModel.termsOfSale != this.quoteModel.quoteRequestData.termsOfSale

    ) {
      quoteLaneModel.TOSModified = true;    
    }
    else {
      quoteLaneModel.TOSModified = true;  

    }
  } 

  displayCommodity(grid?: IAirFreightShipmentDetail) {
    this.showCommodity = true;
    const modalRef = this.modalService.open(QuoteLaneCommodityComponent, { backdrop: 'static', centered: true, });
    const componentInstance = modalRef.componentInstance as QuoteLaneCommodityComponent;
    componentInstance.commodityTypes = this.commodityTypes;
    componentInstance.closeCommodityOverlay.subscribe(($event) => {
      this.showCommodity = false;
      if (grid && $event) {
        grid.shipmentCommodity = $event;
      }
      console.log($event);
    });
  }

  joinCommodityNames(names: CommodityNameList[]) {
    if( names !== undefined ) {
      return names.map( item => item.commodityName).join();
    } else {
      return '';
    }
  }

  getCommodityDescription(code: string) {
    const matched = this.commodityTypes.find(type => (type.commodityTypeCode === code));
    if(matched !== undefined){
      return matched.commodityTypeDescriptionText;
    } else {
      return '';
    }
  }

  getSpecialRequirementsText(commodity: ShipmentCommodity) {
    const requirements = [];
    if( commodity.hazardousMaterialsIndicator === 1) {
      requirements.push('Haz-mat');
    }
    if( commodity.perishableShipmentIndicator === 1) {
      requirements.push('Perishable');
    }
    if( commodity.temperatureControlShipmentIndicator === 1) {
      requirements.push('Temperature-controlled');
    }
    if(commodity.highValueRiskIndicator) {
      requirements.push('High-value/high-risk');
    }
    if(commodity.specialSecurityIndicator) {
      requirements.push('Special security required');
    }
    if(!commodity.shipmentStackableIndicator) {
      requirements.push('Do not stack');
    }
    if(commodity.otherSpecialIndicator) {
      requirements.push('Other special requirements');
    }
    return requirements.join();
  }

  displayNotes(commodity: ShipmentCommodity) {
    return (( commodity.hazardousMaterialsIndicator === 1) ||
    ( commodity.perishableShipmentIndicator === 1) ||
    ( commodity.temperatureControlShipmentIndicator === 1) ||
    commodity.highValueRiskIndicator ||
    commodity.specialSecurityIndicator ||
    !commodity.shipmentStackableIndicator ||
    commodity.otherSpecialIndicator);
  }
}
