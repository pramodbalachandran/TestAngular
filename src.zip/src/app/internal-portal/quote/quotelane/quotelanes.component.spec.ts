import { async, ComponentFixture, TestBed, getTestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterTestingModule } from '@angular/router/testing';

import { MatInputModule, MatAutocompleteModule, MatButtonModule, MatProgressSpinnerModule } from '@angular/material';
import { FormsModule, ReactiveFormsModule, } from '@angular/forms';
import { DebugElement, Component, OnInit, NgModule } from '@angular/core';
import { DataTableModule } from 'angular-6-datatable';
import { Observable } from 'rxjs';
import { DomSanitizer, By } from '@angular/platform-browser';
import { map, startWith } from 'rxjs/operators';
import { MatAutocompleteSelectedEvent, MatFormFieldModule } from '@angular/material';
import { retry } from 'rxjs/operators';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { state } from '@angular/animations/src/animation_metadata';
import { FormGroup, FormBuilder, FormControl } from '@angular/forms';
import { Overlay, OverlayContainer } from '@angular/cdk/overlay';
import { of } from "rxjs";

import { combineAll } from 'rxjs/internal/operators/combineAll';
import { SharedModule } from '@app/shared/shared.module';
import { RoutingKey } from '@app/shared/services/shared/config.const';

import { LocalStorageService, QuoteAPI, GeaographyAPI } from '@app/shared/services';
import { PageState } from '@app/shared/services/shared/enum';
import { GeaographyMockAPI } from '@app/shared/services/shared/mock/geoGraphyMock.service';
import { UtilitiesService } from '@app/shared/services/shared/utilities.service';
import { airportDetails, shipmentServiceType } from '@app/models/autopopulate/autopopulate-data';
import { IAirportODPair } from '@app/shared/interfaces/entities.interface';
import { AutocompleteComponent } from '@app/shared/helper/autocomplete.component';

import { QuoteLanesComponent } from './quotelanes.component';
import { IPHeaderComponent } from '@app/shared/header/header.component';
import { SideNavbarComponent } from '@app/shared/sidenavbar/sidenavbar.component';


describe('QuoteLanesComponent', () => {
   let component: QuoteLanesComponent;
   let fixture: ComponentFixture<QuoteLanesComponent>;
   let fb: FormBuilder;
   let geoGraphyService: GeaographyAPI<any>;
   let geoGraphyMockService: GeaographyMockAPI<any>;
   let injector;
   let overlayContainer: OverlayContainer;
   let overlayContainerElement: HTMLElement;

   beforeEach(async(() => {
       TestBed.configureTestingModule({
           imports: [HttpClientTestingModule,
               // DomSanitizer,
               BrowserAnimationsModule,
               DataTableModule,
               RouterTestingModule,
               MatInputModule,
               MatAutocompleteModule,
               // FormBuilder,
               MatButtonModule,
               MatProgressSpinnerModule,
               FormsModule,
               ReactiveFormsModule,
               SharedModule],
           declarations: [QuoteLanesComponent],
           providers: [UtilitiesService, QuoteAPI, GeaographyAPI],
           schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA]

       })
           .compileComponents();

       injector = getTestBed();
       geoGraphyService = injector.get(GeaographyAPI);
       //geoGraphyMockService= injector.get(GeaographyMockAPI);
   }));

   beforeEach(() => {
       fixture = TestBed.createComponent(QuoteLanesComponent);
       component = fixture.componentInstance;
       fixture.detectChanges();
   });

   //The component should be define.
   it("should have a defined component ", () => {
       expect(component).toBeDefined();
   });

   // //geoGraphyService-mockup testing.
  //  it('geoGraphyService', () => {
  //      let serStates = [];

  //      geoGraphyService.getAirportdetails("Testing").subscribe(
  //          data => {
  //              serStates = data;
  //          });

  //      expect(serStates.length).toBeGreaterThanOrEqual(1);

  //  });

   //getAirportdetails
  //  it('getAirportdetails ', () => {
  //      component.airportDetailsArray = [];
  //      //component.airportCtrl = new FormControl();
  //      geoGraphyMockService.getAirportdetails
  //      expect(component.airportDetailsArray.length).toBeGreaterThanOrEqual(0);
  //  });
   //getAirportdetails else
   it('getAirportdetails ', () => {
       component.airportDetailsArray = [];
       // component.airportCtrl = new FormControl();
       component.getAirportdetails(null);
       expect(component.airportDetailsArray.length).toBeGreaterThanOrEqual(0);

   });
   //createShipmentServiceTypearray
   it('createShipmentServiceTypearray ', () => {
       component.shipmentServiceTypeArray = [];
       component.createShipmentServiceTypearray();
       expect(component.shipmentServiceTypeArray.length).toBeGreaterThanOrEqual(0);
   });
   //_filterAirportArray
   it('_filterAirportArray', () => {
       component.airportDetailsArray = [];
       component.airportDetailsArray.push({
           airportCode: "AAR",
           airportName: "AARHUS",
           autopopulateformat: "AAR Ulstrup,Denmark-Aarhus",
           autopopulateformat1: "AAR Ulstrup,Denmark-Aarhus",
           autopopulateformat2: "AAR Ulstrup,Denmark-Aarhus",
           countryCode: "DK",
           countryName: "Denmark",
           isCustomerData: "0",
           politicalDivision2Name: "ULSTRUP",
           postalCode: "",
           autopopulateformathighlight: "AAR Ulstrup,Denmark-Aarhus"

       });

       component.airportDetailsArray.push({
           airportCode: "ABE",
           airportName: "ALLENTOWN",
           autopopulateformat: "ABE Eckert,United States-Allentown",
           autopopulateformat1: "ABE Eckert,United States-Allentown",
           autopopulateformat2: "ABE Eckert,United States-Allentown",
           countryCode: "US",
           countryName: "United States",
           isCustomerData: "0",
           politicalDivision2Name: "ECKERT",
           postalCode: "",
           autopopulateformathighlight: "ABE Eckert,United States-Allentown"
       });

       component.airportDetailsArray.push({
           airportCode: "ABE",
           airportName: "ALLENTOWN",
           autopopulateformat: "ABE Forty Fort,United States-Allentown",
           autopopulateformat1: "ABE Forty Fort,United States-Allentown",
           autopopulateformat2: "ABE Forty Fort,United States-Allentown",
           countryCode: "US",
           countryName: "United States",
           isCustomerData: "0",
           politicalDivision2Name: "FORTY FORT",
           postalCode: "",
           autopopulateformathighlight: "ABE Forty Fort,United States-Allentown"
       });

       component.airportDetailsArray.push({
           airportCode: "ABE",
           airportName: "ALLENTOWN",
           autopopulateformat: "ABE Kohinoor Junction,United States-Allentown",
           autopopulateformat1: "ABE Kohinoor Junction,United States-Allentown",
           autopopulateformat2: "ABE Kohinoor Junction,United States-Allentown",
           countryCode: "US",
           countryName: "United States",
           isCustomerData: "0",
           politicalDivision2Name: "KOHINOOR JUNCTION",
           postalCode: "",
           autopopulateformathighlight: "ABE Kohinoor Junction,United States-Allentown"
       });

       component.airportDetailsArray.push({
           airportCode: "ABE",
           airportName: "ALLENTOWN",
           autopopulateformat: "ABE Portland,United States-Allentown",
           autopopulateformat1: "ABE Portland,United States-Allentown",
           autopopulateformat2: "ABE Portland,United States-Allentown",
           countryCode: "US",
           countryName: "United States",
           isCustomerData: "0",
           politicalDivision2Name: "PORTLAND",
           postalCode: "",
           autopopulateformathighlight: "ABE Portland,United States-Allentow"
       });

       component.airportDetailsArray.push({
           airportCode: "ABQ",
           airportName: "ALBUQUERQUE",
           autopopulateformat: "ABQ Roswell,United States-Albuquerque",
           autopopulateformat1: "ABQ Roswell,United States-Albuquerque",
           autopopulateformat2: "ABQ Roswell,United States-Albuquerque",
           countryCode: "US",
           countryName: "United States",
           isCustomerData: "0",
           politicalDivision2Name: "ROSWELL",
           postalCode: "",
           autopopulateformathighlight: "ABQ Roswell,United States-Albuquerque"
       });

       component.airportDetailsArray.push({
           airportCode: "ABQ",
           airportName: "ALBUQUERQUE",
           autopopulateformat: "ABQ Willard,United States-Albuquerque",
           autopopulateformat1: "ABQ Willard,United States-Albuquerque",
           autopopulateformat2: "ABQ Willard,United States-Albuquerque",
           countryCode: "US",
           countryName: "United States",
           isCustomerData: "0",
           politicalDivision2Name: "WILLARD",
           postalCode: "",
           autopopulateformathighlight: "ABQ Willard,United States-Albuquerque"
       });

       component.airportDetailsArrayHighlight = [];
       component.finalfilteredairportdetails = [];
       component._filterAirportArray("United");

       expect(component.finalfilteredairportdetails.length).toBeGreaterThanOrEqual(1);

   });




   //transform
   it('transform', () => {
       var response = 0;
       var textResponse = component.transform("A2D", "A");
       if (textResponse == '<span class="highlight">A</span>2D') {
           this.response = 1;
       }
       expect(this.response).toEqual(1);

   });

   describe('displayCommodity', () => {
    it('should set commodity to true by default or to given value', () => {
      component.commodity = false;
      component.displayCommodity();
      expect(component.commodity).toBeTruthy();
    });
   });

});
