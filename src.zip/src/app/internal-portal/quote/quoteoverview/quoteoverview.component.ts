import { Component, OnInit, AfterViewInit, ViewChild, ElementRef, Input, Output, Injectable, EventEmitter, HostListener } from '@angular/core';
import { DataTableModule } from 'angular-6-datatable';
import { Router, ActivatedRoute } from '@angular/router';
import { LocalStorageService, QuoteAPI, GeaographyAPI, CustomerAPI } from '@app/shared/services';
import { IAirFreightShipmentDetail, AirFreightShipmentDetail } from '@app/models/quotes/airfreightshipment-detail';
import { UtilitiesService } from '@app/shared/services/shared/utilities.service';
import { NgbDatepickerConfig, NgbCalendar, NgbDateStruct, NgbDateParserFormatter } from '@ng-bootstrap/ng-bootstrap';
import { NgbDateFormatter } from '@app/shared/helper/ngb-datepicker-formatter.component';
import { FileUploader, FileItem } from 'ng2-file-upload';
import { FormControl, FormGroup, FormBuilder } from '@angular/forms';
import { ICurrencyDetails } from '@app/shared/interfaces/entities.interface';
import { Observable } from 'rxjs';
import { IUpser } from '@app/models';
import { QuoteAttachment } from '@app/models/quotes/quotes-details';
import { startWith, map } from 'rxjs/operators';
import { IQuoteData } from '@app/models/quotes/quote-data';
import { ApplicationUrls } from '@app/shared/services/shared/config.const';
import { NgbDate } from '@ng-bootstrap/ng-bootstrap/datepicker/ngb-date';
import { CustomModalComponent } from '@app/shared/components/custom-modal/custom-modal.component';
import { LaneAlertType } from '@app/shared/services/shared/enum';


enum QuoteRequestValidityOptions { '1Month' = '1 month', '3months' = '3 months', '6months' ='6 months', '1year'='1 year', 'Other'='Other' }
const fileCategoryCode = 'QA001';
const customesBrokerageDefaultValue = 'cb001';

@Component({
  selector: 'pricing-quote-overview',
  templateUrl: './quoteoverview.component.html',
  styleUrls: ['../long-term-quote/long-term-quote.component.css'],
  providers: [{ provide: NgbDateParserFormatter, useClass: NgbDateFormatter }]
})

export class QuoteOverViewComponent implements OnInit {
  body: HTMLBodyElement = document.getElementsByTagName('body')[0];

  @Input('quotemodel') quoteModel: IQuoteData;
  @Input('typeOfQuote') quoteTypeSelectedValue: number;
  @Input('currencyConversionData') currencyConversionData: any[];
  @Output() quoteTypeStatusChange = new EventEmitter<number>();
  @ViewChild('customServiceOverLay') customServiceOverLay: CustomModalComponent;

  oneTimeShipment = 1;
  longTermShipment = 2;

  validityEndPeriod: NgbDateStruct;
  validityStartPeriod: NgbDateStruct;
  quoteRequestDate: NgbDateStruct;
  shipmentReadyDate: NgbDateStruct;
  showAlertPopup = false;
  sourceServiceType = false;
  sourceValidityType = false;
  sourceBrokerageType = false;
  sourceTermsOfSales = false;

  termsOfSaleOptions = [
    { name: 'Choose terms of sale', value: '' },
    { name: 'EXW (Ex Works)', value: 'EXW' },
    { name: 'CPT (Carriage Paid to)', value: 'CPT' },
    { name: 'CIP (Carriage and Insurance Paid to)', value: 'CIP' },
    { name: 'DAT (Delivered at terminal)', value: 'DAT' },
    { name: 'DAP (Delivered at Place)', value: 'DAP' },
    { name: 'DOP (Delivery duty Paid)', value: 'DOP' },
    { name: 'FCA (Free Carrier)', value: 'FCA' },
  ];

  uploader: FileUploader;
  uploadURL: string;
  isPricingTeam: boolean = false;
  hasBaseDropZoneOver: boolean;
  savedUplodDocuments: QuoteAttachment[];
  uploadLabelOptions = [
    { name: 'Choose a label', value: '' },
    { name: 'Customer Bid Documents', value: 'Customer Bid Documents' },
    { name: 'Past/Previous Quotes', value: 'Past/Previous Quotes' },
    { name: 'Temp True Questionnaire', value: 'Temp True Questionnaire' },
    { name: 'Competitors Information', value: 'Competitors Information' },
    { name: 'Miscellaneous', value: 'Miscellaneous' },
  ];

  tempTrueTooltip: string = 'Temp true service is only available on long-term quotes';

  currencyList: any[];
  currencyDetail: ICurrencyDetails;
  selectedCurrency: string = "USD";
  previouslySelectedCurrency: string = "USD";
  suggestedCurrency: string;
  conversionFactor: number;
  currencySelected: boolean;
  currencySetDefault: boolean = true;
  localeCodes: string = "";
  shipmentNext15Days: Date;
  shipmentReadyMinDate: NgbDateStruct ;
  shipmentReadyMaxDate: NgbDateStruct ;
  displayMonth: number = 0;

  userDetails: IUpser;

  constructor(private quoteService: QuoteAPI<any>, fb: FormBuilder, private customerAPI: CustomerAPI<any>,
    private localStorageService: LocalStorageService, private helper: UtilitiesService,
    private config: NgbDatepickerConfig, private calendar: NgbCalendar) {

    this.setupFileUpload();
    var dt = new Date();

    //if (dt.getDate() != 0 && (dt.getDate() >= 2))
    //  this.displayMonth = 2;
    //else if (dt.getDate() != 0)
    //  this.displayMonth = 1;

    //general settings for all cander control
    config.minDate = { year: dt.getFullYear(), month: dt.getMonth() + 1, day: dt.getDate() };    
    config.maxDate = { year: 2099, month: 12, day: 31 };


    //only for shipment ready calender control
    this.shipmentReadyMinDate = { year: dt.getFullYear(), month: dt.getMonth() + 1, day: dt.getDate() };  
    var shipmentNext30Days = new Date();
      //user to only choose a day within 30 days starting from current date for Origin APAC /NON APAC code is within APAC region.
    var numberOfDaysToAdd = 29;  
      
    shipmentNext30Days.setDate(shipmentNext30Days.getDate() + numberOfDaysToAdd);
    this.shipmentReadyMaxDate = { year: shipmentNext30Days.getFullYear(), month: shipmentNext30Days.getMonth() + 1, day: shipmentNext30Days.getDate() } //this.calendar.getNext(calendar.getToday(), 'd', 15);   
  }
 
  ngOnInit() {
    this.body.classList.remove('login-logo');

    

    document.getElementById("txtQuoteName").focus();

    if (this.isPricingTeam) {
      this.uploadLabelOptions.push(
        { name: 'Pricing/Solutions Info', value: 'Pricing/Solutions Info' },
        { name: 'Rating Profile', value: 'Rating Profile' });
    }

    this.setDefaultValues();
  }

  ngAfterViewInit() {
    setTimeout(() => {
      this.showAlertPopup = true;
      
    });
   
  }

  setDefaultValues() {

    this.quoteTypeSelectedValue = this.quoteModel.quoteRequestData.quoteTypeCode;

    if(this.quoteTypeSelectedValue===1/*one-time shipment */)
    {
      this.quoteModel.quoteRequestData.customesBrokerage = customesBrokerageDefaultValue;/*Set Default Value */
    }
    if (this.quoteModel.quoteRequestData.defaultCurrency != '') {
      this.suggestedCurrency = this.quoteModel.quoteRequestData.defaultCurrency;
      this.selectedCurrency = this.quoteModel.quoteRequestData.defaultCurrency;
      this.localeCodes = '';
    }
    else {
      this.setDefaultCurrency();
    }

    if (this.quoteModel.quoteRequestData.shipmentReadyDate != null) {
      this.shipmentReadyDate = { year: this.quoteModel.quoteRequestData.shipmentReadyDate.getFullYear(), month: this.quoteModel.quoteRequestData.shipmentReadyDate.getMonth() + 1, day: this.quoteModel.quoteRequestData.shipmentReadyDate.getDate() };
      this.quoteModel.quoteRequestData.shipmentReadyDate = new Date(this.shipmentReadyDate.year, this.shipmentReadyDate.month - 1, this.shipmentReadyDate.day);
    }
    if (this.quoteModel.quoteRequestData.quoteRequestDate != null) {
      this.quoteRequestDate = { year: this.quoteModel.quoteRequestData.quoteRequestDate.getFullYear(), month: this.quoteModel.quoteRequestData.quoteRequestDate.getMonth() + 1, day: this.quoteModel.quoteRequestData.quoteRequestDate.getDate() };
    }
    if (this.quoteModel.quoteRequestData.quoteValidityStartDate != null) {
      this.validityStartPeriod = { year: this.quoteModel.quoteRequestData.quoteValidityStartDate.getFullYear(), month: this.quoteModel.quoteRequestData.quoteValidityStartDate.getMonth() + 1, day: this.quoteModel.quoteRequestData.quoteValidityStartDate.getDate() };
    }
    if (this.quoteModel.quoteRequestData.quoteValidityEndDate != null) {
      this.validityEndPeriod = { year: this.quoteModel.quoteRequestData.quoteValidityEndDate.getFullYear(), month: this.quoteModel.quoteRequestData.quoteValidityEndDate.getMonth() + 1, day: this.quoteModel.quoteRequestData.quoteValidityEndDate.getDate() };
    }
    
    this.savedUplodDocuments = [];
    if (this.quoteModel.quoteRequestData.quoteAttachment && this.quoteModel.quoteRequestData.quoteAttachment.length>0) {
      for (let item of this.quoteModel.quoteRequestData.quoteAttachment) {
        this.savedUplodDocuments.push(item);
      }
    }
  }


  getTempTrueServiceTypeTooltip() {
    return this.quoteTypeSelectedValue == this.oneTimeShipment ? this.tempTrueTooltip : '';
  }

  setDefaultCurrency() {
    this.currencyDetail = this.quoteService.getCurrencyDetails();
    if (!this.currencyDetail) {
      this.userDetails = this.customerAPI.getUpserProfileDetails();
      if (this.userDetails) {
        this.suggestedCurrency = this.userDetails.defaultCurrency;
        this.selectedCurrency = this.userDetails.defaultCurrency;
        this.localeCodes = '';
        return;
      }
      this.suggestedCurrency = this.selectedCurrency;
      this.selectedCurrency = this.selectedCurrency;
      this.localeCodes = '';
    }
    else {
      this.suggestedCurrency = this.currencyDetail.defaultCurrency;
      this.selectedCurrency = this.currencyDetail.defaultCurrency;
      this.localeCodes = this.currencyDetail.localeCodes;
    }
    this.quoteModel.quoteRequestData.defaultCurrency = this.suggestedCurrency;
  }

  onShipmentTypeChange() {
   
    this.quoteModel.quoteRequestData.serviceTypes.consolidatedECSelected = false;
    this.quoteModel.quoteRequestData.serviceTypes.directCASelected = false;
    this.quoteModel.quoteRequestData.serviceTypes.premiumDirectCXSelected = false;
    this.quoteModel.quoteRequestData.serviceTypes.tempTrueSelected = false;
   
    this.setDefaultCurrency();

    this.shipmentReadyDate = null;
    this.validityEndPeriod = null;
    this.validityStartPeriod = null;
    this.quoteRequestDate = null;

    this.quoteModel.quoteRequestData.shipmentReadyDate = null;
    this.quoteModel.quoteRequestData.quoteRequestDate =  null;
    this.quoteModel.quoteRequestData.quoteValidityStartDate = null;
    this.quoteModel.quoteRequestData.quoteValidityEndDate = null;

    this.quoteModel.quoteRequestData.quoteValidityPeriod = QuoteRequestValidityOptions["1year"];
    this.quoteModel.quoteRequestData.customesBrokerage = "";
    this.quoteModel.quoteRequestData.insuranceRequiredIndicator = false;
    this.quoteModel.quoteRequestData.shipmentInsuranceAmount = '';
    this.quoteModel.quoteRequestData.quoteNotes = '';
    this.quoteModel.quoteRequestData.quoteName = '';
    this.quoteModel.quoteRequestData.termsOfSale = '';
    this.quoteModel.quoteRequestData.quoteAttachment = [];

    if (this.quoteTypeSelectedValue == this.oneTimeShipment) {
      this.quoteModel.quoteRequestData.serviceTypes.consolidatedECSelected = true;
      this.quoteModel.quoteRequestData.serviceTypes.directCASelected = false;
      this.quoteModel.quoteRequestData.serviceTypes.premiumDirectCXSelected = false;
      this.quoteModel.quoteRequestData.serviceTypes.tempTrueSelected = false;
    }
    else {
      this.quoteModel.quoteRequestData.serviceTypes.consolidatedECSelected = true;
      this.quoteModel.quoteRequestData.serviceTypes.directCASelected = true;
      this.quoteModel.quoteRequestData.serviceTypes.premiumDirectCXSelected = false;
      this.quoteModel.quoteRequestData.serviceTypes.tempTrueSelected = false;
    }
  }

  checkTOSType() {

    var self = this;
    var tosTypeMismatch = false;

    if (this.quoteTypeSelectedValue != this.oneTimeShipment && this.quoteModel.airFreightShipmentDetail.length > 0) {

      for (var i = 0; i < this.quoteModel.airFreightShipmentDetail.length; i++) {

        if (this.quoteModel.airFreightShipmentDetail[i].termsOfSale != self.quoteModel.quoteRequestData.termsOfSale) {
          tosTypeMismatch = true;
          break;
        }

      };

      if (tosTypeMismatch) {
        this.sourceServiceType = false;
        this.sourceValidityType = false;
        this.sourceBrokerageType = false;
        this.sourceTermsOfSales = true;
        this.customServiceOverLay.show();
      }

    }

  }

  checkLaneBrokerageType() {
    
    var self = this;
    var brokerageTypeMismatch = false;

    if (this.quoteTypeSelectedValue != this.oneTimeShipment && this.quoteModel.airFreightShipmentDetail.length > 0 ) {

      for (var i = 0; i < this.quoteModel.airFreightShipmentDetail.length; i++) {

        if (this.quoteModel.airFreightShipmentDetail[i].customesBrokerage != self.quoteModel.quoteRequestData.customesBrokerage) {
          brokerageTypeMismatch = true;
          break;
        }

      };

      if (brokerageTypeMismatch) {
        this.sourceServiceType = false;
        this.sourceValidityType = false;
        this.sourceTermsOfSales = false;
        this.sourceBrokerageType = true;
        this.customServiceOverLay.show();
      }

    }

  }

  checkLaneServiceType(event) {
    var self = this;
    var serviceTypeMismatch = false;

    if (this.quoteTypeSelectedValue != this.oneTimeShipment && this.quoteModel.airFreightShipmentDetail.length > 0 && this.quoteModel.airFreightShipmentDetail[0].serviceTypes != null) {

      for (var i = 0; i < this.quoteModel.airFreightShipmentDetail.length; i++) {     
        
        if (this.quoteModel.airFreightShipmentDetail[i].serviceTypes.consolidatedECSelected != self.quoteModel.quoteRequestData.serviceTypes.consolidatedECSelected ||
          this.quoteModel.airFreightShipmentDetail[i].serviceTypes.directCASelected != self.quoteModel.quoteRequestData.serviceTypes.directCASelected ||
          this.quoteModel.airFreightShipmentDetail[i].serviceTypes.premiumDirectCXSelected != self.quoteModel.quoteRequestData.serviceTypes.premiumDirectCXSelected ||
          this.quoteModel.airFreightShipmentDetail[i].serviceTypes.tempTrueSelected != self.quoteModel.quoteRequestData.serviceTypes.tempTrueSelected
        ) {
          serviceTypeMismatch = true;
          break;
        }  

      };

      if (serviceTypeMismatch) {
        this.sourceServiceType = true;
        this.sourceValidityType = false;
        this.sourceBrokerageType = false;
        this.sourceTermsOfSales = false;
        this.customServiceOverLay.show();
      }    
      
    }  

  }

 modifyLane(laneAlertType){

   //update all lanes when service type change
   if (laneAlertType == LaneAlertType.UPDATEALLLANE_SOURCE_SERVICETYPE) {
     
    if (this.quoteModel.airFreightShipmentDetail.length > 0 && this.quoteModel.airFreightShipmentDetail[0].serviceTypes != null) {
      for (var i = 0; i < this.quoteModel.airFreightShipmentDetail.length; i++) {
        this.quoteModel.airFreightShipmentDetail[i].serviceTypes.consolidatedECSelected = this.quoteModel.quoteRequestData.serviceTypes.consolidatedECSelected;
        this.quoteModel.airFreightShipmentDetail[i].serviceTypes.directCASelected = this.quoteModel.quoteRequestData.serviceTypes.directCASelected;
        this.quoteModel.airFreightShipmentDetail[i].serviceTypes.premiumDirectCXSelected = this.quoteModel.quoteRequestData.serviceTypes.premiumDirectCXSelected;
        this.quoteModel.airFreightShipmentDetail[i].serviceTypes.tempTrueSelected = this.quoteModel.quoteRequestData.serviceTypes.tempTrueSelected;
        this.quoteModel.airFreightShipmentDetail[i].serviceTypes.isModified = false;
        this.quoteModel.airFreightShipmentDetail[i].quoteValidityStartDate = this.quoteModel.quoteRequestData.quoteValidityStartDate;
        this.quoteModel.airFreightShipmentDetail[i].quoteValidityEndDate = this.quoteModel.quoteRequestData.quoteValidityEndDate;
        this.quoteModel.airFreightShipmentDetail[i].quoteValidityPeriod = this.quoteModel.quoteRequestData.quoteValidityPeriod;
        this.quoteModel.airFreightShipmentDetail[i].quoteValidityModified = false;
      }     
    }          
   }

   //update all lanes when validity period or date change
   if (laneAlertType == LaneAlertType.UPDATEALLLANE_SOURCE_QUOTEVALIDTY) {

     if (this.quoteModel.airFreightShipmentDetail.length > 0 && (this.quoteModel.airFreightShipmentDetail[0].quoteValidityPeriod != null && this.quoteModel.airFreightShipmentDetail[0].quoteValidityPeriod != undefined)) {
       for (var i = 0; i < this.quoteModel.airFreightShipmentDetail.length; i++) {         
         this.quoteModel.airFreightShipmentDetail[i].quoteValidityStartDate = this.quoteModel.quoteRequestData.quoteValidityStartDate;
         this.quoteModel.airFreightShipmentDetail[i].quoteValidityEndDate = this.quoteModel.quoteRequestData.quoteValidityEndDate;
         this.quoteModel.airFreightShipmentDetail[i].quoteValidityPeriod = this.quoteModel.quoteRequestData.quoteValidityPeriod;
         this.quoteModel.airFreightShipmentDetail[i].quoteValidityModified = false;
       }
     }
   }

   //ignore modified lanes update when service type change
   if (laneAlertType == LaneAlertType.IGNOREMODIFIEDLANE_SOURCE_SERVICETYPE) {

     if (this.quoteModel.airFreightShipmentDetail.length > 0 && this.quoteModel.airFreightShipmentDetail[0].serviceTypes != null) {
       for (var i = 0; i < this.quoteModel.airFreightShipmentDetail.length; i++) {
         if (!this.quoteModel.airFreightShipmentDetail[i].serviceTypes.isModified) {
           this.quoteModel.airFreightShipmentDetail[i].serviceTypes.consolidatedECSelected = this.quoteModel.quoteRequestData.serviceTypes.consolidatedECSelected;
           this.quoteModel.airFreightShipmentDetail[i].serviceTypes.directCASelected = this.quoteModel.quoteRequestData.serviceTypes.directCASelected;
           this.quoteModel.airFreightShipmentDetail[i].serviceTypes.premiumDirectCXSelected = this.quoteModel.quoteRequestData.serviceTypes.premiumDirectCXSelected;
           this.quoteModel.airFreightShipmentDetail[i].serviceTypes.tempTrueSelected = this.quoteModel.quoteRequestData.serviceTypes.tempTrueSelected;           
         }
         else {
           //after alert popup clicked ,status should be not modfied of the indivisual lane
           this.quoteModel.airFreightShipmentDetail[i].serviceTypes.isModified = false;
         }       

       }     
     }
   }

   //ignore modified lanes update when validity period or date change
   if (laneAlertType == LaneAlertType.IGNOREMODIFIEDLANE_SOURCE_QUOTEVALIDTY) {

     if (this.quoteModel.airFreightShipmentDetail.length > 0 && (this.quoteModel.airFreightShipmentDetail[0].quoteValidityPeriod != null && this.quoteModel.airFreightShipmentDetail[0].quoteValidityPeriod !=undefined)) {
       for (var i = 0; i < this.quoteModel.airFreightShipmentDetail.length; i++) {

         if (!this.quoteModel.airFreightShipmentDetail[i].quoteValidityModified) {
           this.quoteModel.airFreightShipmentDetail[i].quoteValidityStartDate = this.quoteModel.quoteRequestData.quoteValidityStartDate;
           this.quoteModel.airFreightShipmentDetail[i].quoteValidityEndDate = this.quoteModel.quoteRequestData.quoteValidityEndDate;
           this.quoteModel.airFreightShipmentDetail[i].quoteValidityPeriod = this.quoteModel.quoteRequestData.quoteValidityPeriod;
         }
         else {
           //after alert popup clicked ,status should be not modfied of the indivisual lane
           this.quoteModel.airFreightShipmentDetail[i].quoteValidityModified = false;
         }
       }

       }
   }

   //update all lanes when brokerage change
   if (laneAlertType == LaneAlertType.UPDATEALLLANE_SOURCE_BROKERAGE) {

     if (this.quoteModel.airFreightShipmentDetail.length > 0) {
       for (var i = 0; i < this.quoteModel.airFreightShipmentDetail.length; i++) {
         this.quoteModel.airFreightShipmentDetail[i].customesBrokerage = this.quoteModel.quoteRequestData.customesBrokerage;
         this.quoteModel.airFreightShipmentDetail[i].quoteBrokeragdeModified = false;
       }
     }
   }
  
   //ignore modified lanes update when brokerage change
   if (laneAlertType == LaneAlertType.IGNOREMODIFIEDLANE_SOURCE_BROKERAGE) {

     if (this.quoteModel.airFreightShipmentDetail.length >0) {
       for (var i = 0; i < this.quoteModel.airFreightShipmentDetail.length; i++) {

         if (!this.quoteModel.airFreightShipmentDetail[i].quoteBrokeragdeModified) {
           this.quoteModel.airFreightShipmentDetail[i].customesBrokerage = this.quoteModel.quoteRequestData.customesBrokerage;
          
         }
         else {
           //after alert popup clicked ,status should be not modfied of the indivisual lane
           this.quoteModel.airFreightShipmentDetail[i].quoteBrokeragdeModified = false;
         }
       }

     }
   }


   //update all lanes when brokerage change
   if (laneAlertType == LaneAlertType.UPDATEALLLANE_SOURCE_TOS) {

     if (this.quoteModel.airFreightShipmentDetail.length > 0) {
       for (var i = 0; i < this.quoteModel.airFreightShipmentDetail.length; i++) {
         this.quoteModel.airFreightShipmentDetail[i].termsOfSale = this.quoteModel.quoteRequestData.termsOfSale;
         this.quoteModel.airFreightShipmentDetail[i].TOSModified = false;
       }
     }
   }

   //ignore modified lanes update when brokerage change
   if (laneAlertType == LaneAlertType.IGNOREMODIFIEDLANE_SOURCE_TOS) {

     if (this.quoteModel.airFreightShipmentDetail.length > 0) {
       for (var i = 0; i < this.quoteModel.airFreightShipmentDetail.length; i++) {

         if (!this.quoteModel.airFreightShipmentDetail[i].TOSModified) {
           this.quoteModel.airFreightShipmentDetail[i].termsOfSale = this.quoteModel.quoteRequestData.termsOfSale;

         }
         else {
           //after alert popup clicked ,status should be not modfied of the indivisual lane
           this.quoteModel.airFreightShipmentDetail[i].TOSModified = false;
         }
       }

     }
   }


   this.sourceValidityType = false;
   this.sourceServiceType = false;
   this.sourceBrokerageType = false;
   this.sourceTermsOfSales = false;
   this.customServiceOverLay.hide();
 }


  isActiveOneTimeShipment() {
    return this.quoteTypeSelectedValue === this.oneTimeShipment;
  }

  isActiveLongTimeShipment() {
    return this.quoteTypeSelectedValue === this.longTermShipment;
  }

  onOneTimeShipmentSelect(value) {
    if (value == this.quoteTypeSelectedValue) {
      return;
    }
    this.quoteModel.airFreightShipmentDetail=[];
    this.quoteTypeSelectedValue = value;
    this.quoteTypeStatusChange.emit(value);
    this.onShipmentTypeChange();
    this.quoteModel.quoteRequestData.customesBrokerage = customesBrokerageDefaultValue;/*Set Default Value */
  }

  onLongTimeShipmentSelect(value) {
    if (value == this.quoteTypeSelectedValue) {
      return;
    }
    this.quoteModel.airFreightShipmentDetail=[];
    this.quoteTypeSelectedValue = value;
    this.quoteTypeStatusChange.emit(value);
    this.onShipmentTypeChange();
  }

  getRequestValidityOptions() {
    var arr = [];
    for (let item in QuoteRequestValidityOptions) {
      arr.push(QuoteRequestValidityOptions[item]);
    }
    return arr;
  }

  onRequestValidityOptionsChange(e) {
    
    if (this.validityStartPeriod != null) {
      var dt: NgbDateStruct = { year: this.validityStartPeriod.year, day: this.validityStartPeriod.day, month: this.validityStartPeriod.month-1  };
      this.setEndDate(dt);
     
    }
    this.checkLaneValidityType();
  }

  onShipmentReadyDateSelect(e: NgbDateStruct) {
    this.quoteModel.quoteRequestData.shipmentReadyDate = new Date(this.shipmentReadyDate.year, this.shipmentReadyDate.month - 1, this.shipmentReadyDate.day);
  }
    
  dateDiffInDays(a, b) {
    const _MS_PER_DAY = 1000 * 60 * 60 * 24;
    const utc1 = Date.UTC(a.getFullYear(), a.getMonth(), a.getDate());
    const utc2 = Date.UTC(b.getFullYear(), b.getMonth(), b.getDate());
    return Math.floor((utc2 - utc1) / _MS_PER_DAY);
  }
  
  onDueDateSelect(e: NgbDateStruct) {
    this.quoteModel.quoteRequestData.quoteRequestDate = new Date(this.quoteRequestDate.year, this.quoteRequestDate.month - 1, this.quoteRequestDate.day);
  }

  onStartDateSelect(e: NgbDateStruct) {
    var dt: NgbDateStruct = { year: e.year, day: e.day, month: e.month - 1 };
    this.setEndDate(dt);
    this.quoteModel.quoteRequestData.quoteValidityStartDate = new Date(this.validityStartPeriod.year, this.validityStartPeriod.month - 1, this.validityStartPeriod.day);   
    this.checkLaneValidityType();
  }

  onEndDateSelect(e: NgbDateStruct) {
   
    if (this.validityStartPeriod == null || this.validityStartPeriod ==undefined) {   
      
      return;
    }

    var dt: NgbDateStruct = { year: e.year, day: e.day, month: e.month - 1 };
    var endDt = new Date(e.year, e.month - 1, e.day);
    var startDt = new Date(this.validityStartPeriod.year, this.validityStartPeriod.month - 1, this.validityStartPeriod.day);
    //update quote model
    this.quoteModel.quoteRequestData.quoteValidityEndDate = endDt;    

    if (endDt < startDt) {
      setTimeout(() => {
        this.validityEndPeriod = null;
        this.quoteModel.quoteRequestData.quoteValidityEndDate = null;
      }, 200);
    }
    else if (this.quoteModel.quoteRequestData.quoteValidityEndDate != null)
      this.checkLaneValidityType();
  }

  setEndDate(e: NgbDateStruct) {

    var dt = new Date(e.year, e.month, e.day - 1);
    var endDate = new Date();

    switch (this.quoteModel.quoteRequestData.quoteValidityPeriod) {
      case QuoteRequestValidityOptions["1Month"]:
        endDate = this.addMonths(dt, 1);
        this.validityEndPeriod = { year: endDate.getFullYear(), month: endDate.getMonth() + 1, day: endDate.getDate() };
        break;
      case QuoteRequestValidityOptions["3months"]:
        endDate = this.addMonths(dt, 3);
        this.validityEndPeriod = { year: endDate.getFullYear(), month: endDate.getMonth() + 1, day: endDate.getDate() };
        break;
      case QuoteRequestValidityOptions["6months"]:
        endDate = this.addMonths(dt, 6);
        this.validityEndPeriod = { year: endDate.getFullYear(), month: endDate.getMonth() + 1, day: endDate.getDate() };
        break;
      case QuoteRequestValidityOptions["1year"]:
        endDate = this.addMonths(dt, 12);
        this.validityEndPeriod = { year: endDate.getFullYear(), month: endDate.getMonth() + 1, day: endDate.getDate() };
        break;
      case QuoteRequestValidityOptions.Other:
        this.validityEndPeriod = null;
        break;
    }

    if (this.validityEndPeriod == null) {
      this.quoteModel.quoteRequestData.quoteValidityEndDate = null;
    }
    else {
      this.quoteModel.quoteRequestData.quoteValidityEndDate = new Date(this.validityEndPeriod.year, this.validityEndPeriod.month - 1, this.validityEndPeriod.day);
      
    }
  }

  isDisableEndDate() {
    return this.quoteModel.quoteRequestData.quoteValidityPeriod != QuoteRequestValidityOptions.Other;
  }

  isLeapYear(year) {
    return (((year % 4 === 0) && (year % 100 !== 0)) || (year % 400 === 0));
  }

  getDaysInMonth(year, month) {
    return [31, (this.isLeapYear(year) ? 29 : 28), 31, 30, 31, 30, 31, 31, 30, 31, 30, 31][month];
  }

  addMonths(date, value) {
    var d = new Date(date), n = date.getDate();
    d.setDate(1);
    d.setMonth(d.getMonth() + value);

    if ((n == this.getDaysInMonth(date.getFullYear(), date.getMonth())) && (this.getDaysInMonth(d.getFullYear(), d.getMonth()) == 31 || this.getDaysInMonth(d.getFullYear(), d.getMonth()) == 29)) {
      d.setDate(this.getDaysInMonth(d.getFullYear(), d.getMonth()));
    }
    else {
      d.setDate(Math.min(n, this.getDaysInMonth(d.getFullYear(), d.getMonth())));
    }
    return d;
  }

  onCustomBrokerageSelectionChange(value) {
    this.quoteModel.quoteRequestData.customesBrokerage = value;
    this.checkLaneBrokerageType();
  }

  checkLaneValidityType() {
    var self = this;
    var validityTypeMismatch = false;

    if (this.quoteTypeSelectedValue != this.oneTimeShipment && this.quoteModel.airFreightShipmentDetail.length > 0 && this.quoteModel.airFreightShipmentDetail[0].serviceTypes != null) {

      for (var i = 0; i < this.quoteModel.airFreightShipmentDetail.length; i++) {

        if ((this.quoteModel.airFreightShipmentDetail[i].quoteValidityStartDate != self.quoteModel.quoteRequestData.quoteValidityStartDate)
          || (this.quoteModel.airFreightShipmentDetail[i].quoteValidityEndDate != self.quoteModel.quoteRequestData.quoteValidityEndDate)
          || (this.quoteModel.airFreightShipmentDetail[i].quoteValidityPeriod != self.quoteModel.quoteRequestData.quoteValidityPeriod)) {
          validityTypeMismatch = true;
          break;
        }
      };

      if (validityTypeMismatch) {
        this.sourceValidityType = true;
        this.sourceServiceType = false;
        this.sourceTermsOfSales = false;
        this.sourceBrokerageType = false;
        this.customServiceOverLay.show();
      }
    }
  }
  currencyValueChanged(event) {
      let input = event.target.value;
      this.currencySelected = false;
      if (this.currencyConversionData !== null && this.currencyConversionData !== undefined &&
          this.currencyConversionData.length > 0) {
          this.currencyList = this.currencyConversionData.filter(currencyData => currencyData.countryName === input.trim().toUpperCase() ||
              currencyData.localCurrencyCode === input.trim().toUpperCase() || currencyData.currencyDescription === input.trim().toUpperCase());
          if (this.currencyList && this.currencyList.length > 0) {
              this.suggestedCurrency = this.currencyList[0].localCurrencyCode;
              this.conversionFactor = this.currencyList[0].localConversionToUsdAmount;
              this.localeCodes = this.currencyList[0].localeCodes;
          }
      }
  }

  filterCurrency(value: string) {
    const filterValue = value.toLowerCase();
    return this.currencyList.filter(currency => currency.code.toLowerCase().indexOf(filterValue) > -1);
  }

  selectCurrency() {
      if (this.previouslySelectedCurrency !== this.suggestedCurrency) {
          this.currencySetDefault = false;
      }
      this.selectedCurrency = this.suggestedCurrency;
      this.previouslySelectedCurrency = this.suggestedCurrency;
      this.currencyList = [];
      this.currencySelected = true;
      this.shipmentValuesfocusOut();
  }

  shipmentValuesfocusOut() {

    if (this.quoteModel.quoteRequestData.shipmentInsuranceAmount  != "")  
     this.quoteModel.quoteRequestData.shipmentInsuranceAmount = (parseFloat(parseFloat(this.quoteModel.quoteRequestData.shipmentInsuranceAmount.toString()).toFixed(2))).toString();

    if (this.quoteModel.quoteRequestData.shipmentInsuranceAmount != "" && this.localeCodes != "") {      
      this.quoteModel.quoteRequestData.shipmentInsuranceAmount = (parseInt(this.quoteModel.quoteRequestData.shipmentInsuranceAmount.replace(/,/g, ""))).toLocaleString(this.localeCodes);
    }
  }

  onNavigateForInCoterms() {   
   window.open(ApplicationUrls[2].viewIncoterms, "_blank");
  }

  setModelValues() {
    this.quoteModel.quoteRequestData.quoteTypeCode = this.quoteTypeSelectedValue;
    this.quoteModel.quoteRequestData.defaultCurrency = !this.suggestedCurrency ? this.selectedCurrency : this.suggestedCurrency;
    this.setQuoteAttachment();
  }

  /* START Upload document*/

  setupFileUpload() {
    this.uploadURL = this.quoteService.getFileUploadURL();

    this.uploader = new FileUploader({
      url: this.uploadURL,
      autoUpload: true,
      allowedMimeType: ['application/pdf', 'application/zip', 'application/x-zip-compressed', 'application/x-zip',
        'application/vnd.ms-powerpoint', 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
        'application/vnd.ms-excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'application/vnd.ms-outlook', 'application/rtf', 'application/vnd.ms-xpsdocument',
        'application/vnd.ms-excel.sheet.macroEnabled.12', 'application/xml+html', 'application/xml','text/plain',
        'image/bmp', 'image/gif', 'image/jpeg', 'image/jpg', 'image/png', 'text/csv', 'image/gif', 'image/tiff'
        ]
    });

    this.hasBaseDropZoneOver = false;

    this.uploader.response.subscribe(
      data => {
        console.log(data);
      },
      error => {
        console.log(error);
      });

    this.uploader.onSuccessItem = (item: any, response: any, status: any, headers: any) => {
      if (item) {
        item.formData = { 'label': this.uploadLabelOptions[0].value, 'documentKey': response };
      }
    };

    this.uploader.onCompleteItem = (item: any, response: any, status: any, headers: any) => {

    };

    this.uploader.onErrorItem = (item: any, response: any, status: any, headers: any) => {

    };

    this.uploader.onWhenAddingFileFailed = (item: any, filter: any, options: any) => {

    };

    this.uploader.onAfterAddingFile = (item: any) => {
      item.withCredentials = false;
    };
  }

  onFileRemove(item: FileItem) {
    item.remove();
  }

  removeFileInfoFromSavedData(item: QuoteAttachment) {
    var index = this.getIndexOfItem(item);
    if (index != -1) {
      this.savedUplodDocuments.splice(index, 1);
    }
  }

  getIndexOfItem(value) {
    return typeof value === 'number' ? value : this.savedUplodDocuments.indexOf(value);
  }

  fileOverBase(e: any): void {
    this.hasBaseDropZoneOver = e;
  }

  setQuoteAttachment() {
    this.quoteModel.quoteRequestData.quoteAttachment = [];

    for (let item of this.savedUplodDocuments) {
      this.quoteModel.quoteRequestData.quoteAttachment.push(item);
    }

    for (let item of this.uploader.queue) {
      if (item.isSuccess) {
        this.quoteModel.quoteRequestData.quoteAttachment.push({
          fileName: item.file.name, fileSize: item.file.size,
          fileOpportunityProductDescriptionText: item.formData.label != undefined ? item.formData.label : '', availableIndicator: '1', fileCategoryCode: fileCategoryCode,
          fileLocationName: '', filePathName: item.formData.documentKey != undefined ? item.formData.documentKey : '', fileStatusCode: '1', financialContentIndicator: ''
        });
      }
    }
  }

  getSavedAttachment(categoryCode) {
    return this.savedUplodDocuments.filter(x => x.fileCategoryCode == (categoryCode ?categoryCode:fileCategoryCode));
  }

  /* END Upload document */
}
