import { async, ComponentFixture, TestBed, getTestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { MatFormFieldModule } from '@angular/material';
import { DataTableModule } from 'angular-6-datatable';
import { FormsModule, ReactiveFormsModule, FormGroup, FormBuilder, FormControl } from '@angular/forms';
import { NgbTooltipConfig } from '@ng-bootstrap/ng-bootstrap';

import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA, NgModule, Component, OnInit } from '@angular/core';
import { NgbDatepickerConfig, NgbDateAdapter, NgbInputDatepicker, NgbDatepickerI18n, NgbDateStruct, NgbDateParserFormatter } from '@ng-bootstrap/ng-bootstrap';
import { MatInputModule, MatAutocompleteModule, MatButtonModule, MatProgressSpinnerModule } from '@angular/material';
import { state } from '@angular/animations/src/animation_metadata';
import { combineAll } from 'rxjs/internal/operators/combineAll';
import { of, Observable } from "rxjs";
import { map, startWith, retry } from 'rxjs/operators';

import { QuoteOverViewComponent } from './quoteoverview.component';
import { NgbDateFormatter } from '@app/shared/helper/ngb-datepicker-formatter.component';
import { SharedModule } from '@app/shared/shared.module';
import { ConfigService } from '@app/shared/services/shared/config.service';
import { GeaographyMockAPI } from '@app/shared/services/mock/geoGraphyMock.service';
import { QuoteMockAPI } from '@app/shared/services/mock/quoteMock.service';
import { RoutingKey } from '@app/shared/services/shared/config.const';
import { UtilitiesService } from '@app/shared/services/shared/utilities.service';
import { QuoteAPI, GeaographyAPI } from '@app/shared/services';
import { ICurrencyData } from '@app/models';
import { ApplicationUrls } from '@app/shared/services/shared/config.const';
import { NgbCalendar, NgbCalendarGregorian } from '@ng-bootstrap/ng-bootstrap/datepicker/ngb-calendar';

export class NgbStringAdapter extends NgbDateAdapter<Date> {

  fromModel(date: Date): NgbDateStruct {
    return date ? {
      year: date.getFullYear(),
      month: date.getMonth() + 1,
      day: date.getDate()
    } : null;
  }

  toModel(date: NgbDateStruct): Date {
    return date ? new Date(date.year, date.month - 1, date.day) : null;
  }
}

describe('QuoteOverViewComponent', () => {
  let component: QuoteOverViewComponent;
  let fixture: ComponentFixture<QuoteOverViewComponent>;
  let fb: FormBuilder;
  let geoGraphyService: GeaographyAPI<any>;
  let quoteService: QuoteAPI<any>;
  let injector;

  
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule,
        DataTableModule,
        RouterTestingModule,
        MatInputModule,
        MatAutocompleteModule,
        MatButtonModule,
        MatProgressSpinnerModule,
        FormsModule,
        ReactiveFormsModule,
        SharedModule,
      ],
      declarations: [QuoteOverViewComponent,
      ],
      providers: [UtilitiesService, NgbInputDatepicker, NgbTooltipConfig,
        NgbDatepickerI18n, NgbDatepickerConfig, ConfigService, QuoteAPI,
        NgbDateParserFormatter, NgbDateFormatter,
        { provide: NgbDateAdapter, useClass: NgbStringAdapter },
        { provide: NgbCalendar, useClass: NgbCalendarGregorian }
      ],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA]
    })
      .compileComponents();

    injector = getTestBed();
    quoteService = injector.get(QuoteAPI);
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(QuoteOverViewComponent);
    component = fixture.componentInstance;
    component.quoteModel = quoteService.getQuoteDetails();
    fixture.detectChanges();
  });


  ////The Dashboard component should be define.
  it("should have a defined component ", () => {
    expect(component).toBeDefined();
  });

  ////The Dashboard component should exist.
  it('should have a Component', () => {
    expect(component).toBeTruthy();
  });


  it('isActiveOneTimeShipment', () => {
    component.oneTimeShipment = 1;
    component.quoteTypeSelectedValue = 1;
    component.isActiveOneTimeShipment();
    expect(component.quoteTypeSelectedValue).toEqual(1);
  });


  it('isActiveLongTimeShipment', () => {
    component.longTermShipment = 2;
    component.quoteTypeSelectedValue = 2;
    component.isActiveLongTimeShipment();
    expect(component.quoteTypeSelectedValue).toEqual(2);
  });



  it('OneTimeShipment success selection', () => {
    component.oneTimeShipment = 1;
    component.quoteTypeSelectedValue = 0;
    component.onOneTimeShipmentSelect(component.oneTimeShipment);
    expect(component.quoteTypeSelectedValue).toEqual(1);

  });

  it('OneTimeShipment already selected', () => {
    component.oneTimeShipment = 1;
    component.quoteTypeSelectedValue = 1;
    component.onOneTimeShipmentSelect(component.oneTimeShipment);
    expect(component.quoteTypeSelectedValue).toEqual(1);

  });

  it('LongTimeShipment success selection', () => {
    component.longTermShipment = 2;
    component.quoteTypeSelectedValue = 0;
    component.onLongTimeShipmentSelect(component.longTermShipment);
    expect(component.quoteTypeSelectedValue).toEqual(2);
  });

  it('LongTimeShipment already selected', () => {
    component.longTermShipment = 2;
    component.quoteTypeSelectedValue = 2;
    component.onLongTimeShipmentSelect(component.longTermShipment);
    expect(component.quoteTypeSelectedValue).toEqual(2);
  });

  it('set end date', () => {
    component.quoteModel.quoteRequestData.quoteValidityPeriod = '1 month';
    component.validityStartPeriod = { year: 2018, month: 11, day: 2 };
    component.validityStartPeriod.month = component.validityStartPeriod.month - 1;
    component.setEndDate(component.validityStartPeriod);
    expect(component.validityEndPeriod).toEqual({ year: 2018, month: 12, day: 1 });

    component.quoteModel.quoteRequestData.quoteValidityPeriod = '3 months';
    component.validityStartPeriod = { year: 2018, month: 11, day: 2 };
    component.validityStartPeriod.month = component.validityStartPeriod.month - 1;
    component.setEndDate(component.validityStartPeriod);
    expect(component.validityEndPeriod).toEqual({ year: 2019, month: 2, day: 1 });

    component.quoteModel.quoteRequestData.quoteValidityPeriod = '6 months';
    component.validityStartPeriod = { year: 2018, month: 11, day: 2 };
    component.validityStartPeriod.month = component.validityStartPeriod.month - 1;
    component.setEndDate(component.validityStartPeriod);
    expect(component.validityEndPeriod).toEqual({ year: 2019, month: 5, day: 1 });

    component.quoteModel.quoteRequestData.quoteValidityPeriod = '1 year';
    component.validityStartPeriod = { year: 2018, month: 11, day: 2 };
    component.validityStartPeriod.month = component.validityStartPeriod.month - 1;
    component.setEndDate(component.validityStartPeriod);
    expect(component.validityEndPeriod).toEqual({ year: 2019, month: 11, day: 1 });

    component.quoteModel.quoteRequestData.quoteValidityPeriod = 'Other';
    component.validityStartPeriod = { year: 2018, month: 11, day: 2 };
    component.setEndDate(component.validityStartPeriod);
    expect(component.validityEndPeriod).toEqual(null);

  });

  it('Start date selection', () => {
    component.quoteModel.quoteRequestData.quoteValidityPeriod = '1 month';
    component.validityStartPeriod = { year: 2018, month: 11, day: 2 };
    component.onStartDateSelect(component.validityStartPeriod);
    expect(component.validityEndPeriod).toEqual({ year: 2018, month: 12, day: 1 });
  });

  it('Request Validity Options Change', () => {
    component.quoteModel.quoteRequestData.quoteValidityPeriod = '1 month';
    component.validityStartPeriod = { year: 2018, month: 11, day: 2 };
    component.validityStartPeriod.month = component.validityStartPeriod.month - 1;
    component.onRequestValidityOptionsChange(component.validityStartPeriod);
    expect(component.validityEndPeriod).toEqual({ year: 2018, month: 12, day: 1 });
  });

  it('End date is disable or not', () => {
    component.quoteModel.quoteRequestData.quoteValidityPeriod = '1 month';
    component.isDisableEndDate();
    expect(component.quoteModel.quoteRequestData.quoteValidityPeriod).toEqual('1 month');
  });

  it('End date selection', () => {
    component.quoteModel.quoteRequestData.quoteValidityPeriod = '1 month';
    component.validityStartPeriod = { year: 2018, month: 11, day: 2 };
    component.validityEndPeriod = { year: 2018, month: 11, day: 1 };
    component.onEndDateSelect(component.validityEndPeriod);
    expect(component.validityEndPeriod).toEqual({ year: 2018, month: 11, day: 1 });
  });

  it('on custom brokerage radion button change', () => {
    component.quoteModel.quoteRequestData.customesBrokerage = 'cb001';
    component.onCustomBrokerageSelectionChange('cb002');
    expect(component.quoteModel.quoteRequestData.customesBrokerage).toEqual('cb002');
  });

  it('Check external url of Incoterms', () => {
    component.onNavigateForInCoterms();
    expect(ApplicationUrls[2].viewIncoterms).toEqual('http://ups-scs.com/tools/');
  });

  it('Check shipment insurance value with decimal upto 2', () => {
    component.quoteModel.quoteRequestData.shipmentInsuranceAmount = "111.911";
    component.shipmentValuesfocusOut();
    expect(component.quoteModel.quoteRequestData.shipmentInsuranceAmount).toEqual('111.91');
  });

  it('Check shipment insurance value with locale changes', () => {
    component.quoteModel.quoteRequestData.shipmentInsuranceAmount = "100000";
    component.localeCodes = "en-in";
    component.shipmentValuesfocusOut();
    expect(component.quoteModel.quoteRequestData.shipmentInsuranceAmount).toEqual('1,00,000');

  });

  it('checkquote  model values', () => {
    component.quoteModel.quoteRequestData.shipmentInsuranceAmount = "100000";
    component.localeCodes = "en-in";
    component.shipmentValuesfocusOut();
    expect(component.quoteModel.quoteRequestData.shipmentInsuranceAmount).toEqual('1,00,000');

  });

  it("check upload label option", () => {

    component.isPricingTeam = true;
    component.uploadLabelOptions = [];
    component.ngOnInit();
    expect(component.uploadLabelOptions[0].name).toEqual('Pricing/Solutions Info');
  });


});
