import { DomSanitizer } from '@angular/platform-browser';
import { ShipmentUnitType } from '@app/shared/enums/ShipmentUnitType';
import { ShipmentPeriod } from '@app/shared/enums/ShipmentPeriod';
import { ShipmentFrequencyPeriod } from '@app/shared/enums/ShipmentFrequencyPeriod';
import { ShipmentType } from '@app/shared/enums/ShipmentType';
import {
  AirFreightShipmentDetail,
  ShipmentWeightByPeice
} from '@app/models/quotes/airfreightshipment-detail';
import {
  async,
  ComponentFixture,
  TestBed,
  getTestBed
} from '@angular/core/testing';
import {
  HttpClientTestingModule,
  HttpTestingController
} from '@angular/common/http/testing';
import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterTestingModule } from '@angular/router/testing';

import { QuoteLanesShipmentComponent } from './quotelanesshipment.component';
import { UtilitiesService, QuoteAPI, GeaographyAPI } from '@app/shared/services';
import { ConfigService } from '@app/shared/services/shared/config.service';
import { ShipmentUnitName } from '@app/shared/enums/ShipmentUnitName';
import { UnitConverterFactory } from '@app/shared/helper/shipment-uom/UnitConverterFactory';
import { IUnitConverter } from '@app/shared/helper/shipment-uom/converter/IUnitConverter';
import { NoUnitConversion } from '@app/shared/helper/shipment-uom/converter/NoUnitConversion';
import { UnitConverter } from '@app/shared/helper/shipment-uom/converter/UnitConverter';

export class MockUnitConversion extends UnitConverter {
  convert(...value: number[]): number[] {
    return [10];
  }
}

export class MockUnitConverterFactory extends UnitConverterFactory {
  createUnitConverter(
    from: ShipmentUnitName,
    to: ShipmentUnitName
  ): IUnitConverter {
    return new MockUnitConversion();
  }
}

describe('quotelanesshipmentComponent', () => {
  let component: QuoteLanesShipmentComponent;
  let fixture: ComponentFixture<QuoteLanesShipmentComponent>;
  let injector;
  const keys = Object.keys;
  let mockConverter: IUnitConverter;
  let mockFactory: MockUnitConverterFactory;
  let mockSanitizer: any;
  let sanitizerSpy: any;

  beforeEach(async(() => {
    mockConverter = new MockUnitConversion();
    mockFactory = new MockUnitConverterFactory();
    sanitizerSpy = jasmine.createSpy('mockSanitizer');
    mockSanitizer = {
      bypassSecurityTrustStyle: sanitizerSpy,
      sanitize: () => 'safeString',
    };
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, HttpClientTestingModule],
      declarations: [QuoteLanesShipmentComponent],
      providers: [
        UtilitiesService,
        ConfigService,
        {
          provide: UnitConverterFactory,
          useValue: mockFactory
        },
        {
          provide: DomSanitizer,
          useValue: mockSanitizer
        },
        QuoteAPI,
        GeaographyAPI
      ],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA]
    }).compileComponents();
    injector = getTestBed();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(QuoteLanesShipmentComponent);
    component = fixture.componentInstance;
    mockFactory = TestBed.get(UnitConverterFactory);
    mockSanitizer = TestBed.get(DomSanitizer);
    fixture.detectChanges();
  });

  // The component should be define.
  it('should have a defined component ', () => {
    expect(component).toBeDefined();
  });
  it('should have a component ', () => {
    expect(component).toBeTruthy();
  });
  describe('initializeShipmentDetails', () => {
    it('should have a shipmentDetails with default values when shipment details is undefined', () => {
      component.shipmentDetails = undefined;
      component.initializeShipmentDetails();
      expect(component.shipmentDetails).toBeDefined();
      expect(
        component.shipmentDetails.shipmentMethod ===
          component.shipmentTypes.WeightPerShipment
      ).toBeTruthy();
      expect(
        component.shipmentDetails.shipmentFrequencyTimePeriodDescriptionText ===
          component.shipmentFrequencyPeriods.Year
      ).toBeTruthy();
      expect(
        component.shipmentDetails.shipmentActualWeightUnitOfMeasureTypeCode ===
          component.shipmentUnitNames.Kg
      ).toBeTruthy();
      expect(
        component.shipmentDetails
          .shipmentDimensionalWeightUnitOfMeasureTypeCode ===
          component.shipmentUnitNames.Kg
      ).toBeTruthy();
      expect(
        component.shipmentDetails.shipmentWeightByPeice.length
      ).toBeGreaterThan(0);
    });

    it('should have a shipmentDetails with provided values if shipment details not undefined', () => {
      component.shipmentDetails = new AirFreightShipmentDetail();
      component.shipmentDetails.shipmentMethod =
        component.shipmentTypes.TypicalCargo;
      component.shipmentDetails.shipmentFrequencyTimePeriodDescriptionText =
        component.shipmentFrequencyPeriods.Month;
      component.shipmentDetails.shipmentActualWeightUnitOfMeasureTypeCode =
        component.shipmentUnitNames.Lb;
      component.shipmentDetails.shipmentDimensionalWeightUnitOfMeasureTypeCode =
        component.shipmentUnitNames.Cbf;
      component.shipmentDetails.shipmentWeightByPeice = [
        new ShipmentWeightByPeice(),
        new ShipmentWeightByPeice()
      ];

      component.initializeShipmentDetails();
      expect(component.shipmentDetails).toBeDefined();
      expect(
        component.shipmentDetails.shipmentMethod ===
          component.shipmentTypes.TypicalCargo
      ).toBeTruthy();
      expect(
        component.shipmentDetails.shipmentFrequencyTimePeriodDescriptionText ===
          component.shipmentFrequencyPeriods.Month
      ).toBeTruthy();
      expect(
        component.shipmentDetails.shipmentActualWeightUnitOfMeasureTypeCode ===
          component.shipmentUnitNames.Lb
      ).toBeTruthy();
      expect(
        component.shipmentDetails
          .shipmentDimensionalWeightUnitOfMeasureTypeCode ===
          component.shipmentUnitNames.Cbf
      ).toBeTruthy();
      expect(
        component.shipmentDetails.shipmentWeightByPeice.length === 2
      ).toBeTruthy();
    });

    it('should set provided shipmentDetails to default values when not undefined but values not provided', () => {
      component.shipmentDetails = new AirFreightShipmentDetail();

      component.initializeShipmentDetails();
      expect(component.shipmentDetails).toBeDefined();
      expect(
        component.shipmentDetails.shipmentMethod ===
          component.shipmentTypes.WeightPerShipment
      ).toBeTruthy();
      expect(
        component.shipmentDetails.shipmentFrequencyTimePeriodDescriptionText ===
          component.shipmentFrequencyPeriods.Year
      ).toBeTruthy();
      expect(
        component.shipmentDetails.shipmentActualWeightUnitOfMeasureTypeCode ===
          component.shipmentUnitNames.Kg
      ).toBeTruthy();
      expect(
        component.shipmentDetails
          .shipmentDimensionalWeightUnitOfMeasureTypeCode ===
          component.shipmentUnitNames.Kg
      ).toBeTruthy();
      expect(
        component.shipmentDetails.shipmentWeightByPeice.length
      ).toBeGreaterThan(0);
    });
    it('should call calculate dim weight when shipment piece is empty', () => {
      spyOn(component, 'calculateDimWeightForPiece');
      component.shipmentDetails = new AirFreightShipmentDetail();
      component.initializeShipmentDetails();
      expect(component.calculateDimWeightForPiece).toHaveBeenCalled();
    });
  });
  describe('addWeight', () => {
    it('should add a new package with default values to the shipping details and calculate dim weight for it', () => {
      component.shipmentDetails = new AirFreightShipmentDetail();
      component.shipmentDetails.shipmentWeightByPeice = [];
      component.addWeight();
      expect(
        component.shipmentDetails.shipmentWeightByPeice.length
      ).toBeGreaterThan(0);
      expect(
        component.shipmentDetails.shipmentWeightByPeice[0]
          .shipmentWeightUnitOfMeasureTypeCode ===
          component.shipmentUnitNames.Kg
      );
      expect(
        component.shipmentDetails.shipmentWeightByPeice[0]
          .shipmentDimensionalUnitOfMeasureTypeCode ===
          component.shipmentUnitNames.Kg
      );
    });
  });
  describe('removeWeight', () => {
    it('should remove a package from given index from shipmentDetails.shipmentWeightbypeice', () => {
      component.shipmentDetails = new AirFreightShipmentDetail();
      component.shipmentDetails.shipmentWeightByPeice = [
        new ShipmentWeightByPeice()
      ];
      const calculateTotalWeightSpy = spyOn(component, 'calculateTotalWeight').and.callFake(() => {});
      component.removeWeight(0);
      expect(
        component.shipmentDetails.shipmentWeightByPeice.length === 0
      ).toBeTruthy();
      expect(calculateTotalWeightSpy).toHaveBeenCalled();
    });
  });

  describe('onShipmentTypeChange', () => {
    it(`should set frequency period to times a year for typical cargo and weight per shipment
    and volume sent a year for weight over time`, () => {
      const shipmentTypeKeys = keys(component.shipmentTypes);
      shipmentTypeKeys.forEach(item => {
        component.shipmentDetails.shipmentMethod = ShipmentType[item];
        component.onShipmentTypeChange();
        if (
          ShipmentType[item] === ShipmentType.TypicalCargo ||
          ShipmentType[item] === ShipmentType.WeightPerShipment
        ) {
          expect(
            component.shipmentDetails
              .shipmentFrequencyTimePeriodDescriptionText ===
              ShipmentFrequencyPeriod.Year
          ).toBeTruthy();
        } else {
          expect(
            component.shipmentDetails
              .shipmentFrequencyTimePeriodDescriptionText ===
              ShipmentPeriod.Year
          ).toBeTruthy();
        }
      });
    });
  });
  describe('getUnitsByType', () => {
    it(`should filter shipment unit names by given types`, () => {
      const shipmentUnitTypes = [
        ShipmentUnitType.Metric,
        ShipmentUnitType.Volume
      ];
      const vals = component.getUnitsByType(...shipmentUnitTypes);
      expect(vals.length === 4).toBeTruthy();
      expect(
        vals.includes(ShipmentUnitName.Cm) &&
          vals.includes(ShipmentUnitName.Inches) &&
          vals.includes(ShipmentUnitName.Cbf) &&
          vals.includes(ShipmentUnitName.Cbm)
      ).toBeTruthy();
    });
  });
  describe('isUnitOfType', () => {
    it(`should check whether the given unit is of any of the given types`, () => {
      const shipmentUnitTypes = [
        ShipmentUnitType.Metric,
        ShipmentUnitType.Volume
      ];
      const units = keys(component.shipmentUnitNames);
      units.forEach(unit => {
        switch (ShipmentUnitName[unit]) {
          case ShipmentUnitName.Cm:
          case ShipmentUnitName.Inches:
          case ShipmentUnitName.Cbf:
          case ShipmentUnitName.Cbm:
            expect(
              component.isUnitOfType(
                ShipmentUnitName[unit],
                ...shipmentUnitTypes
              )
            ).toBeTruthy();
            break;
          default:
            expect(
              component.isUnitOfType(
                ShipmentUnitName[unit],
                ...shipmentUnitTypes
              )
            ).toBeFalsy();
            break;
        }
      });
    });
  });
  describe('checkForDecimalWithPrecision', () => {
    it(`should return empty for non decimal, return value with precision
    less than or equal to two  for valid decimals`, () => {
      const invalid = 'e';
      const valid = '3.434';
      const invalidResult = component.checkForDecimalWithPrecision(invalid);
      const validResult = component.checkForDecimalWithPrecision(valid);
      expect(invalidResult === '').toBeTruthy();
      const decimals = validResult.split('.');
      expect(decimals.length === 1 || decimals[1].length <= 2).toBeTruthy();
    });
  });
  describe('setPieceTwoNumberDecimal', () => {
    it(`should callcheckfordecimalwithprecision function and update the members of pkg:
        weight, height, length, width, shipmentVolumeQuantity, shipmentActualWeightQuantity, quantity`, () => {
      const pkg = new ShipmentWeightByPeice();
      pkg.height = '1';
      pkg.width = '2';
      pkg.length = '3';
      pkg.weight = '4';
      pkg.shipmentVolumeQuantity = '5';
      pkg.shipmentActualWeightQuantity = '6';
      pkg.quantity = '7';
      const checkForDecimalWithPrecisionSpy = spyOn(
        component,
        'checkForDecimalWithPrecision'
      ).and.callThrough();
      const spy9 = spyOn(component, 'calculateDimWeightForPiece');
      component.setPieceTwoNumberDecimal(pkg);
      expect(checkForDecimalWithPrecisionSpy).toHaveBeenCalledWith(pkg.weight);
      expect(checkForDecimalWithPrecisionSpy).toHaveBeenCalledWith(pkg.quantity);
      expect(checkForDecimalWithPrecisionSpy).toHaveBeenCalledWith(pkg.length);
      expect(checkForDecimalWithPrecisionSpy).toHaveBeenCalledWith(pkg.width);
      expect(checkForDecimalWithPrecisionSpy).toHaveBeenCalledWith(pkg.height);
      expect(checkForDecimalWithPrecisionSpy).toHaveBeenCalledWith(pkg.shipmentActualWeightQuantity);
      expect(checkForDecimalWithPrecisionSpy).toHaveBeenCalledWith(pkg.shipmentVolumeQuantity);
      expect(spy9).toHaveBeenCalledWith(pkg);
    });
  });
  describe('setShpDetTwoNumberDecimal', () => {
    it(`should callcheckfordecimalwithprecision function and update the members of shipmentDetails:
    shipmentActualWeightQuantity, shipmentDimensionalWeightQuantity`, () => {
      const shp = new AirFreightShipmentDetail();
      shp.shipmentActualWeightQuantity = '1';
      shp.shipmentDimensionalWeightQuantity = '2';
      const checkForDecimalWithPrecisionSpy = spyOn(
        component,
        'checkForDecimalWithPrecision'
      ).and.callThrough();
      component.setShpDetTwoNumberDecimal(shp);
      expect(checkForDecimalWithPrecisionSpy).toHaveBeenCalledWith(shp.shipmentActualWeightQuantity);
      expect(checkForDecimalWithPrecisionSpy).toHaveBeenCalledWith(shp.shipmentDimensionalWeightQuantity);
    });
  });
  describe('getdimWeightLabel', () => {
    it(`should return appropriate label according to shipment details dimweight unit`, () => {
      component.shipmentDetails = new AirFreightShipmentDetail();
      component.shipmentDetails.shipmentDimensionalWeightUnitOfMeasureTypeCode =
        ShipmentUnitName.Cbf;
      expect(
        component.getdimWeightLabel() === ShipmentUnitType.Volume
      ).toBeTruthy();
      component.shipmentDetails.shipmentDimensionalWeightUnitOfMeasureTypeCode =
        ShipmentUnitName.Kg;
      expect(
        component.getdimWeightLabel() === ShipmentUnitType.Weight
      ).toBeTruthy();
    });
  });
  describe('getValuesForUnitConversion', () => {
    it(`should return appropriate values according to package dimensional unit`, () => {
      const pkg = new ShipmentWeightByPeice();
      pkg.height = '1';
      pkg.width = '2';
      pkg.length = '3';
      pkg.weight = '4';
      pkg.shipmentVolumeQuantity = '5';
      const units = keys(ShipmentUnitName);
      units.forEach(unit => {
        pkg.shipmentDimensionalUnitOfMeasureTypeCode = ShipmentUnitName[unit];
        const values = component.getValuesForUnitConversion(pkg);
        switch (ShipmentUnitName[unit]) {
          case ShipmentUnitName.Cm:
          case ShipmentUnitName.Inches:
            expect(values.length === 3).toBeTruthy();
            expect(values[0] === parseFloat(pkg.length)).toBeTruthy();
            expect(values[1] === parseFloat(pkg.width)).toBeTruthy();
            expect(values[2] === parseFloat(pkg.height)).toBeTruthy();
            break;
          case ShipmentUnitName.Cbf:
          case ShipmentUnitName.Cbm:
            expect(values.length === 1).toBeTruthy();
            expect(
              values[0] === parseFloat(pkg.shipmentVolumeQuantity)
            ).toBeTruthy();
            break;
          case ShipmentUnitName.Kg:
          case ShipmentUnitName.Lb:
            expect(values.length === 1).toBeTruthy();
            expect(values[0] === parseFloat(pkg.weight)).toBeTruthy();
            break;
        }
      });
    });
    it(`should return empty if any of the values are not numeric`, () => {
      const pkg = new ShipmentWeightByPeice();
      pkg.height = '1';
      pkg.width = '';
      pkg.length = '3';
      pkg.weight = '';
      pkg.shipmentVolumeQuantity = '';
      const units = keys(ShipmentUnitName);
      units.forEach(unit => {
        pkg.shipmentDimensionalUnitOfMeasureTypeCode = ShipmentUnitName[unit];
        const values = component.getValuesForUnitConversion(pkg);
        switch (ShipmentUnitName[unit]) {
          case ShipmentUnitName.Cm:
          case ShipmentUnitName.Inches:
            expect(values.length === 0).toBeTruthy();
            break;
          case ShipmentUnitName.Cbf:
          case ShipmentUnitName.Cbm:
            expect(values.length === 0).toBeTruthy();
            break;
          case ShipmentUnitName.Kg:
          case ShipmentUnitName.Lb:
            expect(values.length === 0).toBeTruthy();
            break;
        }
      });
    });
  });
  describe('calculateDimWeightForPiece', () => {
    let calculateTotalWeightSpy;
    beforeEach(() => {
      calculateTotalWeightSpy = spyOn(component, 'calculateTotalWeight').and.callFake(() => {});
    });
    it(`should get the values and if the values are not empty, create appropriate converter and convert unit for the value.`, () => {
      const getValuesForUnitConversionSpy = spyOn(
        component,
        'getValuesForUnitConversion'
      ).and.returnValues([1, 2, 3]);
      const createUnitConverterSpy = spyOn(mockFactory, 'createUnitConverter').and.returnValue(
        mockConverter
      );
      const doConversionSpy = spyOn(mockConverter, 'doConversion').and.returnValue([10]);
      const pkg = new ShipmentWeightByPeice();
      component.calculateDimWeightForPiece(pkg);
      expect(getValuesForUnitConversionSpy).toHaveBeenCalledWith(pkg);
      expect(createUnitConverterSpy).toHaveBeenCalled();
      expect(doConversionSpy).toHaveBeenCalledWith(...[1, 2, 3]);
      expect(pkg.shipmentDimensionalWeightQuantity === '10').toBeTruthy();
      expect(calculateTotalWeightSpy).toHaveBeenCalled();
    });
    it(`shouldn't do anything but call calculatetotalweight if the values are empty.`, () => {
      const getValuesForUnitConversionSpy = spyOn(
        component,
        'getValuesForUnitConversion'
      ).and.returnValues([]);
      const createUnitConverterSpy = spyOn(mockFactory, 'createUnitConverter').and.returnValue(
        mockConverter
      );
      const doConversionSpy = spyOn(mockConverter, 'doConversion').and.returnValue([10]);
      const pkg = new ShipmentWeightByPeice();
      component.calculateDimWeightForPiece(pkg);
      expect(getValuesForUnitConversionSpy).toHaveBeenCalledWith(pkg);
      expect(createUnitConverterSpy).toHaveBeenCalledTimes(0);
      expect(doConversionSpy).toHaveBeenCalledTimes(0);
      expect(pkg.shipmentDimensionalWeightQuantity !== '10').toBeTruthy();
      expect(calculateTotalWeightSpy).toHaveBeenCalled();
    });
    it(`should not assign any value if converted value is empty.`, () => {
      const getValuesForUnitConversionSpy = spyOn(
        component,
        'getValuesForUnitConversion'
      ).and.returnValues([1, 2, 3]);
      const createUnitConverterSpy = spyOn(mockFactory, 'createUnitConverter').and.returnValue(
        mockConverter
      );
      const doConversionSpy = spyOn(mockConverter, 'doConversion').and.returnValue([]);
      const pkg = new ShipmentWeightByPeice();
      component.calculateDimWeightForPiece(pkg);
      expect(getValuesForUnitConversionSpy).toHaveBeenCalledWith(pkg);
      expect(createUnitConverterSpy).toHaveBeenCalled();
      expect(doConversionSpy).toHaveBeenCalledWith(...[1, 2, 3]);
      expect(pkg.shipmentDimensionalWeightQuantity === '10').toBeFalsy();
      expect(calculateTotalWeightSpy).toHaveBeenCalled();
    });
  });
  describe('calculateTotalWeight', () => {
    it(`should get the should set the total of shipment actual weight and dimensional weight if packages exist`, () => {
      const createUnitConverterSpy = spyOn(mockFactory, 'createUnitConverter').and.returnValue(
        mockConverter
      );
      const doConversionSpy = spyOn(mockConverter, 'doConversion').and.returnValues(
        [1], [1], [2], [2]);
      const checkForDecimalWithPrecisionSpy = spyOn(component, 'checkForDecimalWithPrecision').and.returnValue('4');
      const pkg1 = new ShipmentWeightByPeice();
      pkg1.shipmentActualWeightQuantity = '1';
      pkg1.shipmentDimensionalWeightQuantity = '2';
      pkg1.quantity = '2';
      pkg1.shipmentWeightUnitOfMeasureTypeCode = ShipmentUnitName.Kg;
      const pkg2 = new ShipmentWeightByPeice();
      pkg2.shipmentActualWeightQuantity = '1';
      pkg2.shipmentDimensionalWeightQuantity = '2';
      pkg2.quantity = '3';
      pkg2.shipmentWeightUnitOfMeasureTypeCode = ShipmentUnitName.Lb;
      component.shipmentDetails.shipmentWeightByPeice = [pkg1, pkg2];
      component.calculateTotalWeight();
      expect(createUnitConverterSpy).toHaveBeenCalledWith(pkg1.shipmentWeightUnitOfMeasureTypeCode, ShipmentUnitName.Kg);
      expect(createUnitConverterSpy).toHaveBeenCalledWith(pkg2.shipmentWeightUnitOfMeasureTypeCode, ShipmentUnitName.Kg);
      expect(createUnitConverterSpy).toHaveBeenCalledWith(pkg1.shipmentWeightUnitOfMeasureTypeCode, ShipmentUnitName.Kg);
      expect(createUnitConverterSpy).toHaveBeenCalledWith(pkg2.shipmentWeightUnitOfMeasureTypeCode, ShipmentUnitName.Kg);
      expect(doConversionSpy).toHaveBeenCalledWith(...[1]);
      expect(doConversionSpy).toHaveBeenCalledWith(...[1]);
      expect(doConversionSpy).toHaveBeenCalledWith(...[2]);
      expect(doConversionSpy).toHaveBeenCalledWith(...[2]);
      expect(checkForDecimalWithPrecisionSpy).toHaveBeenCalledWith('5');
      expect(checkForDecimalWithPrecisionSpy).toHaveBeenCalledWith('10');
      expect(component.shipmentDetails.shipmentActualWeightQuantity === '4').toBeTruthy();
      expect(component.shipmentDetails.shipmentDimensionalWeightQuantity === '4').toBeTruthy();
    });
    it(`should get the should not add to the total of shipment actual weight
    and dimensional weight if doconversion returned empty or quantity of pkg is invalid`, () => {
      const createUnitConverterSpy = spyOn(mockFactory, 'createUnitConverter').and.returnValue(
        mockConverter
      );
      const doConversionSpy = spyOn(mockConverter, 'doConversion').and.returnValues(
        [1], [], [2], [2]);
      const checkForDecimalWithPrecisionSpy = spyOn(component, 'checkForDecimalWithPrecision').and.returnValue('4');
      const pkg1 = new ShipmentWeightByPeice();
      pkg1.shipmentActualWeightQuantity = '1';
      pkg1.shipmentDimensionalWeightQuantity = '2';
      pkg1.quantity = '';
      pkg1.shipmentWeightUnitOfMeasureTypeCode = ShipmentUnitName.Kg;
      const pkg2 = new ShipmentWeightByPeice();
      pkg2.shipmentActualWeightQuantity = '1';
      pkg2.shipmentDimensionalWeightQuantity = '2';
      pkg2.quantity = '2';
      pkg2.shipmentWeightUnitOfMeasureTypeCode = ShipmentUnitName.Lb;
      component.shipmentDetails.shipmentWeightByPeice = [pkg1, pkg2];
      component.calculateTotalWeight();
      expect(createUnitConverterSpy).toHaveBeenCalledWith(pkg1.shipmentWeightUnitOfMeasureTypeCode, ShipmentUnitName.Kg);
      expect(createUnitConverterSpy).toHaveBeenCalledWith(pkg2.shipmentWeightUnitOfMeasureTypeCode, ShipmentUnitName.Kg);
      expect(createUnitConverterSpy).toHaveBeenCalledWith(pkg1.shipmentWeightUnitOfMeasureTypeCode, ShipmentUnitName.Kg);
      expect(createUnitConverterSpy).toHaveBeenCalledWith(pkg2.shipmentWeightUnitOfMeasureTypeCode, ShipmentUnitName.Kg);
      expect(doConversionSpy).toHaveBeenCalledWith(...[1]);
      expect(doConversionSpy).toHaveBeenCalledWith(...[1]);
      expect(doConversionSpy).toHaveBeenCalledWith(...[2]);
      expect(doConversionSpy).toHaveBeenCalledWith(...[2]);
      expect(checkForDecimalWithPrecisionSpy).toHaveBeenCalledWith('0');
      expect(checkForDecimalWithPrecisionSpy).toHaveBeenCalledWith('4');
      expect(component.shipmentDetails.shipmentActualWeightQuantity === '4').toBeTruthy();
      expect(component.shipmentDetails.shipmentDimensionalWeightQuantity === '4').toBeTruthy();
    });
  });
  describe('showPieceGadTooltip', () => {
    it(`should return false if check is true and actual weight < dim weight or
     check is false and actual weight < dim weight, else true`, () => {
      const pkg = new ShipmentWeightByPeice();
      pkg.shipmentActualWeightQuantity = `1`;
      pkg.shipmentDimensionalWeightQuantity = `2`;
      let check = true;
      expect(!component.showPieceGadTooltip(pkg, check)).toBeTruthy();
      check = false;
      expect(!component.showPieceGadTooltip(pkg, check)).toBeFalsy();
      pkg.shipmentActualWeightQuantity = `2`;
      pkg.shipmentDimensionalWeightQuantity = `1`;
      expect(!component.showPieceGadTooltip(pkg, check)).toBeTruthy();
      check = true;
      expect(!component.showPieceGadTooltip(pkg, check)).toBeFalsy();
    });
  });
  describe('showShipmentGadTooltip', () => {
    it(`should return false if check is true and actual weight < dim weight or
     check is false and actual weight < dim weight, else true`, () => {
      component.shipmentDetails.shipmentActualWeightQuantity = `1`;
      component.shipmentDetails.shipmentDimensionalWeightQuantity = `2`;
      let check = true;
      expect(!component.showShipmentGadTooltip(check)).toBeTruthy();
      check = false;
      expect(!component.showShipmentGadTooltip(check)).toBeFalsy();
      component.shipmentDetails.shipmentActualWeightQuantity = `2`;
      component.shipmentDetails.shipmentDimensionalWeightQuantity = `1`;
      expect(!component.showShipmentGadTooltip(check)).toBeTruthy();
      check = true;
      expect(!component.showShipmentGadTooltip(check)).toBeFalsy();
    });
  });
  describe('closePopup', () => {
    it(`should call emit of onHideshipmentdetails`, () => {
      const emitSpy = spyOn(component.onHideshipmentdetails, 'emit');
      component.closePopup();
      expect(emitSpy).toHaveBeenCalledWith(false);
    });
  });
  describe('setmarginDynamicvalue', () => {
    it(`should call bypassSecurityTrustStyle of _sanitizer`, () => {
      component.childcomponentmargintop = '-333';
      component.setmarginDynamicvalue();
      expect(mockSanitizer.bypassSecurityTrustStyle).toHaveBeenCalledWith(component.childcomponentmargintop);
    });
  });
});
