import { IAirFreightShipmentDetail, ShipmentWeightByPeice, AirFreightShipmentDetail } from '@app/models/quotes/airfreightshipment-detail';
import { Component, OnInit, Input, Output, EventEmitter, ChangeDetectorRef } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { DataTableModule } from 'angular-6-datatable';
import { UtilitiesService } from '@app/shared/services/shared/utilities.service';
import { QuoteAPI, GeaographyAPI } from '@app/shared/services';
import {PackageType} from '@app/shared/enums/PackageType';
import {ShipmentType} from '@app/shared/enums/ShipmentType';
import {ShipmentFrequencyPeriod} from '@app/shared/enums/ShipmentFrequencyPeriod';
import {ShipmentPeriod} from '@app/shared/enums/ShipmentPeriod';
import {ShipmentUnitType} from '@app/shared/enums/ShipmentUnitType';
import {ShipmentUnitName} from '@app/shared/enums/ShipmentUnitName';
import {ShipmentUnit} from '@app/models/quotes/ShipmentUnit';
import {Shipment} from '@app/models/quotes/Shipment';
import {Package} from '@app/models/quotes/Package';
import {UnitConverterFactory} from '@app/shared/helper/shipment-uom/UnitConverterFactory';
import {ShipmentConstants} from '@app/shared/constants/ShipmentConstants';


@Component({
  selector: 'pricing-quotelanesshipment',
  templateUrl: './quotelanesshipment.component.html',
  styleUrls: ['./quotelanesshipment.component.css'],
  providers: [DataTableModule]
})

/*Drop 2 Feature 22(TFS Task:827201) :This component is for "LANES" Tab shipment details textbox click functionalities */
export class QuoteLanesShipmentComponent implements OnInit {
  body: HTMLBodyElement = document.getElementsByTagName('body')[0];
  marginDynamicvalue  = ShipmentConstants.marginDynamicvalue;
  readonly gadTooltipMessage = ShipmentConstants.gadTooltipMessage;
  // enum preparation
  keys = Object.keys;
  readonly shipmentTypes = ShipmentType;
  readonly shipmentFrequencyPeriods = ShipmentFrequencyPeriod;
  readonly shipmentPeriods = ShipmentPeriod;
  readonly packageTypes = PackageType;
  readonly shipmentUnitNames = ShipmentUnitName;
  readonly shipmentUnitTypes = ShipmentUnitType;


  /*START : input,output array declarations */
  @Input() shipmentDetails: AirFreightShipmentDetail;
  @Input() childcomponentmargintop: string;
  @Output() onHideshipmentdetails = new EventEmitter<boolean>();
  @Input() editMode = false;
  /*END : input array declarations */

  constructor(private helper: UtilitiesService,
    private quoteService: QuoteAPI<any>, private geoGraphyService: GeaographyAPI<any>,
    private _sanitizer: DomSanitizer, private _unitConverterFactory: UnitConverterFactory,
    public cdr: ChangeDetectorRef) {
  }

  ngOnInit() {
    this.initializeShipmentDetails();
    this.cdr.detectChanges();
  }

  initializeShipmentDetails() {
    if (!this.shipmentDetails) {
      this.shipmentDetails = new AirFreightShipmentDetail();
    }
    if (!this.shipmentDetails.shipmentActualWeightUnitOfMeasureTypeCode ||
      this.shipmentDetails.shipmentActualWeightUnitOfMeasureTypeCode.length === 0) {
      this.shipmentDetails.shipmentActualWeightUnitOfMeasureTypeCode = this.shipmentUnitNames.Kg;
    }
    if (!this.shipmentDetails.shipmentDimensionalWeightUnitOfMeasureTypeCode ||
      this.shipmentDetails.shipmentDimensionalWeightUnitOfMeasureTypeCode.length === 0) {
      this.shipmentDetails.shipmentDimensionalWeightUnitOfMeasureTypeCode = this.shipmentUnitNames.Kg;
    }
    if (!this.shipmentDetails.shipmentMethod || this.shipmentDetails.shipmentMethod.length === 0) {
      this.shipmentDetails.shipmentMethod = this.shipmentTypes.WeightPerShipment;
    }
    if (!this.shipmentDetails.shipmentFrequencyTimePeriodDescriptionText ||
      this.shipmentDetails.shipmentFrequencyTimePeriodDescriptionText.length === 0) {
      this.shipmentDetails.shipmentFrequencyTimePeriodDescriptionText = this.shipmentFrequencyPeriods.Year;
    }
    if (!this.shipmentDetails.shipmentWeightByPeice ||
      this.shipmentDetails.shipmentWeightByPeice.length === 0) {
      const shipmentWeightByPeice = new ShipmentWeightByPeice();
      shipmentWeightByPeice.shipmentWeightUnitOfMeasureTypeCode = this.shipmentUnitNames.Kg;
      shipmentWeightByPeice.shipmentDimensionalUnitOfMeasureTypeCode = this.shipmentUnitNames.Kg;
      this.shipmentDetails.shipmentWeightByPeice = [shipmentWeightByPeice];
      this.calculateDimWeightForPiece(shipmentWeightByPeice);
    }
  }

  addWeight() {
    const weightByPiece = new ShipmentWeightByPeice();
    weightByPiece.shipmentWeightUnitOfMeasureTypeCode = this.shipmentUnitNames.Kg;
    weightByPiece.shipmentDimensionalUnitOfMeasureTypeCode = this.shipmentUnitNames.Kg;
    this.shipmentDetails.shipmentWeightByPeice.push(weightByPiece);
    this.calculateDimWeightForPiece(weightByPiece);
  }

  removeWeight(i) {
    this.shipmentDetails.shipmentWeightByPeice.splice(i, 1);
    this.calculateTotalWeight();
  }


  getUnitsByType(...types: ShipmentUnitType[]): ShipmentUnitName[] {
    const units: ShipmentUnitName[] = [];
    types.forEach( type => {
      switch (type) {
        case ShipmentUnitType.Metric:
        units.push(ShipmentUnitName.Cm, ShipmentUnitName.Inches);
        break;
        case ShipmentUnitType.Volume:
        units.push(ShipmentUnitName.Cbf, ShipmentUnitName.Cbm);
        break;
        case ShipmentUnitType.Weight:
        units.push(ShipmentUnitName.Kg, ShipmentUnitName.Lb);
        break;
      }
    });
    return units;
  }

  isUnitOfType(unit: ShipmentUnitName, ...types: ShipmentUnitType[]) {
    const unitsToCheck = this.getUnitsByType(...types);
    return unitsToCheck.includes(unit);
  }

  onShipmentTypeChange() {
    switch (this.shipmentDetails.shipmentMethod) {
      case ShipmentType.TypicalCargo:
      case ShipmentType.WeightPerShipment:
      this.shipmentDetails.shipmentFrequencyTimePeriodDescriptionText = this.shipmentFrequencyPeriods.Year;
      break;
      default:
      this.shipmentDetails.shipmentFrequencyTimePeriodDescriptionText = this.shipmentPeriods.Year;
      break;
    }
  }


  checkForDecimalWithPrecision(val: string): string {
    if (parseFloat(val)) {
      return parseFloat(parseFloat(val).toFixed(2)).toString();
    } else {
      return '';
    }
  }

  setPieceTwoNumberDecimal(pkg: ShipmentWeightByPeice) {
    // Bad. bad code.
    pkg.weight = this.checkForDecimalWithPrecision(pkg.weight);
    pkg.shipmentVolumeQuantity = this.checkForDecimalWithPrecision(pkg.shipmentVolumeQuantity);
    pkg.length = this.checkForDecimalWithPrecision(pkg.length);
    pkg.width = this.checkForDecimalWithPrecision(pkg.width);
    pkg.height = this.checkForDecimalWithPrecision(pkg.height);
    pkg.quantity = this.checkForDecimalWithPrecision(pkg.quantity);
    pkg.shipmentActualWeightQuantity = this.checkForDecimalWithPrecision(pkg.shipmentActualWeightQuantity);
    this.calculateDimWeightForPiece(pkg);
  }

  setShpDetTwoNumberDecimal(shp: AirFreightShipmentDetail) {
    // Bad. bad code.
    shp.shipmentActualWeightQuantity = this.checkForDecimalWithPrecision(shp.shipmentActualWeightQuantity);
    shp.shipmentDimensionalWeightQuantity = this.checkForDecimalWithPrecision(shp.shipmentDimensionalWeightQuantity);
  }

  getdimWeightLabel() {
    switch (this.shipmentDetails.shipmentDimensionalWeightUnitOfMeasureTypeCode) {
      case ShipmentUnitName.Cbf:
      case ShipmentUnitName.Cbm:
        return ShipmentUnitType.Volume;
      default:
        return ShipmentUnitType.Weight;
    }
  }

  getValuesForUnitConversion(pkg: ShipmentWeightByPeice): number[] {
        let values: number[];
        // TODO: Find some way to avoid this switch.
        switch (pkg.shipmentDimensionalUnitOfMeasureTypeCode) {
          case ShipmentUnitName.Cm:
          case ShipmentUnitName.Inches:
            values = [parseFloat(pkg.length), parseFloat(pkg.width), parseFloat(pkg.height)];
            break;
            case ShipmentUnitName.Cbf:
            case ShipmentUnitName.Cbm:
            values = [parseFloat(pkg.shipmentVolumeQuantity)];
            break;
          default:
            values = [parseFloat(pkg.weight)];
            break;
        }
        for (let i = 0; i < values.length; i++) {
          if (isNaN(values[i])) {
            return [];
          }
        }
        return values;
  }

  calculateDimWeightForPiece(pkg: ShipmentWeightByPeice) {
    const values = this.getValuesForUnitConversion(pkg);
    if (values.length) {
      const converted = (this._unitConverterFactory
        .createUnitConverter(pkg.shipmentDimensionalUnitOfMeasureTypeCode as ShipmentUnitName,
          pkg.shipmentWeightUnitOfMeasureTypeCode as ShipmentUnitName))
        .doConversion(...values);
      if (converted.length) {
        pkg.shipmentDimensionalWeightQuantity = converted[0].toString();
      }
    }
    this.calculateTotalWeight();
  }

  calculateTotalWeight() {
    this.shipmentDetails.shipmentActualWeightQuantity = '';
    this.shipmentDetails.shipmentDimensionalWeightQuantity = '';
    let actualWeight = 0;
    this.shipmentDetails.shipmentWeightByPeice.forEach(pkg => {
      const converted = this._unitConverterFactory.createUnitConverter(
        <ShipmentUnitName>pkg.shipmentWeightUnitOfMeasureTypeCode,
      ShipmentUnitName.Kg).doConversion(parseFloat(pkg.shipmentActualWeightQuantity));
      if (converted.length && !isNaN(parseFloat(pkg.quantity))) {
        actualWeight += converted[0] * parseFloat(pkg.quantity);
      }
    });
    let dimWeight = 0;
    this.shipmentDetails.shipmentWeightByPeice.forEach(pkg => {
      const converted = this._unitConverterFactory.createUnitConverter(
        <ShipmentUnitName>pkg.shipmentWeightUnitOfMeasureTypeCode,
      ShipmentUnitName.Kg).doConversion(parseFloat(pkg.shipmentDimensionalWeightQuantity));
      if (converted.length && !isNaN(parseFloat(pkg.quantity))) {
        dimWeight += converted[0] * parseFloat(pkg.quantity);
      }
    });

    this.shipmentDetails.shipmentActualWeightQuantity =
      this.checkForDecimalWithPrecision(actualWeight.toString());
    this.shipmentDetails.shipmentDimensionalWeightQuantity =
      this.checkForDecimalWithPrecision(dimWeight.toString());
  }

  showPieceGadTooltip(pkg: ShipmentWeightByPeice, check) {
    return !(((parseFloat(pkg.shipmentActualWeightQuantity) <
    parseFloat(pkg.shipmentDimensionalWeightQuantity)) && check) ||
    ((parseFloat(pkg.shipmentActualWeightQuantity) >
    parseFloat(pkg.shipmentDimensionalWeightQuantity)) && !check));
  }

  showShipmentGadTooltip(check) {
    return !(((parseFloat(this.shipmentDetails.shipmentActualWeightQuantity) <
    parseFloat(this.shipmentDetails.shipmentDimensionalWeightQuantity)) && check) ||
    ((parseFloat(this.shipmentDetails.shipmentActualWeightQuantity) >
    parseFloat(this.shipmentDetails.shipmentDimensionalWeightQuantity)) && !check));
  }

  /*
  * @ngdoc function
  * @name closePopup
  * @methodOf QuoteLanesShipmentComponent
  * @description Method for closing the parent component popup
  * @private
  */
  closePopup() {
    this.onHideshipmentdetails.emit(false);
  }
  setmarginDynamicvalue() {
    // const style = `-120`;
    return this._sanitizer.bypassSecurityTrustStyle(this.childcomponentmargintop);
  }
  isReadOnly(val: string, el) {
    const element = el.element ? el.element : el;
    const pristine = element.classList.contains('ng-pristine');
    return (val != undefined && val != null && this.editMode && val.match(/^ *$/) == null ) && pristine;
  }

}
