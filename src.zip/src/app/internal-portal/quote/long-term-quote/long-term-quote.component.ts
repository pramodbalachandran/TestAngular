import { Component, OnInit, ViewChild, AfterViewInit, OnDestroy, AfterViewChecked, ElementRef, Renderer } from '@angular/core';
import { DataTableModule } from 'angular-6-datatable';
import { Router, ActivatedRoute } from '@angular/router';
import { LocalStorageService, QuoteAPI, GeaographyAPI,ToasterService } from '@app/shared/services';
import { IAirFreightShipmentDetail, AirFreightShipmentDetail } from '@app/models/quotes/airfreightshipment-detail';
import { RoutingKey } from '@app/shared/services/shared/config.const';
import { UtilitiesService } from '@app/shared/services/shared/utilities.service';
import { PageState } from '@app/shared/services/shared/enum';
import { NgbTabset } from '@ng-bootstrap/ng-bootstrap';
import { IQuoteData } from '@app/models/quotes/quote-data';
import { QuoteOverViewComponent } from '@app/internal-portal/quote/quoteoverview/quoteoverview.component';
import { QuoteLanesComponent } from '@app/internal-portal/quote/quotelane/quotelanes.component';
import { LoaderService } from '@app/shared/services/loader.service';
import { BonsaiConstants } from '@app/shared/constants/bonsaiconstants';
enum QuoteRequestValidityOptions { '1year' = '1 year' }
import { Ng4LoadingSpinnerModule, Ng4LoadingSpinnerService } from 'ng4-loading-spinner';

@Component({
  selector: 'pricing-long-term-quote',
  templateUrl: './long-term-quote.component.html',
  styleUrls: ['./long-term-quote.component.css'],

})
export class LongTermQuoteComponent implements OnInit, AfterViewInit, OnDestroy {
  body: HTMLBodyElement = document.getElementsByTagName('body')[0];
  quoteType: number = 1;
  quoteModel: IQuoteData;
  autoSaveIntervalId: any;
  currencyConversionData: any[];
  isNewQuote: boolean = false;

  @ViewChild('tabset') public tabset: NgbTabset;
  @ViewChild(QuoteOverViewComponent) quoteOverviewComp: QuoteOverViewComponent;
  @ViewChild(QuoteLanesComponent) quoteLaneComp: QuoteLanesComponent;

  constructor(private quoteService: QuoteAPI<IQuoteData>, private loaderService: LoaderService,
    private helper: UtilitiesService, private localStorageService: LocalStorageService,
    private geographyService: GeaographyAPI<any>) {
    this.quoteModel = this.quoteService.getQuoteDetails();
    if (this.quoteModel.quoteRequestData.quoteTypeCode === 0) {
      this.isNewQuote = true;
      this.quoteModel = this.quoteService.getEmptyQuoteModel();
      this.quoteModel.quoteRequestData.quoteTypeCode = this.quoteType;
      this.quoteModel.quoteRequestData.businessPartyNumber = localStorageService.getItem(BonsaiConstants.loggedInUserName);
    }
  }


  ngOnInit() {
    this.body.classList.remove('login-logo');
    this.setDefaultValues();
    this.getCurrencyDetails();
  }

  ngAfterViewInit() {
    if (this.tabset) {
      if (localStorage.getItem('isFromIPHeader') === "Yes") {
        setTimeout(() => {
          this.tabset.select('tab-overview')
          localStorage.setItem('isFromIPHeader', null);
        }, 100);
      }
      if (this.localStorageService.getItem('isFromRateDisplay') === true) {
        setTimeout(() => {
          this.tabset.select('tab-lanes')
          this.localStorageService.setItem('isFromRateDisplay', null);
        }, 200);
      }
    }
  }

  ngOnDestroy() {
    this.localStorageService.clearItem('HideLoader');
    if (this.autoSaveIntervalId) {
      clearInterval(this.autoSaveIntervalId);
    }
  }

  setupAutoSaveInterval() {
    this.autoSaveIntervalId = setInterval(() => this.onSave(), 15000);
  }

  setDefaultValues() {
    if (!this.isNewQuote) {
      return;
    }
    this.quoteModel.quoteRequestData.quoteTypeCode = this.quoteType;
    this.quoteModel.quoteRequestData.quoteValidityPeriod = QuoteRequestValidityOptions["1year"];
    this.quoteModel.quoteRequestData.serviceTypes.consolidatedECSelected = true;
    this.quoteModel.quoteRequestData.serviceTypes.directCASelected = false;
    this.quoteModel.quoteRequestData.serviceTypes.premiumDirectCXSelected = false;
    this.quoteModel.quoteRequestData.serviceTypes.tempTrueSelected = false;
  }

  getCurrencyDetails() {
    this.geographyService.getCurrencyDetailList().subscribe(
      data => {
        var result = data.result;
        var resultNotEmpty = result !== null && result !== undefined && result.results !== null &&
          result.results !== undefined && result.results.length > 0;

        if (resultNotEmpty && result.results[0].currencyConversion !== null && result.results[0].currencyConversion !== undefined &&
          result.results[0].currencyConversion.length > 0) {
          this.currencyConversionData = result.results[0].currencyConversion;
        }
        this.setupAutoSaveInterval();
      });
  }
  getAirportdetails(businessPartyNumber: string, isTabswitch: boolean = false) {

    this.geographyService.getAirportdetails(businessPartyNumber)
      .subscribe(
        data => {
          if (data != null && data['Airportdetails'] != null) {
            this.localStorageService.setItem('Airportdetails', data["Airportdetails"]);
          }
        },
        error => {

        });
  }
  onQuoteTypeStatusChange(value) {
    this.quoteType = value;
    this.quoteModel.quoteRequestData.quoteTypeCode = value;
  }

  tabChange(e) {
    if (e.activeId == 'tab-overview' && this.quoteOverviewComp) {
      this.quoteOverviewComp.setModelValues();
    }
    else if (e.activeId == 'tab-lanes' && this.quoteLaneComp) {
      this.quoteLaneComp.setModelValues();
    }
    this.quoteService.setQuoteDetails(this.quoteModel);
  }

  onSave() {
    if(this.quoteOverviewComp) {
      this.quoteOverviewComp.setModelValues();
    }
    if (this.quoteLaneComp) {
      this.quoteLaneComp.setModelValues();
    }
    this.autoSave();
  }

  private autoSave() {
    this.localStorageService.setItem('HideLoader', true);
    this.quoteService.setQuoteDetails(this.quoteModel);
    this.quoteService.save()
      .subscribe(
      data => {
        this.localStorageService.clearItem('HideLoader');
        if (data.responseStatus.status == '200') {
          this.updateQuoteInfo(data.responseData);
          return;
        }
        console.log('something went wrong');
      },
      error => {
        this.localStorageService.clearItem('HideLoader');
        console.log(error);
      });
  }

  updateQuoteInfo(data) {
    this.quoteModel.quoteRequestData.id = data.quoteDetailsId;
    this.quoteModel.quoteRequestData.quoteNumber = data.quoteNumber;
  }
}
