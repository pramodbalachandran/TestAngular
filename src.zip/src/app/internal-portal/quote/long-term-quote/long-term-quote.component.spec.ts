import { async, ComponentFixture, TestBed, getTestBed } from '@angular/core/testing';
import { NgModule } from '@angular/core';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterTestingModule } from '@angular/router/testing';
import { MatInputModule, MatAutocompleteModule, MatButtonModule, MatProgressSpinnerModule } from '@angular/material';
import { SharedModule } from '@app/shared/shared.module';
import { LocalStorageService, QuoteAPI, GeaographyAPI } from '@app/shared/services';
import { LongTermQuoteComponent } from './long-term-quote.component';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';
import { NgbTabsetConfig, NgbTabChangeEvent } from '@ng-bootstrap/ng-bootstrap';
import { ICurrencyData } from '@app/models';
import { of, Observable } from "rxjs";

describe('LongTermQuoteComponent', () => {
  let component: LongTermQuoteComponent;
  let fixture: ComponentFixture<LongTermQuoteComponent>;
  let localStorageService: LocalStorageService;
  let geoGraphyService: GeaographyAPI<any>;
  let injector;

  let quoteService: QuoteAPI<any>;


  let GeographyAPIService: GeaographyAPI<ICurrencyData>,
    mockGeoGraphyService = {
      getCurrencyDetailList: jasmine.createSpy('getCurrencyDetailList').and.returnValue(of(
        {
          "result": {
            "pageSize": 100,
            "totalResults": 1,
            "results": [
              {
                "docType": "currencyConversion",
                "docId": "currencyConversion::10162018",
                "docCategory": "referenceCurrency",
                "docStructureVersion": "1",
                "currencyConversion": [
                  {
                    "countryCode": "YU",
                    "countryName": "YUGOSLAVIA",
                    "exchangeRateAmount": 1,
                    "currencyName": "USD",
                    "decimalPlacesQuantity": 2,
                    "roundingDirectionText": null,
                    "localCurrencyCode": null,
                    "localeCodes": "",
                    "localConversionToUsdAmount": null
                  },
                  {
                    "countryCode": "ZW",
                    "countryName": "ZIMBABWE",
                    "exchangeRateAmount": 1,
                    "currencyName": "USD",
                    "decimalPlacesQuantity": 2,
                    "roundingDirectionText": null,
                    "localCurrencyCode": "ZWN",
                    "localeCodes": "",
                    "localConversionToUsdAmount": null
                  }
                ],
                "id": "1ab65b62-1061-0fd2-0ccc-8bfcb9c07840",
                "partitionKey": "currency",
                "lastContinuationToken": null
              }
            ],
            "continuationToken": null
          },
          "id": 1,
          "exception": null,
          "status": 5,
          "isCanceled": false,
          "isCompleted": true,
          "isCompletedSuccessfully": true,
          "creationOptions": 0,
          "asyncState": null,
          "isFaulted": false
        }))
    };

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule,
        SharedModule,
        BrowserDynamicTestingModule

      ],
      declarations: [LongTermQuoteComponent],
      providers: [LocalStorageService, NgbTabsetConfig, QuoteAPI, {
        provide: GeaographyAPI,
        useValue: mockGeoGraphyService
      }],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA]
    })
      .compileComponents();

    injector = getTestBed();
    localStorageService = injector.get(LocalStorageService);
    quoteService = injector.get(QuoteAPI);
    geoGraphyService = injector.get(GeaographyAPI);
  }));


  beforeEach(() => {
    fixture = TestBed.createComponent(LongTermQuoteComponent);
    component = fixture.componentInstance;
    component.quoteModel = quoteService.getQuoteDetails();
    fixture.detectChanges();
  });

  //The component should be define.
  it("should have a defined component ", () => {
    expect(component).toBeDefined();
  });

  //Quote Type Status Change
  it('Quote Type Status Change', () => {
    component.quoteType = 1;
    component.onQuoteTypeStatusChange(2);
    expect(component.quoteType).toEqual(2);
  });

  //Lane tabe active
  it('Set Lane item tab as active', () => {
    localStorageService.setItem('isFromRateDisplay', true);
    component.ngAfterViewInit();
    setTimeout(() => {
      expect(component.tabset.activeId).toEqual('tab-lanes');
    }, 300);
  });

  it('Set Overview item tab as active from HeaderPageCall', () => {
    localStorageService.setItem('isFromIPHeader', "Yes");
    component.ngAfterViewInit();
    setTimeout(() => {
      expect(component.tabset.activeId).toEqual('tab-overview');
    }, 300);
  });

  //tab change
  it('change tab', () => {
    var tabChange = { activeId: 'tab-overview', nextId: '', preventDefault: false };
    component.tabChange(tabChange);
    expect(tabChange.activeId).toEqual('tab-overview');
  });

  it('set autosave interval', () => {
    component.setupAutoSaveInterval();
    expect(component.autoSaveIntervalId).toBeTruthy(component.autoSaveIntervalId != null);

  });

  //destroy component
  it('component destroy', () => {
    component.setupAutoSaveInterval();
    component.ngOnDestroy();
    expect(localStorageService.getItem('HideLoader')).toEqual(null);
  });


  it('on save', () => {
    component.quoteType = 1;
    component.onSave();
    expect(component.quoteType).toEqual(1);
  });

  it('should return getCurrencyDetail List', () => {
    component.getCurrencyDetails();
    expect(component.currencyConversionData[0]["countryName"]).toBe("YUGOSLAVIA");
  });


  it('change currency value', () => {
    var event = {
      "target": {
        "value": "mexico"
      }
    }
    component.getCurrencyDetails();
    //expect(component.currencyConversionData[0]["countryName"]).toBe("YUGOSLAVIA");
  });

  it('update quote details', () => {
    var data = { quoteDetailsId: "1", quoteNumber:"12345"};
    component.updateQuoteInfo(data);
    expect(component.quoteModel.quoteRequestData.id).toEqual("1");
    expect(component.quoteModel.quoteRequestData.quoteNumber).toEqual("12345");
  });

  it('set default values', () => {
    component.isNewQuote = false;
    component.setDefaultValues();
    expect(component.isNewQuote).toEqual(false);
  });

  

});
