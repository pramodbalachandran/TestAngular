import { NgModule } from '@angular/core';
import { RatecalculatorComponent } from './ratecalculator/ratecalculator.component';
import { AuthenticationGuard, MsAdalAngular6Module } from 'microsoft-adal-angular6';

import { routing } from './internal-portal.routing';
import { SharedModule } from '@app/shared/shared.module';
import { InternalPortalSharedModule } from '@app/internal-portal/shared/shared.module';
import { IPDashboardComponent } from './dashboard/IPDashboard.component';
import { ShortTermServiceTypeComponent } from './shorttermservicetype/shorttermservicetype.component';
import { replyUrlKey,ApplicationKeys } from '@app/shared/services/shared/config.const';
import { RateDisplayComponent } from './ratedisplay/ratedisplay.component';



//http://localhost:4200/upsers/
//"https://bon-ui-dev.azurewebsites.net/upsers/"

@NgModule({
  imports: [routing,
    SharedModule,
    InternalPortalSharedModule,
    MsAdalAngular6Module.forRoot({
      tenant: ApplicationKeys[0].tenantId,
      clientId: ApplicationKeys[1].clientId,
      redirectUri: replyUrlKey.DEV,     
      navigateToLoginRequestUrl: false
      //cacheLocation: 'localStorage',
    })],
  providers: [AuthenticationGuard],
  declarations:
    [
      IPDashboardComponent,
      RatecalculatorComponent,
      RateDisplayComponent
    ],
  bootstrap: [IPDashboardComponent]
})

export class InternalPortalModule  {

  constructor() {

    history.pushState(null, null, location.href);
    window.onpopstate = function () {
      history.go(1);
    };
    window.history.forward();
    
  } 

}
