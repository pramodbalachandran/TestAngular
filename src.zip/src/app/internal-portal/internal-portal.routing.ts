import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthenticationGuard } from 'microsoft-adal-angular6';

import { QuoteInternalPortalModule } from '@app/internal-portal/quote/quote.module';
import { RatecalculatorComponent } from './ratecalculator/ratecalculator.component';
import { IPDashboardComponent } from './dashboard/IPDashboard.component';
import { RateDisplayComponent } from './ratedisplay/ratedisplay.component';

const routes: Routes = [

   //Test your code without Azure login page

  // { path: '', redirectTo: 'IPdashboard', pathMatch: 'full' },
  // { path: 'IPdashboard', component: IPDashboardComponent},
  // { path: 'ratecalculator', component: RatecalculatorComponent},
  // { path: 'ratedisplay', component: RateDisplayComponent },
  // { path: 'quote', loadChildren: () => QuoteInternalPortalModule}


   //Test your code wih Azure login page

  { path: '', redirectTo: 'IPdashboard', pathMatch: 'full' },
  { path: 'IPdashboard', component: IPDashboardComponent, canActivate: [AuthenticationGuard] },
  { path: 'ratecalculator', component: RatecalculatorComponent, canActivate: [AuthenticationGuard] },
  { path: 'ratedisplay', component: RateDisplayComponent, canActivate: [AuthenticationGuard] },
  { path: 'quote', loadChildren: () => QuoteInternalPortalModule, canActivate: [AuthenticationGuard] }
];
export const routing: ModuleWithProviders = RouterModule.forChild(routes);
