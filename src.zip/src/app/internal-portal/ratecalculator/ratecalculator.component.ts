import { Component, OnInit, ViewChild } from '@angular/core';
import { map, startWith, retry } from 'rxjs/operators';
import { DataTableModule } from 'angular-6-datatable';


import { RoutingKey } from '@app/shared/services/shared/config.const';
import { UtilitiesService } from '@app/shared/services/shared/utilities.service';
import { airportDetails, airportDetailsDes } from '@app/models/autopopulate/autopopulate-data';
import { LocalStorageService, QuoteAPI, GeaographyAPI } from '@app/shared/services';
import { PageState } from '@app/shared/services/shared/enum';
import { FormGroup, FormBuilder, FormControl } from '@angular/forms';
import { Observable } from 'rxjs';
import { DomSanitizer } from '@angular/platform-browser';
import { IAirportODPair } from '@app/shared/interfaces/entities.interface';
import { CustomModalComponent } from '@app/shared/components/custom-modal/custom-modal.component';

@Component({
  selector: 'pricing-ratecalculator',
  templateUrl: './ratecalculator.component.html',
  styleUrls: ['./ratecalculator.component.css'],
  providers: [DataTableModule]
})
export class RatecalculatorComponent implements OnInit {
  body: HTMLBodyElement = document.getElementsByTagName('body')[0];
  myFormOrg: FormGroup;

  quoteTypeSelectedValue: number = 1;
  shortTermQuote: number = 1;
  longTermQuote: number = 2;


  lineData = [];
  listorg: Observable<airportDetails[]>;
  listdes: Observable<airportDetails[]>;
  lineDataMaxLength = 10;
  origin: string = '';
  destination: string = '';
  airportOriginCode: string = '';
  airportDestinationCode: string = '';
  airportOriginCountryCode: string = '';
  airportDestinationCountryCode: string = '';

  lineDataOriginValue: string = '';
  lineDataDestinationValue: string = '';
  lineDataAirportOriginCode: string = '';
  lineDataAirportDestinationCode: string = '';
  lineDataAirportOriginCountryCode: string = '';
  lineDataAirportDestinationCountryCode: string = '';

  isInvalidODPair: boolean = false;
  isInvalidLineItemODPair: boolean = false;
  sameODPair: boolean = false;
  sameCountryODPair: boolean = false;
  ODPairAlreadyExist: boolean = false;
  invalidOrigin: boolean = false;
  invalidDestination: boolean = false;
  selectedMenuItem: string = "";



  cssUrl: string = 'assets/css/autocomplete-normal-style.css';
  //stateCtrl_0 = new FormControl();
  //stateCtrlDes_0 = new FormControl();
  filteredStates: Observable<airportDetails[]>;
  filteredStatesDes: Observable<airportDetails[]>;

  filteredStates_0: Observable<airportDetails[]>;
  filteredStatesDes_0: Observable<airportDetails[]>;
  filteredStates_1: Observable<airportDetails[]>;
  filteredStatesDes_1: Observable<airportDetails[]>;
  filteredStates_2: Observable<airportDetails[]>;
  filteredStatesDes_2: Observable<airportDetails[]>;
  filteredStates_3: Observable<airportDetails[]>;
  filteredStatesDes_3: Observable<airportDetails[]>;
  filteredStates_4: Observable<airportDetails[]>;
  filteredStatesDes_4: Observable<airportDetails[]>;
  filteredStates_5: Observable<airportDetails[]>;
  filteredStatesDes_5: Observable<airportDetails[]>;
  filteredStates_6: Observable<airportDetails[]>;
  filteredStatesDes_6: Observable<airportDetails[]>;
  filteredStates_7: Observable<airportDetails[]>;
  filteredStatesDes_7: Observable<airportDetails[]>;
  filteredStates_8: Observable<airportDetails[]>;
  filteredStatesDes_8: Observable<airportDetails[]>;
  filteredStates_9: Observable<airportDetails[]>;
  filteredStatesDes_9: Observable<airportDetails[]>;
  states: airportDetails[];
  intemediatefilteredStates: airportDetails[];
  finalfilteredStates: airportDetails[];

  constructor(private helper: UtilitiesService, public sanitizer: DomSanitizer, private quoteService: QuoteAPI<any>, private geoGraphyService: GeaographyAPI<any>, fb: FormBuilder) {
    this.myFormOrg = fb.group({
      stateCtrl: null,
      stateCtrlDes: null,
      stateCtrl_0: null,
      stateCtrlDes_0: null,
      stateCtrl_1: null,
      stateCtrlDes_1: null,
      stateCtrl_2: null,
      stateCtrlDes_2: null,
      stateCtrl_3: null,
      stateCtrlDes_3: null,
      stateCtrl_4: null,
      stateCtrlDes_4: null,
      stateCtrl_5: null,
      stateCtrlDes_5: null,
      stateCtrl_6: null,
      stateCtrlDes_6: null,
      stateCtrl_7: null,
      stateCtrlDes_7: null,
      stateCtrl_8: null,
      stateCtrlDes_8: null,
      stateCtrl_9: null,
      stateCtrlDes_9: null,
    });
  }

  ngOnInit() {
    this.body.classList.remove('login-logo');
    this.getAirportdetails(null);
  }

  setAirportODPairDetail() {
    var laneInfo = this.quoteService.getAirportODPairLaneDetail();
    if (!laneInfo || laneInfo.length === 0) {
      return;
    }

    if (laneInfo[0].quoteType === this.shortTermQuote) {
      this.quoteTypeSelectedValue = laneInfo[0].quoteType;
      this.showShortTermDetail(laneInfo);
    }
    else {
      this.quoteTypeSelectedValue = laneInfo[0].quoteType;
      this.showLongTermDetail(laneInfo);
    }
  }

  showShortTermDetail(laneInfo) {
    if (laneInfo[0].quoteType !== this.shortTermQuote) {
      return;
    }
    this.destination = laneInfo[0].destination;
    this.airportDestinationCode = laneInfo[0].destinationCode;
    this.airportDestinationCountryCode = laneInfo[0].destinationCountryCode;
    this.origin = laneInfo[0].origin;
    this.airportOriginCode = laneInfo[0].originCode;
    this.airportOriginCountryCode = laneInfo[0].originCountryCode;
  }

  showLongTermDetail(laneInfo) {
    if (laneInfo[0].quoteType != this.longTermQuote) {
      return;
    }

    this.lineData = [];
    var i: number = 0;
    for (let item of laneInfo) {
      this.lineData.push({
        origin: item.origin, airportOriginCode: item.originCode, airportOriginCountryCode: item.originCountryCode,
        destination: item.destination, airportDestinationCode: item.destinationCode, airportDestinationCountryCode: item.destinationCountryCode,
        selected: false, listorg: this.getAirportOriginAutoCompleteFilter(i), listdes: this.getAirportDestinationAutoCompleteFilter(i)
      });
      i = i + 1;
    }
  }

  getAirportDestinationAutoCompleteFilter(index) {
    switch (index) {
      case 0:
        return this.filteredStatesDes_0;
      case 1:
        return this.filteredStatesDes_1;
      case 2:
        return this.filteredStatesDes_2;
      case 3:
        return this.filteredStatesDes_3;
      case 4:
        return this.filteredStatesDes_4;
      case 5:
        return this.filteredStatesDes_5;
      case 6:
        return this.filteredStatesDes_6;
      case 7:
        return this.filteredStatesDes_7;
      case 8:
        return this.filteredStatesDes_8;
      case 9:
        return this.filteredStatesDes_9;
      default:
        return this.filteredStatesDes_0;
    }
  }

  getAirportOriginAutoCompleteFilter(index) {
    switch (index) {
      case 0:
        return this.filteredStates_0;
      case 1:
        return this.filteredStates_1;
      case 2:
        return this.filteredStates_2;
      case 3:
        return this.filteredStates_3;
      case 4:
        return this.filteredStates_4;
      case 5:
        return this.filteredStates_5;
      case 6:
        return this.filteredStates_6;
      case 7:
        return this.filteredStates_7;
      case 8:
        return this.filteredStates_8;
      case 9:
        return this.filteredStates_9;
      default:
        return this.filteredStates_0;
    }
  }

  getRateCalculatorDetails() {
    var laneInfo = [];
    var laneDetails = this.quoteService.getAirportODPairLaneDetail();
    for (let item of laneDetails) {
      laneInfo.push({ originCode: item.originCode, destinationCode: item.destinationCode });
    }


    this.quoteService.getWeightBreaksDetails(laneInfo)
      .subscribe(
        data => {
          if (data == null) {
            console.log('coudnt fetch rate calculator info');
            return;
          }
          this.quoteService.setRateCalculatorDetail(data);
          this.helper.navigateTo(RoutingKey[PageState.RATEDISPLAY]);
        });
  }


  getAirportdetails(businessPartyNumber: string, isTabswitch: boolean = false) {

    this.geoGraphyService.getAirportdetails(businessPartyNumber)
      .subscribe(
        data => {
          if (data != null && data['Airportdetails'] != null) {
            this.states = data["Airportdetails"];
            this.filteredStates = this.myFormOrg
              .get('stateCtrl').valueChanges
              .pipe(
                startWith(''),
                map(state => state ? this._filterStates(state).slice(0, 6) : this.states.filter(x => x.isCustomerData == "1").slice(0, 6))
              );
            this.filteredStatesDes = this.myFormOrg
              .get('stateCtrlDes').valueChanges
              .pipe(
                startWith(''),
                map(state => state ? this._filterStates(state).slice(0, 6) : this.states.filter(x => x.isCustomerData == "1").slice(0, 6))
              );
            this.filteredStates_0 = this.myFormOrg
              .get('stateCtrl_0').valueChanges
              .pipe(
                startWith(''),
                map(state => state ? this._filterStates(state).slice(0, 6) : this.states.filter(x => x.isCustomerData == "1").slice(0, 6))
              );
            this.filteredStatesDes_0 = this.myFormOrg
              .get('stateCtrlDes_0').valueChanges
              .pipe(
                startWith(''),
                map(state => state ? this._filterStates(state).slice(0, 6) : this.states.filter(x => x.isCustomerData == "1").slice(0, 6))
              );
            this.filteredStates_1 = this.myFormOrg
              .get('stateCtrl_1').valueChanges
              .pipe(
                startWith(''),
                map(state => state ? this._filterStates(state).slice(0, 6) : this.states.filter(x => x.isCustomerData == "1").slice(0, 6))
              );
            this.filteredStatesDes_1 = this.myFormOrg
              .get('stateCtrlDes_1').valueChanges
              .pipe(
                startWith(''),
                map(state => state ? this._filterStates(state).slice(0, 6) : this.states.filter(x => x.isCustomerData == "1").slice(0, 6))
              );
            this.filteredStates_2 = this.myFormOrg
              .get('stateCtrl_2').valueChanges
              .pipe(
                startWith(''),
                map(state => state ? this._filterStates(state).slice(0, 6) : this.states.filter(x => x.isCustomerData == "1").slice(0, 6))
              );
            this.filteredStatesDes_2 = this.myFormOrg
              .get('stateCtrlDes_2').valueChanges
              .pipe(
                startWith(''),
                map(state => state ? this._filterStates(state).slice(0, 6) : this.states.filter(x => x.isCustomerData == "1").slice(0, 6))
              );
            this.filteredStates_3 = this.myFormOrg
              .get('stateCtrl_3').valueChanges
              .pipe(
                startWith(''),
                map(state => state ? this._filterStates(state).slice(0, 6) : this.states.filter(x => x.isCustomerData == "1").slice(0, 6))
              );
            this.filteredStatesDes_3 = this.myFormOrg
              .get('stateCtrlDes_3').valueChanges
              .pipe(
                startWith(''),
                map(state => state ? this._filterStates(state).slice(0, 6) : this.states.filter(x => x.isCustomerData == "1").slice(0, 6))
              );
            this.filteredStates_4 = this.myFormOrg
              .get('stateCtrl_4').valueChanges
              .pipe(
                startWith(''),
                map(state => state ? this._filterStates(state).slice(0, 6) : this.states.filter(x => x.isCustomerData == "1").slice(0, 6))
              );
            this.filteredStatesDes_4 = this.myFormOrg
              .get('stateCtrlDes_4').valueChanges
              .pipe(
                startWith(''),
                map(state => state ? this._filterStates(state).slice(0, 6) : this.states.filter(x => x.isCustomerData == "1").slice(0, 6))
              );
            this.filteredStates_5 = this.myFormOrg
              .get('stateCtrl_5').valueChanges
              .pipe(
                startWith(''),
                map(state => state ? this._filterStates(state).slice(0, 6) : this.states.filter(x => x.isCustomerData == "1").slice(0, 6))
              );
            this.filteredStatesDes_5 = this.myFormOrg
              .get('stateCtrlDes_5').valueChanges
              .pipe(
                startWith(''),
                map(state => state ? this._filterStates(state).slice(0, 6) : this.states.filter(x => x.isCustomerData == "1").slice(0, 6))
              );
            this.filteredStates_6 = this.myFormOrg
              .get('stateCtrl_6').valueChanges
              .pipe(
                startWith(''),
                map(state => state ? this._filterStates(state).slice(0, 6) : this.states.filter(x => x.isCustomerData == "1").slice(0, 6))
              );
            this.filteredStatesDes_6 = this.myFormOrg
              .get('stateCtrlDes_6').valueChanges
              .pipe(
                startWith(''),
                map(state => state ? this._filterStates(state).slice(0, 6) : this.states.filter(x => x.isCustomerData == "1").slice(0, 6))
              );
            this.filteredStates_7 = this.myFormOrg
              .get('stateCtrl_7').valueChanges
              .pipe(
                startWith(''),
                map(state => state ? this._filterStates(state).slice(0, 6) : this.states.filter(x => x.isCustomerData == "1").slice(0, 6))
              );
            this.filteredStatesDes_7 = this.myFormOrg
              .get('stateCtrlDes_7').valueChanges
              .pipe(
                startWith(''),
                map(state => state ? this._filterStates(state).slice(0, 6) : this.states.filter(x => x.isCustomerData == "1").slice(0, 6))
              );
            this.filteredStates_8 = this.myFormOrg
              .get('stateCtrl_8').valueChanges
              .pipe(
                startWith(''),
                map(state => state ? this._filterStates(state).slice(0, 6) : this.states.filter(x => x.isCustomerData == "1").slice(0, 6))
              );
            this.filteredStatesDes_8 = this.myFormOrg
              .get('stateCtrlDes_8').valueChanges
              .pipe(
                startWith(''),
                map(state => state ? this._filterStates(state).slice(0, 6) : this.states.filter(x => x.isCustomerData == "1").slice(0, 6))
              );
            this.filteredStates_9 = this.myFormOrg
              .get('stateCtrl_9').valueChanges
              .pipe(
                startWith(''),
                map(state => state ? this._filterStates(state).slice(0, 6) : this.states.filter(x => x.isCustomerData == "1").slice(0, 6))
              );
            this.filteredStatesDes_9 = this.myFormOrg
              .get('stateCtrlDes_9').valueChanges
              .pipe(
                startWith(''),
                map(state => state ? this._filterStates(state).slice(0, 6) : this.states.filter(x => x.isCustomerData == "1").slice(0, 6))
              );
            this.setAirportODPairDetail();
          }
        },
        error => {

        });
  }

  _filterStates(value: string): airportDetails[] {
    const filterValue = value.toLowerCase();
    this.intemediatefilteredStates = this.states;
    this.finalfilteredStates = this.intemediatefilteredStates.filter(state => state.isCustomerData === "0" && state.autopopulateformat.split(',')[0].toLowerCase().indexOf(filterValue) == 0).slice(0, 6);
    this.intemediatefilteredStates = this.intemediatefilteredStates.filter(f => !this.finalfilteredStates.includes(f));
    if (this.finalfilteredStates.length < 6) {
      this.finalfilteredStates = this.finalfilteredStates.concat(this.intemediatefilteredStates.filter(state => state.isCustomerData === "0" && state.autopopulateformat.split(',')[0].split(" ")[1].toLowerCase().indexOf(filterValue) == 0));
      this.intemediatefilteredStates = this.intemediatefilteredStates.filter(f => !this.finalfilteredStates.includes(f));
      if (this.finalfilteredStates.length < 6) {
        this.finalfilteredStates = this.finalfilteredStates.concat(this.intemediatefilteredStates.filter(state => state.isCustomerData === "0" && state.autopopulateformat.toLowerCase().indexOf(filterValue) > -1));
      }
    }
    return this.finalfilteredStates;
  }

  onAirportSelection(value, isOrigin) {
    var obj = this.states.filter(f => f.autopopulateformat == value)[0];
    if (!obj) {
      return;
    }

    if (isOrigin) {
      this.airportOriginCode = obj['airportCode'];
      this.airportOriginCountryCode = obj['countryCode'];
    }
    else {
      this.airportDestinationCode = obj['airportCode'];
      this.airportDestinationCountryCode = obj['countryCode'];
    }
  }

  onLineItemAirportSelection(value, isOrigin) {
    this.onLongTermAirportSelection(value, isOrigin);
  }

  onLongTermAirportSelection(value, isOrigin) {
    var obj = this.states.filter(f => f.autopopulateformat == value)[0];
    if (!obj) {
      return;
    }

    if (isOrigin) {
      this.lineDataAirportOriginCode = obj['airportCode'];
      this.lineDataAirportOriginCountryCode = obj['countryCode'];
    }
    else {
      this.lineDataAirportDestinationCode = obj['airportCode'];
      this.lineDataAirportDestinationCountryCode = obj['countryCode'];
    }
  }

  isActiveShortTerm() {
    return this.quoteTypeSelectedValue === 1;
  }

  isActiveLongTerm() {
    return this.quoteTypeSelectedValue === 2;
  }

  onShortTermClick(value) {
    if (value == this.quoteTypeSelectedValue) {
      return;
    }

    this.quoteTypeSelectedValue = value;
    this.resetLineData();
    this.clearValidationMessage();

    var laneInfo = this.quoteService.getAirportODPairLaneDetail();
    if (!laneInfo || laneInfo.length === 0) {
      return;
    }
    //this.showShortTermDetail(laneInfo);
  }

  onLongTermClick(value) {
    if (value == this.quoteTypeSelectedValue) {
      return;
    }

    this.quoteTypeSelectedValue = value;
    this.resetLineData();
    this.clearValidationMessage();
    var laneInfo = this.quoteService.getAirportODPairLaneDetail();
    if (!laneInfo || laneInfo.length == 0) {
      return;
    }
    // this.showLongTermDetail(laneInfo);
  }

  onOriginChange(value) {
    //this.lineDataOriginValue = value;
  }

  onDestinationChange(value) {
    //this.lineDataDestinationValue = value;
  }

  clearValidationMessage() {
    this.isInvalidODPair = false;
    this.isInvalidLineItemODPair = false;
    this.sameODPair = false;
    this.sameCountryODPair = false;
    this.ODPairAlreadyExist = false;
  }

  addEmptyLineData() {
    if (this.lineData.length >= this.lineDataMaxLength) {
      return;
    }
    this.lineData.push({
      origin: '', airportOriginCode: '', airportOriginCountryCode: '',
      destination: '', airportDestinationCode: '', airportDestinationCountryCode: '',
      selected: false,
      listorg: this.getAirportOriginAutoCompleteFilter(0), listdes: this.getAirportDestinationAutoCompleteFilter(0)
    });
  }

  addLineData() {
    if (this.lineData.length >= this.lineDataMaxLength) {
      return;
    }

    this.resetLineItemViewMode();

    this.isInvalidODPair = false;
    this.isInvalidLineItemODPair = false;
    this.ODPairAlreadyExist = false;

    if (!this.isValidOriginAirportCode() || !this.isValidDestinationAirportCode()) {
      return;
    }

    this.sameODPair = this.isSameODPair();
    if (this.sameODPair) {
      this.isInvalidODPair = true;
      return;
    }

    this.sameCountryODPair = this.isSameCountryODPair();
    if (this.sameCountryODPair) {
      this.isInvalidODPair = true;
      return;
    }

    if (this.isODPairAlreadyExist()) {
      this.isInvalidODPair = true;
      this.ODPairAlreadyExist = true;
      return;
    }


    var datalength = this.lineData.length;

    switch (datalength) {
      case 0:
        this.lineData.push({ origin: this.origin, airportOriginCode: this.airportOriginCode, airportOriginCountryCode: this.airportOriginCountryCode, destination: this.destination, airportDestinationCode: this.airportDestinationCode, airportDestinationCountryCode: this.airportDestinationCountryCode, selected: false, listorg: this.filteredStates_0, listdes: this.filteredStatesDes_0 });
        break;
      case 1:
        this.lineData.push({ origin: this.origin, airportOriginCode: this.airportOriginCode, airportOriginCountryCode: this.airportOriginCountryCode, destination: this.destination, airportDestinationCode: this.airportDestinationCode, airportDestinationCountryCode: this.airportDestinationCountryCode, selected: false, listorg: this.filteredStates_1, listdes: this.filteredStatesDes_1 });
        break;
      case 2:
        this.lineData.push({ origin: this.origin, airportOriginCode: this.airportOriginCode, airportOriginCountryCode: this.airportOriginCountryCode, destination: this.destination, airportDestinationCode: this.airportDestinationCode, airportDestinationCountryCode: this.airportDestinationCountryCode, selected: false, listorg: this.filteredStates_2, listdes: this.filteredStatesDes_2 });
        break;
      case 3:
        this.lineData.push({ origin: this.origin, airportOriginCode: this.airportOriginCode, airportOriginCountryCode: this.airportOriginCountryCode, destination: this.destination, airportDestinationCode: this.airportDestinationCode, airportDestinationCountryCode: this.airportDestinationCountryCode, selected: false, listorg: this.filteredStates_3, listdes: this.filteredStatesDes_3 });
        break;
      case 4:
        this.lineData.push({ origin: this.origin, airportOriginCode: this.airportOriginCode, airportOriginCountryCode: this.airportOriginCountryCode, destination: this.destination, airportDestinationCode: this.airportDestinationCode, airportDestinationCountryCode: this.airportDestinationCountryCode, selected: false, listorg: this.filteredStates_4, listdes: this.filteredStatesDes_4 });
        break;
      case 5:
        this.lineData.push({ origin: this.origin, airportOriginCode: this.airportOriginCode, airportOriginCountryCode: this.airportOriginCountryCode, destination: this.destination, airportDestinationCode: this.airportDestinationCode, airportDestinationCountryCode: this.airportDestinationCountryCode, selected: false, listorg: this.filteredStates_5, listdes: this.filteredStatesDes_5 });
        break;
      case 6:
        this.lineData.push({ origin: this.origin, airportOriginCode: this.airportOriginCode, airportOriginCountryCode: this.airportOriginCountryCode, destination: this.destination, airportDestinationCode: this.airportDestinationCode, airportDestinationCountryCode: this.airportDestinationCountryCode, selected: false, listorg: this.filteredStates_6, listdes: this.filteredStatesDes_6 });
        break;
      case 7:
        this.lineData.push({ origin: this.origin, airportOriginCode: this.airportOriginCode, airportOriginCountryCode: this.airportOriginCountryCode, destination: this.destination, airportDestinationCode: this.airportDestinationCode, airportDestinationCountryCode: this.airportDestinationCountryCode, selected: false, listorg: this.filteredStates_7, listdes: this.filteredStatesDes_7 });
        break;
      case 8:
        this.lineData.push({ origin: this.origin, airportOriginCode: this.airportOriginCode, airportOriginCountryCode: this.airportOriginCountryCode, destination: this.destination, airportDestinationCode: this.airportDestinationCode, airportDestinationCountryCode: this.airportDestinationCountryCode, selected: false, listorg: this.filteredStates_8, listdes: this.filteredStatesDes_8 });
        break;
      case 9:
        this.lineData.push({ origin: this.origin, airportOriginCode: this.airportOriginCode, airportOriginCountryCode: this.airportOriginCountryCode, destination: this.destination, airportDestinationCode: this.airportDestinationCode, airportDestinationCountryCode: this.airportDestinationCountryCode, selected: false, listorg: this.filteredStates_9, listdes: this.filteredStatesDes_9 });
        break;
    }
    this.clearODPairValues();
    this.resetLineItemViewMode();
  }

  isValidOriginAirportCode() {
    if (this.airportOriginCode.trim() === '' && this.origin.trim() === '') {
      return false;
    }

    if (this.states && this.states.filter((item, index) => item.autopopulateformat.trim() == this.origin.trim()).length <= 0) {
      return false;
    }

    return true;
  }

  isValidDestinationAirportCode() {
    if (this.airportDestinationCode.trim() === '' && this.destination.trim() === '') {
      return false;
    }

    if (this.states && this.states.filter((item, index) => item.autopopulateformat.trim() == this.destination.trim()).length <= 0) {
      return false;
    }

    return true;
  }

  isSameODPair() {
    return this.airportOriginCode.trim() == this.airportDestinationCode.trim();
  }

  isSameCountryODPair() {
    return this.airportOriginCountryCode.trim() == this.airportDestinationCountryCode.trim();
  }

  clearODPairValues() {
    this.airportOriginCode = '';
    this.airportDestinationCode = '';
    this.origin = '';
    this.destination = '';
    this.airportOriginCountryCode = '';
    this.airportDestinationCountryCode = '';
    this.lineDataAirportOriginCode = '';
    this.lineDataAirportDestinationCode = '';
    this.lineDataAirportOriginCountryCode = '';
    this.lineDataAirportDestinationCountryCode = '';
  }

  isValidLineItemOriginAirportCode() {
    if (this.lineDataAirportOriginCode.trim() === '' && this.lineDataOriginValue.trim() === '') {
      return false;
    }

    if (this.states && this.states.filter((item, index) => item.autopopulateformat.trim() == this.lineDataOriginValue.trim()).length <= 0) {
      return false;
    }

    return true;

  }

  isSameLineItemODPair() {
    return this.lineDataAirportOriginCode.trim() == this.lineDataAirportDestinationCode.trim();
  }

  isSameLineItemCountryODPair() {
    return this.lineDataAirportOriginCountryCode.trim() == this.lineDataAirportDestinationCountryCode.trim();
  }

  isValidLineItemDestinationAirportCode() {

    if (this.lineDataAirportDestinationCode.trim() === '' && this.lineDataDestinationValue.trim() === '') {
      return false;
    }

    if (this.states && this.states.filter((item, index) => item.autopopulateformat.trim() == this.lineDataDestinationValue.trim()).length <= 0) {
      return false;
    }

    return true;
  }

  onLineItemDone(item, i) {
    this.ODPairAlreadyExist = false;
    this.isInvalidLineItemODPair = false;
    this.invalidOrigin = false;
    this.invalidDestination = false;

    if (!this.isValidLineItemOriginAirportCode()) {
      this.invalidOrigin = true;
      this.isInvalidLineItemODPair = true;
      return;
    }

    if (!this.isValidLineItemDestinationAirportCode()) {
      this.invalidDestination = true;
      this.isInvalidLineItemODPair = true;
      return;

    }

    this.sameODPair = this.isSameLineItemODPair();
    if (this.sameODPair) {
      this.isInvalidLineItemODPair = true;
      return;
    }

    this.sameCountryODPair = this.isSameLineItemCountryODPair()
    if (this.sameCountryODPair) {
      this.isInvalidLineItemODPair = true;
      return;
    }

    if (this.isLineItemODPairAlreadyExist(i)) {
      this.isInvalidLineItemODPair = true;
      this.ODPairAlreadyExist = true;
      return;
    }

    item.selected = false;
    item.origin = this.lineDataOriginValue;
    item.destination = this.lineDataDestinationValue;
    item.airportOriginCode = this.lineDataAirportOriginCode;
    item.airportDestinationCode = this.lineDataAirportDestinationCode;
  }

  onLineDataRemove(item, rowIndex: number) {
    var index = this.getIndexOfItem(item);
    if (index != -1) {
      this.lineData.splice(index, 1);
    }
  }

  onLineDataEdit(item, rowIndex: number) {
    if (item.selected) {
      item.selected = false;
      return;
    }

    this.clearValidationMessage();

    var index = this.getIndexOfItem(item);
    if (index != -1) {
      this.resetLineItemViewMode();
      item.selected = true;

      this.lineDataOriginValue = item.origin;
      this.lineDataDestinationValue = item.destination;
      this.lineDataAirportOriginCode = item.airportOriginCode;
      this.lineDataAirportDestinationCode = item.airportDestinationCode;
      this.lineDataAirportOriginCountryCode = item.airportOriginCountryCode;
      this.lineDataAirportDestinationCountryCode = item.airportDestinationCountryCode;
    }
  }

  resetLineItemViewMode() {
    for (let item of this.lineData) {
      item.selected = false;
    }
  }

  getIndexOfItem(value) {
    return typeof value === 'number' ? value : this.lineData.indexOf(value);
  }

  isValidLineItemData() {

    if (!this.isValidLineItemOriginAirportCode() || !this.isValidLineItemDestinationAirportCode()) {
      return false;
    }

    return true;
  }

  isValidData() {
    var isValid = true;
    if (this.quoteTypeSelectedValue === 1) {
      isValid = (this.isValidOriginAirportCode() && this.isValidDestinationAirportCode());
    }
    else {
      if (this.origin == '') {
        this.airportOriginCode = '';
      }

      if (this.destination == '') {
        this.airportDestinationCode = '';
      }

      if (this.origin.trim() != '' || this.airportOriginCode.trim() != '' || this.destination.trim() != '' || this.airportDestinationCode.trim() != '') {
        return false;
      }

      if (this.lineData.length == 0) {
        return false;
      }

      for (let item of this.lineData) {
        if (item.airportOriginCode.trim() == '' || item.airportDestinationCode.trim() == '') {
          isValid = false;
          break;
        }
      }
    }
    return isValid;
  }

  isValidODPair() {
    this.isInvalidODPair = false;

    this.sameODPair = this.isSameODPair();
    if (this.sameODPair) {
      this.isInvalidODPair = true;
      return false;
    }

    this.sameCountryODPair = this.isSameCountryODPair();
    if (this.sameCountryODPair) {
      this.isInvalidODPair = true;
      return false;
    }

    return this.isInvalidODPair ? false : true;
  }

  isValidLineItemODPair() {
    this.isInvalidODPair = false;
    for (let item of this.lineData) {
      if (item.airportOriginCode.trim() == item.airportDestinationCode.trim()) {
        this.sameODPair = true;
        this.isInvalidODPair = true;
        break;
      }

      if (item.airportOriginCountryCode.trim() == item.airportDestinationCountryCode.trim()) {
        this.sameCountryODPair = true;
        this.isInvalidODPair = true;
        break;
      }
    }
    return this.isInvalidODPair ? false : true;
  }

  resetLineData() {
    this.lineData = [];
    this.clearODPairValues();
    //this.addEmptyLineData();
  }

  isLineItemODPairAlreadyExist(rowIndex: number) {
    if (rowIndex == -1) {
      return false;
    }

    var length = this.lineData.filter((item, index) => index != rowIndex && item.airportOriginCode.toLowerCase().trim() == this.lineDataAirportOriginCode.toLowerCase().trim()
      && item.airportDestinationCode.toLowerCase().trim() == this.lineDataAirportDestinationCode.toLowerCase().trim()
    ).length;

    return length > 0;
  }

  isODPairAlreadyExist() {
    var length = this.lineData.filter((item, index) => item.airportOriginCode.toLowerCase().trim() == this.airportOriginCode.toLowerCase().trim()
      && item.airportDestinationCode.toLowerCase().trim() == this.airportDestinationCode.toLowerCase().trim()
    ).length;

    return length > 0;
  }

  onCalculateRate() {
    this.updateRateCalculatorInfo();
    if (this.quoteTypeSelectedValue === 1) {
      if (!this.isValidODPair()) {
        return;
      }

      this.getRateCalculatorDetails();

    }
    else {
      if (!this.isValidLineItemODPair()) {
        return;
      }
      this.getRateCalculatorDetails();

    }
  }

  updateRateCalculatorInfo() {
    var laneDetails: IAirportODPair[] = [];
    if (this.quoteTypeSelectedValue === 1) {
      var selectedOriginDetails = this.states.filter(item => item.autopopulateformat == this.origin);
      var selectedDestinationDetails = this.states.filter(item => item.autopopulateformat == this.destination);

      laneDetails.push({
        quoteType: this.quoteTypeSelectedValue,
        destination: this.destination,
        destinationCode: this.airportDestinationCode,
        destinationCountryCode: this.airportDestinationCountryCode,
        origin: this.origin,
        originCode: this.airportOriginCode,
        originCountryCode: this.airportOriginCode,
        originCity: selectedOriginDetails[0].politicalDivision2Name,  //city name
        originCountry: selectedOriginDetails[0].countryName,
        originRegion: selectedOriginDetails[0].region,
        destinationCity: selectedDestinationDetails[0].politicalDivision2Name,
        destinationCountry: selectedDestinationDetails[0].countryName,
        destinationRegion: selectedDestinationDetails[0].region
      });
    }
    else {
      for (let item of this.lineData) {
        var selectedOriginDetails = this.states.filter(odpair => odpair.autopopulateformat == item['origin']);
        var selectedDestinationDetails = this.states.filter(odpair => odpair.autopopulateformat == item['destination']);
        laneDetails.push({
          quoteType: this.quoteTypeSelectedValue,
          destination: item.destination,
          destinationCode: item.airportDestinationCode,
          destinationCountryCode: item.airportDestinationCountryCode,
          origin: item.origin,
          originCode: item.airportOriginCode,
          originCountryCode: item.airportOriginCountryCode,
          originCity: selectedOriginDetails.length > 0 && selectedOriginDetails[0].politicalDivision2Name,
          originCountry: selectedOriginDetails.length > 0 && selectedOriginDetails[0].countryName,
          originRegion: selectedOriginDetails.length > 0 && selectedOriginDetails[0].region,
          destinationCity: selectedDestinationDetails.length > 0 && selectedDestinationDetails[0].politicalDivision2Name,
          destinationCountry: selectedDestinationDetails.length > 0 && selectedDestinationDetails[0].countryName,
          destinationRegion: selectedDestinationDetails.length > 0 && selectedDestinationDetails[0].region
        });
      }
    }
    this.quoteService.setAirportODPairLaneDetail(laneDetails);
  }
 
}
