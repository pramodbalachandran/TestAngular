import { async, ComponentFixture, TestBed, getTestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { RouterTestingModule } from '@angular/router/testing';

import { RatecalculatorComponent } from '@app/internal-portal/ratecalculator/ratecalculator.component';
import { AutopopulateFilterPipe } from '@app/shared/directives/filter-data.directive';
import { AutopopulateHighlightPipe } from '@app/shared/pipes/highlight.pipe';

import { MatInputModule, MatAutocompleteModule, MatButtonModule, MatProgressSpinnerModule } from '@angular/material';
import { combineAll } from 'rxjs/internal/operators/combineAll';
import { SharedModule } from '@app/shared/shared.module';
//import { UPSersComponent } from '@app/UPSers/upsers/upsers.component';
import { ConfigService } from '@app/shared/services/shared/config.service';


import { NgModule } from '@angular/core';
import { UPSersRoutingModule } from './upsers-routing.module';
import { RateDisplayComponent } from './ratedisplay/ratedisplay.component';
import { IPHeaderComponent } from './shared/header/header.component';
import { SideNavbarComponent } from './shared/sidenavbar/sidenavbar.component';
import { MatFormFieldModule } from '@angular/material';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { GeaographyMockAPI } from '@app/shared/services/mock/geoGraphyMock.service';
import { QuoteMockAPI } from '@app/shared/services/mock/quoteMock.service';

import { state } from '@angular/animations/src/animation_metadata';
import { of } from "rxjs";
import { Component, OnInit } from '@angular/core';
import { map, startWith, retry } from 'rxjs/operators';
import { DataTableModule } from 'angular-6-datatable';
import { RoutingKey } from '@app/shared/services/shared/config.const';
import { UtilitiesService } from '@app/shared/services/shared/utilities.service';
import { airportDetails, airportDetailsDes } from '@app/models/autopopulate/autopopulate-data';
import { LocalStorageService, QuoteAPI, GeaographyAPI } from '@app/shared/services';
import { PageState } from '@app/shared/services/shared/enum';
import { FormGroup, FormBuilder, FormControl } from '@angular/forms';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Observable } from 'rxjs';
import { DomSanitizer } from '@angular/platform-browser';
import { IAirportODPair } from '@app/shared/interfaces/entities.interface';



describe('RatecalculatorComponent', () => {
  let component: RatecalculatorComponent;
  let fixture: ComponentFixture<RatecalculatorComponent>;
  let fb: FormBuilder;
  let geoGraphyService: GeaographyAPI<any>;
  let injector;


  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule,
        // DomSanitizer,
        BrowserAnimationsModule,
        DataTableModule,
        RouterTestingModule,
        MatInputModule,
        MatAutocompleteModule,
        // FormBuilder,
        MatButtonModule,
        MatProgressSpinnerModule,
        FormsModule,
        ReactiveFormsModule,
        SharedModule],
      declarations: [RatecalculatorComponent,
        AutopopulateFilterPipe,
        AutopopulateHighlightPipe,
        //UPSersComponent
      ],
      providers: [UtilitiesService, ConfigService, { provide: QuoteAPI, useClass: QuoteMockAPI }, { provide: GeaographyAPI, useClass: GeaographyMockAPI }],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA]

    })
      .compileComponents();

    injector = getTestBed();
    geoGraphyService = injector.get(GeaographyAPI);
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RatecalculatorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  //The component should be define.
  it("should have a defined component ", () => {
    expect(component).toBeDefined();
  });

  //showShortTermDetail
  it('showShortTermDetail', () => {


    component.destination = "";
    component.airportDestinationCode = "";
    component.airportDestinationCountryCode = "";
    component.origin = "";
    component.airportOriginCode = "";
    component.airportOriginCountryCode = "";

    let laneInfo = [];
    laneInfo.push({

      destination: "testing",
      destinationCode: "testing",
      destinationCountryCode: "testing",
      origin: "testing",
      originCode: "testing",
      originCountryCode: "testing"
    })
    //component.lineDataMaxLength = 0;
    component.showShortTermDetail(laneInfo);
    expect(component.origin.length).toBeGreaterThanOrEqual(0);
  });

  //geoGraphyService-mockup testing.
  it('geoGraphyService', () => {
    let serStates = [];

    geoGraphyService.getAirportdetails("Testing").subscribe(
      data => {
        serStates = data;
      });

    expect(serStates.length).toBeGreaterThanOrEqual(1);

  });

  //-updateRateCalculatorInfo.
  it('updateRateCalculatorInfo', () => {
    let laneDetails = [];
    //component.airportODPairLaneDetail = [];
    component.quoteTypeSelectedValue = 1;
    component.destination = "Delhi";
    component.airportDestinationCode = "DL";
    component.airportDestinationCountryCode = "IND";
    component.origin = "Denmark";
    component.airportOriginCode = "AARHUS";
    component.airportOriginCode = "DK";

    component.updateRateCalculatorInfo();

    expect(laneDetails.length).toBeLessThanOrEqual(1);

  });
  //-updateRateCalculatorInfo.
  it('updateRateCalculatorInfo', () => {
    let laneDetails = [];

    component.lineData = [];
    component.lineData.push({
      quoteType: 2,
      origin: 'Delhi',
      destination: 'Bangalore',
      originCode: 'DL',
      destinationCode: 'BLR',
      originCountryCode: 'IND',
      destinationCountryCode: 'IND',
      originRegion: 'Delhi',
      destinationRegion: 'Bangalore'
    },
      {
        quoteType: 2,
        origin: 'Delhi',
        destination: 'Hyderabad',
        originCode: 'DL',
        destinationCode: 'HYD',
        originCountryCode: 'IND',
        destinationCountryCode: 'IND',
        originRegion: 'Delhi',
        destinationRegion: 'Hyderabad'
      });
    //----------------------------------//
    component.quoteTypeSelectedValue = 2;
    component.destination = "Delhi";
    component.airportDestinationCode = "DL";
    component.airportDestinationCountryCode = "IND";
    component.origin = "Denmark";
    component.airportOriginCode = "AARHUS";
    component.airportOriginCode = "DK";

    component.updateRateCalculatorInfo();

    expect(laneDetails.length).toBeLessThanOrEqual(1);

  });

  //getAirportdetails
  it('getAirportdetails ', () => {
    component.states = [];
    component.myFormOrg = fb.group({
      stateCtrl: null,
      stateCtrlDes: null,
      stateCtrl_0: null,
      stateCtrlDes_0: null,
      stateCtrl_1: null,
      stateCtrlDes_1: null,
      stateCtrl_2: null,
      stateCtrlDes_2: null,
      stateCtrl_3: null,
      stateCtrlDes_3: null,
      stateCtrl_4: null,
      stateCtrlDes_4: null,
      stateCtrl_5: null,
      stateCtrlDes_5: null,
      stateCtrl_6: null,
      stateCtrlDes_6: null,
      stateCtrl_7: null,
      stateCtrlDes_7: null,
      stateCtrl_8: null,
      stateCtrlDes_8: null,
      stateCtrl_9: null,
      stateCtrlDes_9: null,
    });

    component.getAirportdetails("test", false);

    //console.log(component.quoteTypeSelectedValue);
    expect(component.states.length).toBeGreaterThanOrEqual(0);
  });

  //   //_filterStates
  it('_filterStates', () => {
    component.states = [];
    component.states.push({
      autopopulateformathighlight: "yes",
      airportCode: "AAR",
      airportName: "AARHUS",
      autopopulateformat: "AAR Ulstrup,Denmark-Aarhus",
      countryCode: "DK",
      countryName: "Denmark",
      isCustomerData: "0",
      politicalDivision2Name: "ULSTRUP",
      autopopulateformat1: '',
      autopopulateformat2: '',
      postalCode: '',
      region: ''
    });

    component.states.push({
      autopopulateformathighlight: "yes",
      airportCode: "ABE",
      airportName: "ALLENTOWN",
      autopopulateformat: "ABE Eckert,United States-Allentown",
      countryCode: "US",
      countryName: "United States",
      isCustomerData: "0",
      politicalDivision2Name: "ECKERT",
      autopopulateformat1: '',
      autopopulateformat2: '',
      postalCode: '',
      region: ''
    });

    component.states.push({
      autopopulateformathighlight: "yes",
      airportCode: "ABE",
      airportName: "ALLENTOWN",
      autopopulateformat: "ABE Forty Fort,United States-Allentown",
      countryCode: "US",
      countryName: "United States",
      isCustomerData: "0",
      politicalDivision2Name: "FORTY FORT",
      autopopulateformat1: '',
      autopopulateformat2: '',
      postalCode: '',
      region: ''
    });

    component.states.push({
      autopopulateformathighlight: "yes",
      airportCode: "ABE",
      airportName: "ALLENTOWN",
      autopopulateformat: "ABE Kohinoor Junction,United States-Allentown",
      countryCode: "US",
      countryName: "United States",
      isCustomerData: "0",
      politicalDivision2Name: "KOHINOOR JUNCTION",
      autopopulateformat1: '',
      autopopulateformat2: '',
      postalCode: '',
      region: ''
    });

    component.states.push({
      autopopulateformathighlight: "yes",
      airportCode: "ABE",
      airportName: "ALLENTOWN",
      autopopulateformat: "ABE Portland,United States-Allentown",
      countryCode: "US",
      countryName: "United States",
      isCustomerData: "0",
      politicalDivision2Name: "PORTLAND",
      autopopulateformat1: '',
      autopopulateformat2: '',
      postalCode: '',
      region: ''
    });

    component.states.push({
      autopopulateformathighlight: "yes",
      airportCode: "ABQ",
      airportName: "ALBUQUERQUE",
      autopopulateformat: "ABQ Roswell,United States-Albuquerque",
      countryCode: "US",
      countryName: "United States",
      isCustomerData: "0",
      politicalDivision2Name: "ROSWELL",
      autopopulateformat1: '',
      autopopulateformat2: '',
      postalCode: '',
      region: ''
    });

    component.states.push({
      autopopulateformathighlight: "yes",
      airportCode: "ABQ",
      airportName: "ALBUQUERQUE",
      autopopulateformat: "ABQ Willard,United States-Albuquerque",
      countryCode: "US",
      countryName: "United States",
      isCustomerData: "0",
      politicalDivision2Name: "WILLARD",
      autopopulateformat1: '',
      autopopulateformat2: '',
      postalCode: '',
      region: ''
    });

    component.intemediatefilteredStates = []
    component.finalfilteredStates = []
    component._filterStates("United");

    expect(component.states.length).toBeGreaterThanOrEqual(1);

  });

  //isODPairAlreadyExist
  it('isODPairAlreadyExist', () => {
    component.airportOriginCode = "DEL";
    component.airportDestinationCode = "BLR";
    component.lineData = [];
    component.lineData.push({
      airportOriginCode: "DEL",
      airportDestinationCode: "BLR"
    }, {
        airportOriginCode: "DEL",
        airportDestinationCode: "HYD"
      }, {
        airportOriginCode: "VZG",
        airportDestinationCode: "BLR"
      }, {
        airportOriginCode: "DEL",
        airportDestinationCode: "VZG"
      });
    expect(component.isODPairAlreadyExist()).toBeGreaterThanOrEqual(1);

  });

  //isLineItemODPairAlreadyExist
  it('isODPairAlreadyExist', () => {

    component.airportOriginCode = "DEL";
    component.airportDestinationCode = "BLR";
    component.lineData = [];
    component.lineData.push({
      airportOriginCode: "DEL",
      airportDestinationCode: "BLR"
    }, {
        airportOriginCode: "DEL",
        airportDestinationCode: "HYD"
      }, {
        airportOriginCode: "VZG",
        airportDestinationCode: "BLR"
      }, {
        airportOriginCode: "DEL",
        airportDestinationCode: "VZG"
      });
    expect(component.isLineItemODPairAlreadyExist(1)).toBeGreaterThanOrEqual(1);

  });


  //resetLineData
  it('resetLineData', () => {

    component.lineData = [];
    component.airportOriginCode = 'TESTING';
    component.airportDestinationCode = 'TESTING';
    component.origin = 'TESTING';
    component.destination = 'TESTING';
    component.airportOriginCountryCode = 'TESTING';
    component.airportDestinationCountryCode = 'TESTING';
    component.lineDataAirportOriginCode = 'TESTING';
    component.lineDataAirportDestinationCode = 'TESTING';
    component.lineDataAirportOriginCountryCode = 'TESTING';
    component.lineDataAirportDestinationCountryCode = 'TESTING';
    component.resetLineData();
    expect(component.airportOriginCode.length).toBeLessThanOrEqual(0);

  });

  //isValidLineItemODPair
  it('isValidLineItemODPair', () => {

    component.isInvalidODPair = false;
    component.sameODPair = false;
    component.isInvalidODPair = false;
    component.sameCountryODPair = false;
    component.isInvalidODPair = false;

    component.lineData = [];
    component.lineData.push({
      airportOriginCode: "DEL",
      airportDestinationCode: "BLR",
      airportOriginCountryCode: "DEL",
      airportDestinationCountryCode: "BLR"
    }, {
        airportOriginCode: "DEL",
        airportDestinationCode: "HYD",
        airportOriginCountryCode: "DEL",
        airportDestinationCountryCode: "HYD"
      }, {
        airportOriginCode: "VZG",
        airportDestinationCode: "BLR",
        airportOriginCountryCode: "VZG",
        airportDestinationCountryCode: "BLR"
      }, {
        airportOriginCode: "DEL",
        airportDestinationCode: "DEL",
        airportOriginCountryCode: "DEL",
        airportDestinationCountryCode: "VZG"
      });
    component.isValidLineItemODPair();
    expect(component.sameODPair).toEqual(true);

  });

  //isValidLineItemODPair
  it('isValidLineItemODPair', () => {

    component.isInvalidODPair = false;
    component.sameODPair = false;
    component.isInvalidODPair = false;
    component.sameCountryODPair = false;
    component.isInvalidODPair = false;

    component.lineData = [];
    component.lineData.push({
      airportOriginCode: "DEL",
      airportDestinationCode: "BLR",
      airportOriginCountryCode: "DEL",
      airportDestinationCountryCode: "BLR"
    }, {
        airportOriginCode: "DEL",
        airportDestinationCode: "HYD",
        airportOriginCountryCode: "DEL",
        airportDestinationCountryCode: "HYD"
      }, {
        airportOriginCode: "VZG",
        airportDestinationCode: "BLR",
        airportOriginCountryCode: "VZG",
        airportDestinationCountryCode: "BLR"
      }, {
        airportOriginCode: "DEL",
        airportDestinationCode: "VZG",
        airportOriginCountryCode: "DEL",
        airportDestinationCountryCode: "DEL"
      });
    component.isValidLineItemODPair();
    expect(component.sameCountryODPair).toEqual(true);

  });

  //isValidODPair
  it('isValidODPair', () => {

    component.isInvalidODPair = false;
    component.airportOriginCode = "";
    component.airportDestinationCode = "";
    component.airportOriginCountryCode = "";
    component.airportDestinationCountryCode = "";
    component.isValidODPair();
    expect(component.isInvalidODPair).toEqual(true);
  });

  //isValidODPair
  it('isValidODPair', () => {

    component.isInvalidODPair = false;
    component.airportOriginCode = "Testing";
    component.airportDestinationCode = "";
    component.airportOriginCountryCode = "Testing";
    component.airportDestinationCountryCode = "";
    component.isValidODPair();
    expect(component.isInvalidODPair).toEqual(false);

  });

  //isValidData
  it('isValidData', () => {

    let isValid = false;
    component.quoteTypeSelectedValue = 1;
    component.airportOriginCode = "";
    component.origin = "";
    component.airportDestinationCode = "";
    component.destination = "";
    component.isValidData();
    expect(isValid).toEqual(false);

  });
  //isValidData
  it('isValidData', () => {

    let isValid = false;
    component.quoteTypeSelectedValue = 2;
    component.origin = "";
    component.destination = "";
    component.airportDestinationCode = "";
    component.airportOriginCode = "";
    component.lineData = [];


    component.isValidData();
    expect(isValid).toEqual(false);

  });
  //isValidData
  it('isValidData', () => {

    let isValid = false;
    component.quoteTypeSelectedValue = 2;
    component.origin = "TESTING";
    component.destination = "";
    component.airportDestinationCode = "TESTING";
    component.airportOriginCode = "";
    component.lineData = [];
    component.lineData.push({
      airportOriginCode: "",
      airportDestinationCode: ""
    });

    component.isValidData();
    expect(isValid).toEqual(false);

  });

  //getIndexOfItem
  it('getIndexOfItem', () => {
    component.lineData = [];
    component.lineData.push({
      airportOriginCode: "Testing",
      airportDestinationCode: "Testing"
    }, {
        airportOriginCode: "Testing1",
        airportDestinationCode: "Testing1"
      }, {
        airportOriginCode: "Testing2",
        airportDestinationCode: "Testing2"
      });
    expect(component.getIndexOfItem(1)).toEqual(1);

  });
  //resetLineItemViewMode
  it('resetLineItemViewMode', () => {
    component.lineData = [];
    component.lineData.push({
      airportOriginCode: "Testing",
      airportDestinationCode: "Testing",
      selected: true
    }, {
        airportOriginCode: "Testing1",
        airportDestinationCode: "Testing1",
        selected: true
      }, {
        airportOriginCode: "Testing2",
        airportDestinationCode: "Testing2",
        selected: true
      });
    component.resetLineItemViewMode()
    expect(component.lineData[0].selected).toEqual(false);

  });
  //onLineDataEdit
  it('onLineDataEdit', () => {
    //component.selected = true;

    component.lineDataOriginValue = "";
    component.lineDataDestinationValue = "";
    component.lineDataAirportOriginCode = "";
    component.lineDataAirportDestinationCode = "";
    component.lineDataAirportOriginCountryCode = "";
    component.lineDataAirportDestinationCountryCode = "";

    component.isInvalidODPair = true;
    component.isInvalidLineItemODPair = true;
    component.sameODPair = true;
    component.sameCountryODPair = true;
    component.ODPairAlreadyExist = true;

    component.lineData = [];
    component.lineData.push({
      origin: "Testing",
      destination: "Testing",
      airportOriginCode: "Testing",
      airportDestinationCode: "Testing",
      airportOriginCountryCode: "Testing",
      airportDestinationCountryCode: "Testing",
      selected: false
    }, {
        origin: "Testing1",
        destination: "Testing1",
        airportOriginCode: "Testing1",
        airportDestinationCode: "Testing1",
        airportOriginCountryCode: "Testing1",
        airportDestinationCountryCode: "Testing1",
        selected: false
      });
    component.onLineDataEdit(component.lineData[0], 0);
    expect(component.isInvalidODPair).toEqual(false);

  });

  //onLineDataRemove
  it('onLineDataRemove', () => {
    component.lineData = [];
    component.lineData.push({
      airportOriginCode: "Testing",
      airportDestinationCode: "Testing",
      selected: true
    }, {
        airportOriginCode: "Testing1",
        airportDestinationCode: "Testing1",
        selected: true
      }, {
        airportOriginCode: "Testing2",
        airportDestinationCode: "Testing2",
        selected: true
      });
    component.onLineDataRemove(component.lineData[0], 0);
    expect(component.lineData.length).toBeLessThanOrEqual(2);

  });

  //add line data success
  it('add line data success', () => {

    component.isInvalidODPair = true;
    component.isInvalidLineItemODPair = true;
    component.ODPairAlreadyExist = true;

    component.airportOriginCode = '';
    component.origin = '';


    component.lineDataMaxLength = 10;
    component.lineData = [];

    component.lineData.push({
      origin: 'LON',
      destination: 'CO',
      airportDestinationCode: 'LON',
      airportOriginCode: 'CO',
      selected: true
    })
    component.addLineData();
    expect(component.lineData.length).toBeGreaterThanOrEqual(1);

  });

  //add line data success
  it('add line data success', () => {

    component.isInvalidODPair = true;
    component.isInvalidLineItemODPair = true;
    component.ODPairAlreadyExist = true;

    component.airportOriginCode = 'Testing';
    component.origin = '';


    component.lineDataMaxLength = 10;
    component.lineData = [];

    component.lineData.push({
      origin: 'LON',
      destination: 'CO',
      airportDestinationCode: 'LON',
      airportOriginCode: 'CO',
      selected: true
    })
    component.addLineData();
    expect(component.lineData.length).toBeGreaterThanOrEqual(1);

  });

  //add line data success
  it('add line data success', () => {

    component.isInvalidODPair = true;
    component.isInvalidLineItemODPair = true;
    component.ODPairAlreadyExist = true;

    component.airportOriginCode = 'Testing';
    component.origin = 'Testing';

    component.destination = '';
    component.airportDestinationCode = '';


    component.lineDataMaxLength = 10;
    component.lineData = [];

    component.lineData.push({
      origin: 'LON',
      destination: 'CO',
      airportDestinationCode: 'LON',
      airportOriginCode: 'CO',
      selected: true
    })
    component.addLineData();
    expect(component.lineData.length).toBeGreaterThanOrEqual(1);

  });

  //add line data success
  it('add line data success', () => {

    component.isInvalidODPair = true;
    component.isInvalidLineItemODPair = true;
    component.ODPairAlreadyExist = true;

    component.airportOriginCode = 'Testing';
    component.origin = 'Testing';

    component.destination = 'Testing';
    component.airportDestinationCode = 'Testing';

    component.lineDataMaxLength = 10;
    component.lineData = [];

    component.lineData.push({
      origin: 'LON',
      destination: 'CO',
      airportDestinationCode: 'LON',
      airportOriginCode: 'CO',
      selected: true
    })
    component.addLineData();
    expect(component.lineData.length).toBeGreaterThanOrEqual(1);

  });


  //add line data success
  it('add line data success', () => {

    component.isInvalidODPair = true;
    component.isInvalidLineItemODPair = true;
    component.ODPairAlreadyExist = true;

    component.airportOriginCode = 'Testing';
    component.origin = 'Testing';

    component.airportOriginCode = 'Testing';
    component.airportDestinationCode = 'Testing2';

    component.lineDataMaxLength = 10;
    component.lineData = [];

    component.lineData.push({
      origin: 'LON',
      destination: 'CO',
      airportDestinationCode: 'LON',
      airportOriginCode: 'CO',
      selected: true
    })
    component.addLineData();
    expect(component.lineData.length).toBeGreaterThanOrEqual(1);

  });

  //add line data success
  it('add line data success', () => {

    component.isInvalidODPair = true;
    component.isInvalidLineItemODPair = true;
    component.ODPairAlreadyExist = true;

    component.airportOriginCode = 'Testing';
    component.origin = 'Testing';

    component.airportOriginCode = 'Testing';
    component.airportDestinationCode = 'Testing2';

    component.airportOriginCountryCode = '';
    component.airportDestinationCountryCode = '';

    component.lineDataMaxLength = 10;
    component.lineData = [];

    component.lineData.push({
      origin: 'LON',
      destination: 'CO',
      airportDestinationCode: 'LON',
      airportOriginCode: 'CO',
      selected: true
    })
    component.addLineData();
    expect(component.lineData.length).toBeGreaterThanOrEqual(1);

  });


  //add line data success
  it('add line data success', () => {

    component.isInvalidODPair = true;
    component.isInvalidLineItemODPair = true;
    component.ODPairAlreadyExist = true;

    component.airportOriginCode = '';
    component.origin = '';

    component.airportOriginCode = '';
    component.airportDestinationCode = '';

    component.airportOriginCountryCode = '';
    component.airportDestinationCountryCode = '';

    component.lineDataMaxLength = 10;
    component.lineData = [];

    component.lineData.push({
      origin: 'LON',
      destination: 'CO',
      airportDestinationCode: 'LON',
      airportOriginCode: 'CO',
      selected: true
    })
    component.addLineData();
    expect(component.lineData.length).toBeGreaterThanOrEqual(1);

  });

  //add line data success
  it('add line data success', () => {

    component.filteredStates_0 = getairportDetails(0);
    component.filteredStatesDes_0 = getairportDetails(0);
    component.filteredStates_1 = getairportDetails(1);
    component.filteredStatesDes_1 = getairportDetails(1);
    component.filteredStates_2 = getairportDetails(2);
    component.filteredStatesDes_2 = getairportDetails(2);
    component.filteredStates_3 = getairportDetails(3);
    component.filteredStatesDes_3 = getairportDetails(3);
    component.filteredStates_4 = getairportDetails(4);
    component.filteredStatesDes_4 = getairportDetails(4);
    component.filteredStates_5 = getairportDetails(5);
    component.filteredStatesDes_5 = getairportDetails(5);
    component.filteredStates_6 = getairportDetails(6);
    component.filteredStatesDes_6 = getairportDetails(6);
    component.filteredStates_7 = getairportDetails(7);
    component.filteredStatesDes_7 = getairportDetails(7);
    component.filteredStates_8 = getairportDetails(8);
    component.filteredStatesDes_8 = getairportDetails(8);
    component.filteredStates_9 = getairportDetails(9);
    component.filteredStatesDes_9 = getairportDetails(9);

    component.isInvalidODPair = true;
    component.isInvalidLineItemODPair = true;
    component.ODPairAlreadyExist = true;

    component.airportOriginCode = 'Testing';
    component.origin = 'Testing';

    component.airportOriginCode = 'Testing';
    component.airportDestinationCode = 'Testing2';

    component.airportOriginCountryCode = 'Testing';
    component.airportDestinationCountryCode = 'Testing2';

    component.lineDataMaxLength = 10;
    component.lineData = [];

    component.lineData.push({
      origin: "Testing",
      airportOriginCode: "Testing",
      airportOriginCountryCode: "Testing",
      destination: "Testing",
      airportDestinationCode: "Testing",
      airportDestinationCountryCode: "Testing",
      selected: true,
      listorg: "Testing",
      listdes: "Testing"
    });

    component.addLineData();

    component.lineData.push({
      origin: "Testing1",
      airportOriginCode: "Testing1",
      airportOriginCountryCode: "Testing1",
      destination: "Testing1",
      airportDestinationCode: "Testing1",
      airportDestinationCountryCode: "Testing1",
      selected: true,
      listorg: "Testing1",
      listdes: "Testing1"
    })

    component.addLineData();

    component.lineData.push({
      origin: "Testing2",
      airportOriginCode: "Testing2",
      airportOriginCountryCode: "Testing2",
      destination: "Testing2",
      airportDestinationCode: "Testing2",
      airportDestinationCountryCode: "Testing2",
      selected: true,
      listorg: "Testing2",
      listdes: "Testing2"
    })

    component.addLineData();

    component.lineData.push({
      origin: "Testing3",
      airportOriginCode: "Testing3",
      airportOriginCountryCode: "Testing3",
      destination: "Testing3",
      airportDestinationCode: "Testing3",
      airportDestinationCountryCode: "Testing3",
      selected: true,
      listorg: "Testing3",
      listdes: "Testing3"
    })
    component.addLineData();

    component.lineData.push({
      origin: "Testing4",
      airportOriginCode: "Testing4",
      airportOriginCountryCode: "Testing4",
      destination: "Testing4",
      airportDestinationCode: "Testing4",
      airportDestinationCountryCode: "Testing4",
      selected: true,
      listorg: "Testing4",
      listdes: "Testing4"
    })
    component.addLineData();

    component.lineData.push({
      origin: "Testing5",
      airportOriginCode: "Testing5",
      airportOriginCountryCode: "Testing5",
      destination: "Testing5",
      airportDestinationCode: "Testing5",
      airportDestinationCountryCode: "Testing5",
      selected: true,
      listorg: "Testing5",
      listdes: "Testing5"
    })
    component.addLineData();

    component.lineData.push({
      origin: "Testing6",
      airportOriginCode: "Testing6",
      airportOriginCountryCode: "Testing6",
      destination: "Testing6",
      airportDestinationCode: "Testing6",
      airportDestinationCountryCode: "Testing6",
      selected: true,
      listorg: "Testing6",
      listdes: "Testing6"
    })
    component.addLineData();

    component.lineData.push({
      origin: "Testing7",
      airportOriginCode: "Testing7",
      airportOriginCountryCode: "Testing7",
      destination: "Testing7",
      airportDestinationCode: "Testing7",
      airportDestinationCountryCode: "Testing7",
      selected: true,
      listorg: "Testing7",
      listdes: "Testing7"
    })
    component.addLineData();

    component.lineData.push({
      origin: "Testing8",
      airportOriginCode: "Testing8",
      airportOriginCountryCode: "Testing8",
      destination: "Testing8",
      airportDestinationCode: "Testing8",
      airportDestinationCountryCode: "Testing8",
      selected: true,
      listorg: "Testing8",
      listdes: "Testing8"
    })
    component.addLineData();

    component.lineData.push({
      origin: "Testing9",
      airportOriginCode: "Testing9",
      airportOriginCountryCode: "Testing9",
      destination: "Testing9",
      airportDestinationCode: "Testing9",
      airportDestinationCountryCode: "Testing9",
      selected: true,
      listorg: "Testing9",
      listdes: "Testing9"
    })
    component.addLineData();
    expect(component.lineData.length).toBeGreaterThanOrEqual(1);

  });

  //return this.airportOriginCountryCode.trim() == this.airportDestinationCountryCode.trim();


  //add line data failure
  it('add line data failure', () => {
    component.lineDataMaxLength = 10;
    component.lineData = [];
    component.origin = '';
    component.destination = '';
    component.addLineData();
    expect(component.lineData.length).toBeGreaterThanOrEqual(0);
  });

  // autopopulateformat: string;
  // airportCode: string;
  // airportName: string;
  // countryCode: string;
  // countryName: string;
  // politicalDivision2Name: string;
  // isCustomerData: string;

  function getairportDetails(val: number): Observable<airportDetails[]> {
    let states = [];
    switch (val) {
      case 0:
        states.push({
          'autopopulateformat': "One",
          'airportCode': "One",
          'airportName': "One",
          'countryCode': "One",
          'countryName': "One",
          'politicalDivision2Name': "One",
          'isCustomerData': "One"
        });
        break;
      case 1:
        states.push({
          'autopopulateformat': "One1",
          'airportCode': "One1",
          'airportName': "One1",
          'countryCode': "One1",
          'countryName': "One1",
          'politicalDivision2Name': "One1",
          'isCustomerData': "One1"
        });
        break;
      case 2:
        states.push({
          'autopopulateformat': "One2",
          'airportCode': "One2",
          'airportName': "One2",
          'countryCode': "One2",
          'countryName': "One2",
          'politicalDivision2Name': "One2",
          'isCustomerData': "One2"
        });
        break;
      case 3:
        states.push({
          'autopopulateformat': "One3",
          'airportCode': "One3",
          'airportName': "One3",
          'countryCode': "One3",
          'countryName': "One3",
          'politicalDivision2Name': "One3",
          'isCustomerData': "One3"
        });
        break;
      case 4:
        states.push({
          'autopopulateformat': "One4",
          'airportCode': "One4",
          'airportName': "One4",
          'countryCode': "One4",
          'countryName': "One4",
          'politicalDivision2Name': "One4",
          'isCustomerData': "One4"
        });
        break;
      case 5:
        states.push({
          'autopopulateformat': "One5",
          'airportCode': "One5",
          'airportName': "One5",
          'countryCode': "One5",
          'countryName': "One5",
          'politicalDivision2Name': "One5",
          'isCustomerData': "One5"
        });
        break;
      case 6:
        states.push({
          'autopopulateformat': "One6",
          'airportCode': "One6",
          'airportName': "One6",
          'countryCode': "One6",
          'countryName': "One6",
          'politicalDivision2Name': "One6",
          'isCustomerData': "One6"
        });
        break;
      case 7:
        states.push({
          'autopopulateformat': "One7",
          'airportCode': "One7",
          'airportName': "One7",
          'countryCode': "One7",
          'countryName': "One7",
          'politicalDivision2Name': "One7",
          'isCustomerData': "One7"
        });
        break;
      case 8:
        states.push({
          'autopopulateformat': "One8",
          'airportCode': "One8",
          'airportName': "One8",
          'countryCode': "One8",
          'countryName': "One8",
          'politicalDivision2Name': "One8",
          'isCustomerData': "One8"
        });
        break;
      case 9:
        states.push({
          'autopopulateformat': "One9",
          'airportCode': "One9",
          'airportName': "One9",
          'countryCode': "One9",
          'countryName': "One9",
          'politicalDivision2Name': "One9",
          'isCustomerData': "One9"
        });
        break;
      case 10:
        states.push({
          'autopopulateformat': "One10",
          'airportCode': "One10",
          'airportName': "One10",
          'countryCode': "One10",
          'countryName': "One10",
          'politicalDivision2Name': "One10",
          'isCustomerData': "One10"
        });
        break;
      default:
        states.push({
          'autopopulateformat': "One",
          'airportCode': "One",
          'airportName': "One",
          'countryCode': "One",
          'countryName': "One",
          'politicalDivision2Name': "One",
          'isCustomerData': "One"
        });
        break;
    }
    return of(states);
  }





  //isValidLineItemOriginAirportCode
  it('isValidLineItemOriginAirportCode', () => {
    component.lineDataAirportOriginCode = "Teting";
    component.lineDataOriginValue = "Testing";
    expect(component.isValidLineItemOriginAirportCode()).toEqual(true)
  });



  //isValidDestinationAirportCode
  it('isValidDestinationAirportCode', () => {
    component.airportDestinationCode = "Teting";
    component.destination = "Testing";
    expect(component.isValidDestinationAirportCode()).toEqual(true)
  });

  //resetLineItemViewMode
  it('resetLineItemViewMode', () => {
    component.lineData = [];
    component.lineData.push({
      airportDestinationCode: "Teting",
      destination: "Testing",
      selected: true
    }, {
        airportDestinationCode: "Teting",
        destination: "Testing",
        selected: true
      })
    component.resetLineItemViewMode();
    expect(component.lineData[0].selected).toEqual(false)
  });


  //isSameODPair
  it('isSameODPair', () => {
    component.airportOriginCode = "Teting";
    component.airportDestinationCode = "Testing";
    expect(component.isSameODPair()).toEqual(true)
  });

  //isSameCountryODPair
  it('isSameCountryODPair', () => {
    component.airportOriginCountryCode = "Teting";
    component.airportDestinationCountryCode = "Testing";
    expect(component.isSameCountryODPair()).toEqual(true)
  });

  //onLineItemDone
  //add line data failure
  it('onLineItemDone', () => {

    component.lineDataAirportOriginCode = "Teting";
    component.lineDataOriginValue = "Testing";
    component.airportDestinationCode = "Teting";
    component.destination = "Testing";
    component.airportOriginCountryCode = "Teting";
    component.airportDestinationCountryCode = "Testing";
    component.airportOriginCode = "Teting";
    component.airportDestinationCode = "Testing";

    component.lineData = [];
    component.lineData.push({
      airportDestinationCode: "Teting",
      destination: "Testing",
      selected: true
    }, {
        airportDestinationCode: "Teting",
        destination: "Testing",
        selected: true
      })

    component.lineDataMaxLength = 10;
    component.origin = '';
    component.destination = '';
    component.addLineData();
    expect(component.lineData.length).toBeGreaterThanOrEqual(0);
  });


  // //isValidLineItemDestinationAirportCode
  it('isValidLineItemDestinationAirportCode', () => {
    component.lineDataAirportDestinationCode = 'LON';
    component.lineDataDestinationValue = 'UK';
    expect(component.isValidLineItemDestinationAirportCode()).toEqual(true);
  });

  //isSameLineItemCountryODPair
  it('isSameLineItemCountryODPair', () => {
    component.lineDataAirportOriginCountryCode = 'LON';
    component.lineDataAirportDestinationCountryCode = 'UK';
    expect(component.isSameLineItemCountryODPair()).toEqual(true);
  });
  //isSameLineItemODPair
  it('isSameLineItemODPair', () => {
    component.lineDataAirportOriginCode = 'LON';
    component.lineDataAirportDestinationCode = 'UK';
    expect(component.isSameLineItemODPair()).toEqual(true);
  });

  // onLineItemDone 
  it('add line data done', () => {
    component.lineData = [] = new Array();
    component.lineData.push({
      origin: 'Cochin',
      destination: 'London',
      selected: false,
      airportOriginCode: '',
      airportDestinationCode: ''
    });

    component.lineDataOriginValue = 'LOC';
    component.lineDataDestinationValue = 'LON';
    component.lineDataAirportOriginCode = 'LOC';
    component.lineDataAirportDestinationCode = 'LON';
    component.onLineItemDone(component.lineData[0], 0);
    expect(component.lineData[0].origin).toEqual('LOC');
  });


  //   //onShortTermClick-positive
  it('short term success selection', () => {

    component.airportOriginCode = 'Testing';
    component.airportDestinationCode = 'Testing';
    component.origin = 'Testing';
    component.destination = 'Testing';
    component.airportOriginCountryCode = 'Testing';
    component.airportDestinationCountryCode = 'Testing';
    component.lineDataAirportOriginCode = 'Testing';
    component.lineDataAirportDestinationCode = 'Testing';
    component.lineDataAirportOriginCountryCode = 'Testing';
    component.lineDataAirportDestinationCountryCode = 'Testing';

    component.isInvalidODPair = true;
    component.isInvalidLineItemODPair = true;
    component.sameODPair = true;
    component.sameCountryODPair = true;
    component.ODPairAlreadyExist = true;
    component.lineData = [];

    component.quoteTypeSelectedValue = 1;
    component.onShortTermClick(1);
    //console.log(component.quoteTypeSelectedValue);
    expect(component.isInvalidODPair).toEqual(true);

  });

  // //onShortTermClick-negative
  it('short term failure selection', () => {
    component.lineData = [];

    component.airportOriginCode = 'Testing';
    component.airportDestinationCode = 'Testing';
    component.origin = 'Testing';
    component.destination = 'Testing';
    component.airportOriginCountryCode = 'Testing';
    component.airportDestinationCountryCode = 'Testing';
    component.lineDataAirportOriginCode = 'Testing';
    component.lineDataAirportDestinationCode = 'Testing';
    component.lineDataAirportOriginCountryCode = 'Testing';
    component.lineDataAirportDestinationCountryCode = 'Testing';

    component.isInvalidODPair = true;
    component.isInvalidLineItemODPair = true;
    component.sameODPair = true;
    component.sameCountryODPair = true;
    component.ODPairAlreadyExist = true;
    component.quoteTypeSelectedValue = 1;
    component.onShortTermClick(2);
    expect(component.airportOriginCode.length).toBeGreaterThanOrEqual(0);
  });


  //long term selection.
  it('long term selection', () => {
    component.airportOriginCode = 'Testing';
    component.airportDestinationCode = 'Testing';
    component.origin = 'Testing';
    component.destination = 'Testing';
    component.airportOriginCountryCode = 'Testing';
    component.airportDestinationCountryCode = 'Testing';
    component.lineDataAirportOriginCode = 'Testing';
    component.lineDataAirportDestinationCode = 'Testing';
    component.lineDataAirportOriginCountryCode = 'Testing';
    component.lineDataAirportDestinationCountryCode = 'Testing';

    component.isInvalidODPair = true;
    component.isInvalidLineItemODPair = true;
    component.sameODPair = true;
    component.sameCountryODPair = true;
    component.ODPairAlreadyExist = true;
    component.lineData = [];

    component.quoteTypeSelectedValue = 2;
    component.onLongTermClick(1);
    expect(component.airportOriginCode.length).toBeGreaterThanOrEqual(0);
  });

  //getAirportOriginAutoCompleteFilter
  it('getAirportOriginAutoCompleteFilter', () => {

    let sFlag = true;
    component.filteredStates_0 = getairportDetails(0);
    component.filteredStatesDes_0 = getairportDetails(0);
    component.filteredStates_1 = getairportDetails(1);
    component.filteredStatesDes_1 = getairportDetails(1);
    component.filteredStates_2 = getairportDetails(2);
    component.filteredStatesDes_2 = getairportDetails(2);
    component.filteredStates_3 = getairportDetails(3);
    component.filteredStatesDes_3 = getairportDetails(3);
    component.filteredStates_4 = getairportDetails(4);
    component.filteredStatesDes_4 = getairportDetails(4);
    component.filteredStates_5 = getairportDetails(5);
    component.filteredStatesDes_5 = getairportDetails(5);
    component.filteredStates_6 = getairportDetails(6);
    component.filteredStatesDes_6 = getairportDetails(6);
    component.filteredStates_7 = getairportDetails(7);
    component.filteredStatesDes_7 = getairportDetails(7);
    component.filteredStates_8 = getairportDetails(8);
    component.filteredStatesDes_8 = getairportDetails(8);
    component.filteredStates_9 = getairportDetails(9);
    component.filteredStatesDes_9 = getairportDetails(9);

    component.getAirportOriginAutoCompleteFilter(0);
    component.getAirportOriginAutoCompleteFilter(1);
    component.getAirportOriginAutoCompleteFilter(2);
    component.getAirportOriginAutoCompleteFilter(3);
    component.getAirportOriginAutoCompleteFilter(4);
    component.getAirportOriginAutoCompleteFilter(5);
    component.getAirportOriginAutoCompleteFilter(6);
    component.getAirportOriginAutoCompleteFilter(7);
    component.getAirportOriginAutoCompleteFilter(8);
    component.getAirportOriginAutoCompleteFilter(9);
    expect(sFlag).toEqual(true);

  });

  //getAirportDestinationAutoCompleteFilter
  it('getAirportDestinationAutoCompleteFilter', () => {

    let sFlag = true;
    component.filteredStates_0 = getairportDetails(0);
    component.filteredStatesDes_0 = getairportDetails(0);
    component.filteredStates_1 = getairportDetails(1);
    component.filteredStatesDes_1 = getairportDetails(1);
    component.filteredStates_2 = getairportDetails(2);
    component.filteredStatesDes_2 = getairportDetails(2);
    component.filteredStates_3 = getairportDetails(3);
    component.filteredStatesDes_3 = getairportDetails(3);
    component.filteredStates_4 = getairportDetails(4);
    component.filteredStatesDes_4 = getairportDetails(4);
    component.filteredStates_5 = getairportDetails(5);
    component.filteredStatesDes_5 = getairportDetails(5);
    component.filteredStates_6 = getairportDetails(6);
    component.filteredStatesDes_6 = getairportDetails(6);
    component.filteredStates_7 = getairportDetails(7);
    component.filteredStatesDes_7 = getairportDetails(7);
    component.filteredStates_8 = getairportDetails(8);
    component.filteredStatesDes_8 = getairportDetails(8);
    component.filteredStates_9 = getairportDetails(9);
    component.filteredStatesDes_9 = getairportDetails(9);

    component.getAirportDestinationAutoCompleteFilter(0);
    component.getAirportDestinationAutoCompleteFilter(1);
    component.getAirportDestinationAutoCompleteFilter(2);
    component.getAirportDestinationAutoCompleteFilter(3);
    component.getAirportDestinationAutoCompleteFilter(4);
    component.getAirportDestinationAutoCompleteFilter(5);
    component.getAirportDestinationAutoCompleteFilter(6);
    component.getAirportDestinationAutoCompleteFilter(7);
    component.getAirportDestinationAutoCompleteFilter(8);
    component.getAirportDestinationAutoCompleteFilter(9);
    expect(sFlag).toEqual(true);

  });

  //onAirportSelection--
  it('onAirportSelection', () => {
    component.states = [];
    component.states.push({
      autopopulateformathighlight: "yes",
      airportCode: "AAR",
      airportName: "AARHUS",
      autopopulateformat: "AAR Ulstrup,Denmark-Aarhus",
      countryCode: "DK",
      countryName: "Denmark",
      isCustomerData: "0",
      politicalDivision2Name: "ULSTRUP",
      autopopulateformat1: '',
      autopopulateformat2: '',
      postalCode: '',
      region: ''
    });

    component.states.push({
      autopopulateformathighlight: "yes",
      airportCode: "ABE",
      airportName: "ALLENTOWN",
      autopopulateformat: "ABE Eckert,United States-Allentown",
      countryCode: "US",
      countryName: "United States",
      isCustomerData: "0",
      politicalDivision2Name: "ECKERT",
      autopopulateformat1: '',
      autopopulateformat2: '',
      postalCode: '',
      region: ''
    });

    component.states.push({
      autopopulateformathighlight: "yes",
      airportCode: "ABE",
      airportName: "ALLENTOWN",
      autopopulateformat: "ABE Forty Fort,United States-Allentown",
      countryCode: "US",
      countryName: "United States",
      isCustomerData: "0",
      politicalDivision2Name: "FORTY FORT",
      autopopulateformat1: '',
      autopopulateformat2: '',
      postalCode: '',
      region: ''
    });

    component.states.push({
      autopopulateformathighlight: "yes",
      airportCode: "ABE",
      airportName: "ALLENTOWN",
      autopopulateformat: "ABE Kohinoor Junction,United States-Allentown",
      countryCode: "US",
      countryName: "United States",
      isCustomerData: "0",
      politicalDivision2Name: "KOHINOOR JUNCTION",
      autopopulateformat1: '',
      autopopulateformat2: '',
      postalCode: '',
      region: ''
    });

    component.states.push({
      autopopulateformathighlight: "yes",
      airportCode: "ABE",
      airportName: "ALLENTOWN",
      autopopulateformat: "ABE Portland,United States-Allentown",
      countryCode: "US",
      countryName: "United States",
      isCustomerData: "0",
      politicalDivision2Name: "PORTLAND",
      autopopulateformat1: '',
      autopopulateformat2: '',
      postalCode: '',
      region: ''
    });

    component.states.push({
      autopopulateformathighlight: "yes",
      airportCode: "ABQ",
      airportName: "ALBUQUERQUE",
      autopopulateformat: "ABQ Roswell,United States-Albuquerque",
      countryCode: "US",
      countryName: "United States",
      isCustomerData: "0",
      politicalDivision2Name: "ROSWELL",
      autopopulateformat1: '',
      autopopulateformat2: '',
      postalCode: '',
      region: ''
    });

    component.states.push({
      autopopulateformathighlight: "yes",
      airportCode: "ABQ",
      airportName: "ALBUQUERQUE",
      autopopulateformat: "ABQ Willard",
      countryCode: "US",
      countryName: "United States",
      isCustomerData: "0",
      politicalDivision2Name: "WILLARD",
      autopopulateformat1: '',
      autopopulateformat2: '',
      postalCode: '',
      region: ''
    });

    let bflag = true;
    component.airportOriginCode = "";
    component.airportOriginCountryCode = "";
    component.airportDestinationCode = "";
    component.airportDestinationCountryCode = "";

    component.onAirportSelection("ABQ Willard", "US");
    component.onAirportSelection("ABQ Willard", "");

    expect(bflag).toEqual(true);
  });

  //onLineItemAirportSelection
  it('onLineItemAirportSelection', () => {
    component.states = [];
    component.states.push({
      airportCode: "AAR",
      airportName: "AARHUS",
      autopopulateformat: "AAR Ulstrup,Denmark-Aarhus",
      countryCode: "DK",
      countryName: "Denmark",
      isCustomerData: "0",
      politicalDivision2Name: "ULSTRUP",
      autopopulateformathighlight: '',
      autopopulateformat1: '',
      autopopulateformat2: '',
      postalCode: '',
      region: ''
    });

    component.states.push({
      airportCode: "ABE",
      airportName: "ALLENTOWN",
      autopopulateformat: "ABE Eckert,United States-Allentown",
      countryCode: "US",
      countryName: "United States",
      isCustomerData: "0",
      politicalDivision2Name: "ECKERT",
      autopopulateformathighlight: '',
      autopopulateformat1: '',
      autopopulateformat2: '',
      postalCode: '',
      region: ''
    });

    component.states.push({
      airportCode: "ABE",
      airportName: "ALLENTOWN",
      autopopulateformat: "ABE Forty Fort,United States-Allentown",
      countryCode: "US",
      countryName: "United States",
      isCustomerData: "0",
      politicalDivision2Name: "FORTY FORT",
      autopopulateformathighlight: '',
      autopopulateformat1: '',
      autopopulateformat2: '',
      postalCode: '',
      region: ''
    });

    component.states.push({
      airportCode: "ABE",
      airportName: "ALLENTOWN",
      autopopulateformat: "ABE Kohinoor Junction,United States-Allentown",
      countryCode: "US",
      countryName: "United States",
      isCustomerData: "0",
      politicalDivision2Name: "KOHINOOR JUNCTION",
      autopopulateformathighlight: '',
      autopopulateformat1: '',
      autopopulateformat2: '',
      postalCode: '',
      region: ''
    });

    component.states.push({
      airportCode: "ABE",
      airportName: "ALLENTOWN",
      autopopulateformat: "ABE Portland,United States-Allentown",
      countryCode: "US",
      countryName: "United States",
      isCustomerData: "0",
      politicalDivision2Name: "PORTLAND",
      autopopulateformathighlight: '',
      autopopulateformat1: '',
      autopopulateformat2: '',
      postalCode: '',
      region: ''
    });

    component.states.push({
      airportCode: "ABQ",
      airportName: "ALBUQUERQUE",
      autopopulateformat: "ABQ Roswell,United States-Albuquerque",
      countryCode: "US",
      countryName: "United States",
      isCustomerData: "0",
      politicalDivision2Name: "ROSWELL",
      autopopulateformathighlight: '',
      autopopulateformat1: '',
      autopopulateformat2: '',
      postalCode: '',
      region: ''
    });

    component.states.push({
      airportCode: "ABQ",
      airportName: "ALBUQUERQUE",
      autopopulateformat: "ABQ Willard",
      countryCode: "US",
      countryName: "United States",
      isCustomerData: "0",
      politicalDivision2Name: "WILLARD",
      autopopulateformathighlight: '',
      autopopulateformat1: '',
      autopopulateformat2: '',
      postalCode: '',
      region: ''
    });


    component.lineDataAirportOriginCode = "";
    component.lineDataAirportOriginCountryCode = "";

    component.lineDataAirportDestinationCode = "";
    component.lineDataAirportDestinationCountryCode = "";
    let bFlag = true;

    component.onLineItemAirportSelection("ABQ Willard", "US");
    component.onLineItemAirportSelection("ABQ Willard", "");

    expect(bFlag).toEqual(true);
  });

  //onLongTermAirportSelection
  it('onLongTermAirportSelection', () => {
    component.states = [];
    component.states.push({
      airportCode: "AAR",
      airportName: "AARHUS",
      autopopulateformat: "AAR Ulstrup,Denmark-Aarhus",
      countryCode: "DK",
      countryName: "Denmark",
      isCustomerData: "0",
      politicalDivision2Name: "ULSTRUP",
      autopopulateformathighlight: '',
      autopopulateformat1: '',
      autopopulateformat2: '',
      postalCode: '',
      region: ''
    });

    component.states.push({
      airportCode: "ABE",
      airportName: "ALLENTOWN",
      autopopulateformat: "ABE Eckert,United States-Allentown",
      countryCode: "US",
      countryName: "United States",
      isCustomerData: "0",
      politicalDivision2Name: "ECKERT",
      autopopulateformathighlight: '',
      autopopulateformat1: '',
      autopopulateformat2: '',
      postalCode: '',
      region: ''
    });

    component.states.push({
      airportCode: "ABE",
      airportName: "ALLENTOWN",
      autopopulateformat: "ABE Forty Fort,United States-Allentown",
      countryCode: "US",
      countryName: "United States",
      isCustomerData: "0",
      politicalDivision2Name: "FORTY FORT",
      autopopulateformathighlight: '',
      autopopulateformat1: '',
      autopopulateformat2: '',
      postalCode: '',
      region: ''
    });

    component.states.push({
      airportCode: "ABE",
      airportName: "ALLENTOWN",
      autopopulateformat: "ABE Kohinoor Junction,United States-Allentown",
      countryCode: "US",
      countryName: "United States",
      isCustomerData: "0",
      politicalDivision2Name: "KOHINOOR JUNCTION",
      autopopulateformathighlight: '',
      autopopulateformat1: '',
      autopopulateformat2: '',
      postalCode: '',
      region: ''
    });

    component.states.push({
      airportCode: "ABE",
      airportName: "ALLENTOWN",
      autopopulateformat: "ABE Portland,United States-Allentown",
      countryCode: "US",
      countryName: "United States",
      isCustomerData: "0",
      politicalDivision2Name: "PORTLAND",
      autopopulateformathighlight: '',
      autopopulateformat1: '',
      autopopulateformat2: '',
      postalCode: '',
      region: ''
    });

    component.states.push({
      airportCode: "ABQ",
      airportName: "ALBUQUERQUE",
      autopopulateformat: "ABQ Roswell,United States-Albuquerque",
      countryCode: "US",
      countryName: "United States",
      isCustomerData: "0",
      politicalDivision2Name: "ROSWELL",
      autopopulateformathighlight: '',
      autopopulateformat1: '',
      autopopulateformat2: '',
      postalCode: '',
      region: ''
    });

    component.states.push({
      airportCode: "ABQ",
      airportName: "ALBUQUERQUE",
      autopopulateformat: "ABQ Willard",
      countryCode: "US",
      countryName: "United States",
      isCustomerData: "0",
      politicalDivision2Name: "WILLARD",
      autopopulateformathighlight: '',
      autopopulateformat1: '',
      autopopulateformat2: '',
      postalCode: '',
      region: ''
    });


    component.lineDataAirportOriginCode = "";
    component.lineDataAirportOriginCountryCode = "";

    component.lineDataAirportDestinationCode = "";
    component.lineDataAirportDestinationCountryCode = "";

    let bFlag = true;

    component.onLongTermAirportSelection("ABQ Willard", "US");
    component.onLongTermAirportSelection("ABQ Willard", "");

    expect(bFlag).toEqual(true);
    //expect(component.lineDataAirportDestinationCode).toEqual("");
  });

  //empty line data
  it('empty line data', () => {
    component.lineData = [];
    component.lineDataMaxLength = 10;
    component.addEmptyLineData();
    expect(component.lineData.length).toBeGreaterThanOrEqual(1);
  });
  //'max limit line exceeds'
  it('max limit line exceeds', () => {
    component.lineData = [];
    component.lineDataMaxLength = 0;
    component.addEmptyLineData();
    expect(component.lineData.length).toBeGreaterThanOrEqual(0);
  });

  //showShortTermDetail
  it('showShortTermDetail', () => {

    component.destination = "";
    component.airportDestinationCode = "";
    component.airportDestinationCountryCode = "";
    component.origin = "";
    component.airportOriginCode = "";
    component.airportOriginCountryCode = "";

    let laneInfo = [];
    laneInfo.push({
      destination: "testing",
      airportDestinationCode: "testing",
      airportDestinationCountryCode: "testing",
      origin: "testing",
      airportOriginCode: "testing",
      airportOriginCountryCode: "testing"
    })

    component.lineDataMaxLength = 0;
    component.showShortTermDetail(laneInfo);
    expect(component.origin.length).toBeGreaterThanOrEqual(0);
  });

  //showLongTermDetail
  it('showLongTermDetail', () => {

    component.lineData = [];
    component.destination = "";
    component.airportDestinationCode = "";
    component.airportDestinationCountryCode = "";
    component.origin = "";
    component.airportOriginCode = "";
    component.airportOriginCountryCode = "";

    let laneInfo = [];
    laneInfo.push({
      destination: "testing",
      airportDestinationCode: "testing",
      airportDestinationCountryCode: "testing",
      origin: "testing",
      airportOriginCode: "testing",
      airportOriginCountryCode: "testing",
      quoteType: 2
    })
    component.lineDataMaxLength = 0;
    component.showLongTermDetail(laneInfo);
    expect(component.lineData.length).toBeGreaterThanOrEqual(1);
  });


  /* ----------Version 1.0-----------
   //   //onAirportSelection
     it('onAirportSelection', () => {
       component.states = [];
       component.states.push({airportCode: "AAR",
       airportName: "AARHUS",
       autopopulateformat: "AAR Ulstrup,Denmark-Aarhus",
       countryCode: "DK",
       countryName: "Denmark",
       isCustomerData: "0",
       politicalDivision2Name: "ULSTRUP"});
   
       component.states.push({airportCode: "ABE",
       airportName: "ALLENTOWN",
       autopopulateformat: "ABE Eckert,United States-Allentown",
       countryCode: "US",
       countryName: "United States",
       isCustomerData: "0",
       politicalDivision2Name: "ECKERT"});
   
       component.states.push({airportCode: "ABE",
       airportName: "ALLENTOWN",
       autopopulateformat: "ABE Forty Fort,United States-Allentown",
       countryCode: "US",
       countryName: "United States",
       isCustomerData: "0",
       politicalDivision2Name: "FORTY FORT"});
   
       component.states.push({airportCode: "ABE",
       airportName: "ALLENTOWN",
       autopopulateformat: "ABE Kohinoor Junction,United States-Allentown",
       countryCode: "US",
       countryName: "United States",
       isCustomerData: "0",
       politicalDivision2Name: "KOHINOOR JUNCTION"});
   
       component.states.push({airportCode: "ABE",
       airportName: "ALLENTOWN",
       autopopulateformat: "ABE Portland,United States-Allentown",
       countryCode: "US",
       countryName: "United States",
       isCustomerData: "0",
       politicalDivision2Name: "PORTLAND"});
   
       component.states.push({airportCode: "ABQ",
       airportName: "ALBUQUERQUE",
       autopopulateformat: "ABQ Roswell,United States-Albuquerque",
       countryCode: "US",
       countryName: "United States",
       isCustomerData: "0",
       politicalDivision2Name: "ROSWELL"});
   
       component.states.push({airportCode: "ABQ",
       airportName: "ALBUQUERQUE",
       autopopulateformat: "ABQ Willard,United States-Albuquerque",
       countryCode: "US",
       countryName: "United States",
       isCustomerData: "0",
       politicalDivision2Name: "WILLARD"});
       component.airportOriginCode = "";
       component.airportDestinationCode = "";
       component.onAirportSelection("US","US");
       component.onAirportSelection("US","");
   
       expect(component.airportOriginCode).toEqual("");
     });
   
   //   //onLineItemAirportSelection
     it('onLineItemAirportSelection', () => {
       component.states = [];
       component.states.push({airportCode: "AAR",
       airportName: "AARHUS",
       autopopulateformat: "AAR Ulstrup,Denmark-Aarhus",
       countryCode: "DK",
       countryName: "Denmark",
       isCustomerData: "0",
       politicalDivision2Name: "ULSTRUP"});
   
       component.states.push({airportCode: "ABE",
       airportName: "ALLENTOWN",
       autopopulateformat: "ABE Eckert,United States-Allentown",
       countryCode: "US",
       countryName: "United States",
       isCustomerData: "0",
       politicalDivision2Name: "ECKERT"});
   
       component.states.push({airportCode: "ABE",
       airportName: "ALLENTOWN",
       autopopulateformat: "ABE Forty Fort,United States-Allentown",
       countryCode: "US",
       countryName: "United States",
       isCustomerData: "0",
       politicalDivision2Name: "FORTY FORT"});
   
       component.states.push({airportCode: "ABE",
       airportName: "ALLENTOWN",
       autopopulateformat: "ABE Kohinoor Junction,United States-Allentown",
       countryCode: "US",
       countryName: "United States",
       isCustomerData: "0",
       politicalDivision2Name: "KOHINOOR JUNCTION"});
   
       component.states.push({airportCode: "ABE",
       airportName: "ALLENTOWN",
       autopopulateformat: "ABE Portland,United States-Allentown",
       countryCode: "US",
       countryName: "United States",
       isCustomerData: "0",
       politicalDivision2Name: "PORTLAND"});
   
       component.states.push({airportCode: "ABQ",
       airportName: "ALBUQUERQUE",
       autopopulateformat: "ABQ Roswell,United States-Albuquerque",
       countryCode: "US",
       countryName: "United States",
       isCustomerData: "0",
       politicalDivision2Name: "ROSWELL"});
   
       component.states.push({airportCode: "ABQ",
       airportName: "ALBUQUERQUE",
       autopopulateformat: "ABQ Willard,United States-Albuquerque",
       countryCode: "US",
       countryName: "United States",
       isCustomerData: "0",
       politicalDivision2Name: "WILLARD"});
   
       component.lineDataAirportOriginCode = "";
       component.lineDataAirportDestinationCode = "";
       component.onLineItemAirportSelection("US","US");
       component.onLineItemAirportSelection("US","");
   
       expect(component.lineDataAirportDestinationCode).toEqual("");
     });
   
   // //isActiveShortTerm
   it('isActiveShortTerm', () => {
       component.quoteTypeSelectedValue = 0;
       component.isActiveShortTerm();
       expect(component.quoteTypeSelectedValue).toEqual(1);
     });
   // //isActiveLongTerm
   it('isActiveLongTerm', () => {
       component.quoteTypeSelectedValue = 0;
       component.isActiveLongTerm();
       expect(component.quoteTypeSelectedValue).toEqual(2);
     });
   //   //onShortTermClick-positive
     it('short term default selection', () => {
       component.quoteTypeSelectedValue = 1;
       component.onShortTermClick(1);
       //console.log(component.quoteTypeSelectedValue);
       expect(component.destination.length).toBeGreaterThanOrEqual(0);
     });
   // //onShortTermClick-negative
   it('short term default selection', () => {
       component.lineData=[];
       component.airportOriginCode= 'LON';
       component.airportDestinationCode = 'LON';
       component.origin = 'LON';
       component.destination = 'LON';
       component.quoteTypeSelectedValue = 1;
       component.onShortTermClick(2);
       expect(component.destination.length).toEqual(0);
   });
   
   //short term set value.
     it('short term set value', () => {
       component.quoteTypeSelectedValue = 0;
       component.onShortTermClick(1);
       expect(component.quoteTypeSelectedValue).toEqual(1);
     });
   
   
     //long term selection.
     it('long term selection', () => {
       component.quoteTypeSelectedValue = 2;
       component.onLongTermClick(2);
       expect(component.quoteTypeSelectedValue).toEqual(2);
     });
   
     //empty line data
     it('empty line data', () => {
       component.lineData =[];
       component.lineDataMaxLength = 10;
       component.addEmptyLineData();
       expect(component.lineData.length).toBeGreaterThanOrEqual(1);
     });
   //'max limit line exceeds'
     it('max limit line exceeds', () => {
       component.lineData = [];
       component.lineDataMaxLength = 0;
       component.addEmptyLineData();
       expect(component.lineData.length).toBeGreaterThanOrEqual(0);
     });
   
   //add line data success
     it('add line data success', () => {
       component.lineData = [];
       component.origin = 'LON';
       component.destination = 'CO';
       component.airportDestinationCode = 'LON';
       component.airportOriginCode = 'CO';
       component.addLineData();
       component.origin = 'LON';
       component.destination = 'CO';
       component.airportDestinationCode = 'LON';
       component.airportOriginCode = 'CO';
       component.addLineData();
       component.origin = 'LON';
       component.destination = 'CO';
       component.airportDestinationCode = 'LON';
       component.airportOriginCode = 'CO';
       component.addLineData();
       component.origin = 'LON';
       component.destination = 'CO';
       component.airportDestinationCode = 'LON';
       component.airportOriginCode = 'CO';
       component.addLineData();
       component.origin = 'LON';
       component.destination = 'CO';
       component.airportDestinationCode = 'LON';
       component.airportOriginCode = 'CO';
       component.addLineData();
       component.origin = 'LON';
       component.destination = 'CO';
       component.airportDestinationCode = 'LON';
       component.airportOriginCode = 'CO';
       component.addLineData();
       component.origin = 'LON';
       component.destination = 'CO';
       component.airportDestinationCode = 'LON';
       component.airportOriginCode = 'CO';
       component.addLineData();
       component.origin = 'LON';
       component.destination = 'CO';
       component.airportDestinationCode = 'LON';
       component.airportOriginCode = 'CO';
       component.addLineData();
       component.origin = 'LON';
       component.destination = 'CO';
       component.airportDestinationCode = 'LON';
       component.airportOriginCode = 'CO';
       component.addLineData();
       component.origin = 'LON';
       component.destination = 'CO';
       component.airportDestinationCode = 'LON';
       component.airportOriginCode = 'CO';
       component.addLineData();
       expect(component.lineData.length).toBeGreaterThanOrEqual(1);
     });
   
     //add line data failure
     it('add line data failure', () => {
       component.lineData = [];
       component.origin = '';
       component.destination = '';
       component.addLineData();
       expect(component.lineData.length).toBeGreaterThanOrEqual(0);
     });
   
   // isValidOriginAirportCode
     it('isValidOriginAirportCode', () => {
       component.lineData = [];
       component.origin = 'Co';
       component.airportOriginCode = 'CO';
       expect(component.isValidOriginAirportCode()).toEqual(true);
       //expect(component.lineData.length).toBeGreaterThanOrEqual(0);
     });
     //isValidDestinationAirportCode
     it('isValidDestinationAirportCode', () => {
       component.lineData = [];
       component.destination = 'Co';
       component.airportDestinationCode = 'CO';
       //component.isValidDestinationAirportCode();
       expect(component.isValidDestinationAirportCode()).toEqual(true);
       
     });
   //   //clearODPairValues
     it('isValidDestinationAirportCode', () => {
       component.airportOriginCode= 'AA';
       component.airportDestinationCode = 'BB';
       component.origin = 'CC';
       component.destination = 'DD';
       component.clearODPairValues();
       expect(component.destination.length).toBeLessThanOrEqual(1);
     });
   
   // //isValidLineItemOriginAirportCode
   it('isValidDestinationAirportCode', () => {
       component.lineDataAirportOriginCode = 'LON';
       component.lineDataOriginValue = 'UK';
       expect(component.isValidLineItemOriginAirportCode()).toEqual(true);
   });
   
   // //isValidLineItemDestinationAirportCode
   it('isValidDestinationAirportCode', () => {
       component.lineDataAirportDestinationCode = 'LON';
       component.lineDataDestinationValue = 'UK';
       expect(component.isValidLineItemDestinationAirportCode()).toEqual(true);
   });
   
   //onLineDataRemove
   it('on line data remove', () => {
       component.lineData = [] = new Array();
       component.lineData.push({ origin: 'Cochin', destination: 'London',selected:false });
       component.lineData.push({ origin: 'Cochin1', destination: 'London1',selected:false });
       component.onLineDataRemove(component.lineData[0], 0);
       expect(component.lineData.length).toBeLessThanOrEqual(1);
     });
   
     //onLineDataEdit
     it('on line data edit', () => {
       component.lineData = [];
   
       component.lineDataOriginValue = '';
       component.lineDataDestinationValue = '';
       component.lineDataAirportOriginCode = '';
       component.lineDataAirportDestinationCode = '';
   
       component.lineData.push({ origin: 'Cochin', destination: 'London', selected: false , airportOriginCode:'LOC', airportDestinationCode:'LON'});
       component.lineData.push({ origin: 'Cochin1', destination: 'London1', selected: false , airportOriginCode:'LOC1', airportDestinationCode:'LON1'});
       component.onLineDataEdit(component.lineData[0],0);
       expect(component.origin).toEqual('Cochin');
   
     });
   
   // //resetViewMode
   it('resetViewMode', () => {
       component.lineData = [];
       component.lineData.push({ origin: 'Cochin', destination: 'London', selected: true , airportOriginCode:'LOC', airportDestinationCode:'LON'});
       component.lineData.push({ origin: 'Cochin1', destination: 'London1', selected: true , airportOriginCode:'LOC1', airportDestinationCode:'LON1'});
       component.resetLineItemViewMode();
       //expect(component.lineDataAirportDestinationCode).toEqual('LON');
       expect(component.lineData[0].selected).toEqual(false);
     });
   
   //getIndexOfItem
   it('getIndexOfItem', () => {
       component.lineData = [];
       component.lineData.push({ origin: 'Cochin', destination: 'London', selected: true , airportOriginCode:'LOC', airportDestinationCode:'LON'});
       component.lineData.push({ origin: 'Cochin1', destination: 'London1', selected: true , airportOriginCode:'LOC1', airportDestinationCode:'LON1'});
       //component.getIndexOfItem(1);
       //expect(component.lineDataAirportDestinationCode).toEqual('LON');
       expect(component.getIndexOfItem(1)).toEqual(1);
     });
   
     //isValidData.
     it('is validdata', () => {
       component.quoteTypeSelectedValue=2;
       component.lineData = [];
       component.lineData.push({ origin: '', destination: '', selected: false , airportOriginCode:'', airportDestinationCode:''});
       expect(component.isValidData()).toEqual(false);
     });
   
   //resetLineData.
   it('resetLineData', () => {
       component.airportOriginCode= 'aa';
       component.airportDestinationCode = 'bb';
       component.origin = 'cc';
       component.destination = 'dd';
   
       component.lineData = [];
       component.lineData.push({ origin: '', destination: '', selected: false , airportOriginCode:'', airportDestinationCode:''});
       component.resetLineData();
       expect(component.airportOriginCode.length).toBeLessThanOrEqual(1);
   
     });
   // onLineItemDone 
     it('add line data done', () => {
       component.lineData = []= new Array();
       component.lineData.push({ origin: 'Cochin', destination: 'London', selected: false , airportOriginCode:'', airportDestinationCode:''});
       component.lineDataOriginValue = 'LOC';
       component.lineDataDestinationValue = 'LON';
       component.lineDataAirportOriginCode = 'LOC';
       component.lineDataAirportDestinationCode = 'LON';
       component.onLineItemDone(component.lineData[0],0);
       expect(component.lineData[0].origin).toEqual('LOC');
     });
     //onCalculateRate
     it('onCalculateRate', () => {
       component.quoteTypeSelectedValue = 1;
       component.onCalculateRate();
       //expect(component.lineData.length).toBeGreaterThanOrEqual(0);
     });
     //onCalculateRate
     it('onCalculateRate', () => {
       component.quoteTypeSelectedValue = 2;
       component.onCalculateRate();
       //expect(component.lineData.length).toBeGreaterThanOrEqual(0);
     });
   
   */
});
