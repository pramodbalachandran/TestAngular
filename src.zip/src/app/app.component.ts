import { Component, HostListener } from '@angular/core';
import { PlatformLocation } from '@angular/common'

@Component({
  selector: 'pricing-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'UPS';


  constructor() {

    window.onbeforeunload = check;
    function check() {
      return "Are you sure you want to exit this page?";
      //or put whatever function you need to call when a user closes the web //browser.
    }

    
    history.pushState(null, null, location.href);
    window.onpopstate = function () {
      // as per requirement user will be logged out browser back button
      history.go(1);
      localStorage.clear();
      location.href = '';
    };
  }
  

  @HostListener('window:beforeunload', ['$event'])
  doBeforeUnload($event) {   
    this.clearModel();
  }

  clearModel() {  
   
  }

  ngOnInit() {
    
  }


}
