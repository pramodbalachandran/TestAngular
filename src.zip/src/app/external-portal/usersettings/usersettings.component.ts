import { Component, OnInit } from '@angular/core';
import { User } from '@app/shared/interfaces/entities.interface';
import { UserRegistrationService, CustomerAPI, LocalStorageService ,GeaographyAPI} from '@app/shared/services';
import { Router } from '@angular/router';
import { ICustomer } from '@app/models';


@Component({
  selector: 'app-usersettings',
  templateUrl: './usersettings.component.html',
  styleUrls: ['./usersettings.component.css']
})
export class UserSettingsComponent implements OnInit {
  public body: HTMLBodyElement = document.getElementsByTagName('body')[0];
  userId = '';
  emailAddress = '';
  user: ICustomer;
  userModelBeforeChange: ICustomer;
  countries = [];
  states = [];
  billingStates = [];
  initialLoad:boolean=true;
  postalCodes: any;

  constructor(
      private router: Router,
      private customerAPI: CustomerAPI<any>,
      private localStorageService: LocalStorageService,
      private geographyServcie:GeaographyAPI<any>
  ) {
    this.user = this.customerAPI.getEmptyUserModel();
  }

  ngOnInit() {
    this.body.classList.remove('login-logo');
    this.user = this.customerAPI.getEmptyUserModel();
    this.setPostalCodes();
    this.fillUserData();
    
  }

  componentInitialize(): void {
    this.initialLoad = false;
  }

  fillUserData() {
    this.customerAPI.getUserByUserId(localStorage.getItem('currentUserName1'))
          .subscribe(
              data => {
                if (data) {
                  this.user = data as ICustomer;
                  this.setbackUpModel();

                  this.emailAddress = this.user.emailAddress;
                  this.userId = this.user.userId;
                  this.user.countryCode = this.user.countryCode.trim();
                  this.user.phoneCountryCode = this.user.phoneCountryCode.trim()

                  if (this.user.billingAddress.length == 0) {
                    this.user.billingAddress = [];
                    this.user.billingAddress.push({contactName: '', addressLine1: '', addressLine2: '', addressLine3: '', countryName: '', countryCode: '', politicalDivision1Name: '', politicalDivision1Code: '', politicalDivision2Name: '', postalCode: '' });
                  }

                  if (this.user.notificationSettings == null) {
                    this.user.notificationSettings = {
                      emailPickupRequest: true, emailPreApprovedRate: true, emailQuoteRespondByUSP: true, emailQuoteStatusExpiring: true,
                      emailResetPassword: true
                    }
                  }
                  this.setbackUpModel();
                  this.customerAPI.setCustomerProfileDetails(this.user);
                  this.getCountries();
                }
                else {
                  console.log('Cannot find data for specified user: ' + localStorage.getItem('currentUserName1'));
                }
              },
              error => {
                console.log(error);
              });
  }

  setbackUpModel() {
    this.userModelBeforeChange =JSON.parse(JSON.stringify(this.user));
  }

  getCountries() {

    this.geographyServcie.getCountries()
      .subscribe(
        data => {
          if (data && data['results']) {
            var defaultCountry = { 'countryCode': '', 'countryName': '--Choose a Country/Territory--' };
            this.countries = data['results'];
            this.countries.splice(0, 0, defaultCountry);
            if (this.user.countryCode == undefined || this.user.countryCode == null || this.user.countryCode == '') {
              this.user.countryCode = this.countries[0].countryCode;
            }
            if (this.user.billingAddress[0].countryCode == undefined || this.user.billingAddress[0].countryCode == null || this.user.billingAddress[0].countryCode == '') {
              this.user.billingAddress[0].countryCode = this.countries[0].countryCode;
            }
            this.getStates(false);
            this.getStates(true);
          }
        },
        error => {
          
        });
  }

  getStates(isBillingAddress) {
    var countrycode = isBillingAddress ? this.user.billingAddress[0].countryCode : this.user.countryCode;
    if (!countrycode) {
      this.setState([], isBillingAddress);
      return;
    }

    this.geographyServcie.getStates(countrycode)
      .subscribe(
        data => {
          if (data && data['results']) {
            this.setState(data['results'], isBillingAddress);
          }
        },
        error => {
          
        });
  }

  setState(data, isBillingAddress) {
    var defaultState = { 'politicalDivision1Code': '', 'politicalDivision1Name': '--Choose a State--' };
    if (!isBillingAddress) {
      this.states = data;
      this.states.splice(0, 0, defaultState);
    }
    else {
      this.billingStates = data;
      this.billingStates.splice(0, 0, defaultState);
    }
  }

  setPostalCodes() {
    this.postalCodes = this.geographyServcie.getPostalCodeArray();

    /* loading data from json file but need to solve perfomance issue */

    //this.postalCodes = [];
    //this.geographyServcie.getPostalCodes().subscribe(
    //  data => {
    //    this.postalCodes = data;
    //  },
    //  error => {
    //    console.log(error);
    //  });
  }
}
