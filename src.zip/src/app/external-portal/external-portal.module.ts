import { NgModule, CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA  } from '@angular/core';
import { PlatformLocation } from '@angular/common'
import { routing } from './external-portal.routing';
import { SharedModule } from '@app/shared/shared.module';

import { LoginComponent } from './login/login.component';
import { ChangepasswordComponent } from './changepassword/changepassword.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { UserSettingsComponent } from './usersettings/usersettings.component';
import { UserProfileComponent } from './userprofile/userprofile.component';
import { UserNotificationSettingsComponent } from './usernotificationsettings/usernotificationsettings.component';
import { ContactSettingsComponent } from './contactSettings/contactSettings.component';
import { ShippingaddressComponent } from './shippingaddress/shippingaddress.component';

@NgModule({
  imports: [routing, SharedModule],
  providers:[],
  declarations:
    [
      LoginComponent,
      DashboardComponent,
      UserSettingsComponent,
      UserProfileComponent,
      UserNotificationSettingsComponent,
      ContactSettingsComponent,
      ShippingaddressComponent,
      ChangepasswordComponent
    ],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA,
    NO_ERRORS_SCHEMA
  ]
})
export class ExternalPortalModule {

  constructor() {

    history.pushState(null, null, location.href);
    window.onpopstate = function () {
      history.go(1);
    };
    window.history.forward();
  }

}
