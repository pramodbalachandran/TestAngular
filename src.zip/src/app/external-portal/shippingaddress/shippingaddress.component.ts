import { Component, OnInit,Input } from '@angular/core';
import { Router } from '@angular/router';
import { ICustomer,IShippingAddress } from '@app/models';



import { ShippingAddress, getShippingAddress } from '@app/shared/interfaces/entities.interface';
import { CustomerAPI, ToasterService,GeaographyAPI} from '@app/shared/services';



@Component({
  selector: 'app-shippingaddress',
  templateUrl: './shippingaddress.component.html',
  styleUrls: ['../usersettings/usersettings.component.css'],
})
export class ShippingaddressComponent implements OnInit {
  @Input('countryList') countryOptions;
  @Input('shippingAddressPostalCodes') shippingAddressPostalCodes: any;
  tmpid: string;
  tmpUserId: string;
  hdnUserId: string;

  customerProfileDetails: ICustomer;
  shippingAddressDetails: IShippingAddress[] = [];
  newshippingAddressDetails: IShippingAddress = this.getEmptyShippingAddressDetails();
  getInputPar: getShippingAddress = new getShippingAddress();
  inputObj: ShippingAddress = new ShippingAddress();
  returnResult: ShippingAddress;
  oldShippingAddress: IShippingAddress;
  data: IShippingAddress[];
  shippingEditDetails: ShippingAddress[] = [];
  shippingStateOptions: any = [];
  doShowAddNewShippingForm: boolean = false;
  UserId: string;
  shippingAddress: string;
  AddressLine1: string;
  AddressLine2: string;
  AddressLine3: string;
  Country: string;
  State: string;
  City: string;
  PostalCode: string;
  index: number;
  public showShippingAddressLine1 = false;
  public showShippingAddressLine2 = false;
  invalidShipmentEntry: boolean = false;
  shippingAddressAlreadyExist: boolean = false;
  stateList: any;
  invalidShippingAddrPostalCodeMask: boolean = false;
  shippingAddrPostalCodeMask: any;
  invalidShippingAddrPostalCode: boolean = false;

  constructor(
    private router: Router,private geographyService:GeaographyAPI<any>, private _customerAPI: CustomerAPI<any>, private toastr: ToasterService, private customerService: CustomerAPI<ShippingAddress>
  ) { }

  ngOnInit() {
    this.doShowAddNewShippingForm = false;
    this.customerProfileDetails = this._customerAPI.getCustomerProfileDetails() as ICustomer;
    this.shippingAddressDetails = this.customerProfileDetails.shippingAddress;
    this.data = this.shippingAddressDetails;
    this.oldShippingAddress = null;
    this.resetViewMode();
  }

  displayAddNewShipping() {
    this.invalidShipmentEntry = false;
    this.shippingAddressAlreadyExist = false;
    this.resetShippingAddressModel();
    this.resetViewMode();
    this.doShowAddNewShippingForm = !this.doShowAddNewShippingForm;
    this.shippingStateOptions = [];
  }

  resetShippingAddressModel() {
    this.AddressLine1 = "";
    this.AddressLine2 = "";
    this.AddressLine3 = "";
    this.Country = "";
    this.State = "";
    this.City = "";
    this.PostalCode = "";
    this.showShippingAddressLine1 = false;
    this.showShippingAddressLine2 = false;
  }

  saveNewShippingAddress() {
    this.invalidShipmentEntry = false;
    this.shippingAddressAlreadyExist = false;
    this.invalidShippingAddrPostalCode = false;
    this.PostalCode = this.PostalCode.toUpperCase();

    if (this.Country.trim() == '') {
      this.invalidShipmentEntry = true;
      return;
    }
    else {
      if (this.City.trim() == '' ||  this.PostalCode.trim() == '' || this.AddressLine1.trim() == '') {
        this.invalidShipmentEntry = true;
        return;
      }

      if (this.shippingStateOptions && this.shippingStateOptions.length > 1 && this.State.trim() == '') {
        this.invalidShipmentEntry = true;
        return;
      }
    }

    if(!this.isValidPostalCode()){
      this.invalidShippingAddrPostalCode = true;
      return;
    }

    if (this.isShippingAddressAlreadyExist(-1)) {
      this.shippingAddressAlreadyExist = true;
      return;
    }

    this.customerProfileDetails = this._customerAPI.getCustomerProfileDetails() as ICustomer;
    

    this.newshippingAddressDetails = {
      addressLine1: this.AddressLine1,
      addressLine2 : this.AddressLine2,
      addressLine3 : this.AddressLine3,
      countryCode : this.Country,
      politicalDivision1Code : this.State,
      politicalDivision2Name : this.City,
      postalCode: this.PostalCode,
      countryName: this.Country,
      doShowEditShippingForm: false,
      politicalDivision1Name: this.State,
    };

    this.customerProfileDetails.shippingAddress.push(this.newshippingAddressDetails);
    this._customerAPI.setCustomerProfileDetails(this.customerProfileDetails);

    //----------service-call----------//
    this._customerAPI.updateUserProfile(this.customerProfileDetails)
      .subscribe(
        data => {
          if (data == null || data == undefined) {
            this.removeShippingAddress(this.newshippingAddressDetails);
            this.toastr.error('Updation failed');
            return;
          }
          this.toastr.success('Successfully profile updated!');
          this.doShowAddNewShippingForm = false;
          this.newshippingAddressDetails = this.getEmptyShippingAddressDetails();
        },
      error => {
        this.removeShippingAddress(this.newshippingAddressDetails);
        this.toastr.error('Failed!');
      });
  }

  updateShippingAddress(i: number) {
    this.invalidShipmentEntry = false;
    this.shippingAddressAlreadyExist = false;
    this.invalidShippingAddrPostalCode = false;
    this.PostalCode = this.PostalCode.toUpperCase();

    if (this.Country.trim() == '') {
      this.invalidShipmentEntry = true;
      return;
    }
    else {
      if (this.City.trim() == '' || this.PostalCode.trim() == '' || this.AddressLine1.trim() == '') {
        this.invalidShipmentEntry = true;
        return;
      }

      if (this.shippingStateOptions && this.shippingStateOptions.length > 1 && this.State.trim() == '') {
        this.invalidShipmentEntry = true;
        return;
      }
    }

    if (!this.isValidPostalCode()) {
      this.invalidShippingAddrPostalCode = true;
      return;
    }

    if (this.isShippingAddressAlreadyExist(i)) {
      this.shippingAddressAlreadyExist = true;
      return;
    }

    this.customerProfileDetails.shippingAddress[i].addressLine1 = this.AddressLine1;
    this.customerProfileDetails.shippingAddress[i].addressLine2 = this.AddressLine2;
    this.customerProfileDetails.shippingAddress[i].addressLine3 = this.AddressLine3;
    this.customerProfileDetails.shippingAddress[i].countryCode = this.Country,
    this.customerProfileDetails.shippingAddress[i].countryName = '';
    this.customerProfileDetails.shippingAddress[i].doShowEditShippingForm = false;
    this.customerProfileDetails.shippingAddress[i].politicalDivision1Code = this.State;
    this.customerProfileDetails.shippingAddress[i].politicalDivision1Name = '';
    this.customerProfileDetails.shippingAddress[i].politicalDivision2Name = this.City;
    this.customerProfileDetails.shippingAddress[i].postalCode = this.PostalCode;

    this._customerAPI.updateUserProfile(this.customerProfileDetails)
      .subscribe(
        data => {
          if (data == null || data == undefined) {
            this.toastr.error('Updation failed');
            return;
          }
          this.toastr.success('Successfully profile updated!');
          this.doShowAddNewShippingForm = false;
        },
        error => {
          this.toastr.error('Failed!');
      });
  }

  displayEdit(item: IShippingAddress, i: number) {
    this.doShowAddNewShippingForm = false;
    this.showShippingAddressLine1 = false;
    this.showShippingAddressLine2 = false;
    this.invalidShipmentEntry = false;
    this.shippingAddressAlreadyExist = false;

    this.oldShippingAddress = {
      addressLine1: item.addressLine1,
      addressLine2 : item.addressLine2,
      addressLine3 : item.addressLine3,
      countryCode : item.countryCode,
      countryName : item.countryName,
      doShowEditShippingForm : item.doShowEditShippingForm,
      politicalDivision1Code : item.politicalDivision1Code,
      politicalDivision1Name : item.politicalDivision1Name,
      politicalDivision2Name : item.politicalDivision2Name,
      postalCode: item.postalCode
    }
   

    if (this.data[i].doShowEditShippingForm) {
      this.data[i].doShowEditShippingForm = false;
      return;
    }


    this.resetViewMode();

    this.data[i].doShowEditShippingForm = true;

    this.AddressLine1 = item.addressLine1;
    this.AddressLine2 = item.addressLine2;
    this.AddressLine3=item.addressLine3;
    this.Country = item.countryCode;
    this.doShowAddNewShippingForm = this.doShowAddNewShippingForm;
    this.State = item.politicalDivision1Code;
    this.City = item.politicalDivision2Name;
    this.PostalCode = item.postalCode;

    if (this.AddressLine2) {
      this.showShippingAddressLine1 = true;
    }

    if (this.AddressLine3) {
      this.showShippingAddressLine2 = true;
    }

    this.setPostalCode();
    this.getStates(this.data[i].countryCode);

  }

  resetViewMode() {
    for (let item of this.data) {
      item.doShowEditShippingForm = false;
    }
  }

  resetModelValues(i) {
    this.shippingAddressAlreadyExist = false;
    this.invalidShipmentEntry = false;
    this.data[i] = this.oldShippingAddress;
  }

  removeItem(i) {
    this.data.splice(i, 1);
    this._customerAPI.updateUserProfile(this.customerProfileDetails)
      .subscribe(
        data => {
          if (data == null || data == undefined) {
            console.log('Updation failed');
            return;
          }
          this.toastr.success('Successfully deleted!');
        },
        error => {
          console.log(error);
        });
  }

  //calling from View.
  onCountryChange(countryCode) {
    this.PostalCode = '';
    this.setPostalCode();
    this.getStates(countryCode);
  }

  setPostalCode() {
    if (!this.Country) {
      this.setPostalCodeMask('');
      return;
    }
    this.setPostalCodeMask(this.Country);
  }

  
  getStates(countryCode: string) {
    if (countryCode == '') {
      this.shippingStateOptions = [];
      return;
    }

    this.geographyService.getStates(countryCode)
      .subscribe(
        data => {
          if (data && data['results']) {
            this.shippingStateOptions = data['results'];
          }
        },
        error => {
          this.toastr.error('failed');
        });

  }

  getaddresslist(): void {

    this.getUserId();
    //console.log("Response from server");

    this._customerAPI.getExistingShippingAddress(this.getInputPar).subscribe(
      res => {
        this.data = res.results;
      },
      err => {
        // Log errors if any
        //console.log(err);
        //this.loading = false;
        this.toastr.error('failed');

      },
      () => {///complete.

        //console.log("----------");
        //console.log(this.resp.results);
        //this.data = this.resp.results;
        if (this.data.length > 0) {
          // this.hdnUserId = this.data[0].UserId;
        }
        else {
          this.getUserId();
        }
      });

  };

  removeShippingAddress(item) {
    var index = this.getIndexOfItem(item);
    this.customerProfileDetails.shippingAddress.splice(index, 1);
  }

  getIndexOfItem(value) {
    return typeof value === 'number' ? value : this.customerProfileDetails.shippingAddress.indexOf(value);
  }

  getUserId() {

    //hardcoded for teting. needs to modify
    // this.getInputPar.customerId = localStorage.getItem('currentUserName1'); // "002";
  }

  AddShippingAddressLines() {
    if (this.showShippingAddressLine1 && this.showShippingAddressLine2) {
      return;
    }
    if (!this.showShippingAddressLine1) {
      this.showShippingAddressLine1 = true;
      return;
    }
    if (!this.showShippingAddressLine2) {
      this.showShippingAddressLine2 = true;
      return;
    }
  }

  getEmptyShippingAddressDetails(): IShippingAddress {
    return {
      addressLine1: '',
      addressLine2: '',
      addressLine3: '',
      countryCode: '',
      countryName: '',
      politicalDivision1Code: '',
      politicalDivision1Name: '',
      politicalDivision2Name: '',
      postalCode: '',
      doShowEditShippingForm: false
    };
  }

  isShippingAddressAlreadyExist(rowIndex: number) {
    if (!rowIndex) {
      return false;
    }

    var length = 0;

   
    length = this.data.filter((address: IShippingAddress, index) => index != rowIndex && address.addressLine1.toLowerCase().trim() == this.AddressLine1.toLowerCase().trim()
      && address.countryCode.toLowerCase().trim() == this.Country.toLowerCase().trim()
      && address.politicalDivision2Name.toLowerCase().trim() == this.City.toLowerCase().trim()
      && address.postalCode.toLowerCase().trim() == this.PostalCode.toLowerCase().trim()
      && address.politicalDivision1Code.toLowerCase().trim() == this.State.toLowerCase().trim()
      ).length;
    
    return length > 0;
  }

  setPostalCodeMask(countryCode) {
    this.invalidShippingAddrPostalCodeMask = false;

    if (!countryCode) {
      this.shippingAddrPostalCodeMask = [];
      this.invalidShippingAddrPostalCodeMask = true;
      return;
    }

    var mask = [];
    var data = this.shippingAddressPostalCodes.filter((x) => x.countryCode == countryCode);
    mask = data.length > 0 ? eval(data[0].mask) : [];
    this.shippingAddrPostalCodeMask = mask;
    if (mask.length <= 0) {
      this.invalidShippingAddrPostalCodeMask = true;
    }
  }

  isValidPostalCode() {
    var data = this.shippingAddressPostalCodes.filter((x) => x.countryCode == this.Country);
    var mask = data.length > 0 ? data[0].mask : [];
    if (mask.length > 0 && data[0].length != this.replaceAll(this.PostalCode, '_', '').length) {
      return false;
    }
    return true;
  }

  replaceAll(str, target, replacement) {
    return str.split(target).join(replacement);
  }
}


