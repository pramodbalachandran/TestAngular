import { Component, OnInit, ViewChild } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { DatePipe } from "@angular/common";
import { DataTableModule } from 'angular-6-datatable';
import { NgForm } from '@angular/forms';
import { ICustomer, IContactsDetails } from '@app/models';
import { CustomerAPI, ToasterService } from '@app/shared/services';


@Component({
  selector: 'app-contact-settings',
  templateUrl: './contactSettings.component.html',
  styleUrls: ['../usersettings/usersettings.component.css'],
  providers: [DataTableModule],
})
export class ContactSettingsComponent implements OnInit {

  customerProfileDetails: ICustomer;
  data: IContactsDetails[];
  contact: IContactsDetails;
  oldContact: IContactsDetails;
  doShowAddNewContactForm: boolean = false;
  isValidFormSubmitted = false;
  @ViewChild('contactForm') contactForm: NgForm;
  invalidContactEntry: boolean = false;
  invalidName: boolean = false;
  invalidEmail: boolean = false;
  invalidPhoneNumber: boolean = false;
  contactAlreadyExist: boolean = false;

  constructor(private _routes: Router, private _customerAPI: CustomerAPI<any>, private toastr: ToasterService) {
  }

  ngOnInit() {
    this.customerProfileDetails = this._customerAPI.getCustomerProfileDetails() as ICustomer;
    this.data = this.customerProfileDetails.contactsDetails;
    this.invalidContactEntry = false;
    this.contactAlreadyExist = false;
    this.doShowAddNewContactForm = false;
    this.resetContactModel();
    this.resetViewMode();
    this.oldContact = null;
  }

  getContacts() {
    this._customerAPI.getContactsList().subscribe(
          resdata => {
            this.data = resdata['results'] as IContactsDetails[];
          }
      );

  } 

  resetContactModel() {
    this.contact = { contactName: '', doShowEditContactForm: false, emailAddress: '', phoneNumber: '',lastUsedDate:null };
  }


  showContact(item: IContactsDetails, i: number) {
    this.doShowAddNewContactForm = false;
    this.invalidContactEntry = false;
    this.contactAlreadyExist = false;

    this.oldContact = {
      contactName: item.contactName,
      emailAddress: item.emailAddress,
      phoneNumber: item.phoneNumber,
      lastUsedDate:null,
      doShowEditContactForm: item.doShowEditContactForm
    }


    if (this.data[i].doShowEditContactForm) {
      this.data[i].doShowEditContactForm = false;
      return;
    }


    this.resetViewMode();

    this.data[i].doShowEditContactForm = true;

    this.contact = { contactName: item.contactName, doShowEditContactForm: item.doShowEditContactForm, emailAddress: item.emailAddress, phoneNumber: item.phoneNumber,lastUsedDate:null };
  }

  resetViewMode() {
    for (let item of this.data) {
      item.doShowEditContactForm = false;
    }
  }

  resetModelValues(item: IContactsDetails, i) {
    this.contactAlreadyExist = false;
    this.invalidContactEntry = false;
    this.data[i] = this.oldContact;
  }

  removeContact(item: IContactsDetails, i: number) {
    this.data.splice(i, 1);
    this._customerAPI.updateUserProfile(this.customerProfileDetails)
      .subscribe(
        data => {
          if (data == null || data == undefined) {
            console.log('Updation failed');
            return;
          }
          this.toastr.success('Successfully deleted!');
        },
        error => {
          console.log(error);
        });
  }

  showNewContact() {
    this.invalidContactEntry = false;
    this.contactAlreadyExist = false;
    this.resetContactModel();
    this.resetViewMode();
    this.doShowAddNewContactForm = !this.doShowAddNewContactForm;
  }

  onFormSubmit(form: NgForm) {
    this.invalidContactEntry = false;
    this.contactAlreadyExist = false;
    this.invalidName = false;
    this.invalidEmail = false;
    this.invalidPhoneNumber = false;

   
    if (form.controls.contact_Name.invalid || form.controls.contact_Name.value.trim() == '') {
      this.invalidContactEntry = true;
      this.invalidName = true;
    }
    if (form.controls.email_Address.invalid || form.controls.email_Address.value.trim() == '') {
      this.invalidContactEntry = true;
      this.invalidEmail = true;
    }
    if (form.controls.phone_No.invalid || form.controls.phone_No.value.trim() == '') {
      this.invalidPhoneNumber = true;
      this.invalidContactEntry = true;
    }


    if (form.invalid || this.invalidContactEntry == true) {
      return;
    }

    this.saveNewContact();
  }



  updateContact(i:number) {
    this.invalidContactEntry = false;
    this.contactAlreadyExist = false;
    this.invalidName = false;
    this.invalidEmail = false;
    this.invalidPhoneNumber = false;

    if (this.contact.contactName.trim() == '') {
      this.invalidContactEntry = true;
      this.invalidName = true;
    }
    if (this.contact.emailAddress.trim() == '' || !this.isValidEmail(this.contact.emailAddress)) {
      this.invalidContactEntry = true;
      this.invalidEmail = true;
    }

    if (this.contact.phoneNumber.trim() == '' || !this.isValidPhoneNumber(this.contact.phoneNumber)) {
      this.invalidContactEntry = true;
      this.invalidPhoneNumber = true;
    }

    if (this.invalidContactEntry) {
      return;
    }

    if (this.isContactAlreadyExist(i)) {
      this.contactAlreadyExist = true;
      return;
    }


    this.customerProfileDetails.contactsDetails[i] = this.contact;
    this._customerAPI.setCustomerProfileDetails(this.customerProfileDetails);
    this._customerAPI.updateUserProfile(this.customerProfileDetails)
      .subscribe(
        data => {
          if (data == null || data == undefined) {
            this.toastr.error('Updation failed');
            return;
          }
          this.toastr.success('Successfully profile updated!');
          this.contact.doShowEditContactForm = false;
        },
      error => {
        this.toastr.error('Failed!');
      });
  }

  isValidPhoneNumber(value) {
    var pattern = new RegExp("([0-9]{10,14})");
    return pattern.test(value);
  }

  isValidEmail(value) {
    var pattern = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return pattern.test(value);
  }

  public saveNewContact() {
    this.contact.doShowEditContactForm = false;

    if (this.isContactAlreadyExist(-1)) {
      this.contactAlreadyExist = true;
      return;
    }

   
    this.customerProfileDetails = this._customerAPI.getCustomerProfileDetails() as ICustomer;
    this.customerProfileDetails.contactsDetails.push(this.contact);
    this._customerAPI.setCustomerProfileDetails(this.customerProfileDetails);

    //----------service-call----------//
    this._customerAPI.updateUserProfile(this.customerProfileDetails)
      .subscribe(
        data => {
          if (data == null || data == undefined) {
            this.removeContactsList(this.contact);
            this.toastr.error('Updation failed');
            return;
          }
          this.toastr.success('Successfully profile updated!');
          this.doShowAddNewContactForm = false;
        },
      error => {
        this.removeContactsList(this.contact);
        this.toastr.error('Failed!');
      });
  }

  removeContactsList(item) {
    var index = this.getIndexOfItem(item);
    this.customerProfileDetails.contactsDetails.splice(index, 1);
  }

  getIndexOfItem(value) {
    return typeof value === 'number' ? value : this.customerProfileDetails.contactsDetails.indexOf(value);
  }

  isContactAlreadyExist(rowIndex: number) {
    if (!rowIndex) {
      return false;
    }

   var length= this.data.filter((contact: IContactsDetails, index) => index != rowIndex &&  contact.contactName.toLowerCase().trim() == this.contact.contactName.toLowerCase().trim()
      && contact.emailAddress.toLowerCase().trim() == this.contact.emailAddress.toLowerCase().trim()
      && contact.phoneNumber.toLowerCase().trim() == this.contact.phoneNumber.toLowerCase().trim()
    ).length;

    return length > 0;
  }
}
