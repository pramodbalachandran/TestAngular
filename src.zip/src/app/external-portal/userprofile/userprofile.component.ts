import { Component, OnInit, Input, Output, EventEmitter,AfterViewInit  } from '@angular/core';
import { ICustomer } from '@app/models';
import { Router } from '@angular/router';
import { UserRegistrationService,ToasterService,CustomerAPI,GeaographyAPI } from '@app/shared/services';
import { RoutingKey } from '@app/shared/services/shared/config.const';
import { UtilitiesService } from '@app/shared/services/shared/utilities.service';
import { PageState } from '@app/shared/services/shared/enum';
import { settings } from 'cluster';
import { conformToMask } from 'angular2-text-mask';

@Component({
  selector: 'app-userprofile',
  templateUrl: './userprofile.component.html',
  styleUrls: ['../usersettings/usersettings.component.css'],
})
export class UserProfileComponent implements OnInit, AfterViewInit {
  @Input() model: ICustomer;
  @Input() oldModel: ICustomer;
  @Input('userId') userId: string;
  @Input('emailAddress') emailAddr: string;
  @Input('revisitTab') revisitTab: boolean;
  @Input('countryList') countryOptions;
  @Input('stateList') stateOptions;
  @Input('billingStateList') billingStateOptions;
  @Input('postalCodeList') postalCodes:any;

  @Output() componentInit = new EventEmitter();

  showPassword = false;
  isPasswordIsUserName = false;
  showMultipleUserIdsMessage = false;

  userExists = false;
  emailAddress = false;
  loading = false;
  contactTypeOptions = ['Mobile', 'Home', 'Office'];
  showAddressLine1 = false;
  showAddressLine2 = false;
  showBillingAddressLine1 = false;
  showBillingAddressLine2 = false;
  postalCodeMask: any;
  billingPostalCodeMask: any;
  defaultPostalCodeMask: any = [];
  phoneCountryCodeMask = ['+', /[1-9]/, /\d/, /\d/];
  invalidPostalCodeMask: boolean = false;
  invalidBillingPostalCodeMask: boolean = false;
  invalidPostalCode: boolean = false;
  invalidBillingPostalCode: boolean = false;

  constructor(private helper: UtilitiesService, private geographyService: GeaographyAPI<any>, private customerAPI: CustomerAPI<any>, private toastr: ToasterService) {
  }

  ngOnInit() {
    this.setDefaultValues();
  }

  ngAfterViewInit() {
    setTimeout(() => {
      this.setDefaultValues();
    }, 5000);
  }

  setDefaultValues() {

    if (this.model.billingAddress.length == 0) {
      this.model.billingAddress = [];
      this.model.billingAddress.push({ contactName: '', addressLine1: '', addressLine2: '', addressLine3: '', countryName: '', countryCode: '', politicalDivision1Name: '', politicalDivision1Code: '', politicalDivision2Name: '', postalCode: '' });
    }

    if (this.model.contactAddressLine1 != undefined && this.model.contactAddressLine1 != null && this.model.contactAddressLine1.toString().trim() != '') {
      this.showAddressLine1 = true;
    }

    if (this.model.contactAddressLine2 != undefined && this.model.contactAddressLine2 != null && this.model.contactAddressLine2.toString().trim() != '') {
      this.showAddressLine2 = true;
    }

    if (!this.model.contactAsBillingAddressIndicator && this.model.billingAddress[0].addressLine2 != undefined && this.model.billingAddress[0].addressLine2 != null && this.model.billingAddress[0].addressLine2.toString().trim() != '') {
      this.showBillingAddressLine1 = true;
    }

    if (!this.model.contactAsBillingAddressIndicator && this.model.billingAddress[0].addressLine3 != undefined && this.model.billingAddress[0].addressLine3 != null && this.model.billingAddress[0].addressLine3.toString().trim() != '') {
      this.showBillingAddressLine2 = true;
    }

    if (this.model.phoneCountryCode == '') {
      this.model.phoneCountryCode = "+";
    }

    this.setPostalCodeMask(this.model.countryCode);
    this.setBillingPostalCodeMask(this.model.billingAddress[0].countryCode);
  }

  AddAddressLine() {
    if (this.showAddressLine1 && this.showAddressLine2) {
      return;
    }
    if (!this.showAddressLine1) {
      this.showAddressLine1 = true;
      return;
    }
    if (this.showAddressLine1) {
      this.showAddressLine2 = true;
      return;
    }
  }

  AddBillingAddressLine() {
    if (this.showBillingAddressLine1 && this.showBillingAddressLine2) {
      return;
    }
    if (!this.showBillingAddressLine1) {
      this.showBillingAddressLine1 = true;
      return;
    }
    if (this.showBillingAddressLine1) {
      this.showBillingAddressLine2 = true;
      return;
    }
  }

  updateUser() {
    if (this.userId != this.model.userId || !this.model.id) {
      console.log('Invalid User ID');
      return;
    }

    this.model.postalCode = this.model.postalCode.toUpperCase();

    if (this.model.contactAsBillingAddressIndicator) {
      this.model.billingAddress[0].addressLine1 = '';
      this.model.billingAddress[0].addressLine2 = '';
      this.model.billingAddress[0].addressLine3 = '';
      this.model.billingAddress[0].countryCode = '';
      this.model.billingAddress[0].countryName = '';
      this.model.billingAddress[0].politicalDivision1Code = '';
      this.model.billingAddress[0].politicalDivision1Name = '';
      this.model.billingAddress[0].politicalDivision2Name = '';
      this.model.billingAddress[0].postalCode = '';
      this.billingStateOptions = [];
    }
    else {
      this.model.billingAddress[0].postalCode = this.model.billingAddress[0].postalCode.toUpperCase();
    }

    this.customerAPI.setCustomerProfileDetails(this.model);

    this.customerAPI.updateUserProfile(this.model)
      .subscribe(
        data => {
          if (data == null || data == undefined) {
            this.toastr.error('Updation failed');
            return;
          }
          this.toastr.success('Successfully profile updated!');
          this.oldModel = JSON.parse(JSON.stringify(this.model));
        },
        error => {
          this.loading = false;
          this.toastr.error('Registration failed');
        });
  }

  onPhoneCountryCodeKeypress(event) {
    if (this.model.phoneCountryCode == '' && event.which != 43) {
      return false;
    }
    else if (event.which == 43 && this.model.phoneCountryCode.length==0) {
      return true;
    }

    if (event.which != 8 && event.which != 0 && (event.which < 48 || event.which > 57)) {
      return false;
    }
  }

  validateForm() {
    if (!this.model.contactAsBillingAddressIndicator) {
      if (this.model.billingAddress[0].countryCode.trim() == '') {
        return false;
      }
      else if (this.model.billingAddress[0].politicalDivision2Name.trim() == '' || this.model.billingAddress[0].postalCode.trim() == '') {
        return false;
      }

      if (this.billingStateOptions && this.billingStateOptions.length > 1 && this.model.billingAddress[0].politicalDivision1Code == '') {
        return false;
      }
    }
    else {
      if (this.stateOptions && this.stateOptions.length > 1 && this.model.politicalDivision1Code == '') {
        return false;
      }
    }

    this.invalidPostalCode = false;
    this.invalidBillingPostalCode = false;

    if (this.model.countryCode.trim() != '') {
      var data = this.postalCodes.filter((x) => x.countryCode == this.model.countryCode.trim());
      var mask = data.length > 0 ? data[0].mask : [];
      if (mask.length > 0 && data[0].length != this.replaceAll(this.model.postalCode,'_','').length) {
        this.invalidPostalCode = true;
        return;
      }
    }

    if (this.model.billingAddress[0].countryCode.trim() != '') {
      var data = this.postalCodes.filter((x) => x.countryCode == this.model.billingAddress[0].countryCode.trim());
      var mask = data.length > 0 ? data[0].mask : [];
      if (mask.length > 0 && data[0].length != this.replaceAll(this.model.billingAddress[0].postalCode,'_','').length) {
        this.invalidBillingPostalCode = true;
        return;
      }
    }


    return !this.isPasswordIsUserName;
  }

  onCountryChange(isBillingAddress) {
    this.setPostalSetup(isBillingAddress);
    this.getStates(isBillingAddress);
  }

  setPostalSetup(isBillingAddress) {
    var countrycode = isBillingAddress ? this.model.billingAddress[0].countryCode : this.model.countryCode;
    if (isBillingAddress) {
      this.model.billingAddress[0].postalCode = '';
      if (!countrycode) {
        this.setBillingPostalCodeMask('');
        return;
      }
      this.setBillingPostalCodeMask(countrycode);
    }
    else {
      this.model.postalCode = '';
      if (!countrycode) {
        this.setPostalCodeMask('');
        return;
      }
      this.setPostalCodeMask(countrycode);
    }
  }

  replaceAll(str,target, replacement) {
    return str.split(target).join(replacement);
  }

  getStates(isBillingAddress) {
    var countrycode = isBillingAddress ? this.model.billingAddress[0].countryCode : this.model.countryCode;
    if (!countrycode) {
      this.setState([], isBillingAddress);
      return;
    }

    this.geographyService.getStates(isBillingAddress ? this.model.billingAddress[0].countryCode : this.model.countryCode)
      .subscribe(
        data => {
          if (data && data['results']) {
            this.setState(data['results'], isBillingAddress);
          }
        },
        error => {
          this.loading = false;
          this.toastr.error('failed');
        });
  }

  setState(data, isBillingAddress) {
    var defaultState = { 'politicalDivision1Code': '', 'politicalDivision1Name': '--Choose a State--' };
    if (!isBillingAddress) {
      this.stateOptions = data;
      this.stateOptions.splice(0, 0, defaultState);
    }
    else {
      this.billingStateOptions = data;
      this.billingStateOptions.splice(0, 0, defaultState);
    }
  }

  onChangePassword() {
    this.helper.navigateTo(RoutingKey[PageState.CHANGEPASSWORD]);
  }

  emailfocusOutFunction() {

  }

  sendUserIdsMail() {
  }

  resetOldModelValues() {
    this.model.id = this.oldModel.id;
    this.model.docType = this.oldModel.docType;
    this.model.docId = this.oldModel.docId;
    this.model.businessPartyName = this.oldModel.businessPartyName;
    this.model.businessPartyNumber = this.oldModel.businessPartyNumber;
    this.model.accountNumber = this.oldModel.accountNumber;
    this.model.tempAccountNumber = this.oldModel.tempAccountNumber;
    this.model.companyName = this.oldModel.companyName;
    this.model.contactName = this.oldModel.contactName;
    this.model.contactType = this.oldModel.contactType;
    this.model.phoneCountryCode = this.oldModel.phoneCountryCode;
    this.model.phoneNumber = this.oldModel.phoneNumber;
    this.model.extension = this.oldModel.extension;
    this.model.password = this.oldModel.password;
    this.model.confirmPassword = this.oldModel.confirmPassword;
    this.model.emailAddress = this.oldModel.emailAddress;
    this.model.userId = this.oldModel.userId;
    this.model.termsAccepted = this.oldModel.termsAccepted;
    this.model.contactAddressName = this.oldModel.contactAddressName;
    this.model.contactAddress = this.oldModel.contactAddress;
    this.model.contactAddressLine1 = this.oldModel.contactAddressLine1;
    this.model.contactAddressLine2 = this.oldModel.contactAddressLine2;
    this.model.countryCode = this.oldModel.countryCode;
    this.model.countryName = this.oldModel.countryName;
    this.model.politicalDivision1Code = this.oldModel.politicalDivision1Code;
    this.model.politicalDivision1Name = this.oldModel.politicalDivision1Name;
    this.model.politicalDivision2Name = this.oldModel.politicalDivision2Name;
    this.model.postalCode = this.oldModel.postalCode;
    this.model.contactAsBillingAddressIndicator = this.oldModel.contactAsBillingAddressIndicator;
    this.model.billingAddress = JSON.parse(JSON.stringify(this.oldModel.billingAddress));
    this.getStates(true);
    this.getStates(false);
  }

  onCancel() {
    this.resetOldModelValues();
  }

  setPostalCodeMask(countryCode) {
    this.invalidPostalCodeMask = false;

    if (!countryCode) {
      this.postalCodeMask = this.defaultPostalCodeMask;
      this.invalidPostalCodeMask = true;
      return;
    }

    var mask=[];
    var data = this.postalCodes.filter((x) => x.countryCode == countryCode);
    mask = data.length > 0 ? data[0].mask : this.defaultPostalCodeMask;
   
    this.postalCodeMask = mask;
    if (mask.length <= 0) {
      this.invalidPostalCodeMask = true;
    }
  }

  setBillingPostalCodeMask(countryCode) {
   
    this.invalidBillingPostalCodeMask = false;

    if (!countryCode) {
      this.billingPostalCodeMask = this.defaultPostalCodeMask;
      this.invalidBillingPostalCodeMask = true;
      return;
    }

    var mask = [];
    var data = this.postalCodes.filter((x) => x.countryCode == countryCode);
    mask = data.length > 0 ? data[0].mask : this.defaultPostalCodeMask;
    this.billingPostalCodeMask = mask;
    if (mask.length <= 0) {
      this.invalidBillingPostalCodeMask = true;
    }
  }
}
