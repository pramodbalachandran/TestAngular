import { async, ComponentFixture, TestBed, getTestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { FormsModule } from '@angular/forms';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { RouterTestingModule } from '@angular/router/testing';
import { Router } from '@angular/router';
import { of } from "rxjs";

import { LoginRegisterComponent } from './loginregister.component';
import { CustomerAPI, LocalStorageService } from '@app/shared/services';
import { ConfigService } from '@app/services/shared/config.service';
import { UtilitiesService } from '@app/services/shared/utilities.service';

//describe('LoginregisterComponent', () => {
//  let component: LoginRegisterComponent;
//  let fixture: ComponentFixture<LoginRegisterComponent>;

//  beforeEach(async(() => {
//    TestBed.configureTestingModule({
//      declarations: [LoginRegisterComponent],
//      imports: [FormsModule, HttpClientTestingModule,RouterTestingModule],
//      providers: [CustomerAPI, ConfigService, LocalStorageService, UtilitiesService],
//      schemas: [NO_ERRORS_SCHEMA]
//    })  
//    .compileComponents();
//  }));

//  beforeEach(() => {
//    fixture = TestBed.createComponent(LoginRegisterComponent);
//    component = fixture.componentInstance;
//    fixture.detectChanges();
//  });

//  ////The Login component should be define.
//  it("should have a defined component ", () => {
//    expect(component).toBeDefined();
//  });

//  ////The login component should exist.
//  it('should have a Component', () => {
//    expect(component).toBeTruthy();
//  });

//  ////verify the ngOnit method

//  it('checkingNgOnit', () => {

//    component.model.phoneCountryCode = '';  

//    component.ngOnInit();

//    expect(component.model.phoneCountryCode).toEqual('+');

//  });
//});

describe('LoginregisterComponent with service call', () => {
  let component: LoginRegisterComponent;
  let fixture: ComponentFixture<LoginRegisterComponent>;
  let injector;
  let service: CustomerAPI<any>;

  let router = {
    navigate: jasmine.createSpy('navigate')
  }

  const data = {
    accessToken: 'token', errorMessage: "success", UserName: "ValidUser"
  };

  const createUserResponseData = {
    responseStatus:{
      status: '200',
      errorMessage:'signInNames already exists'
    }
  };

  let dummyCustomerAPIService = {
    ValidateUser: () => {
      return of(data); 
    },
    createUser: () => {
      return of(createUserResponseData); 
    },
    getEmptyUserModel: ICustomer => {
      return of({
        id: '',
        docType: '',
        docId: '',
        docStructureVersion: 0,
        partitionkey: '',
        businessPartyName: '',
        businessPartyNumber: '',
        accountNumber: '',
        tempAccountNumber: '',
        companyName: '',
        contactName: '',
        contactType: 'Mobile',
        phoneCountryCode: '',
        phoneNumber: '',
        extension: '',
        password: '',
        confirmPassword: '',
        emailAddress: '',
        userId: '',
        termsAccepted: false,
        contactAddressName: '',
        contactAddress: '',
        contactAddressLine1: '',
        contactAddressLine2: '',
        countryCode: '',
        countryName: '',
        politicalDivision1Code: '', //state
        politicalDivision1Name: '',
        politicalDivision2Name: '', // city
        postalCode: '',
        contactAsBillingAddressIndicator: false,

        contactsDetails: [],
        billingAddress: [],
        shippingAddress: [],
        notificationSettings: { emailPickupRequest: false, emailPreApprovedRate: false, emailQuoteRespondByUSP: false, emailQuoteStatusExpiring: false, emailResetPassword: false }
      });
    }
  }


  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [LoginRegisterComponent],
      imports: [FormsModule, HttpClientTestingModule, RouterTestingModule],
      providers: [{ provide: CustomerAPI, useValue: dummyCustomerAPIService }, ConfigService, LocalStorageService, UtilitiesService, { provide: Router, useValue: router }],
      schemas: [NO_ERRORS_SCHEMA]
    })
      .compileComponents();

    injector = getTestBed();
    service = injector.get(CustomerAPI);  

  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LoginRegisterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  ////Login check
  it("DoLogin Method with valid user creds", () => {

    component.loginModel = {
      Username: '',
      Password: ''
    };
    component.loginUser_name = "ValidUser";
    component.loginUser_password = "validPassword";

    component.doLogin();
    expect(component.loggedInUserName).toEqual('ValidUser');
    expect(router.navigate).toHaveBeenCalledWith(['/dashboard']);

  });

  it("DoLogin Method with invalid user creds", () => {
    component.loginModel = {
      Username: '',
      Password: ''
    };
    component.loginUser_name = "InValidUser";
    component.loginUser_password = "InvalidPassword";

    component.doLogin();
    expect(component.loggedInUserName).toEqual('ValidUser');
    expect(router.navigate).toHaveBeenCalledWith(['/dashboard']);
  });

  ////Registration Process
  it('Create User or Register user', () => {

    //component.model.userId = "ValidUser";
    //component.model.companyName = "ValidUser";
    //component.model.password = "InvalidPassword";

    //component.register();
    //expect(component.loggedInUserName).toEqual('ValidUser');
    //expect(router.navigate).toHaveBeenCalledWith(['/dashboard']);
  });

  //Registration Process
  it('Create User or Register user which already exists', () => {
    component.model.userId = "ValidUser";
    component.model.companyName = "ValidUser";
    component.model.password = "InvalidPassword";

    component.register();
    expect(component.errormessage).toEqual('UserId already exists. Please try with new User ID');
    
  });

});
