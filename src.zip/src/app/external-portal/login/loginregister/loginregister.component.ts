import { Component, OnInit, ElementRef, ViewChild, AfterViewInit } from '@angular/core';
import { NgForm } from '@angular/forms';


import { CustomerAPI, LocalStorageService } from '@app/shared/services';
import { Router, ActivatedRoute } from '@angular/router';
import { IUser, IUSER_MASTER, LoggedInUser } from '@app/shared/interfaces/entities.interface';
import { element } from 'protractor';
import { forEach } from '@angular/router/src/utils/collection';
import { RoutingKey, ApplicationUrls} from '@app/shared/services/shared/config.const';
import { UtilitiesService } from '@app/shared/services/shared/utilities.service';
import { shipmentFrequencyType, PageState } from '@app/shared/services/shared/enum';
import { ICustomer } from '@app/models';
import { access } from 'fs';


@Component({
    selector: 'pricing-loginregister',
    templateUrl: './loginregister.component.html',
    styleUrls: ['./loginregister.component.css']
})
export class LoginRegisterComponent implements OnInit, AfterViewInit {
   loginCounter: number = 0;
   loginshowPassword: boolean = false;
   userBlocked: boolean = false;
   invalidAttempt: boolean = false;

   showPassword = false;
   confirmPasswordSuccess = true;
   isPasswordIsUserName = false;
   isPasswordIsContactName = false;
   showMultipleUserIdsMessage = false;
   showUserSuggestions = false;
   userExists = false;
   userSuggestedValue: string;
   userSuggestionModel: any = {};
   itemsList = [];
   radioSel: any;
   radioSelected: string;
   radioSelectedString: string;

   loginUser_name: string;
   loginUser_password: string;
   RegisterTabsactivemode: boolean = false;
   LoginTabsactivemode: boolean = true;

   errormessage: string = "";
   errormessageLogin: string = "";
   successMeassage: string = "";
   loggedInUserName: string = "";
   controlTypeLogin: string = "password";
   eyeClassLogin: string = "fa fa-eye";
   eyeTextLogin: string = "Show password";
   controlTypeRegister: string = "password";
   eyeClassRegister: string = "fa fa-eye";
   eyeTextRegister: string = "Show password";
   displayForgotPassword: boolean = false;
   displayForgotPasswordOTPScreen: boolean = false;
   displayChangePassword: boolean = false;
   displayFinalPasswordChangeScreen: boolean = false;
   userId: string = "";
   accessToken: string = "";
   lockNext: boolean = false;
   setTimeforLockDisable: any;

    showRegisterTabValidation = true;
    prevEnteredUserid = '';
    userTimer: any = null;
    EmailTimer: any = null;
    contactTypeOptions = ['Mobile', 'Home', 'Office'];
    countryCodeMask = ['+', /[1-9]/, /\d/,/\d/];
    model: ICustomer;
    loginModel: any = {   
      Username: '',
      Password: ''   
    };

    passwordModel: any = {
      UserId: '',
      EmailId: ''
    };

    OTPModel: any = {
      UserName: this.passwordModel.UserId,
      SCode: ''
    };

    resetPasswordModel: any = {
      UserName: this.passwordModel.UserId,
      SCode: '',
      NewPswd:''
    };

    @ViewChild('f') registrationForm: NgForm;
    @ViewChild('loginForm') loginForm: NgForm;
    @ViewChild('input') el: ElementRef;

    public user: IUSER_MASTER = { user_name: '', password: '' } as IUSER_MASTER;

  constructor(private router: Router, private userService: CustomerAPI<ICustomer>, private userService1: CustomerAPI<LoggedInUser>, private localStorageService: LocalStorageService, private helper: UtilitiesService) {
  }
  

  ngOnInit() {
    this.userSuggestedValue = '';
    this.model = this.userService.getEmptyUserModel();
    if (this.model.phoneCountryCode == '') {
      this.model.phoneCountryCode = '+'; 
    }
  }

  ngAfterViewInit() {
  
    this.el.nativeElement.focus();
    this.loginForm.resetForm();
    this.registrationForm.resetForm();
  }

  Tabsactivemodechange(tab) {
      // Login
      if (tab == 1) {    
        this.clearModel();
        this.RegisterTabsactivemode = false;
        this.LoginTabsactivemode = true;
        this.errormessage = "";
        this.successMeassage = "";
        this.registrationForm.resetForm();
        this.showPassword = true;
        this.passwordToggleLogin();
      }

      // Register
      if (tab == 2) {
          this.clearLoginModel();
          this.errormessageLogin = "";
          this.successMeassage = "";
          this.RegisterTabsactivemode = true;
          this.LoginTabsactivemode = false;
          this.loginForm.resetForm();
          this.showPassword = true;
          this.passwordToggleRegister();
      }
    };

    //****Login****//

  onUserNameKeyPress(event: any) { // without type info
    this.clearMessage();
    this.user.user_name = this.user.user_name.trim();
    }

  onPasswordKeyPress(event: any) { // without type info
    this.clearMessage();
    this.user.password = this.user.password.trim();
  }

  clearErrorMessagePress(event: any) {
    this.errormessageLogin = "";
  }

  isValidUser(user: IUSER_MASTER) {
        if (this.user != undefined
            && (this.user.user_name == 'MRZ7HCB' || this.user.user_name == 'mrz7hcb')
            && this.user.password == 'Per@123') {
            localStorage.setItem('currentUser', JSON.stringify(user));
            localStorage.setItem('currentUserName', this.user.user_name);
            this.router.navigate(['/home']);
        }
        else {
            this.invalidUser(this.user.user_name);
        }
  }

  clearMessage() {

    this.errormessageLogin = "";
  }

  invalidUser(userName: string) {
        // block user after 3 invalide attempts
        this.loginCounter++;
        var errorMessage1: string = "The information that you have enetered doesn't match any ups.com profile. If you are attempting to login with your email, try again using your UserID. Remember that UserID and password fields are case-sensitive.";
        var note: string = "Note. To protect your information, we'll block access to your profile after [3] consecutive unsuccessfull attempts to log in";
        var blockedText: string = " You are blocked.";

        if (this.loginCounter == 3) {
            this.userBlocked = true;
            this.invalidAttempt = true;
            return;
        }
        this.invalidAttempt = true;
    }

  validateLoginForm() {
        return !this.userBlocked;
    }

  invalidTry() {
        return this.invalidAttempt;
    }

    //----------------------------------------//
  navigateToPage(self: any) {

      let userId: string = self.loginUser_name;
      let navigationAction = localStorage.getItem("navigationAction");    
     

        switch (localStorage.getItem("lastVisitedPage")) {
            
            case PageState.CONTACT: {
            //localStorage.clear(); //don't clear,user coming from contact page.
            localStorage.setItem('currentUserName1', self.loginUser_name.toLowerCase());
            localStorage.setItem("LoggedInUser", this.loggedInUserName);
                
            if (navigationAction != null && navigationAction == "nextcontactbutton") {
                    
                    
                this.helper.navigateTo(RoutingKey[PageState.QUOTE_SUCCESS]);
            }
            else {
                    
                this.helper.navigateTo(RoutingKey[PageState.DASHBOARD]);
            }
            break;
            }
            case PageState.QUOTE_RATE: {
            localStorage.setItem('currentUserName1', userId.toLowerCase());
            localStorage.setItem("LoggedInUser", this.loggedInUserName);

                if (navigationAction != null && navigationAction == "requestPickupButton") {
                 
                    this.helper.navigateTo(RoutingKey[PageState.DASHBOARD]);
                }
                else {
                    this.helper.navigateTo(RoutingKey[PageState.DASHBOARD]);
                }
                break;
            }
            default: {
                localStorage.clear();
                localStorage.setItem('currentUserName1', userId.toLowerCase());
                localStorage.setItem("LoggedInUser", this.loggedInUserName);
                
                this.helper.navigateTo(RoutingKey[PageState.DASHBOARD]);

            }

        }

    }

  doLogin() {
       

        this.loginModel.Username = this.loginUser_name.trim();
        this.loginModel.Password = this.loginUser_password.trim();
        var self = this;
        

        this.userService.ValidateUser(this.loginModel)
            .subscribe(
            data => {
              if (data.accessToken) {
                    self.loggedInUserName = data.UserName;              
                    this.navigateToPage(self);
                }
                else {
                    var errMsgNotNull = (data.errorMessage !== null && data.errorMessage !== undefined);
                    if (errMsgNotNull && (data.errorMessage.indexOf('The username or password provided in the request are invalid') !== -1)) {
                        self.errormessageLogin = 'Invalid User ID/Password';
                    }
                    else {
                      self.errormessageLogin = data.errorMessage;
                    }
                }
            },
            error => {
                console.log(error);
            });
    }
    //****Register****//

  pasteUrl(event: any) {
        
    }

  passwordToggleLogin() {
      this.showPassword = !this.showPassword;

      if (this.showPassword) {
        this.eyeClassLogin = "fa fa-eye-slash";
        this.controlTypeLogin = 'text';
        this.eyeTextLogin = "Hide password";
      } else {
        this.eyeClassLogin = "fa fa-eye";
        this.controlTypeLogin = 'password';
        this.eyeTextLogin = "Show password";
      }
  }

  passwordToggleRegister() {
    this.showPassword = !this.showPassword;

    if (this.showPassword) {
      this.eyeClassRegister = "fa fa-eye-slash";
      this.controlTypeRegister = 'text';
      this.eyeTextRegister = "Hide password";
    } else {
      this.eyeClassRegister = "fa fa-eye";
      this.controlTypeRegister = 'password';
      this.eyeTextRegister = "Show password";
    }
  }

  focusOutFunction() {
    if (this.model.password != undefined) {
      this.model.password = this.model.password.trim();
    }
    if (this.model.confirmPassword != undefined && this.model.confirmPassword != '') {
      this.confirmPasswordSuccess = (this.model.password == this.model.confirmPassword);
    }
  }

  passwordfocusOutFunction() {
    if (this.model.userId != undefined && this.model.userId != '') {
      this.isPasswordIsUserName = (this.model.password == this.model.userId);
      this.isPasswordIsContactName = (this.model.password == this.model.contactName.trim());
    }
    this.focusOutFunction();
  }  

  onEmailChange() {
    this.errormessage = '';
    this.showMultipleUserIdsMessage = false;
    clearTimeout(this.EmailTimer);
    this.EmailTimer = setTimeout(() => {
      this.checkEmailExist();
    }, 300);
  }

  checkEmailExist() {
    this.model.emailAddress = this.model.emailAddress.trim();
    if (this.model.emailAddress == '') {
      return;
    }

    this.showMultipleUserIdsMessage = false;
    this.userService.getUsersCountByEmail(this.model.emailAddress)
      .subscribe(
        data => {
          if (data && data.length > 0) {
            this.showMultipleUserIdsMessage = true;
            //setTimeout(() => {
            //  this.showMultipleUserIdsMessage = false;
            //}, 15000);
          }
        },
        error => {
          console.log(error);
        });
  }

  onUserChange() {
    this.isPasswordIsUserName = (this.model.password == this.model.userId);
    this.errormessage = '';
    this.showUserSuggestions = false;
    this.userExists = false;
    clearTimeout(this.userTimer);
    this.userTimer = setTimeout(() => {
      this.getUser();
    }, 300);
  }

  getUser() {
    this.model.userId = this.model.userId.trim();
    if (this.model.userId == '' || this.prevEnteredUserid == this.model.userId) {
      return;
    }
    this.prevEnteredUserid = this.model.userId;
    this.showUserSuggestions = false;
    this.userExists = false;
    this.userService.getUserNameSuggestion(this.model.userId)
      .subscribe(
        data => {
          if (data != null && data.length>0) {
            this.userExists = true;
            this.showUserSuggestions = true;
            this.itemsList = [];
            this.itemsList.push({ name: data[0], value: data[0] });
            this.itemsList.push({ name: data[1], value: data[1] });

            this.radioSelected = '';
            this.getSelecteditem();

            //setTimeout(() => {
            //    this.showUserSuggestions = false;
            //}, 15000);
          }
        },
        error => {
            console.log(error);
        });
    }

  getSelecteditem() {
        this.radioSel = this.itemsList.find(Item => Item.value === this.radioSelected);
        this.radioSelectedString = JSON.stringify(this.radioSel);
        return this.radioSelectedString;
    }

  isRadioSelected(value: any) {
        return false;
    }

  onItemChange(item) {
    var selected = this.getSelecteditem();
    this.model.userId = this.radioSel.value;
    this.showUserSuggestions = false;
    this.userExists = false;
    this.prevEnteredUserid = '';
  }

  onRadioItemChange(item) {
    this.model.userId = this.getSelecteditem();
    this.showUserSuggestions = false;
  }

  showMultipleUserIdsPopup() {

    }

  onNavigate() {
    window.open(ApplicationUrls[3].technology_Aggrement, "_blank");
  }

  forgotPassword() {

    this.displayForgotPassword = true;

    this.resetModels();  

  } 

  navigatePasswordChangeScreen() {

    var self = this;
    this.lockNext = false;
    this.OTPModel.UserName = localStorage.getItem('userNameForPassword');
    this.userService.verifyFPCode(this.OTPModel)
      .subscribe(
        data => {
          if (data != null) {
            if (data.responseStatus.status == '200') {
              this.displayForgotPasswordOTPScreen = false;
              this.displayChangePassword = true;
              this.userId = self.OTPModel.UserName;
              this.accessToken = data.responseStatus.accessToken;             
            }
            else if (data.responseStatus.status == '400') {
              self.errormessageLogin = String(data.responseStatus.accessToken)  +'.Please try again with valid OTP';
            }
            else if (data.responseStatus.status == '401') {
              this.lockNext = true;
              //lock next button for 5 min
              this.setTimeforLockDisable=setTimeout(function () {
                self.lockNext = false;
                self.errormessageLogin = "Please try now with requested PIN again.";
               
              }, 5 * 60 * 1000);
              self.errormessageLogin = 'Request PIN button is disabled for 5 min.';
            }
          }
        },
        error => {
          console.log(error);
        });      
  }

  displayOTPScreen() {    
    var self = this;
    this.userService.verifyUser(this.passwordModel)
      .subscribe(
      data => {
        if (data != null) {
          if (data.responseStatus.status == '200') {
            localStorage.setItem('userNameForPassword', self.passwordModel.UserId);
            this.displayForgotPasswordOTPScreen = true;       
          }
          else if (data.responseStatus.status == '400') {           
            self.errormessageLogin = 'The entered user ID or e-mail address do not match with stored information.Please check for accuracy and re-enter.';
          }
        }
      },
      error => {
        console.log(error);
      });  
  }

  resetPassword() {
  
    var self = this;
    this.resetPasswordModel.UserName = localStorage.getItem('userNameForPassword');
    this.resetPasswordModel.SCode = this.accessToken;
    
    this.userService.resetPassword(this.resetPasswordModel)
      .subscribe(
        data => {
          if (data != null) {
            if (data.responseStatus.status == '204') {              
              this.displayFinalPasswordChangeScreen = true;
              this.displayChangePassword = false;             
            }
            else if (data.responseStatus.status == '401') {
              self.errormessageLogin = 'Unable to reset password due to system error.Please try again';
            }
          }
        },
      error => {
        self.errormessageLogin = 'Unable to reset password due to system error.Please try again.';
          console.log(error);
        });  
    
  }

  onCancel() {

    this.displayForgotPassword = false;
    this.displayForgotPasswordOTPScreen = false;
    this.displayChangePassword = false;
    this.displayFinalPasswordChangeScreen = false;
    this.errormessageLogin = "";
    this.lockNext = false;
    clearTimeout(this.setTimeforLockDisable);
  }

  sendUserIdsMail() {
    this.userService.sendUserIdsMail(this.model.emailAddress)
      .subscribe(
        data => {
          this.showMultipleUserIdsMessage = false;
        },
        error => {
          console.log(error);
        });

    }

  trimModelValues() {
    this.model.companyName = this.model.companyName.trim();
    this.model.contactName = this.model.contactName.trim();
    this.isPasswordIsContactName = (this.model.password == this.model.contactName);
  }

  validateForm() {
    return !this.isPasswordIsUserName && !this.isPasswordIsContactName && this.confirmPasswordSuccess && !this.userExists;
  }

  register() {
    this.errormessage = '';
    if (!this.confirmPasswordSuccess && !this.userExists) {
        return;
    }

      
    this.model.userId.trim();
    this.model.password.trim();
    this.loginUser_name = this.model.userId;
    var self = this;

    if (this.model.phoneCountryCode== '') {
      this.model.phoneCountryCode = ' ';
    }
    if (this.model.countryCode == '') {
      this.model.countryCode = ' ';
    }


    this.userService.createUser(this.model)
      .subscribe(
      data => {         

          if (data.responseStatus.status == '201') {
              self.loggedInUserName = this.model.companyName; 
              this.navigateToPage(self);    

              this.RegisterTabsactivemode = false;
              this.errormessage = "";
              this.LoginTabsactivemode = true;
              this.successMeassage = "Registration has been successfully completed. Please Login.";

              setTimeout(() => {
                  this.successMeassage = "";
              }, 2000);
          }
          else {
              if (data.responseStatus.errorMessage.indexOf('signInNames already exists') !== -1) {
                this.errormessage = 'UserId already exists. Please try with new User ID';
              }
              else {
                  this.errormessage = data.responseStatus.errorMessage;
              }
              this.RegisterTabsactivemode = true;
              this.LoginTabsactivemode = false;
              return;
          }
      },
      error => {
          console.log(error);
      });
    }

  clearModel() {

    this.model = this.userService.getEmptyUserModel();
  }

  clearLoginModel() {

        this.loginModel = {
            Username: '',
            Password: ''

        }
  }

  resetModels() {

    this.passwordModel = {
      UserId: '',
      EmailId: ''
    };

    this.OTPModel = {
      UserName: this.passwordModel.UserId,
      SCode: ''
    };

    this.resetPasswordModel = {
      UserName: this.passwordModel.UserId,
      SCode: '',
      NewPswd: ''
    };
    this.errormessageLogin = "";
    this.errormessage = "";
    this.successMeassage = "";


  }

}

