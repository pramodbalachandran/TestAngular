import { Component } from '@angular/core';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
})


export class LoginComponent {
  body: HTMLBodyElement = document.getElementsByTagName('body')[0];
  constructor() {
    this.body.classList.add('login-logo');
  }
}
