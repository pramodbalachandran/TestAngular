import { Component } from '@angular/core';
import { Router } from '@angular/router';

import { User } from '@app/shared/interfaces/entities.interface';
import { UserRegistrationService } from '@app/shared/services';
import { element } from 'protractor';
import { triggerAsyncId } from 'async_hooks';
import { PageState } from '@app/shared/services/shared/enum';
import { RoutingKey } from '@app/shared/services/shared/config.const';
import { UtilitiesService } from '@app/shared/services/shared/utilities.service';

@Component({
    selector: 'app-changepassword',
    templateUrl: './changepassword.component.html',
    styleUrls: ['./changepassword.component.css']
})

export class ChangepasswordComponent {
    model: any = {};
    userId = '';
    constructor(
      private router: Router, private helper: UtilitiesService
        ) { }

    public confirmPasswordSuccess = true;

    ngOnInit() {
        this.userId = localStorage.getItem('currentUserName');
    }

    changePassword(){
        //toastr.info('Not Implemented!!');
    }


    newPasswordfocusOutFunction() {
        if (this.model.Password != undefined) {
            this.model.Password = this.model.Password.trim();
        }
        if (this.model.ConfirmPassword != undefined && this.model.ConfirmPassword != '') {
            this.confirmPasswordSuccess = (this.model.Password == this.model.ConfirmPassword);
        }
    }

    confirmPasswordfocusOutFunction() {
        this.newPasswordfocusOutFunction();
    }


    validateForm() {
        return this.confirmPasswordSuccess;
  }

  onCancel() {
    this.helper.navigateTo(RoutingKey[PageState.USERSETTINGS]);
  }
}
