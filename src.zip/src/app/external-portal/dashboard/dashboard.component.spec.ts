import { async, ComponentFixture, TestBed, getTestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';

import { DashboardComponent } from './dashboard.component';
import { IQuoteData, IQuoteListDetails } from '@app/models/quotes/quote-data'
import { QuoteAPI } from '@app/shared/services';
import { Enviorment } from '@app/services/shared/config.const';

describe('DashboardComponent', () => {
  let component: DashboardComponent;
    let fixture: ComponentFixture<DashboardComponent>;

  beforeEach(async(() => {

    let injector;
    let service: QuoteAPI<IQuoteData>;


    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      declarations: [DashboardComponent],
      providers: [{ provide: QuoteAPI }]
    })
      .compileComponents();

    injector = getTestBed();
    service = injector.get(QuoteAPI);

  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create the Dashboard Componenet', () => {
    expect(component).toBeDefined();
  });

  //describe('#getQuoteDetails', () => {

  //  it('should load the quote list based on userId', () => {     

  //    localStorage.setItem('currentUserName1', 'sudiptadev1');

  //    switch (Enviorment.type) {

  //      case "dev":
  //        localStorage.setItem('currentUserName1', '');
  //        break;

  //      case "QA":
  //        localStorage.setItem('currentUserName1', '');
  //        break;

  //      case "UAT":
  //        localStorage.setItem('currentUserName1', '');
  //        break;

  //      case "PROD":
  //        localStorage.setItem('currentUserName1', '');
  //        break;
  //    }
  //    component.getQuotes();     
  //    expect(component.data[0].id).length>0;
  //    expect(component.data[0].quoteStatusCode).toBeGreaterThan(0);
  //    localStorage.removeItem('currentUserName1');
  
  //  });
  //});

  //describe('#getQuoteDetailsbyQuoteId', () => {
  //  it('should load the quote detail based on quoteId', () => {
  //    var quoteId = "";

  //    switch (Enviorment.type) {

  //      case "dev":
  //        quoteId = "";
  //        break;

  //      case "QA":
  //        quoteId = "";
  //        break;

  //      case "UAT":
  //        quoteId = "";
  //        break;

  //      case "PROD":
  //        quoteId = "";
  //        break;
  //    }

  //    component.getQuoteDetailsbyQuoteId(quoteId);     
  //    expect(component.lastVisitedPage).toBeDefined();
  //    expect(parseInt(component.lastVisitedPage)).toBeGreaterThan(0);     

  //  });
  //});

});
