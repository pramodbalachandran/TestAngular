import { Component, OnInit,AfterViewInit, ViewChild, ElementRef, Renderer2 } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { DatePipe } from "@angular/common";
import { DataTableModule } from 'angular-6-datatable';

import { QuoteService } from '../services/quote.service';
import { IQuoteStrcuture, IQUOTE, ShippingAddress, LoggedInUser, QuoteDetail } from '@app/shared/interfaces/entities.interface';
import { QuoteAPI, LocalStorageService, CustomerAPI, GeaographyAPI } from '@app/shared/services';
import { getMatIconFailedToSanitizeLiteralError } from '@angular/material';
import { IQuoteData,IQuoteListDetails} from '@app/models/quotes/quote-data'
import { IQuoteDetails} from '@app/models/quotes/quotes-details'
import { IAirFreightShipmentDetail } from '@app/models/quotes/airfreightshipment-detail'
import { PageState } from '@app/shared/services/shared/enum';
import { ApplicationUrls, RoutingKey, monthNames } from '@app/shared/services/shared/config.const';
import { UtilitiesService } from '@app/shared/services/shared/utilities.service';
import { ToasterService } from '@app/shared/services';
import * as _ from 'lodash';
import { ICurrencyData,ICurrencyDetailData } from '@app/models';



@Component({
    selector: 'pricing-dashboard',
    templateUrl: './dashboard.component.html',
    styleUrls: ['./dashboard.component.scss'],
    providers: [DataTableModule],
  
})


export class DashboardComponent implements OnInit,AfterViewInit {

      data: IQuoteListDetails[];
      quotedataList:IQuoteListDetails[];
      master: IQuoteListDetails[];   
      isDataAvailable: boolean = false;
      isSearchDataAvailable: boolean = false;
      keyshipmentAddress = 'Shipmentaddressselectedfromddl';
      keyshipmentAddressd2d = 'Shipmentaddressselectedfromddld2d';
      isNewQuote: boolean = false;
      userId: string = "";
      body: HTMLBodyElement = document.getElementsByTagName('body')[0];
      classes: string[]=[];
      show: boolean = false;
      lastVisitedPage: string = "";
      shipmentCurrencyCodeData: ICurrencyDetailData[];
      @ViewChild('dashboardLoader') dashboardLoader: ElementRef;



  constructor(private renderer: Renderer2, private helper: UtilitiesService, private localStorageService: LocalStorageService, private quoteService: QuoteAPI<IQuoteData>, private qouteAPI: QuoteAPI<IQUOTE>, private customerAPI: CustomerAPI<LoggedInUser>, private toastr: ToasterService, private geoGraphyService: GeaographyAPI<ICurrencyData>) {
   
  }


  ngOnInit() {
    localStorage.removeItem(this.keyshipmentAddress);
    localStorage.removeItem(this.keyshipmentAddressd2d);
    let navigationAction = localStorage.getItem("navigationAction");    
    this.body.classList.remove('login-logo');  
    this.setDataForNewUser();
    if (navigationAction != null && navigationAction == "requestPickupButton") {
        this.helper.navigateTo(RoutingKey[PageState.QUOTE_RATE]);
    }
  }

  ngAfterViewInit() {
    //console.log("ngAfterViewInit");        
  }

  getCurrencyDetail(quoteId:string) {

    var self = this; 
    //checking currency data for just loggedin user become register user
    if ((this.geoGraphyService.getCurrencyDetails() != null &&  this.geoGraphyService.getCurrencyDetails().currencyData.length>1)) {

      this.getQuoteDetailsbyQuoteId(quoteId);
    }
    else {

      this.geoGraphyService.getCurrencyDetailList().subscribe(
        resdata => {

          if (resdata.result != null && resdata.result.results[0] != null && resdata.result.results[0].currencyConversion.length > 0) {

            this.shipmentCurrencyCodeData = resdata.result.results[0]["currencyConversion"];
            let currencyDetail = this.geoGraphyService.getCurrencyDetails() as ICurrencyData;
            currencyDetail.currencyData = this.shipmentCurrencyCodeData;            
            
            this.shipmentCurrencyCodeData.forEach(function (element) {
              currencyDetail.currencyData.push(element);
            });
            this.geoGraphyService.setCurrencyDetails(currencyDetail);
            this.getQuoteDetailsbyQuoteId(quoteId);
          }
        },
        error => {
            this.shipmentCurrencyCodeData = [];         
        });     
    }
  }

  toggleClass() {
    this.classes.splice(this.classes.length - 1, 1); // removes the class 
    this.show = !this.show;
    if (this.show) {
      this.classes.push('dropdown-menu dropdown-content')
    } else {
      this.classes.pop();
    }
  }

  setDataForNewUser() {

    //checking quote data for just loggedin user become register user
    if ((this.quoteService.getQuoteDetails() != null || this.quoteService.getQuoteDetails() !=undefined ) && this.quoteService.getQuoteDetails().quoteRequestData.lastVisitedPage !="" && this.quoteService.getQuoteDetails().quoteRequestData.quoteServiceType != "") {
      //Set logged user details in the existing data model for guest users
      let quoteDetail = this.quoteService.getQuoteDetails() as IQuoteData;
      quoteDetail.quoteRequestData.businessPartyNumber = localStorage.getItem('currentUserName1');
      this.quoteService.setQuoteDetails(quoteDetail);
      //Save existing data model for guest users
      this.quoteService.save().subscribe(
        resdata => {
          if (resdata != null) {
            if (resdata.responseStatus.status == '200') {
              this.clearModel();
              this.getQuotes();
              return;
            }
            else {
              this.getQuotes();
              this.toastr.error('Problem occured while saving new quote!');
            }
          }
        },
        error => {
          this.getQuotes();
          this.toastr.error('System Error while saving new quote.Please Contact Admisnistrator!');
        });
    }
    else {
      this.getQuotes();
    }
  }

   //---------------------------------//
   wait(ms) {
    var start = new Date().getTime();
    var end = start;
    while (end < start + ms) {
        end = new Date().getTime();
    }
   }
   //---------------------------------//

  getQuotes() {
     var self = this;    
    this.qouteAPI.getQuoteList(localStorage.getItem('currentUserName1')).subscribe(
        resdata => {
          if (resdata!=null ) {
            if (resdata['results'] != null && resdata['results'].length > 0) {
              self.data = resdata['results'] as IQuoteListDetails[];
              self.master = resdata['results'] as IQuoteListDetails[];
              self.isDataAvailable = true;
              self.isNewQuote = false;
            }
            else {
              self.isDataAvailable = false;
              self.isNewQuote = true;
            }
          }
          else {           
            this.toastr.error('Problem occured while saving new quote!');
          }
      },      
      error => {
        this.renderer.setProperty(this.dashboardLoader.nativeElement, 'innerHTML', '');
        this.toastr.error('System Error in dashboard. Please Contact Admisnistrator!');
        setTimeout(() => {
          this.helper.navigateTo(RoutingKey[PageState.LOGIN]);         
        }, 5000);       
      });
    } 

  removeItem(item: any) {

    var self = this;
    self.isSearchDataAvailable = true;
    this.data = _.filter(this.data, (elem) => elem != item);
    this.master = this.data;
    this.qouteAPI.deleteQuote(item.quoteNumber).subscribe(
      resdata => {
        if (resdata != null) {
          if (this.data.length == 0) {
            self.isSearchDataAvailable = false;
            self.isDataAvailable = false;
            self.isNewQuote = true;
          }    
        }        
      },
      error => {       
        this.toastr.error('System Error while removing quote.Please Contact Admisnistrator!');
      });   
  }

  duplicateQuote(item: any) {
    var self = this;
    this.qouteAPI.duplicateQuote(item.quoteNumber).subscribe(
      resdata => {
        if (resdata != null) {

          var deplicateEntry = {
            quoteNumber: resdata.responseData.quoteRequestData.quoteNumber,
            quoteRequestDate: resdata.responseData.quoteRequestData.quoteRequestDate,
            quoteStatusCode: resdata.responseData.quoteRequestData.quoteStatusCode,
            quoteStatusDescriptionText: resdata.responseData.quoteRequestData.quoteStatusDescriptionText,
            docId: resdata.responseData.quoteRequestData.docId,
            id: resdata.responseData.quoteRequestData.id,
            partitionKey: resdata.responseData.quoteRequestData.partitionkey
          }
          this.data.push(deplicateEntry);
        }       

      },      
      error => {
        this.toastr.error('System Error while duplicating quote.Please Contact Admisnistrator!');
      });  
    
  }  

  newQuoteCall() {
    this.clearModel();
    this.helper.navigateTo(RoutingKey[PageState.SUBMIT_SERVICE_TYPE]); 
  }

  sortByWordLength = (a: any) => {
    return a.name.length;
  }

  filterQuote(status: string) {

    if (status == "") {

    this.data = this.master;
    }

    else {
     this.data = this.performFilter(status);
      if (this.data.length == 0) {
        this.isDataAvailable = true;
        this.isSearchDataAvailable = false;
      }
      else {
        this.isSearchDataAvailable = true;
        this.isDataAvailable = true;
      }
    }
  }

  performFilter(filterBy: string): IQuoteListDetails[] {
    // this.master.forEach(x => x.quoteStatusDescriptionText = x.quoteStatusDescriptionText == null ? "NotSubmitted" : x.quoteStatusDescriptionText);
    return this.master.filter((quote: IQuoteListDetails) => quote.quoteStatusDescriptionText.trim().indexOf(filterBy.trim()) !== -1);
  }

  navigateTo(quoteId: string) {

   // this.getCurrencyDetail(quoteId);  will use this in drop 2 as part of performance improvement for commodity page
    this.getQuoteDetailsbyQuoteId(quoteId);
  }

  getQuoteDetailsbyQuoteId(quoteId: string) {

    var quoteNumber =
      {
        "quoteNumber": quoteId
      }

    this.quoteService.GetQuoteDetailsbyQuoteId(quoteNumber).subscribe(
      resdata => {
        if (resdata != null ) {
          var qouteData = resdata as IQuoteData;
          this.quoteService.resetQuoteModel();
          this.quoteService.setQuoteDetails(qouteData);
          if (this.quoteService.getQuoteDetails().quoteRequestData != null) {
            this.lastVisitedPage = this.quoteService.getQuoteDetails().quoteRequestData.lastVisitedPage;
            if (this.lastVisitedPage != undefined)
              this.helper.navigateTo(RoutingKey[this.lastVisitedPage]);
            else
              this.helper.navigateTo(RoutingKey[PageState.SUBMIT_SERVICE_TYPE]);
          }
        }
        else {
          this.toastr.error('Error while fetching quote detail.Please Contact Admisnistrator!');
        }
      },
      error => {
        this.toastr.error('System Error.Please Contact Admisnistrator!');
      });  
  }
  clearModel() {
    this.quoteService.resetQuoteModel();
  }

  getFormattedDate(dt) {
    if (dt) {
      dt = new Date(dt);
      return monthNames[dt.getMonth()] + ' ' + dt.getDate() + ', ' + dt.getFullYear();
    }
    return '';
  }
}

