import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { UserSettingsComponent } from './usersettings/usersettings.component';
import { QuoteExternalPortalModule } from '@app/external-portal/quote/quote.module';
import { ChangepasswordComponent } from './changepassword/changepassword.component';

const routes: Routes = [
  { path: '', redirectTo: 'login', pathMatch: 'full' },
  { path: 'login', component: LoginComponent },
  { path: 'dashboard', component: DashboardComponent },
  { path: 'usersettings', component: UserSettingsComponent },
  { path: 'changepassword', component: ChangepasswordComponent },
  { path: 'quote', loadChildren: () => QuoteExternalPortalModule }

];
export const routing: ModuleWithProviders = RouterModule.forChild(routes);
