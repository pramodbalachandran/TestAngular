import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ShipmentMovementComponent } from './shipmentmovement.component';

describe('ShipmentMovementComponent', () => {
  let component: ShipmentMovementComponent;
  let fixture: ComponentFixture<ShipmentMovementComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ShipmentMovementComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ShipmentMovementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeDefined();
  });
});
