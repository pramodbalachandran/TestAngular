import { Component, OnInit, ViewChild, ElementRef, Renderer2, ViewEncapsulation } from '@angular/core';
import { DataTableModule } from 'angular-6-datatable';
import { Router, ActivatedRoute } from '@angular/router';
import { retry } from 'rxjs/operators';
import { Stream } from 'stream';
import { transformAll } from '@angular/compiler/src/render3/r3_ast';
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';
import * as _ from 'lodash';
import { Ng4LoadingSpinnerModule, Ng4LoadingSpinnerService  } from 'ng4-loading-spinner';
import { IQuoteData, IQuoteListDetails } from '@app/models/quotes/quote-data'
import { airportDetails, airportDetailsDes } from '@app/models/autopopulate/autopopulate-data'
import { IQuoteDetails } from '@app/models/quotes/quotes-details'
import { IAirFreightShipmentDetail } from '@app/models/quotes/airfreightshipment-detail'
import { QuoteDetail, AboutShipment, A2ADetail, D2ADetail, A2DDetail, D2DDetail, ShippingAddress, getShippingAddress } from '@app/shared/interfaces/entities.interface';
import { ModalComponent } from '@app/shared/helper/modalpopup.component';
import { QuoteAPI, CustomerAPI, LocalStorageService, GeaographyAPI } from '@app/shared/services';
import { ShipmentMovementType, shipmentFrequencyType, PageState } from '@app/shared/services/shared/enum';
import { RoutingKey } from '@app/shared/services/shared/config.const';
import { UtilitiesService } from '@app/shared/services/shared/utilities.service';
import { ICustomer, IShippingAddress } from '@app/models';
import { FormControl } from '@angular/forms';
import { map, startWith } from 'rxjs/operators';
import { Observable } from 'rxjs'
import { OrderPipe } from 'ngx-order-pipe';
import { DomSanitizer } from '@angular/platform-browser';


@Component({
  selector: 'pricing-shipmentmovement',
  templateUrl: './shipmentmovement.component.html',
  styleUrls: ['./shipmentmovement.component.scss'],
  providers: [DataTableModule],
  encapsulation: ViewEncapsulation.None
})

export class ShipmentMovementComponent implements OnInit {
  postalCodes:any;
  private loadingComplete = false;
  private isstillLoading = true ;
  isoriginACErroroccured=false;
  isdestinationACErroroccured=false;
  order: string = 'politicalDivision1Name';
  orderCountry: string = 'countryName';
  keyshipmentAddress = 'Shipmentaddressselectedfromddl';
  keyshipmentAddressd2d = 'Shipmentaddressselectedfromddld2d';
  isHighlighterror:boolean=false;
  isHighlighterrorAddressvalidationorg:boolean=false;
  isHighlighterrorAddressvalidationdes:boolean=false;
  invalidPostalCodeMask: boolean = false;
  postalCodeMask: any;
  defaultPostalCodeMask: any = [];
  invalidPostalCodeMaskD2D: boolean = false;
  postalCodeMaskD2D: any;
  defaultPostalCodeMaskD2D: any = [];
  cssUrl: string='assets/css/autocomplete-normal-style.css';
  IsAddressValidationSuccess: boolean = true;
  IsNextButtondisablereq: boolean = true;
  stateCtrl = new FormControl();
  stateCtrlDes = new FormControl();
  filteredStates: Observable<airportDetails[]>;
  filteredStatesDes: Observable<airportDetailsDes[]>;
  airportDetails: airportDetails[] = [];
  states: airportDetails[];
  intemediatefilteredStates: airportDetails[];
  finalfilteredStates: airportDetails[];
  statesDes: airportDetailsDes[];
  AddressValidationSuccessType: number = 0;/*1-Orgin Address,2-Destination Address,3-both,4-international */
  validateCityName: string;
  validatePostalCode: string;
  validateStatePovinceCode: string;
  validateCountry: string;
  d2dvalidateCityName: string;
  d2dvalidatePostalCode: string;
  d2dvalidateStatePovinceCode: string;
  d2dvalidateCountry: string;
  selectedtab: number = 0;
  IsAddressValidationrequired: boolean = true;
  countryOptions: any = [];
  stateOptions: any = [];
  d2dStateDetails: any = [];
  cityOptions: any = [];
  shippingAddressOptions: any = [];
  loggedinUserDetails: ICustomer;
  isSaveforlaterenableD2Dorg: boolean = true;
  ischeckboxdisabledforSaveaddress: boolean = false;
  ischeckboxdisabledforSaveaddressD2D: boolean = false;
  @ViewChild('modalLogin') modallogin: ModalComponent;
  @ViewChild('uldD2ACity') D2ADestCity: ElementRef;

  shipmentMovementData: any;
  quoteDetail: IQuoteData;
  isCountryselectedD2A: boolean = false;
  isCountrySelectedA2D: boolean = false;
  isCountrySelectedD2DOrigin: boolean = false;
  isCountrySelectedD2DDestination: boolean = false;
  isStateavailabeforthecountryD2A: boolean = false;
  isOriginStateD2D: boolean = false;
  isDestinationD2D: boolean = false;
  public body: HTMLBodyElement = document.getElementsByTagName('body')[0];

  //page-A2A
  originCity: string[];
  destCity: string[];
  originCityText: string = "";
  destCityText: string = "";
  originCityTextBkp: string = "";
  destCityTextBkp: string = "";
  selectedShipmentMovement: string;
  isWarningMessageVisible: boolean = false;
  showFirstDiv: boolean = false;

  //page-D2A

  modelD2A: any = {
    destCityD2AText: "",
    destCityD2ATextBkp: "",
    Address1D2A: "",
    Address2D2A: "",
    Address3D2A: "",
    stateIdD2A: "0",
    cityD2A: "",
    countryIdD2A: "0",
    PostalCodeD2A: "",
    chkSaveProfileAddressD2A: false
  }
  showAddressLine1D2A = false;
  showAddressLine2D2A = false;
  showAddressLineD2A = true;
  shipppingAddressD2A: string = "0";
  hdnUserId: string;
  getInputPar: getShippingAddress = new getShippingAddress();

  //page-A2D

  modelA2D: any = {
    originCityA2DText: "",
    originCityA2DTextBkp: "",
    Address1A2D: "",
    Address2A2D: "",
    Address3A2D: "",
    stateIdA2D: "0",
    cityA2D: "",
    countryIdA2D: "0",
    PostalCodeA2D: "",
    chkSaveProfileAddressA2D: false
  }
  showAddressLine1A2D = false;
  showAddressLine2A2D = false;
  showAddressLineA2D = true;

  //page-D2D

  modelD2D1: any = {
    Address1D2D1: "",
    Address2D2D1: "",
    Address3D2D1: "",
    countryIdD2D1: "0",
    cityD2D1: "",
    StateIdD2D1: "0",
    PostalCodeD2D1: "",
    chkSaveProfileAddressD2D1: false
  }

  modelD2D2: any = {
    Address1D2D2: "",
    Address2D2D2: "",
    Address3D2D2: "",
    countryIdD2D2: "0",
    cityD2D2: "",
    StateIdD2D2: "0",
    PostalCodeD2D2: "",
    chkSaveProfileAddressD2D2: false
  }
  showAddressLine1D2D2 = false;
  showAddressLine2D2D2 = false;
  showAddressLine1D2D1 = false;
  showAddressLine2D2D1 = false;


  //others
  originOptions = ["ust global,technopark2,trivandrum", "ust global,Electronic City,Bangalore", "ust global,madhapur,Hyderabad"];
  countries = ["USA", "UK", "INDIA", "UAE", "POLAND"];
  //states = ["1", "2", "3", "4", "5"];


  airporttoairport: boolean = false;
  doortoairport: boolean = false;
  airporttodoor: boolean = false
  doortodoor: boolean = false;
  showLogin = false;
  showWarningMessage: boolean = false;
  isLoading = false;
  private _filterStates(value: string): airportDetails[] {
    const filterValue = value.toLowerCase();
    this.intemediatefilteredStates=this.states;
    this.finalfilteredStates=this.intemediatefilteredStates.filter(state => state.isCustomerData === "0" && state.autopopulateformat.split(',')[0].toLowerCase().indexOf(filterValue) ==0).slice(0,6);
    this.intemediatefilteredStates= this.intemediatefilteredStates.filter(f => !this.finalfilteredStates.includes(f));
    if(this.finalfilteredStates.length<6)
    {
      this.finalfilteredStates=this.finalfilteredStates.concat(this.intemediatefilteredStates.filter(state => state.isCustomerData === "0" && state.autopopulateformat.split(',')[0].split(" ")[1].toLowerCase().indexOf(filterValue) ==0));
      this.intemediatefilteredStates= this.intemediatefilteredStates.filter(f => !this.finalfilteredStates.includes(f));
      if(this.finalfilteredStates.length<6)
      {
        this.finalfilteredStates=this.finalfilteredStates.concat(this.intemediatefilteredStates.filter(state => state.isCustomerData === "0" && state.autopopulateformat.toLowerCase().indexOf(filterValue) > -1));
      }
    }
    return this.finalfilteredStates;
  }
  private _filterStatesDes(value: string): airportDetailsDes[] {
    const filterValue = value.toLowerCase();
    this.intemediatefilteredStates=this.states;
    this.finalfilteredStates=this.intemediatefilteredStates.filter(state => state.isCustomerData === "0" && state.autopopulateformat.split(',')[0].toLowerCase().indexOf(filterValue) ==0).slice(0,6);
    this.intemediatefilteredStates= this.intemediatefilteredStates.filter(f => !this.finalfilteredStates.includes(f));
    if(this.finalfilteredStates.length<6)
    {
      this.finalfilteredStates=this.finalfilteredStates.concat(this.intemediatefilteredStates.filter(state => state.isCustomerData === "0" && state.autopopulateformat.split(',')[0].split(" ")[1].toLowerCase().indexOf(filterValue) ==0));
      this.intemediatefilteredStates= this.intemediatefilteredStates.filter(f => !this.finalfilteredStates.includes(f));
      if(this.finalfilteredStates.length<6)
      {
        this.finalfilteredStates=this.finalfilteredStates.concat(this.intemediatefilteredStates.filter(state => state.isCustomerData === "0" && state.autopopulateformat.toLowerCase().indexOf(filterValue) > -1));
      }
    }
    return this.finalfilteredStates;

  }
  constructor(private renderer: Renderer2, private helper: UtilitiesService, private route: ActivatedRoute, private quoteService: QuoteAPI<IQuoteData>, private localStorageService: LocalStorageService,
    private customerService: CustomerAPI<ShippingAddress>, private geoGraphyService: GeaographyAPI<any>,
    private orderPipe: OrderPipe,public sanitizer: DomSanitizer,private ng4LoadingSpinnerService: Ng4LoadingSpinnerService) {
    this.loggedinUserDetails = this.customerService.getEmptyUserModel();
  }


  ngOnInit() {
    this.body.classList.remove('login-logo');
    //To get the existing shipment address
    this.setPostalCodes();
    this.GetExistingShipmentAddress();
    this.bindControls();
    //this.populateControls();
    this.showTab();
    this.getCountries();
    if (localStorage.getItem('currentUserName1') == null) {
      this.getAirportdetails(null);
    }
    else {
      this.getAirportdetails(localStorage.getItem('currentUserName1'));
    }
    if (localStorage.length > 0) {
      if(localStorage.getItem(this.keyshipmentAddress)!=null&&localStorage.getItem(this.keyshipmentAddress)=="true")
      {
        this.ischeckboxdisabledforSaveaddress=true;
      }
      if(localStorage.getItem(this.keyshipmentAddressd2d)!=null&&localStorage.getItem(this.keyshipmentAddressd2d)=="true")
      {
        this.ischeckboxdisabledforSaveaddress=true;
      }
    } 
    //this.getAirportdetailsDes(null);
  }
  setPostalCodes() {
    this.postalCodes = this.geoGraphyService.getPostalCodeArray();
  }
  
  setPostalCodeMask(countryCode) {
    this.invalidPostalCodeMask = false;

    if (!countryCode) {
      this.postalCodeMask = this.defaultPostalCodeMask;
      this.invalidPostalCodeMask = true;
      return;
    }

    var mask=[];
    var data = this.postalCodes.filter((x) => x.countryCode == countryCode);
    mask = data.length > 0 ? data[0].mask : this.defaultPostalCodeMask;
   
    this.postalCodeMask = mask;
    if (mask.length <= 0) {
      this.invalidPostalCodeMask = true;
    }
  }
  setPostalCodeMaskD2D(countryCode) {
    this.invalidPostalCodeMaskD2D = false;

    if (!countryCode) {
      this.postalCodeMaskD2D = this.defaultPostalCodeMaskD2D;
      this.invalidPostalCodeMaskD2D = true;
      return;
    }

    var mask=[];
    var data = this.postalCodes.filter((x) => x.countryCode == countryCode);
    mask = data.length > 0 ? data[0].mask : this.defaultPostalCodeMaskD2D;
   
    this.postalCodeMaskD2D = mask;
    if (mask.length <= 0) {
      this.invalidPostalCodeMaskD2D = true;
    }
  }
  public onSPChange(event, ddlName: number = 0): void {  // event will give you full breif of action
    const index = event.target.value;
    if(index=="-1")
    {
      this.ischeckboxdisabledforSaveaddress = false;
      switch (parseInt(localStorage.getItem('selectedShipmentMovement'))) {
        case ShipmentMovementType.D2A:
          this.modelD2A.Address1D2A = "";
          this.modelD2A.Address2D2A = "";
          this.modelD2A.Address3D2A = "";
          this.modelD2A.cityD2A = "";
          this.modelD2A.PostalCodeD2A = "";
          this.modelD2A.stateIdD2A = "";
          this.modelD2A.countryIdD2A = "";
          this.modelD2A.chkSaveProfileAddressD2A = false;
          this.showAddressLine1D2A=false;
          this.showAddressLine2D2A=false;
          this.isCountryselectedD2A=false;
          break;

        case ShipmentMovementType.A2D:
          this.modelA2D.Address1A2D = "";
          this.modelA2D.Address2A2D = "";
          this.modelA2D.Address3A2D = "";
          this.modelA2D.cityA2D = "";
          this.modelA2D.PostalCodeA2D = "";
          this.modelA2D.stateIdA2D = "";
          this.modelA2D.countryIdA2D = "";
          this.modelA2D.chkSaveProfileAddressA2D = false;
          this.showAddressLine1A2D=false;
          this.showAddressLine2A2D=false;
          this.isCountrySelectedA2D=false;
          break;

        case ShipmentMovementType.D2D:
          this.modelD2D1.Address1D2D1 = "";
          this.modelD2D1.Address2D2D1 = "";
          this.modelD2D1.Address3D2D1 = "";
          this.modelD2D1.cityD2D1 = "";
          this.modelD2D1.PostalCodeD2D1 = "";
          this.modelD2D1.StateIdD2D1 = "";
          this.modelD2D1.countryIdD2D1 = "";
          this.modelD2D1.chkSaveProfileAddressD2D1 = false;
          this.showAddressLine2D2D1=false;
          this.showAddressLine1D2D1=false;
          this.isCountrySelectedD2DOrigin = false;
          this.isOriginStateD2D = false;
          break;
      }
    }
    else{
    this.ischeckboxdisabledforSaveaddress = true;
    localStorage.setItem(this.keyshipmentAddress, "true");
    var selectedshipmentaddress = this.loggedinUserDetails.shippingAddress[index];
    switch (parseInt(localStorage.getItem('selectedShipmentMovement'))) {
      case ShipmentMovementType.D2A:
        this.modelD2A.Address1D2A = selectedshipmentaddress.addressLine1;
        this.modelD2A.Address2D2A = selectedshipmentaddress.addressLine2;
        this.modelD2A.Address3D2A = selectedshipmentaddress.addressLine3;
        this.modelD2A.cityD2A = selectedshipmentaddress.politicalDivision2Name;
        this.modelD2A.PostalCodeD2A = selectedshipmentaddress.postalCode;
        this.modelD2A.stateIdD2A = selectedshipmentaddress.politicalDivision1Code;
        this.modelD2A.countryIdD2A = selectedshipmentaddress.countryCode;
        this.modelD2A.chkSaveProfileAddressD2A = false;
        if(this.modelD2A.Address2D2A !="" && this.modelD2A.Address2D2A !=null)
            this.showAddressLine1D2A=true;
        if(this.modelD2A.Address3D2A !="" && this.modelD2A.Address3D2A !=null)
            this.showAddressLine2D2A=true;
        break;
      case ShipmentMovementType.A2D:
        this.modelA2D.Address1A2D = selectedshipmentaddress.addressLine1;
        this.modelA2D.Address2A2D = selectedshipmentaddress.addressLine2;
        this.modelA2D.Address3A2D = selectedshipmentaddress.addressLine3;
        this.modelA2D.cityA2D = selectedshipmentaddress.politicalDivision2Name;
        this.modelA2D.PostalCodeA2D = selectedshipmentaddress.postalCode;
        this.modelA2D.stateIdA2D = selectedshipmentaddress.politicalDivision1Code;
        this.modelA2D.countryIdA2D = selectedshipmentaddress.countryCode;
        this.modelA2D.chkSaveProfileAddressA2D = false;
        if(this.modelA2D.Address2A2D !="" && this.modelA2D.Address2A2D !=null)
            this.showAddressLine1A2D=true;
        if(this.modelA2D.Address3A2D !="" && this.modelA2D.Address3A2D !=null)
            this.showAddressLine2A2D=true;
        break;
      case ShipmentMovementType.D2D:
        this.modelD2D1.Address1D2D1 = selectedshipmentaddress.addressLine1;
        this.modelD2D1.Address2D2D1 = selectedshipmentaddress.addressLine2;
        this.modelD2D1.Address3D2D1 = selectedshipmentaddress.addressLine3;
        this.modelD2D1.cityD2D1 = selectedshipmentaddress.politicalDivision2Name;
        this.modelD2D1.PostalCodeD2D1 = selectedshipmentaddress.postalCode;
        this.modelD2D1.StateIdD2D1 = selectedshipmentaddress.politicalDivision1Code;
        this.modelD2D1.countryIdD2D1 = selectedshipmentaddress.countryCode;
        this.modelD2D1.chkSaveProfileAddressD2D1 = false;
        if(this.modelD2D1.Address2D2D1 !="" && this.modelD2D1.Address2D2D1 !=null)
            this.showAddressLine1D2D1=true;
        if(this.modelD2D1.Address3D2D1 !="" && this.modelD2D1.Address3D2D1 !=null)
            this.showAddressLine2D2D1=true;
        if (selectedshipmentaddress.countryCode.length > 0) {
          this.isCountrySelectedD2DOrigin = true;
          this.isOriginStateD2D = true;
        }
        break;
      }

    }


    this.GetStates(selectedshipmentaddress.countryCode, ddlName);
    // this.modelD2A.destCityD2AText = this.shipmentMovementData.destinationAirport;
    // this.modelD2A.destCityD2ATextBkp = this.shipmentMovementData.destinationAirport;
  }

  public onSPChangeD2DDes(event, ddlName: number = 0): void {  // event will give you full breif of action
    
    localStorage.setItem(this.keyshipmentAddressd2d, "false"); 
    const index = event.target.value;
    if(index=="-1")
    {
      this.ischeckboxdisabledforSaveaddressD2D = false;
      this.modelD2D2.Address1D2D2 = "";
      this.modelD2D2.Address2D2D2 = "";
      this.modelD2D2.Address3D2D2 = "";
      this.modelD2D2.cityD2D2 = "";
      this.modelD2D2.PostalCodeD2D2 = "";
      this.modelD2D2.StateIdD2D2 = "";
      this.modelD2D2.countryIdD2D2 = "";
      this.modelD2D2.chkSaveProfileAddressD2D2 = false;
      this.showAddressLine1D2D2=false;
      this.showAddressLine2D2D2=false;
      this.isCountrySelectedD2DDestination = false;
      this.isDestinationD2D = false;
    }
    else
    {
        this.ischeckboxdisabledforSaveaddressD2D = true;
        var selectedshipmentaddress = this.loggedinUserDetails.shippingAddress[index];
        this.modelD2D2.Address1D2D2 = selectedshipmentaddress.addressLine1;
        this.modelD2D2.Address2D2D2 = selectedshipmentaddress.addressLine2;
        this.modelD2D2.Address3D2D2 = selectedshipmentaddress.addressLine3;
        this.modelD2D2.cityD2D2 = selectedshipmentaddress.politicalDivision2Name;
        this.modelD2D2.PostalCodeD2D2 = selectedshipmentaddress.postalCode;
        this.modelD2D2.StateIdD2D2 = selectedshipmentaddress.politicalDivision1Code;
        this.modelD2D2.countryIdD2D2 = selectedshipmentaddress.countryCode;
        this.modelD2D2.chkSaveProfileAddressD2D2 = false;
        if(this.modelD2D2.Address2D2D2 !="" && this.modelD2D2.Address2D2D2 !=null  )
            this.showAddressLine1D2D2=true;
        if(this.modelD2D2.Address3D2D2!="" && this.modelD2D2.Address3D2D2 !=null)
            this.showAddressLine2D2D2=true;
        this.GetStates(selectedshipmentaddress.countryCode, ddlName);
        // this.modelD2A.destCityD2AText = this.shipmentMovementData.destinationAirport;
        // this.modelD2A.destCityD2ATextBkp = this.shipmentMovementData.destinationAirport;
        if (selectedshipmentaddress.countryCode.length > 0) {
          this.isCountrySelectedD2DDestination = true;
          this.isDestinationD2D = true;
        }
     }
  }


  onvalueEdit(changedValue: string) {
    this.ischeckboxdisabledforSaveaddress = false;
    localStorage.setItem(this.keyshipmentAddress, "false");
  }
  valuechangeD2DDes(newValue) {
    localStorage.setItem(this.keyshipmentAddressd2d, "false"); 
    this.ischeckboxdisabledforSaveaddressD2D = false;
  }
  //To get the existing customer data to display the already saved shipping address
  GetExistingShipmentAddress() {
    if (localStorage.getItem('currentUserName1') != null) {
      this.customerService.getUserByUserId(localStorage.getItem('currentUserName1'))
        .subscribe(
        customerData => {
          if (customerData) {
            this.loggedinUserDetails = customerData as ICustomer;
          }
        });
    }
    this.customerService.setCustomerProfileDetails(this.loggedinUserDetails);


  }

  getCountries() {
    this.ng4LoadingSpinnerService.show();
    this.stateOptions = [];
    this.d2dStateDetails = [];
    this.geoGraphyService.getCountries()
      .subscribe(
      data => {
        if (data != null && data['results'] != null) {
          this.countryOptions = data['results'];
         // this.countryOptions= this.orderPipe.transform(this.countryOptions, 'countryName');
         this.isstillLoading = false;
         this.loadingComplete = true;
         this.ng4LoadingSpinnerService.hide();
        }
      },
      error => {

      });
  }
    getAirportdetails(businessPartyNumber: string, isTabswitch: boolean = false) {

    this.geoGraphyService.getAirportdetails(businessPartyNumber)
      .subscribe(
      data => {
        if (data != null && data['Airportdetails'] != null) {
          this.states = data["Airportdetails"];
          this.filteredStates = this.stateCtrl.valueChanges
            .pipe(
            startWith(''),
            map(state => state ? this._filterStates(state).slice(0, 6) : this.states.filter(x => x.isCustomerData == "1").slice(0, 6))
            );
          this.statesDes = data["Airportdetails"];

          this.filteredStatesDes = this.stateCtrlDes.valueChanges
            .pipe(
            startWith(''),
            map(state => state ? this._filterStatesDes(state).slice(0, 6) : this.statesDes.filter(x => x.isCustomerData == "1").slice(0, 6))
            );
          if (!isTabswitch) {
            this.populateControls();
          }

        }
      },
      error => {

      });
  }

  //To get state based on country code
  GetStates(countryId: string, ddlName: number = 0,countrytab:number=0) {

    if(countrytab!=4)
      this.setPostalCodeMask(countryId);
    else
      this.setPostalCodeMaskD2D(countryId);
    if (ddlName != 2)
      this.stateOptions = [];
    // this.d2dStateDetails=[];
    this.isCountryselectedD2A = true;
    this.isCountrySelectedA2D = true;
    if (ddlName == 1) {
      this.isCountrySelectedD2DOrigin = true;
      this.isOriginStateD2D = true;
      this.isDestinationD2D = false;
    }
    if (ddlName == 2) {
      this.isOriginStateD2D = false;
      this.isDestinationD2D = true;
      this.isCountrySelectedD2DDestination = true;
    }
    if(countrytab==1)
    {
      this.modelD2A.PostalCodeD2A="";
    }
    else if(countrytab==2)
    {
      this.modelA2D.PostalCodeA2D="";
    }
    else if(countrytab==3)
    {
      this.modelD2D1.PostalCodeD2D1="";
    }
    else if(countrytab==4)
    {
      this.modelD2D2.PostalCodeD2D2="";
    }
    
    this.geoGraphyService.getStates(countryId)
      .subscribe(
      data => {
        if (data && data['results'] != null && data['results'] != "") {
          
       
          
          if (ddlName == 2)
          {
            this.d2dStateDetails = data['results'];
            this.d2dStateDetails= this.orderPipe.transform(this.d2dStateDetails, 'politicalDivision1Name');
          }

          else
          {
            this.stateOptions = data['results'];
            this.stateOptions= this.orderPipe.transform(this.stateOptions, 'politicalDivision1Name');
          }
            
          this.isStateavailabeforthecountryD2A = true;
        }
        else {
          this.isStateavailabeforthecountryD2A = false;
        }
      },
      error => {
      });
  }

  getCity(countryId: string, stateId: string) {

    this.cityOptions = this.countryOptions.filter(country => country['countryCode'] == countryId.trim().toUpperCase() && country['politicalDivision1Code'] == stateId.trim().toUpperCase());

  }

  showTab() {
    if (this.quoteService.getQuoteDetails().airFreightShipmentDetail != null && this.quoteService.getQuoteDetails().airFreightShipmentDetail[0].movementTypeCode > 0)
      this.selectShipmentMovement(this.quoteService.getQuoteDetails().airFreightShipmentDetail[0].movementTypeCode.toString());
    else
      this.selectShipmentMovement(ShipmentMovementType.A2A.toString());
  }

  populateControls() {

    //A2A

    // this.modelA2AShipmentMovement = this.quoteService.getQuoteDetails().ShipingA2ADetail;
    this.shipmentMovementData = this.quoteService.getQuoteDetails().airFreightShipmentDetail[0];
    //load source airport

    if (this.shipmentMovementData != null) {

      switch (this.quoteService.getQuoteDetails().airFreightShipmentDetail[0].movementTypeCode) {



        case ShipmentMovementType.A2A:


          this.originCityText = this.shipmentMovementData.originAirport;
          this.originCityTextBkp = this.shipmentMovementData.originAirport;
          if (this.states && this.states.length > 0) {
            var selectedData = this.states.filter(x => x.airportCode == this.shipmentMovementData.originAirport &&
              x.politicalDivision2Name == this.shipmentMovementData.originLocationPoliticalDivsion2Code);
            if (selectedData && selectedData.length > 0) {
              this.originCityText = selectedData[0].autopopulateformat;
              this.originCityTextBkp = selectedData[0].autopopulateformat;
            }
          }

          //load destination airport

          this.destCityText = this.shipmentMovementData.destinationAirport;
          this.destCityTextBkp = this.shipmentMovementData.destinationAirport;
          if (this.states && this.states.length > 0) {
            var selectedDataDes = this.states.filter(x => x.airportCode == this.shipmentMovementData.destinationAirport &&
              x.politicalDivision2Name == this.shipmentMovementData.destinationLocationPoliticalDivsion2Code);
            if (selectedDataDes && selectedDataDes.length > 0) {
              this.destCityText = selectedDataDes[0].autopopulateformat;
              this.destCityTextBkp = selectedDataDes[0].autopopulateformat;
            }
          }
          this.IsNextButtonDisabled();
          break;

        //D2A

        case ShipmentMovementType.D2A:
          this.GetStates(this.shipmentMovementData.originLocationCountryCode);
          this.modelD2A.Address1D2A = this.shipmentMovementData.originAddressLine1Text;
          this.modelD2A.Address2D2A = this.shipmentMovementData.originAddressLine2Text;
          this.modelD2A.Address3D2A = this.shipmentMovementData.originAddressLine3Text;
          this.modelD2A.cityD2A = this.shipmentMovementData.originLocationPoliticalDivsion2Code;
          this.modelD2A.PostalCodeD2A = this.shipmentMovementData.originLocationPostalCode;
          this.modelD2A.stateIdD2A = this.shipmentMovementData.originPoliticalDivision1Name;
          this.modelD2A.countryIdD2A = this.shipmentMovementData.originLocationCountryCode;
          this.modelD2A.chkSaveProfileAddressD2A = this.shipmentMovementData.shipmentOriginAddressProfileSaveIndicator;
          this.modelD2A.destCityD2AText = this.shipmentMovementData.destinationAirport;
          this.modelD2A.destCityD2ATextBkp = this.shipmentMovementData.destinationAirport;
          if(this.modelD2A.Address2D2A!="" && this.modelD2A.Address2D2A != null)
              this.showAddressLine1D2A=true;
          if(this.modelD2A.Address3D2A!="" && this.modelD2A.Address3D2A != null)
              this.showAddressLine2D2A=true;
          // this.isStateavailabeforthecountryD2A=false;
          if (this.modelD2A.countryIdD2A != "") {
            this.GetStates(this.modelD2A.countryIdD2A);
            if (this.states && this.states.length > 0) {
              var selectedDataDes = this.states.filter(x => x.airportCode == this.shipmentMovementData.destinationAirport &&
                x.politicalDivision2Name == this.shipmentMovementData.destinationLocationPoliticalDivsion2Code);
              if (selectedDataDes && selectedDataDes.length > 0) {
                this.modelD2A.destCityD2AText = selectedDataDes[0].autopopulateformat;
                this.modelD2A.destCityD2ATextBkp = selectedDataDes[0].autopopulateformat;
              }
            }
          }
          this.IsAddressValidationSuccess = true;
          this.IsNextButtonDisabled();
          break;


        //A2D

        case ShipmentMovementType.A2D:
          this.modelA2D.originCityA2DText = this.shipmentMovementData.originAirport;
          this.modelA2D.originCityA2DTextBkp = this.shipmentMovementData.originAirport;
          this.modelA2D.Address1A2D = this.shipmentMovementData.destinationAddressLine1Text;
          this.modelA2D.Address2A2D = this.shipmentMovementData.destinationAddressLine2Text;
          this.modelA2D.Address3A2D = this.shipmentMovementData.destinationAddressLine3Text;
          this.modelA2D.cityA2D = this.shipmentMovementData.destinationLocationPoliticalDivsion2Code;
          this.modelA2D.PostalCodeA2D = this.shipmentMovementData.destinationLocationPostalCode;
          this.modelA2D.stateIdA2D = this.shipmentMovementData.destinationPoliticalDivision1Name;
          this.modelA2D.countryIdA2D = this.shipmentMovementData.destinationLocationCountryCode;
          this.modelA2D.chkSaveProfileAddressA2D = this.shipmentMovementData.shipmentDestinationAddressProfileSaveIndicator;
          if(this.modelA2D.Address2A2D !="" && this.modelA2D.Address2A2D !=null)
              this.showAddressLine1A2D=true;
          if(this.modelA2D.Address3A2D !="" && this.modelA2D.Address3A2D !=null)
              this.showAddressLine2A2D=true;

          if (this.modelA2D.countryIdA2D != "") {
            this.GetStates(this.modelA2D.countryIdA2D);
            if (this.states && this.states.length > 0) {
              var selectedDataDes = this.states.filter(x => x.airportCode == this.shipmentMovementData.originAirport &&
                x.politicalDivision2Name == this.shipmentMovementData.originLocationPoliticalDivsion2Code);
              if (selectedDataDes && selectedDataDes.length > 0) {
                this.modelA2D.originCityA2DText = selectedDataDes[0].autopopulateformat;
                this.modelA2D.originCityA2DTextBkp = selectedDataDes[0].autopopulateformat;
              }
            }
          }
          this.IsNextButtonDisabled();
          break;

        //D2D

        case ShipmentMovementType.D2D:
          //Soure Address
          this.modelD2D1.Address1D2D1 = this.shipmentMovementData.originAddressLine1Text;
          this.modelD2D1.Address2D2D1 = this.shipmentMovementData.originAddressLine2Text;
          this.modelD2D1.Address3D2D1 = this.shipmentMovementData.originAddressLine3Text;
          this.modelD2D1.cityD2D1 = this.shipmentMovementData.originLocationPoliticalDivsion2Code;
          this.modelD2D1.PostalCodeD2D1 = this.shipmentMovementData.originLocationPostalCode;
          this.modelD2D1.StateIdD2D1 = this.shipmentMovementData.originPoliticalDivision1Name;
          this.modelD2D1.countryIdD2D1 = this.shipmentMovementData.originLocationCountryCode;
          this.modelD2D1.chkSaveProfileAddressD2D1 = this.shipmentMovementData.shipmentOriginAddressProfileSaveIndicator;
          if(this.modelD2D1.Address2D2D1 !="" && this.modelD2D1.Address2D2D1 !=null)
            this.showAddressLine1D2D1=true;
          if(this.modelD2D1.Address3D2D1 !="" && this.modelD2D1.Address3D2D1 !=null)
            this.showAddressLine2D2D1=true;

          if (this.modelD2D1.countryIdD2D1 != "")
            this.GetStates(this.modelD2D1.countryIdD2D1, 1);
          //Destination Addresss
          this.modelD2D2.Address1D2D2 = this.shipmentMovementData.destinationAddressLine1Text;
          this.modelD2D2.Address2D2D2 = this.shipmentMovementData.destinationAddressLine2Text;
          this.modelD2D2.Address3D2D2 = this.shipmentMovementData.destinationAddressLine3Text;
          this.modelD2D2.cityD2D2 = this.shipmentMovementData.destinationLocationPoliticalDivsion2Code;
          this.modelD2D2.PostalCodeD2D2 = this.shipmentMovementData.destinationLocationPostalCode;
          this.modelD2D2.StateIdD2D2 = this.shipmentMovementData.destinationPoliticalDivision1Name;
          this.modelD2D2.countryIdD2D2 = this.shipmentMovementData.destinationLocationCountryCode;
          this.modelD2D2.chkSaveProfileAddressD2D2 = this.shipmentMovementData.shipmentDestinationAddressProfileSaveIndicator;
          if(this.modelD2D2.Address2D2D2 !="" && this.modelD2D2.Address2D2D2 !=null  )
            this.showAddressLine1D2D2=true;
          if(this.modelD2D2.Address3D2D2!="" && this.modelD2D2.Address3D2D2 !=null)
            this.showAddressLine2D2D2=true;
         
          if (this.modelD2D2.countryIdD2D2 != "")
            this.GetStates(this.modelD2D2.countryIdD2D2, 2);

          this.IsNextButtonDisabled();
          break;
      }
    }
  }

  bindControls() {
    this.modelD2D1.countryIdD2D1 = "0";
    this.modelD2D2.countryIdD2D2 = "0";
  }

  getUserId() {

    //hardcoded for teting. needs to modify
    this.getInputPar.customerId = localStorage.getItem('currentUserName1');
    //this.hdnUserId = "cust002";

  }

  getaddresslist(): void {

    this.getUserId();
    //console.log("Response from server");

    this.customerService.getExistingShippingAddress(this.getInputPar).subscribe(
      res => {
        //console.log("res");
        //console.log(res);
        //this.resp = res
        // this.drpshippingAddress = res.results;
        //this.modelD2A.shipppingAddressD2A=
        this.shippingAddressOptions = res.results;

      },
      err => {
        // Log errors if any
        //console.log(err);
        //this.alertService.error(err);
        //this.loading = false;
        // toastr.error('failed');

      },
      () => {///complete.

        //console.log("----------");
        //console.log(this.resp.results);
        //this.data = this.resp.results;
        //if (this.drpshippingAddress.length > 0) {
        //  this.hdnUserId = this.drpshippingAddress[0].UserId;
        //}
        //else {
        //  this.getUserId();
        //}
      });

  };


  populateAddress(d2dMode: string) {

    var selectedAddress = this.shippingAddressOptions.filter(item => item['id'] == this.modelD2A.shipppingAddressD2A);


    switch (parseInt(localStorage.getItem('selectedShipmentMovement'))) {


      case ShipmentMovementType.D2A:
        var selectedAddressD2A = this.shippingAddressOptions.filter(item => item['id'] == this.modelD2A.shipppingAddressD2A);

        if (selectedAddressD2A && selectedAddressD2A.length > 0) {
          this.modelD2A.Address1D2A = selectedAddressD2A[0].addressLine1;
          this.modelD2A.Address2D2A = selectedAddressD2A[0].addressLine2;
          this.modelD2A.Address3D2A = selectedAddressD2A[0].addressLine3;
          this.modelD2A.countryIdD2A = selectedAddressD2A[0].countryCode;
          this.modelD2A.cityD2A = selectedAddressD2A[0].politicalDivision2Name;
          this.modelD2A.PostalCodeD2A = selectedAddressD2A[0].postalCode;
        }

        break;

      case ShipmentMovementType.A2D:

        var selectedAddressA2D = this.shippingAddressOptions.filter(item => item['id'] == this.modelD2A.shipppingAddressD2A);
        if (selectedAddressA2D && selectedAddressA2D.length > 0) {
          this.modelA2D.Address1A2D = selectedAddressA2D[0].addressLine1;
          this.modelA2D.Address2A2D = selectedAddressA2D[0].addressLine2;
          this.modelA2D.Address3A2D = selectedAddressA2D[0].addressLine3;
          this.modelA2D.countryIdA2D = selectedAddressA2D[0].countryCode;
          this.modelA2D.cityA2D = selectedAddressA2D[0].politicalDivision2Name;
          this.modelA2D.PostalCodeA2D = selectedAddressA2D[0].postalCode;
        }

        break;

      case ShipmentMovementType.D2D:

        var selectedAddressD2D = this.shippingAddressOptions.filter(item => item['id'] == this.modelD2A.shipppingAddressD2A);

        if (d2dMode == "1" && (selectedAddressD2D && selectedAddressD2D.length > 0)) {

          this.modelD2D1.Address1D2D1 = selectedAddressD2D[0].addressLine1;
          this.modelD2D1.Address2D2D1 = selectedAddressD2D[0].addressLine2;
          this.modelD2D1.Address3D2D1 = selectedAddressD2D[0].addressLine3;
          this.modelD2D1.countryIdD2D1 = selectedAddressD2D[0].countryCode;
          //this.StateIdD2D1.StateIdD2D1 = selectedAddress.state
          this.modelD2D1.cityD2D1 = selectedAddressD2D[0].politicalDivision2Name;
          this.modelD2D1.PostalCodeD2D1 = selectedAddressD2D[0].postalCode;
        }


        if (d2dMode == "2" && (selectedAddressD2D && selectedAddressD2D.length > 0)) {
          this.modelD2D2.Address1D2D2 = selectedAddressD2D[0].addressLine1;
          this.modelD2D2.Address2D2D2 = selectedAddressD2D[0].addressLine2;
          this.modelD2D2.Address3D2D2 = selectedAddressD2D[0].addressLine3;
          this.modelD2D1.countryIdD2D2 = selectedAddressD2D[0].countryCode;
          //this.StateIdD2D1.StateIdD2D1 = selectedAddress.state
          this.modelD2D2.cityD2D2 = selectedAddressD2D[0].politicalDivision2Name;
          this.modelD2D2.PostalCodeD2D2 = selectedAddressD2D[0].postalCode;
        }

        break;


    }

  }
  //auto complete

  private searchSourcePramChange(event) {
    var self = this;
    this.originCity = new Array();
    this.originCityTextBkp = "";
    this.destCityTextBkp = "";
    this.modelA2D.originCityA2DTextBkp = "";

    if (event.length == 0) {
      return;
    }

    if (self.originCity.length == 0) {
      this.quoteService.getDistinctCity(event.trim()).subscribe(
        (resdata: any) => {

          this.originCity = resdata.city;
        }
      );
    }
  }

  private searchDestPramChange(event) {
    var self = this;
    this.destCity = new Array();
    this.destCityTextBkp = "";
    this.originCityTextBkp = "";


    if (event.length == 0) {
      return;
    }

    if (self.destCity.length == 0) {
      this.quoteService.getDistinctCity(event.trim()).subscribe(
        (resdata: any) => {

          this.destCity = resdata.city;

        }
      );
    }
  }

  private searchDestD2APramChange(event) {
    var self = this;
    this.destCity = new Array();
    this.modelD2A.destCityD2ATextBkp = "";
    if (event.length == 0) {
      return;
    }

    if (self.destCity.length == 0) {
      this.quoteService.getDistinctCity(event.trim()).subscribe(
        (resdata: any) => {

          this.destCity = resdata.city;

          if (!this.showAddressLine1D2A && !this.showAddressLine2D2A)

            var top = `93px`;


          if (this.showAddressLine1D2A && !this.showAddressLine2D2A)
            var top = `93px`;

          if (this.showAddressLine1D2A && this.showAddressLine2D2A)
            //this.D2ADestCity.nativeElement.offsetHeight 
            var top = `93px`;

          this.renderer.setStyle(this.D2ADestCity.nativeElement, "top", top);

        }
      );
    }
  }

  private selectedSourcePram(value: any) {
    this.originCityText = value;

    this.originCity = new Array();

    if (this.destCityText != "") {
      this.originCityTextBkp = value;
      this.destCityTextBkp = this.destCityText;
    }

  }

  private selectedDestinationPram(value: any) {
    this.destCityText = value;

    this.destCity = new Array();

    if (this.originCityText != "") {
      this.destCityTextBkp = value;
      this.originCityTextBkp = this.originCityText;
    }
  }

  private selectedDestinationD2APram(value: any) {
    this.modelD2A.destCityD2AText = value;
    this.modelD2A.destCityD2ATextBkp = value;
    this.destCity = new Array();
    this.renderer.setStyle(this.D2ADestCity.nativeElement, "top", `262px`);
  }

  private selectedSourceA2DPram(value: any) {
    this.modelA2D.originCityA2DText = value;
    this.modelA2D.originCityA2DTextBkp = value;
    this.originCity = new Array();
  }

  //end of auto complete
  //Shipmentmovement Tab click event
  selectShipmentMovement(btnNo) {
    this.IsNextButtondisablereq = true;
    if (btnNo == ShipmentMovementType.A2A) {
      this.airporttoairport = true;
      this.doortoairport = false;
      this.airporttodoor = false;
      this.doortodoor = false;
      this.isdestinationACErroroccured=false;
      this.isoriginACErroroccured=false;
      this.cssUrl ='assets/css/autocomplete-normal-style.css';
      this.ClrearD2D();
      this.ClrearA2D();
      this.ClrearD2A();
      // if (localStorage.getItem('currentUserName1') == null) {
      //   this.getAirportdetails(null, true);
      // }
      // else {
      //   this.getAirportdetails(localStorage.getItem('currentUserName1'), true);
      // }

      if (this.quoteService.getQuoteDetails().airFreightShipmentDetail[0].movementTypeCode == ShipmentMovementType.A2A) {
        this.populateControls();
      }

      this.IsAddressValidationSuccess = true;
      this.ischeckboxdisabledforSaveaddress = false;
      this.isHighlighterrorAddressvalidationdes=false;
      this.isHighlighterrorAddressvalidationorg=false;
      this.isHighlighterror=false;
    }

    if (btnNo == ShipmentMovementType.D2A) {
      this.airporttoairport = false;
      this.doortoairport = true;
      this.airporttodoor = false;
      this.doortodoor = false;
      this.isHighlighterrorAddressvalidationdes=false;
      this.isHighlighterrorAddressvalidationorg=false;
      this.isHighlighterror=false;
      this.isdestinationACErroroccured=false;
      this.isoriginACErroroccured=false;
      this.cssUrl ='assets/css/autocomplete-normal-style.css';
      this.ClrearD2D();
      this.ClrearA2D();
      this.ClrearA2A();
      // if (localStorage.getItem('currentUserName1') == null) {
      //   this.getAirportdetails(null, true);
      // }
      // else {
      //   this.getAirportdetails(localStorage.getItem('currentUserName1'), true);
      // }
      this.isCountryselectedD2A = false;
      this.isStateavailabeforthecountryD2A = false;
      this.IsAddressValidationSuccess = true;
      this.ischeckboxdisabledforSaveaddress = false;
      if (this.quoteService.getQuoteDetails().airFreightShipmentDetail[0].movementTypeCode == ShipmentMovementType.D2A) {
        this.populateControls();
        if (localStorage.length > 0) {
          if(localStorage.getItem(this.keyshipmentAddress)!=null&&localStorage.getItem(this.keyshipmentAddress)=="true")
          {
            this.ischeckboxdisabledforSaveaddress=true;
          }
          if(localStorage.getItem(this.keyshipmentAddressd2d)!=null&&localStorage.getItem(this.keyshipmentAddressd2d)=="true")
          {
            this.ischeckboxdisabledforSaveaddress=true;
          }
        }
      }
      
    }

    if (btnNo == ShipmentMovementType.A2D) {

      this.airporttoairport = false;
      this.doortoairport = false;
      this.airporttodoor = true;
      this.doortodoor = false;
      this.cssUrl ='assets/css/autocomplete-normal-style.css';
      this.isCountrySelectedA2D = false;
      this.isHighlighterrorAddressvalidationdes=false;
      this.isHighlighterrorAddressvalidationorg=false;
      this.isHighlighterror=false;
      this.isdestinationACErroroccured=false;
      this.isoriginACErroroccured=false;
      this.ClrearD2D();
      this.ClrearD2A();
      this.ClrearA2A();
      // if (localStorage.getItem('currentUserName1') == null) {
      //   this.getAirportdetails(null, true);
      // }
      // else {
      //   this.getAirportdetails(localStorage.getItem('currentUserName1'), true);
      // }
      this.ischeckboxdisabledforSaveaddress = false;
      if (this.quoteService.getQuoteDetails().airFreightShipmentDetail[0].movementTypeCode == ShipmentMovementType.A2D) {
        this.populateControls();
        if (localStorage.length > 0) {
          if(localStorage.getItem(this.keyshipmentAddress)!=null&&localStorage.getItem(this.keyshipmentAddress)=="true")
          {
            this.ischeckboxdisabledforSaveaddress=true;
          }
          if(localStorage.getItem(this.keyshipmentAddressd2d)!=null&&localStorage.getItem(this.keyshipmentAddressd2d)=="true")
          {
            this.ischeckboxdisabledforSaveaddress=true;
          }
        }
      }
      this.IsAddressValidationSuccess = true;
      
    }

    if (btnNo == ShipmentMovementType.D2D) {
      this.isOriginStateD2D = false;
      this.isDestinationD2D = false;
      this.isCountrySelectedD2DDestination = false;
      this.isCountrySelectedD2DOrigin = false;
      this.airporttoairport = false;
      this.doortoairport = false;
      this.isHighlighterrorAddressvalidationdes=false;
      this.isHighlighterrorAddressvalidationorg=false;
      this.isHighlighterror=false;
      this.isdestinationACErroroccured=false;
      this.isoriginACErroroccured=false;
      this.cssUrl ='assets/css/autocomplete-normal-style.css';
      this.airporttodoor = false;
      this.doortodoor = true;
      this.ClrearA2D();
      this.ClrearD2A();
      this.ClrearA2A();
      // if (localStorage.getItem('currentUserName1') == null) {
      //   this.getAirportdetails(null, true);
      // }
      // else {
      //   this.getAirportdetails(localStorage.getItem('currentUserName1'), true);
      // }
      this.ischeckboxdisabledforSaveaddress = false;
      this.ischeckboxdisabledforSaveaddressD2D = false;
      if (this.quoteService.getQuoteDetails().airFreightShipmentDetail[0].movementTypeCode == ShipmentMovementType.D2D) {
        this.populateControls();
        if (localStorage.length > 0) {
          if(localStorage.getItem(this.keyshipmentAddress)!=null&&localStorage.getItem(this.keyshipmentAddress)=="true")
          {
            this.ischeckboxdisabledforSaveaddress=true;
          }
          if(localStorage.getItem(this.keyshipmentAddressd2d)!=null&&localStorage.getItem(this.keyshipmentAddressd2d)=="true")
          {
            this.ischeckboxdisabledforSaveaddress=true;
          }
        }
      }
      this.IsAddressValidationSuccess = true;
    }


    if ((btnNo == "2" || btnNo == "3" || btnNo == "4") && localStorage.getItem('currentUserName1') == null) {
      this.isWarningMessageVisible = true;
    } else {
      this.isWarningMessageVisible = false;
    }

    this.selectedShipmentMovement = btnNo;

    localStorage.setItem('selectedShipmentMovement', this.selectedShipmentMovement);

  };

  isSelectedShipmentMovementActive(btnNo) {

    //this.isSelectedShipmentMovementActive(btnNo1);
    //return localStorage.getItem('selectedShipmentMovement') === btnNo1;
    return this.selectedShipmentMovement === btnNo;
  };
  //IsNextButtonDisabled() {
  //  return (this.hazardousSelected == null || this.perishableSelected == null || this.temperatureSelected == null) ? true : false;
  //}

  IsNextButtonDisabled() {
    this.IsNextButtondisablereq = true;

    switch (parseInt(localStorage.getItem('selectedShipmentMovement'))) {

      case ShipmentMovementType.A2A:
        //code will be uncommented when autocomplete api is ready
        //if ((this.destCityTextBkp != "" && this.originCityTextBkp != "") && (this.destCityTextBkp != this.originCityTextBkp))
        //  this.IsNextButtondisablereq = false;

        if ((this.destCityText != "" && this.originCityText != "") && (this.destCityText != this.originCityText))
          this.IsNextButtondisablereq = false;

        break;
      case ShipmentMovementType.D2A:
        if (this.modelD2A.Address1D2A != "" && this.modelD2A.countryIdD2A != "0" && this.modelD2A.cityD2A != "" && this.modelD2A.PostalCodeD2A != "") {

          if (this.isStateavailabeforthecountryD2A) {
            if (this.modelD2A.destCityD2AText != ""&& this.modelD2A.stateIdD2A != "")
              this.IsNextButtondisablereq = false;
          }
          else {
            if (this.modelD2A.destCityD2AText != "" )
              this.IsNextButtondisablereq = false;

          }
          //code will be uncommented when autocomplete api is ready
          //if (this.modelD2A.destCityD2ATextBkp != "")
          //  this.IsNextButtondisablereq = false;

        }
        break;

      case ShipmentMovementType.A2D:
        if (this.modelA2D.Address1A2D != "" && this.modelA2D.countryIdA2D != "0" && this.modelA2D.cityA2D != "" && this.modelA2D.PostalCodeA2D != "") {
          //code will be uncommented when autocomplete api is ready
          //if (this.modelA2D.originCityA2DTextBkp != "")
          //  this.IsNextButtondisablereq = false;
          if (this.states && this.states.length > 0) {
            if (this.modelA2D.originCityA2DText != "" )
              this.IsNextButtondisablereq = false;
          }
          else {
            if (this.modelA2D.originCityA2DText != ""&& this.modelA2D.stateIdA2D != "0")
              this.IsNextButtondisablereq = false;
          }
        }
        break;


      case ShipmentMovementType.D2D:
        if ((this.modelD2D1.Address1D2D1 != "" && this.modelD2D1.countryIdD2D1 != "0" && this.modelD2D1.cityD2D1 != "" && this.modelD2D1.PostalCodeD2D1 != "")
          && (this.modelD2D2.Address1D2D2 != "" && this.modelD2D2.countryIdD2D2 != "" && this.modelD2D2.countryIdD2D2 != "0" && this.modelD2D2.cityD2D2 != "" && this.modelD2D2.PostalCodeD2D2 != "")
        ) {
          var isD2Dcheckingpassed = false;
          if (this.states && this.states.length > 0) {
            if (this.modelD2D1.stateIdD2D1 != "0") {
              isD2Dcheckingpassed = true;
            }
          }
          if (this.statesDes && this.statesDes.length > 0) {
            if (this.modelD2D2.stateIdD2D2 != "0") {
              this.IsNextButtondisablereq = false;
              isD2Dcheckingpassed = true;
            }
            else {
              isD2Dcheckingpassed = false;
            }

          }
          if (isD2Dcheckingpassed)
            this.IsNextButtondisablereq = false;

        }

        break;

    }
    //if (!this.originCityText || !this.destCityText || (this.originCityText == this.destCityText))
    // if(!this.IsNextButtondisablereq)
    //   return true;
    // else
    //   return false;
    //return this.frequencySelected == null ? false : true;
    return this.IsNextButtondisablereq;
  }

  nextButtonClass() {

    //commenting for time being to support QA

    if (!this.IsNextButtonDisabled()) {
      return "buttonYellow pull-right";
    } else {
      return "buttonGrey pull-right";
    }

  }

  AddAddressLineD2A() {
    if (this.showAddressLine1D2A && this.showAddressLine2D2A) {
      return;
    }
    if (!this.showAddressLine1D2A) {
      this.showAddressLine1D2A = true;
      return;
    }
    if (this.showAddressLine1D2A) {
      this.showAddressLine2D2A = true;
      return;
    }
  }

  AddAddressLineA2D() {
    if (this.showAddressLine1A2D && this.showAddressLine2A2D) {
      return;
    }
    if (!this.showAddressLine1A2D) {
      this.showAddressLine1A2D = true;
      return;
    }
    if (this.showAddressLine1A2D) {
      this.showAddressLine2A2D = true;
      return;
    }
  }

  AddAddressLineD2D1() {
    if (this.showAddressLine1D2D1 && this.showAddressLine2D2D1) {
      return;
    }
    if (!this.showAddressLine1D2D1) {
      this.showAddressLine1D2D1 = true;
      return;
    }
    if (this.showAddressLine1D2D1) {
      this.showAddressLine2D2D1 = true;
      return;
    }
  }

  AddAddressLineD2D2() {
    if (this.showAddressLine1D2D2 && this.showAddressLine2D2D2) {
      return;
    }
    if (!this.showAddressLine1D2D2) {
      this.showAddressLine1D2D2 = true;
      return;
    }
    if (this.showAddressLine1D2D2) {
      this.showAddressLine2D2D2 = true;
      return;
    }
  }

  showLoginPopup() {
    this.updateQuoteModel();
    this.save();
  }

  onCloseClick() {
    this.showLogin = false;
    this.modallogin.hide()
    this.helper.navigateTo(RoutingKey[PageState.SHIPMENT_MOVEMENT]);
  }

  validateaddressdetails(selectedtab) {

    var objAddress =
      {
        "City": this.validateCityName,
        "StateProvinceCode": this.validateStatePovinceCode,
        "PostalCode": this.validatePostalCode
      }

    this.geoGraphyService.Validateaddressdetails(objAddress).subscribe(
      resdata => {

        // if (resdata["Results"] != null)  {
        if (resdata != null) {
          // if(resdata['results']['ResponseStatusCode']=="1")
          // {
          if (resdata['ResponseStatusCode'] == "1") {
            if (selectedtab == ShipmentMovementType.D2D && this.d2dvalidateCountry == "US") {
              this.validateaddressdetailsforDestinationD2D();
            }
            else {
              this.IsAddressValidationSuccess = true;
              this.updateQuoteModel();
              //this.saveProfileAddress();
              this.helper.navigateTo(RoutingKey[PageState.SHIPMENT_MEASUREMENT]);
            }

          }
          else {
            this.IsAddressValidationSuccess = false;
            if (selectedtab == 2)
            {
              this.AddressValidationSuccessType = 1;
              this.isHighlighterrorAddressvalidationorg=true;
            }
            if (selectedtab == 3)
            {
              this.AddressValidationSuccessType = 2;
              this.isHighlighterrorAddressvalidationdes=true;
            }
            else
            {
              this.isHighlighterrorAddressvalidationorg=true;
              this.AddressValidationSuccessType = 1;
            }
            window.scroll(0, 0);
          }
        }
        return;
      }


    );

  }

  validateaddressdetailsforDestinationD2D() {

    var objAddress =
      {
        "City": this.d2dvalidateCityName,
        "StateProvinceCode": this.d2dvalidateStatePovinceCode,   
        "PostalCode": this.d2dvalidatePostalCode
      }

    this.geoGraphyService.Validateaddressdetails(objAddress).subscribe(
      resdata => {

        if (resdata != null) {
          if (resdata['ResponseStatusCode'] == "1") {
            // if(resdata['results']['ResponseStatusCode']=="1")
            // {
            this.IsAddressValidationSuccess = true;
            this.updateQuoteModel();
            //this.saveProfileAddress();
            this.helper.navigateTo(RoutingKey[PageState.SHIPMENT_MEASUREMENT]);
          }
          else {
            this.IsAddressValidationSuccess = false;
            this.isHighlighterrorAddressvalidationdes=true;
            this.AddressValidationSuccessType = 2;
            window.scroll(0, 0);
          }
        }
        return;
      }

    );

  }

  validateaddressdetailsforSaveforlater(selectedtab) {

    var objAddress =
      {
        "City": this.validateCityName,
        "StateProvinceCode": this.validateStatePovinceCode,
        "PostalCode": this.validatePostalCode
      }

    this.geoGraphyService.Validateaddressdetails(objAddress).subscribe(
      resdata => {

        if (resdata != null) {

          // if(resdata['results']['ResponseStatusCode']=="1")
          // {
          if (resdata['ResponseStatusCode'] == "1") {
            if (selectedtab == ShipmentMovementType.D2D && this.d2dvalidateCountry == "US") {
              this.validateaddressdetailsD2DforSaveforlater();
            }
            else {

              this.updateQuoteModel();
              //this.saveProfileAddress();
              this.save();
            }

          }
          else {
            this.IsAddressValidationSuccess = false;
            if (selectedtab == 2)
            {
                this.AddressValidationSuccessType = 1;
                this.isHighlighterrorAddressvalidationorg=true;
            }
            if (selectedtab == 3)
            {
                this.AddressValidationSuccessType = 2;
                this.isHighlighterrorAddressvalidationdes=true;
            }
            else
            {
              this.AddressValidationSuccessType = 1;
              this.isHighlighterrorAddressvalidationorg=true;
            }
                
            window.scroll(0, 0);
          }
        }
        return;
      }


    );

  }

  validateaddressdetailsD2DforSaveforlater() {
    var objAddress =
      {
        "City": this.d2dvalidateCityName,
        "StateProvinceCode": this.validateStatePovinceCode,
        "PostalCode": this.d2dvalidatePostalCode
      }
    this.geoGraphyService.Validateaddressdetails(objAddress).subscribe(
      resdata => {

        if (resdata != null) {

          // if(resdata['results']['ResponseStatusCode']=="1")
          // {
          if (resdata['ResponseStatusCode'] == "1") {

            //this.prepareModel();
            //this.saveProfileAddress();
            this.save();
          }
          else {
            this.IsAddressValidationSuccess = false;
            this.AddressValidationSuccessType = 2;
            this.isHighlighterrorAddressvalidationdes=true;
            window.scroll(0, 0);
          }
        }
        return;
      }


    );

  }

  saveProfileAddress() {

    if (this.modelD2A.chkSaveProfileAddressD2A) {

      var shippingAddress = {

        "UserId": localStorage.getItem('currentUserName1'),//this.tmpUserId;
        "AddressLine1": this.modelD2A.Address1D2A,
        "AddressLine2": this.modelD2A.Address2D2A,
        "AddressLine3": this.modelD2A.Address3D2A,
        "Country": this.modelD2A.cityD2A,
        "State": this.modelD2A.stateIdD2A,
        "City": this.modelD2A.countryIdD2A,
        "PostalCode": this.modelD2A.PostalCodeD2A,
        "DoShowEditShippingForm": false
      }
      this.saveProfileAddressDetails(shippingAddress);

    };

    if (this.modelA2D.chkSaveProfileAddressA2D) {

      var shippingAddress = {

        "UserId": localStorage.getItem('currentUserName1'),//this.tmpUserId;
        "AddressLine1": this.modelD2A.Address1D2A,
        "AddressLine2": this.modelD2A.Address2D2A,
        "AddressLine3": this.modelD2A.Address3D2A,
        "Country": this.modelD2A.cityD2A,
        "State": this.modelD2A.stateIdD2A,
        "City": this.modelD2A.countryIdD2A,
        "PostalCode": this.modelD2A.PostalCodeD2A,
        "DoShowEditShippingForm": false
      }

      this.saveProfileAddressDetails(shippingAddress);

    }
    if (this.modelD2D1.chkSaveProfileAddressD2D1) {

      var shippingAddress = {

        "UserId": localStorage.getItem('currentUserName1'),//this.tmpUserId;
        "AddressLine1": this.modelA2D.Address1A2D,
        "AddressLine2": this.modelA2D.Address2A2D,
        "AddressLine3": this.modelA2D.Address3A2D,
        "Country": this.modelA2D.cityA2D,
        "State": this.modelA2D.stateIdA2D,
        "City": this.modelD2A.countryIdD2A,
        "PostalCode": this.modelA2D.PostalCodeA2D,
        "DoShowEditShippingForm": false
      }

      this.saveProfileAddressDetails(this.modelD2D1.modelD2DshipmentMovement.OriginShippingAddress);

    }

    if (this.modelD2D2.chkSaveProfileAddressD2D2) {

      var shippingAddress = {

        "UserId": localStorage.getItem('currentUserName1'),//this.tmpUserId;
        "AddressLine1": this.modelD2D1.Address1D2D1,
        "AddressLine2": this.modelD2D1.Address2D2D1,
        "AddressLine3": this.modelD2D1.Address3D2D1,
        "Country": this.modelD2D1.cityD2D1,
        "State": this.modelD2D1.stateIdD2D1,
        "City": this.modelD2D1.countryIdD2D1,
        "PostalCode": this.modelD2A.PostalCodeD2D1,
        "DoShowEditShippingForm": false
      }

      this.saveProfileAddressDetails(shippingAddress)

      var shippingAddress = {

        "UserId": localStorage.getItem('currentUserName1'),//this.tmpUserId;
        "AddressLine1": this.modelD2D2.Address1D2D2,
        "AddressLine2": this.modelD2D2.Address2D2D2,
        "AddressLine3": this.modelD2D2.Address3D2D2,
        "Country": this.modelD2D2.cityD2D2,
        "State": this.modelD2D2.stateIdD2D2,
        "City": this.modelD2D2.countryIdD2D2,
        "PostalCode": this.modelD2D2.PostalCodeD2D2,
        "DoShowEditShippingForm": false
      }

      this.saveProfileAddressDetails(shippingAddress);
    }
  }

  saveProfileAddressDetails(model: any) {


    //Sudipta please fix the defect
    this.customerService.createNewShippingAddress(model).subscribe(
      res => {

        //this.data = res.results;

      },
      err => {


      },
      () => {///complete.


      });



  }
  ValidateOriginDestinationAirport() {
    var selectedOriginAirport = this.states.filter(item => item.autopopulateformat == this.originCityText);
    var selectedDestinationAirport = this.states.filter(item => item.autopopulateformat == this.originCityText);

  }

  //Next button validation
  Next() {
    this.isHighlighterror=false; 
    this.isHighlighterrorAddressvalidationdes=false;
    this.isHighlighterrorAddressvalidationorg=false;
    this.cssUrl ='assets/css/autocomplete-normal-style.css';
    switch (parseInt(localStorage.getItem('selectedShipmentMovement'))) {
      case ShipmentMovementType.A2A:
        if (this.states != null && this.states != undefined) {
          var selectedairport = this.states.filter(item => item.autopopulateformat == this.originCityText);
          // if (selectedairport.length == 0)
          //   selectedairport = this.states.filter(item => item.politicalDivision2Name.toLowerCase() == this.originCityText.toLowerCase());
          // if (selectedairport.length > 0)
          var originLocationCountryCode = selectedairport.length > 0 ? selectedairport[0].countryCode : "";
          var selecteDestinationAirport = this.states.filter(item => item.autopopulateformat == this.destCityText);
          // if (selecteDestinationAirport.length == 0)
          //   selecteDestinationAirport = this.states.filter(item => item.politicalDivision2Name.toLowerCase() == this.destCityText);
          // if (selecteDestinationAirport.length > 0)
          var destinationLocationCountryCode = selecteDestinationAirport.length > 0 ? selecteDestinationAirport[0].countryCode : "";
          if ((originLocationCountryCode.length > 0 && destinationLocationCountryCode.length > 0) && (originLocationCountryCode.toLowerCase() == destinationLocationCountryCode.toLowerCase())) {
            this.IsAddressValidationSuccess = false;
            this.AddressValidationSuccessType = 4;
            //this.cssUrl ='assets/css/autocomplete-error-style.css';
            this.isoriginACErroroccured=true;
            this.isdestinationACErroroccured=true;
            window.scroll(0, 0);
          }
          else if(selectedairport.length==0 &&selecteDestinationAirport.length==0)
          {
            this.IsAddressValidationSuccess = false;
            this.AddressValidationSuccessType = 5;
            //this.cssUrl ='assets/css/autocomplete-error-style.css';
            this.isoriginACErroroccured=true;
            this.isdestinationACErroroccured=true;
            window.scroll(0, 0);
          }
          else if(selectedairport.length==0 )
          {
            this.IsAddressValidationSuccess = false;
            this.AddressValidationSuccessType = 5;
            //this.cssUrl ='assets/css/autocomplete-orgerror-style.css';
            this.isoriginACErroroccured=true;
            window.scroll(0, 0);
          }
          else if( selecteDestinationAirport.length==0)
          {
            this.IsAddressValidationSuccess = false;
            this.AddressValidationSuccessType = 5;
            //this.cssUrl ='assets/css/autocomplete-deserror-style.css';
            this.isdestinationACErroroccured=true;
            window.scroll(0, 0);
          }
          else
            this.IsAddressValidationrequired = false;
        }
        else
          this.IsAddressValidationrequired = false;

        break;

      case ShipmentMovementType.D2A:

        this.validateCityName = this.modelD2A.cityD2A;
        this.validatePostalCode = this.modelD2A.PostalCodeD2A;
        this.validateStatePovinceCode = this.modelD2A.stateIdD2A;

        var selectedDestinationAirport = this.states.filter(item => item.autopopulateformat == this.modelD2A.destCityD2AText);
        // if (selectedDestinationAirport.length == 0)
        //   selectedDestinationAirport = this.states.filter(item => item.politicalDivision2Name.toLowerCase() == this.modelD2A.destCityD2AText);
        // if (selecteDestinationAirport.length > 0)
        var destinationLocationCountryCode = selectedDestinationAirport.length > 0 ? selectedDestinationAirport[0].countryCode : "";
        if ((this.modelD2A.countryIdD2A.length > 0 && destinationLocationCountryCode.length > 0) && (this.modelD2A.countryIdD2A.toLowerCase() == destinationLocationCountryCode.toLowerCase())) {
          this.IsAddressValidationSuccess = false;
          this.AddressValidationSuccessType = 4;
          this.isHighlighterror=true; 
          //this.cssUrl ='assets/css/autocomplete-deserror-style.css'; 
          this.isdestinationACErroroccured=true;  
          window.scroll(0, 0);      
        }
        else if(selectedDestinationAirport.length==0)
        {
          this.IsAddressValidationSuccess = false;
          this.AddressValidationSuccessType = 5;
          //this.cssUrl ='assets/css/autocomplete-deserror-style.css';
          this.isdestinationACErroroccured=true;
          window.scroll(0, 0);
        }
        else {
          if (this.modelD2A.countryIdD2A == "US")
            this.validateaddressdetails(ShipmentMovementType.D2A);
          else
            this.IsAddressValidationrequired = false;
        }
        break;

      case ShipmentMovementType.A2D:

        this.validateCityName = this.modelA2D.cityA2D;
        this.validatePostalCode = this.modelA2D.PostalCodeA2D;
        this.validateStatePovinceCode = this.modelA2D.stateIdA2D;
        this.validateCountry = this.modelA2D.countryIdA2D;

        var selectedoriginAirport = this.states.filter(item => item.autopopulateformat == this.modelA2D.originCityA2DText);
        // if (selectedoriginAirport.length == 0)
        //   selectedoriginAirport = this.states.filter(item => item.politicalDivision2Name.toLowerCase() == this.modelA2D.originCityA2DText);
        // if (selecteDestinationAirport.length > 0)
        var originLocationCountryCode = selectedoriginAirport.length > 0 ? selectedoriginAirport[0].countryCode : "";
        if ((this.modelA2D.countryIdA2D.length > 0 && originLocationCountryCode.length > 0) && (this.modelA2D.countryIdA2D.toLowerCase() == originLocationCountryCode.toLowerCase())) {
          this.IsAddressValidationSuccess = false;
          this.AddressValidationSuccessType = 4;
          this.isHighlighterror=true; 
          //this.cssUrl ='assets/css/autocomplete-orgerror-style.css';
          this.isoriginACErroroccured=true;
          window.scroll(0, 0);
        }
        else if(selectedoriginAirport.length==0)
        {
          this.IsAddressValidationSuccess = false;
          this.AddressValidationSuccessType = 5;
          //this.cssUrl ='assets/css/autocomplete-orgerror-style.css';
          this.isoriginACErroroccured=true;
          window.scroll(0, 0);
        }
        else {
          if (this.modelA2D.countryIdA2D == "US")
            this.validateaddressdetails(ShipmentMovementType.A2D);
          else
            this.IsAddressValidationrequired = false;
        }
        break;

      case ShipmentMovementType.D2D:

        //SOURCE ADDRESSS
        this.validateCityName = this.modelD2D1.cityD2D1;
        this.validateCountry = this.modelD2D1.countryIdD2D1;
        this.validatePostalCode = this.modelD2D1.PostalCodeD2D1;
        this.validateStatePovinceCode = this.modelD2D1.stateIdD2D1;

        //DESTINATION ADDRESS
        this.d2dvalidateCityName = this.modelD2D2.cityD2D2;
        this.d2dvalidatePostalCode = this.modelD2D2.PostalCodeD2D2;
        this.d2dvalidateStatePovinceCode = this.modelD2D2.stateIdD2D2;
        this.d2dvalidateCountry = this.modelD2D2.countryIdD2D2;

        if ((this.modelD2D1.countryIdD2D1.length > 0 && this.modelD2D2.countryIdD2D2.length > 0) && (this.modelD2D1.countryIdD2D1.toLowerCase() == this.modelD2D2.countryIdD2D2.toLowerCase())) {
          this.IsAddressValidationSuccess = false;
          this.AddressValidationSuccessType = 4;
          this.isHighlighterror=true; 
          //this.cssUrl ='assets/css/autocomplete-error-style.css';
          window.scroll(0, 0);
        }
        
        else {
          if (this.modelD2D1.countryIdD2D1 == "US") {
            this.validateaddressdetails(ShipmentMovementType.D2D);
          }
          else if (this.modelD2D2.countryIdD2D2 == "US") {
            this.validateaddressdetailsforDestinationD2D();
          }
          else { this.IsAddressValidationrequired = false; }
        }

        break;
    }

    if (!this.IsAddressValidationrequired) {
      //this.prepareModel();
      this.updateQuoteModel();
      //this.router.navigate(['/shipmentmeasurement']);
      this.helper.navigateTo(RoutingKey[PageState.SHIPMENT_MEASUREMENT]);
    }
  }

  back() {

    //put validation logic
    this.updateQuoteModel();
    //this.router.navigate(['/shipmentFrequency']);
    this.helper.navigateTo(RoutingKey[PageState.SHIPMENT_FREQUENCY]);
  }

  save() {

    var self = this;

    if (localStorage.getItem('currentUserName1') == null) {

      this.showLogin = true;
      this.modallogin.show();
      //alert('Navigate to login not implemented !!');
      return;
    }

    this.quoteService.save().subscribe(
      resdata => {

        if (resdata != null) {

          //this.quoteDetail = resdata['results'] as QuoteDetail;
          //if (self.isSaveForLater) {

          //if (this.localStorageService.getItem('userAccessToken')) {
          this.clearModel();
          this.helper.navigateTo(RoutingKey[PageState.DASHBOARD]);
}

      }
    );
  }

  //Save For Later button click event
  saveForLater() {
    this.isHighlighterror=false; 
    this.isHighlighterrorAddressvalidationdes=false;
    this.isHighlighterrorAddressvalidationorg=false;
    this.cssUrl ='assets/css/autocomplete-normal-style.css';
    //Check for each movement type
    switch (parseInt(localStorage.getItem('selectedShipmentMovement'))) {
      //User selects Airpot to Airport
      case ShipmentMovementType.A2A:
        if (this.states != null && this.states != undefined) {
          //User selects origin airport details from auto populated value
          var selectedairport = this.states.filter(item => item.autopopulateformat == this.originCityText);
          //User types city/airport
          // if (selectedairport.length == 0)
          //   selectedairport = this.states.filter(item => item.politicalDivision2Name.toLowerCase() == this.originCityText.toLowerCase());
          var originLocationCountryCode = selectedairport.length > 0 ? selectedairport[0].countryCode : "";
          //User selects destination airport details from auto populated value
          var selecteDestinationAirport = this.states.filter(item => item.autopopulateformat == this.destCityText);
          //User types city/airport
          // if (selecteDestinationAirport.length == 0)
          //   selecteDestinationAirport = this.states.filter(item => item.politicalDivision2Name.toLowerCase() == this.destCityText);
          var destinationLocationCountryCode = selecteDestinationAirport.length > 0 ? selecteDestinationAirport[0].countryCode : "";
          if ((originLocationCountryCode.length > 0 && destinationLocationCountryCode.length > 0) && (originLocationCountryCode.toLowerCase() == destinationLocationCountryCode.toLowerCase())) {
            this.IsAddressValidationSuccess = false;
            this.AddressValidationSuccessType = 4;
            
            this.cssUrl ='assets/css/autocomplete-error-style.css';
          }
          else if(selectedairport.length==0 &&selecteDestinationAirport.length==0)
          {
            this.IsAddressValidationSuccess = false;
            this.AddressValidationSuccessType = 5;
            this.cssUrl ='assets/css/autocomplete-error-style.css';
            window.scroll(0, 0);
          }
          else if(selectedairport.length==0)
          {
            this.IsAddressValidationSuccess = false;
            this.AddressValidationSuccessType = 5;
            this.cssUrl ='assets/css/autocomplete-orgerror-style.css';
          }
          else if(selecteDestinationAirport.length==0)
          {
            this.IsAddressValidationSuccess = false;
            this.AddressValidationSuccessType = 5;
            this.cssUrl ='assets/css/autocomplete-deserror-style.css';
          }
          else
            this.IsAddressValidationrequired = false;
        }
        else
          this.IsAddressValidationrequired = false;
        break;
      //User selects Door To Airport
      case ShipmentMovementType.D2A:
        this.validateCityName = this.modelD2A.cityD2A;
        this.validatePostalCode = this.modelD2A.PostalCodeD2A;
        this.validateStatePovinceCode = "";
        var selecteDestinationAirport = this.states.filter(item => item.autopopulateformat == this.modelD2A.destCityD2AText);
        //User types city/airport
        // if (selecteDestinationAirport.length == 0)
        //   selecteDestinationAirport = this.states.filter(item => item.politicalDivision2Name.toLowerCase() == this.modelD2A.destCityD2AText);
        var destinationLocationCountryCode = selecteDestinationAirport.length > 0 ? selecteDestinationAirport[0].countryCode : "";
        if ((this.modelD2A.countryIdD2A.length > 0 && destinationLocationCountryCode.length > 0) && (this.modelD2A.countryIdD2A.toLowerCase() == destinationLocationCountryCode.toLowerCase())) {
          this.IsAddressValidationSuccess = false;
          this.AddressValidationSuccessType = 4;
          this.isHighlighterror=true; 
          this.cssUrl ='assets/css/autocomplete-deserror-style.css';
        }
        else if(selecteDestinationAirport.length==0)
        {
            this.IsAddressValidationSuccess = false;
            this.AddressValidationSuccessType = 5;
            this.cssUrl ='assets/css/autocomplete-deserror-style.css';
        }
        //if origin and destination country are not same
        else {
          //validate origin address for US
          if (this.modelD2A.countryIdD2A == "US")
            this.validateaddressdetailsforSaveforlater(ShipmentMovementType.D2A);
          else
            this.IsAddressValidationrequired = false;
        }
        break;

      case ShipmentMovementType.A2D:

        this.validateCityName = this.modelA2D.cityA2D;
        this.validatePostalCode = this.modelA2D.PostalCodeA2D;
        this.validateStatePovinceCode = "";
        this.validateCountry = this.modelA2D.countryIdA2D;
        if (this.states != null && this.states != undefined) {
          //User selects origin airport details from auto populated value
          var selectedairport = this.states.filter(item => item.autopopulateformat == this.modelA2D.originCityA2DText);
          //User types city/airport
          // if (selectedairport.length == 0)
          //   selectedairport = this.states.filter(item => item.politicalDivision2Name.toLowerCase() == this.modelA2D.originCityA2DText.toLowerCase());
          var originLocationCountryCode = selectedairport.length > 0 ? selectedairport[0].countryCode : "";
        
        //if origin and destination country code are same
        if ((originLocationCountryCode.length > 0 && this.modelA2D.countryIdA2D.length > 0) && (originLocationCountryCode.toLowerCase() == this.modelA2D.countryIdA2D.toLowerCase())) {
          this.IsAddressValidationSuccess = false;
          this.AddressValidationSuccessType = 4;
          this.isHighlighterror=true;
          this.cssUrl ='assets/css/autocomplete-orgerror-style.css';
        }
        else if(selectedairport.length==0)
        {
            this.IsAddressValidationSuccess = false;
            this.AddressValidationSuccessType = 5;
            this.cssUrl ='assets/css/autocomplete-orgerror-style.css';
        }
        else {
          //Destination address validation for US
          if (this.modelA2D.countryIdA2D == "US")
            this.validateaddressdetailsforSaveforlater(ShipmentMovementType.A2D);
          else
            this.IsAddressValidationrequired = false;
        }
      }
        break;

      case ShipmentMovementType.D2D:

        this.validateCityName = this.modelD2D1.cityD2D1;
        this.validatePostalCode = this.modelD2D1.PostalCodeD2D1;
        this.validateStatePovinceCode = "";   //this.modelD2D1.StateIdD2D1;
        this.validateCountry = this.modelD2D1.countryIdD2D1;

        this.d2dvalidateCityName = this.modelD2D2.cityD2D2;
        this.d2dvalidatePostalCode = this.modelD2D2.PostalCodeD2D2;
        this.d2dvalidateStatePovinceCode = this.modelD2D2.stateIdD2D2;
        this.d2dvalidateCountry = this.modelD2D2.countryIdD2D2;
        //if origin and destination country code are same
        if ((this.modelD2D1.countryIdD2D1.length > 0 && this.modelD2D2.countryIdD2D2.length > 0) && (this.modelD2D1.countryIdD2D1.toLowerCase() == this.modelD2D2.countryIdD2D2.toLowerCase())) {
          this.IsAddressValidationSuccess = false;
          this.AddressValidationSuccessType = 4;
          this.isHighlighterror=true;
        }
        else {
          if (this.modelD2D1.countryIdD2D1 == "US") {
            this.validateaddressdetailsforSaveforlater(ShipmentMovementType.D2D);

          }
          else if (this.modelD2D2.countryIdD2D2 == "US") {
            this.validateaddressdetailsD2DforSaveforlater();
          }
          else {
            this.IsAddressValidationrequired = false;
          }
        }
        break;
    }
    if (!this.IsAddressValidationrequired) {
      this.updateQuoteModel();
      // this.saveProfileAddress();
      this.save();
    }

  }

  updateQuoteModel() {
    //Get the current quote data
    let quoteDetails = this.quoteService.getQuoteDetails() as IQuoteData;
    switch (parseInt(localStorage.getItem('selectedShipmentMovement'))) {
      case ShipmentMovementType.A2A:
        this.resetModelA2D();
        this.resetModelD2A();
        //Filter the airport/city from location master data
        if (this.states != null && this.states != undefined) {
          //User selects origin airport from autopopulated value
          var selectedairport = this.states.filter(item => item.autopopulateformat == this.originCityText);
          //User types origin city
          if (selectedairport.length == 0)
            selectedairport = this.states.filter(item => item.politicalDivision2Name.toLowerCase() == this.originCityText.toLowerCase());
          //Fill the origin airport and address details
          quoteDetails.airFreightShipmentDetail[0].originAirportName = selectedairport.length > 0 ? selectedairport[0].airportName : "";
          quoteDetails.airFreightShipmentDetail[0].originAirport = selectedairport.length > 0 ? selectedairport[0].airportCode : "";
          quoteDetails.airFreightShipmentDetail[0].originLocationCountryCode = selectedairport.length > 0 ? selectedairport[0].countryCode : "";
          quoteDetails.airFreightShipmentDetail[0].originLocationPoliticalDivsion2Code = selectedairport.length > 0 ? selectedairport[0].politicalDivision2Name : this.originCityText;
          //User selects destination airport from autopopulated value
          var selecteDestinationAirport = this.states.filter(item => item.autopopulateformat == this.destCityText);
          //User types destination city
          if (selecteDestinationAirport.length == 0)
            selecteDestinationAirport = this.states.filter(item => item.politicalDivision2Name.toLowerCase() == this.destCityText.toLowerCase());
          //Fill the destination airport and address details
          quoteDetails.airFreightShipmentDetail[0].destinationAirportName = selecteDestinationAirport.length > 0 ? selecteDestinationAirport[0].airportName : "";
          quoteDetails.airFreightShipmentDetail[0].destinationAirport = selecteDestinationAirport.length > 0 ? selecteDestinationAirport[0].airportCode : "";
          quoteDetails.airFreightShipmentDetail[0].destinationLocationCountryCode = selecteDestinationAirport.length > 0 ? selecteDestinationAirport[0].countryCode : "";
          quoteDetails.airFreightShipmentDetail[0].destinationLocationPoliticalDivsion2Code = selecteDestinationAirport.length > 0 ? selecteDestinationAirport[0].politicalDivision2Name : this.destCityText;
        }
        //if there is no location master data available.
        else {
          quoteDetails.airFreightShipmentDetail[0].originAirportName = this.originCityText;
          quoteDetails.airFreightShipmentDetail[0].originAirport = this.originCityText;
          quoteDetails.airFreightShipmentDetail[0].destinationAirportName = this.destCityText;
          quoteDetails.airFreightShipmentDetail[0].destinationAirport = this.destCityText;

        }
        break;
      case ShipmentMovementType.D2A:
        this.resetModelA2D();
        quoteDetails.airFreightShipmentDetail[0].originAddressLine1Text = this.modelD2A.Address1D2A;
        quoteDetails.airFreightShipmentDetail[0].originAddressLine2Text = this.modelD2A.Address2D2A;
        quoteDetails.airFreightShipmentDetail[0].originAddressLine3Text = this.modelD2A.Address3D2A;
        quoteDetails.airFreightShipmentDetail[0].originLocationPoliticalDivsion2Code = this.modelD2A.cityD2A;
        quoteDetails.airFreightShipmentDetail[0].originLocationPostalCode = this.modelD2A.PostalCodeD2A;
        quoteDetails.airFreightShipmentDetail[0].originPoliticalDivision1Name = this.modelD2A.stateIdD2A==0?"":this.modelD2A.stateIdD2A;
        quoteDetails.airFreightShipmentDetail[0].originLocationCountryCode = this.modelD2A.countryIdD2A;
        quoteDetails.airFreightShipmentDetail[0].shipmentOriginAddressProfileSaveIndicator = this.modelD2A.chkSaveProfileAddressD2A;
        quoteDetails.airFreightShipmentDetail[0].shipmentDestinationAddressProfileSaveIndicator = false;
        //Filter the airport/city from location master data
        if (this.states != null && this.states != undefined) {
          //User selects destination airport from autopopulated value
          var selecteDestinationAirport = this.states.filter(item => item.autopopulateformat == this.modelD2A.destCityD2AText);
          //User types destination city
          if (selecteDestinationAirport.length == 0)
            selecteDestinationAirport = this.states.filter(item => item.politicalDivision2Name.toLowerCase() == this.modelD2A.destCityD2AText.toLowerCase());
          //Fill the destination airport and address details
          quoteDetails.airFreightShipmentDetail[0].destinationAirportName = selecteDestinationAirport.length > 0 ? selecteDestinationAirport[0].airportName : "";
          quoteDetails.airFreightShipmentDetail[0].destinationAirport = selecteDestinationAirport.length > 0 ? selecteDestinationAirport[0].airportCode : "";
          quoteDetails.airFreightShipmentDetail[0].destinationLocationCountryCode = selecteDestinationAirport.length > 0 ? selecteDestinationAirport[0].countryCode : "";
          quoteDetails.airFreightShipmentDetail[0].destinationLocationPoliticalDivsion2Code = selecteDestinationAirport.length > 0 ? selecteDestinationAirport[0].politicalDivision2Name : this.destCityText;
        }
        break;

      case ShipmentMovementType.A2D:
        //clear model if tab switching done
        this.resetModelA2D();
        //Filter the airport/city from location master data
        if (this.states != null && this.states != undefined) {
          //User selects origin airport from autopopulated value
          var selectedairport = this.states.filter(item => item.autopopulateformat == this.modelA2D.originCityA2DText);
          //User types origin city
          if (selectedairport.length == 0)
            selectedairport = this.states.filter(item => item.politicalDivision2Name.toLowerCase() == this.modelA2D.originCityA2DText.toLowerCase());
          //Fill the origin airport and address details
          quoteDetails.airFreightShipmentDetail[0].originAirportName = selectedairport.length > 0 ? selectedairport[0].airportName : "";
          quoteDetails.airFreightShipmentDetail[0].originAirport = selectedairport.length > 0 ? selectedairport[0].airportCode : "";
          quoteDetails.airFreightShipmentDetail[0].originLocationCountryCode = selectedairport.length > 0 ? selectedairport[0].countryCode : "";
          quoteDetails.airFreightShipmentDetail[0].originLocationPoliticalDivsion2Code = selectedairport.length > 0 ? selectedairport[0].politicalDivision2Name : this.originCityText;
          quoteDetails.airFreightShipmentDetail[0].destinationAddressLine1Text = this.modelA2D.Address1A2D;
        }
        quoteDetails.airFreightShipmentDetail[0].destinationAddressLine2Text = this.modelA2D.Address2A2D;
        quoteDetails.airFreightShipmentDetail[0].destinationAddressLine3Text = this.modelA2D.Address3A2D;
        quoteDetails.airFreightShipmentDetail[0].destinationLocationPoliticalDivsion2Code = this.modelA2D.cityA2D;
        quoteDetails.airFreightShipmentDetail[0].destinationLocationPostalCode = this.modelA2D.PostalCodeA2D;
        quoteDetails.airFreightShipmentDetail[0].destinationPoliticalDivision1Name = this.modelA2D.stateIdA2D==0?"":this.modelA2D.stateIdA2D;
        quoteDetails.airFreightShipmentDetail[0].destinationLocationCountryCode = this.modelA2D.countryIdA2D;
        quoteDetails.airFreightShipmentDetail[0].shipmentDestinationAddressProfileSaveIndicator = false;
        quoteDetails.airFreightShipmentDetail[0].shipmentDestinationAddressProfileSaveIndicator = this.modelA2D.chkSaveProfileAddressA2D;
        break;

      case ShipmentMovementType.D2D:

        //Soure Address
        quoteDetails.airFreightShipmentDetail[0].originAddressLine1Text = this.modelD2D1.Address1D2D1;
        quoteDetails.airFreightShipmentDetail[0].originAddressLine2Text = this.modelD2D1.Address2D2D1;
        quoteDetails.airFreightShipmentDetail[0].originAddressLine3Text = this.modelD2D1.Address3D2D1;
        quoteDetails.airFreightShipmentDetail[0].originLocationPoliticalDivsion2Code = this.modelD2D1.cityD2D1;
        quoteDetails.airFreightShipmentDetail[0].originLocationPostalCode = this.modelD2D1.PostalCodeD2D1;
        quoteDetails.airFreightShipmentDetail[0].originPoliticalDivision1Name = this.modelD2D1.StateIdD2D1==0?"":this.modelD2D1.StateIdD2D1;
        quoteDetails.airFreightShipmentDetail[0].originLocationCountryCode = this.modelD2D1.countryIdD2D1;
        quoteDetails.airFreightShipmentDetail[0].shipmentOriginAddressProfileSaveIndicator = this.modelD2D1.chkSaveProfileAddressD2D1;

        //Destination Addresss
        quoteDetails.airFreightShipmentDetail[0].destinationAddressLine1Text = this.modelD2D2.Address1D2D2;
        quoteDetails.airFreightShipmentDetail[0].destinationAddressLine2Text = this.modelD2D2.Address2D2D2;
        quoteDetails.airFreightShipmentDetail[0].destinationAddressLine3Text = this.modelD2D2.Address3D2D2;
        quoteDetails.airFreightShipmentDetail[0].destinationLocationPoliticalDivsion2Code = this.modelD2D2.cityD2D2;
        quoteDetails.airFreightShipmentDetail[0].destinationLocationPostalCode = this.modelD2D2.PostalCodeD2D2;
        quoteDetails.airFreightShipmentDetail[0].destinationPoliticalDivision1Name = this.modelD2D2.StateIdD2D2==0?"":this.modelD2D2.StateIdD2D2;
        quoteDetails.airFreightShipmentDetail[0].destinationLocationCountryCode = this.modelD2D2.countryIdD2D2;
        quoteDetails.airFreightShipmentDetail[0].shipmentDestinationAddressProfileSaveIndicator = this.modelD2D2.chkSaveProfileAddressD2D2;
        break;

    }
    quoteDetails.airFreightShipmentDetail[0].movementTypeCode = parseInt(localStorage.getItem('selectedShipmentMovement'));
    quoteDetails.quoteRequestData.businessPartyNumber = localStorage.getItem('currentUserName1');
    quoteDetails.quoteRequestData.lastVisitedPage = PageState.SHIPMENT_MOVEMENT;
    this.quoteService.setQuoteDetails(quoteDetails);
    return quoteDetails;
  }

  clearModel() {
    this.quoteService.resetQuoteModel();
  }

  ClearTab() {

    switch (parseInt(localStorage.getItem('selectedShipmentMovement'))) {

      case ShipmentMovementType.A2A:
        this.ClrearA2D();
        this.ClrearD2A();
        this.ClrearD2D();
        break;

      case ShipmentMovementType.D2A:
        this.ClrearA2D();
        this.ClrearD2D();
        this.ClrearA2A();
        break;

      case ShipmentMovementType.A2D:
        this.ClrearD2A();
        this.ClrearD2D();
        this.ClrearA2A();
        break;

      case ShipmentMovementType.D2D:
        this.ClrearA2D();
        this.ClrearD2A();
        this.ClrearA2A();
        break;

    }
  }

  ClrearA2A() {
    this.originCityText = "";
    this.originCityTextBkp = "";
    this.destCityText = "";
    this.destCityTextBkp = "";
    //clear Tabe-1
    // let quoteDetails = this.quoteService.getQuoteDetails() as IQuoteData;
    // quoteDetails.airFreightShipmentDetail.originAirport = this.originCityText;
    // quoteDetails.airFreightShipmentDetail.destinationAirport = this.destCityText;
  }

  ClrearD2A() {
    this.modelD2A = {
      destCityD2AText: "",
      destCityD2ATextBkp: "",
      Address1D2A: "",
      Address2D2A: "",
      Address3D2A: "",
      stateIdD2A: "0",
      cityD2A: "",
      countryIdD2A: "0",
      PostalCodeD2A: "",
      chkSaveProfileAddressD2A: false
    }

    this.showAddressLine1D2A = false;
    this.showAddressLine2D2A = false;
    //this.showAddressLineD2A = true;

  }

  resetModelD2A() {

    //clear Tabe-2
    let quoteDetails = this.quoteService.getQuoteDetails() as IQuoteData;

    quoteDetails.airFreightShipmentDetail[0].originAddressLine1Text = this.modelD2A.Address1D2A;
    quoteDetails.airFreightShipmentDetail[0].originAddressLine2Text = this.modelD2A.Address2D2A;
    quoteDetails.airFreightShipmentDetail[0].originAddressLine3Text = this.modelD2A.Address3D2A;
    quoteDetails.airFreightShipmentDetail[0].originLocationPoliticalDivsion2Code = this.modelD2A.cityD2A;
    quoteDetails.airFreightShipmentDetail[0].originLocationPostalCode = this.modelD2A.PostalCodeD2A;
    quoteDetails.airFreightShipmentDetail[0].originPoliticalDivision1Name = this.modelD2A.stateIdD2A;
    quoteDetails.airFreightShipmentDetail[0].originLocationCountryCode = this.modelD2A.countryIdD2A
    quoteDetails.airFreightShipmentDetail[0].shipmentOriginAddressProfileSaveIndicator = this.modelD2A.chkSaveProfileAddressD2A;
    quoteDetails.airFreightShipmentDetail[0].shipmentDestinationAddressProfileSaveIndicator = false;
    quoteDetails.airFreightShipmentDetail[0].destinationAirport = this.modelD2A.destCityD2AText;

  }

  ClrearA2D() {

    this.modelA2D = {
      originCityA2DText: "",
      originCityA2DTextBkp: "",
      Address1A2D: "",
      Address2A2D: "",
      Address3A2D: "",
      stateIdA2D: "0",
      cityA2D: "",
      countryIdA2D: "0",
      PostalCodeA2D: "",
      chkSaveProfileAddressA2D: false
    }
    this.showAddressLine1A2D = false;
    this.showAddressLine2A2D = false;
    // this.showAddressLineA2D = true;


  }

  resetModelA2D() {

    //clear Tabe-3
    let quoteDetails = this.quoteService.getQuoteDetails() as IQuoteData;
    quoteDetails.airFreightShipmentDetail[0].originAirport = this.modelD2A.originCityA2DText;
    quoteDetails.airFreightShipmentDetail[0].destinationAddressLine1Text = this.modelA2D.Address1A2D;
    quoteDetails.airFreightShipmentDetail[0].destinationAddressLine2Text = this.modelA2D.Address2A2D;
    quoteDetails.airFreightShipmentDetail[0].destinationAddressLine3Text = this.modelA2D.Address3A2D;
    quoteDetails.airFreightShipmentDetail[0].destinationLocationPoliticalDivsion2Code = this.modelA2D.cityA2D;
    quoteDetails.airFreightShipmentDetail[0].destinationLocationPostalCode = this.modelA2D.PostalCodeA2D;
    quoteDetails.airFreightShipmentDetail[0].destinationPoliticalDivision1Name = this.modelA2D.stateIdA2D;
    quoteDetails.airFreightShipmentDetail[0].destinationLocationCountryCode = this.modelA2D.countryIdA2D
    quoteDetails.airFreightShipmentDetail[0].shipmentDestinationAddressProfileSaveIndicator = false;
    quoteDetails.airFreightShipmentDetail[0].shipmentDestinationAddressProfileSaveIndicator = this.modelA2D.chkSaveProfileAddressA2D;

  }

  ClrearD2D() {
    this.modelD2D1 = {
      Address1D2D1: "",
      Address2D2D1: "",
      Address3D2D1: "",
      countryIdD2D1: "0",
      cityD2D1: "",
      StateIdD2D1: "0",
      PostalCodeD2D1: "",
      chkSaveProfileAddressD2D1: false
    }

    this.modelD2D2 = {
      Address1D2D2: "",
      Address2D2D2: "",
      Address3D2D2: "",
      countryIdD2D2: "0",
      cityD2D2: "",
      StateIdD2D2: "0",
      PostalCodeD2D2: "",
      chkSaveProfileAddressD2D2: false
    }

    this.showAddressLine1D2D2 = false;
    this.showAddressLine2D2D2 = false;
    this.showAddressLine1D2D1 = false;
    this.showAddressLine2D2D1 = false;




  }
}
