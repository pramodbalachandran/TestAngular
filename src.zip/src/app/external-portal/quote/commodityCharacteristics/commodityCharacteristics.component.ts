import { Component, OnInit,ViewChild } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

import { QuoteDetail } from '@app/shared/interfaces/entities.interface';
import { QuoteAPI } from '@app/shared/services';
import { ModalComponent } from '@app/shared/helper/modalpopup.component';

import { IQuoteData, IQuoteListDetails } from '@app/models/quotes/quote-data';
import { IQuoteDetails } from '@app/models/quotes/quotes-details';
import { IAirFreightShipmentDetail } from '@app/models/quotes/airfreightshipment-detail';
import { PageState } from '@app/shared/services/shared/enum';
import { RoutingKey } from '@app/shared/services/shared/config.const';
import { UtilitiesService } from '@app/shared/services/shared/utilities.service';

@Component({
  selector: 'commodityCharacteristics',
  templateUrl: './commodityCharacteristics.component.html',
  styleUrls: ['./commodityCharacteristics.component.scss'],
  providers: []
})
export class CommodityCharacteristicsComponent implements OnInit {
  modelShipmentFrequency: any = {};
  private hazardousSelected: number;
  private perishableSelected: number;
  private temperatureSelected: number;
  private hazardous: boolean = false;
  private perishable : boolean = false;
  private temperature: boolean = false;
  private isSaveForLater: boolean = false;
  @ViewChild('modalLogin') modallogin: ModalComponent;
  
  constructor(private helper: UtilitiesService, private route: ActivatedRoute, private quoteService: QuoteAPI<IQuoteData>)
  { }

  ngOnInit() {


    this.populateControls();   
   
  }

  populateControls() {

    if (this.quoteService.getQuoteDetails() != null && this.quoteService.getQuoteDetails().airFreightShipmentDetail != null) {

      this.hazardousSelected = this.quoteService.getQuoteDetails().airFreightShipmentDetail[0].hazardousMaterialsIndicator;
      this.perishableSelected = this.quoteService.getQuoteDetails().airFreightShipmentDetail[0].perishableShipmentIndicator;
      this.temperatureSelected = this.quoteService.getQuoteDetails().airFreightShipmentDetail[0].temperatureControlShipmentIndicator;

      this.hazardous = this.hazardousSelected == 1 ? true : false;
      this.perishable = this.perishableSelected == 1 ? true : false;
      this.temperature = this.temperatureSelected == 1 ? true : false;

    }
  }

  selectCharacteristics(btnNo) {

    switch (btnNo) {
      case 1:
        this.hazardous = true;
        this.hazardousSelected = btnNo;
        break;
      case 2:
        this.hazardous = false;
        this.hazardousSelected = btnNo;
        break;
      case 3:
        this.perishable = true;
        this.perishableSelected = 1;
        break;
      case 4:
        this.perishable = false;
        this.perishableSelected = 2;
        break;
      case 5:
        this.temperature = true;
        this.temperatureSelected = 1;
        break;
      case 6:
        this.temperature = false;
        this.temperatureSelected = 2;
        break;
    }

  };

  isHazardousActive(btnNo) {
    return this.hazardousSelected === btnNo;
  };

  isPerishableActive(btnNo) {
    return this.perishableSelected === btnNo;
  };

  isTemperatureActive(btnNo) {
    return this.temperatureSelected === btnNo;
  };

  IsNextButtonDisabled() {
    return (this.hazardousSelected == 0 || this.perishableSelected == 0 || this.temperatureSelected == 0) ? true : false;
  }


  OnNextClick() {
    this.updateQuoteModel();
    if (!this.hazardous && !this.perishable && !this.temperature) {
      this.helper.navigateTo(RoutingKey[PageState.SHIPMENT_DATE]);
      return;
    } else if (this.hazardous || this.perishable || this.temperature) {
      localStorage.setItem('uploadPageRedirectUrl', 'commodityCharacteristics');
      this.helper.navigateTo(RoutingKey[PageState.DOCUMENT_UPLOAD]);
      return;
    }
  }

  nextButtonClass() {
    if (!this.IsNextButtonDisabled()) {
      return " nextButtonEnabled upsSans_Bd";
    } else {
      return "btn_next upsSans_Bd";
    }
  }

  private save() {

    var self = this;

    if (localStorage.getItem('currentUserName1') == null) {
      localStorage.setItem('IsGuestUser', 'true');
      this.modallogin.show();
      return;
    }

    this.quoteService.save().subscribe(
      resdata => {

        if (resdata != null) {

          if (self.isSaveForLater) {
            this.clearModel();
            this.helper.navigateTo(RoutingKey[PageState.DASHBOARD]);
          }
        }
      }
    );
  }

  private saveForLater() {

    this.isSaveForLater = true;
    this.updateQuoteModel();
    this.save();

  }
  

  private back() {
    this.isSaveForLater = false;
    this.updateQuoteModel();
    this.helper.navigateTo(RoutingKey[PageState.SHIPMENT_COMMODITY]);
  }

  

  updateQuoteModel() {

    this.modelShipmentFrequency = this.perishableSelected;
    let quoteDetails = this.quoteService.getQuoteDetails() as IQuoteData;
    // quoteDetails.CommodityCharacteristics = {
    //   hazardousSelected: this.hazardousSelected,
    //   perishableSelected: this.perishableSelected,
    //   temperatureSelected: this.temperatureSelected
    // }; 
    quoteDetails.airFreightShipmentDetail[0].hazardousMaterialsIndicator =this.hazardousSelected;
    quoteDetails.airFreightShipmentDetail[0].perishableShipmentIndicator =this.perishableSelected;
    quoteDetails.airFreightShipmentDetail[0].temperatureControlShipmentIndicator =this.temperatureSelected;  
    quoteDetails.quoteRequestData.businessPartyNumber = localStorage.getItem('currentUserName1');
    this.quoteService.getQuoteDetails().quoteRequestData.lastVisitedPage = PageState.COMMODITY_CHARACTERISTICS;
    this.quoteService.setQuoteDetails(quoteDetails);
    return quoteDetails;
  }

  clearModel() {
    this.quoteService.resetQuoteModel();
  }
}
