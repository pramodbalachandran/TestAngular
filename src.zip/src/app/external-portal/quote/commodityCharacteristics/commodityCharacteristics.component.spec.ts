import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CommodityCharacteristicsComponent } from './commodityCharacteristics.component';

describe('CommodityCharacteristicsComponent', () => {
  let component: CommodityCharacteristicsComponent;
  let fixture: ComponentFixture<CommodityCharacteristicsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [CommodityCharacteristicsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CommodityCharacteristicsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeDefined();
  });
});
