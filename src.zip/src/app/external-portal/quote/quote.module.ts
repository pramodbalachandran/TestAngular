import { NgModule, CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA  } from '@angular/core';
import { routing } from './quote.routing';
import { HttpModule } from '@angular/http';
import { FormsModule,FormGroup } from '@angular/forms';
import { SharedModule } from '@app/shared/shared.module';

import { QuoteComponent } from './quote/quote.component';
import { ShipmentMovementComponent } from './shipmentmovement/shipmentmovement.component';
import { ShipmentFrequencyComponent } from './shipmentFrequency/shipmentFrequency.component';
import { SubmitServiceTypeComponent } from './submitServiceType/submitServiceType.component';
import { ShipmentspeedComponent } from './shipmentspeed/shipmentspeed.component';
import { ShipmentmeasurementComponent } from './shipmentmeasurement/shipmentmeasurement.component';
import { CommodityComponent } from './commodity/commodity.component';
import { CommodityCharacteristicsComponent } from './commodityCharacteristics/commodityCharacteristics.component';
import { ConfirmDetailsComponent } from './confirmDetails/confirmDetails.component';
import { ContactdetailsComponent } from './contactdetails/contactdetails.component';
import { DocumentUploadComponent } from './documentupload/documentupload.component';
import { MiscellaneousComponent } from './miscellaneous/miscellaneous.component';
import { ShipmentdateComponent } from './shipmentdate/shipmentdate.component';
import { QuoteRateComponent } from './quoterate/quoterate.component';
import { QuotesuccessComponent } from './quotesuccess/quotesuccess.component';
import { RequestPickupComponent } from './requestpickup/requestpickup.component';

@NgModule({
  imports: [routing, SharedModule, HttpModule],
  providers:[],
  declarations:
    [
      QuoteComponent,
      ShipmentMovementComponent,
      ShipmentFrequencyComponent,
      SubmitServiceTypeComponent,
      ShipmentspeedComponent,
      ShipmentmeasurementComponent,
      CommodityComponent,
      CommodityCharacteristicsComponent,
      ConfirmDetailsComponent,
      ContactdetailsComponent,
      DocumentUploadComponent,
      MiscellaneousComponent,
      ShipmentdateComponent,
      QuoteRateComponent,
      QuotesuccessComponent,
      RequestPickupComponent
    ],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA,
    NO_ERRORS_SCHEMA
  ]
})
export class QuoteExternalPortalModule {}
