import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { QuoteRateComponent } from './quoterate.component';

describe('QuoterateComponent', () => {
  let component: QuoteRateComponent;
  let fixture: ComponentFixture<QuoteRateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [QuoteRateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(QuoteRateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeDefined();
  });
});
