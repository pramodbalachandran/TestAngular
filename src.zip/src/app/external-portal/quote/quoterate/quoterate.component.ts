import { Component, OnInit, ViewChild } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

import { QuoteAPI } from '@app/shared/services';
import { IQuoteData, QuoteData, MBPRequest } from '@app/models/quotes/quote-data';
import { LocalStorageService } from '@app/shared/services';
import { UtilitiesService } from '@app/shared/services/shared/utilities.service';


import { ModalComponent } from '@app/shared/helper/modalpopup.component';
import { CustomModalComponent } from '@app/shared/components/custom-modal/custom-modal.component';
import { shipmentFrequencyType, PageState } from '@app/shared/services/shared/enum';
import { RoutingKey } from '@app/shared/services/shared/config.const';

//import * as saveAs from 'assets/js/FileSaver/FileSaver';
//import * as FileSaver from 'file-saver';
import * as FileSaver from "file-saver"
import print from 'print-js';
import { ResponseContentType } from '@angular/http';
import { toInteger } from '@ng-bootstrap/ng-bootstrap/util/util';



@Component({
  selector: 'pricing-quoterate',
  templateUrl: './quoterate.component.html',
  styleUrls: ['./quoterate.component.css']
})
export class QuoteRateComponent implements OnInit {
  @ViewChild('customModalDeclineQuote') modalDeclineQuote: CustomModalComponent;
  @ViewChild('customModalDeclineQuoteConfirmation') modalDeclineQuoteConfirmation: CustomModalComponent;
  @ViewChild('customModalOthers') modalOthers: CustomModalComponent;
  @ViewChild('modalLogin') modallogin: ModalComponent;
  @ViewChild('modalCMF') modalCMF: CustomModalComponent;
  @ViewChild('modalTermsAndConditions') modalTermsAndConditions: CustomModalComponent;

  private declineNote = '';
  private showRequestPickup: boolean;
  private movementTypeCode: number;
  private isAcceptChecked: boolean = false;
  private quoteRate: string = "$ 764.64";
  private marketRate: string;  
  private selectedRateTab: number = 1;
  private firstName: string;
  private isPARateFound: boolean;
  private isExistingRateActive: boolean = true;
  private quoteRateModel: IQuoteData;
  private downloadFile: string;
  private isUserProfileIsAssociatedWithCMF: boolean;
  private originText: string;
  private destinationText: string;
  private chargebaleWeightText: string;
  private serviceText: string;
  private mbpRequestObj: MBPRequest;
  private printFile: string;
  private chargebaleWeight: number = 0;
  private quoteAccessorialData:any;
  constructor(private router: Router, private quoteService: QuoteAPI<IQuoteData>, private localStorageService: LocalStorageService, private helper: UtilitiesService) { }

  ngOnInit() {
    localStorage.setItem("lastVisitedPage", PageState.QUOTE_RATE);
    // TODO - Make one of the tabe active by default, as per PA rate existance
    // TODO: Existing rate(PA) should be loaded from API
    this.showRequestPickupDropOffButton();
    this.firstName = localStorage.getItem('currentUserName1');  // TODO - CHANGE THIS TO FIRST NAME
    this.modalTermsAndConditions.hide();
    this.isUserProfileIsAssociatedWithCMF = false; // TODO - GET THIS VALUE FROM API
    if (this.isUserProfileIsAssociatedWithCMF) {
      this.PArateCheck();
    }

    //this.quoteRate = '0';

    this.quoteRateModel = this.quoteService.getQuoteDetails();
    this.movementTypeCode = this.quoteRateModel.airFreightShipmentDetail[0].movementTypeCode;
    this.mbpRequestObj = new MBPRequest();

    // Get weight dimensional or actual
    this.calculateChargeableWeight();

    // Get Market based price details from API
    this.getMBPDetails();
    this.getE2kRates();

    if (this.quoteRateModel && this.quoteRateModel.quoteRequestData && this.quoteRateModel.quoteRequestData.rateTabIndicator) {
        this.selectedRateTab = this.quoteRateModel.quoteRequestData.rateTabIndicator;
        this.isRateTabActive(this.selectedRateTab);
    } else {
        this.isRateTabActive(1);
    }

    this.populateQuoteDetails();

    ////this.downloadFile = "http://localhost:4200/assets/UPS_IPR_IAF.pdf";
    ////this.download();
  }

  toggleRateTab(btnNo) {
    this.selectedRateTab = btnNo;
    this.isExistingRateActive = this.selectedRateTab == 1 ? true : false;
  }

  isRateTabActive(btnNo) {
    return this.selectedRateTab == btnNo;
  }

  showRequestPickupDropOffButton() {
    this.movementTypeCode = this.quoteService.getQuoteDetails().airFreightShipmentDetail[0].movementTypeCode;

    /* movementTypeCode:
     * 1 - Airport-to-Airport
     * 2 - Door-to-Airport
     * 3 - Airport-to-Door
     * 4 - Door-to-Door
     * Show 'Request pickup' if Origin's movement type is Door
     * Show 'Request Drop off' if Origin's movement type is Airport
     */
    if (this.movementTypeCode == 1 || this.movementTypeCode == 3) {
      this.showRequestPickup = false;
    } else if (this.movementTypeCode == 2 || this.movementTypeCode == 4) {
      this.showRequestPickup = true;
    }
  }

  toggleAccept() {
    this.isAcceptChecked = !this.isAcceptChecked;
  }

  requestButtonClass() {
    if (this.isAcceptChecked) {
      return "btn-custom upsSans_Bd colorOrange";
    }
  }

  enableRequestButton() {
    return this.isAcceptChecked && this.selectedRateTab == (1 || 2);
  }

  showDeclinePopUp() {
    this.modalDeclineQuote.show();
  }

  onPreferCompetitorsRate() {
    this.updateQuoteModel(4, 1, '');
    if (localStorage.getItem('currentUserName1') == null) {
      this.modalDeclineQuote.hide();
      this.modalDeclineQuoteConfirmation.show();
    }
    else {
      this.quoteService.save()
        .subscribe(
          data => {
            this.modalDeclineQuote.hide();
            this.modalDeclineQuoteConfirmation.show();
          },
          error => {
            console.log(error);
          });
    }
  }
  print() {

    window.open(this.quoteService.printPdf(), "_blank");     

  }

  download() {  


    let URLToPDF = this.quoteService.downloadPDF()      

    var oReq = new XMLHttpRequest();
    // The Endpoint of your server 
   
    // Configure XMLHttpRequest
    oReq.open("GET", URLToPDF, true);

    // Important to use the blob response type
    oReq.responseType = "blob";

    // When the file request finishes
    // Is up to you, the configuration for error events etc.
    oReq.onload = function () {
      // Once the file is downloaded, open a new window with the PDF
      // Remember to allow the POP-UPS in your browser
      var file = new Blob([oReq.response], {
        type: 'application/pdf'
      });

      // Generate file download directly in the browser !

      if (localStorage.getItem('currentUserName1') == null)
        saveAs(file, "Guest" + "_quoteReport11.pdf");
      else
        saveAs(file, localStorage.getItem('currentUserName1') + "_quoteReport11.pdf");
      //for IE or edge
      //if (window.navigator && window.navigator.msSaveOrOpenBlob) {
      //  window.navigator.msSaveOrOpenBlob(file);
      //  return;
      //} 
    };
    oReq.send(); 

  }


 

  onShipmentNotReady() {
    this.updateQuoteModel(4, 2, '');
    if (localStorage.getItem('currentUserName1') == null) {
      this.modalDeclineQuote.hide();
      this.modalDeclineQuoteConfirmation.show();
    }
    else {
      this.quoteService.save()
        .subscribe(
          data => {
            this.modalDeclineQuote.hide();
            this.modalDeclineQuoteConfirmation.show();
          },
          error => {
            console.log(error);
          });
    }
  }

  onOthers() {
    this.declineNote = '';
    this.updateQuoteModel(4, 3, this.declineNote);
    this.modalDeclineQuote.hide();
    this.modalOthers.show();
  }

  declineNoteValueChange(e) {
    if (this.declineNote != undefined && this.declineNote != null) {
      this.declineNote = this.declineNote.toString().trim();
    }
  }

  onDeclineNoteSubmit() {
    this.updateQuoteModel(4, 3, this.declineNote);
    if (localStorage.getItem('currentUserName1') == null) {
      this.modalOthers.hide();
      this.modalDeclineQuoteConfirmation.show();
    }
    else {
      this.quoteService.save()
        .subscribe(
          data => {
            this.modalOthers.hide();
            this.modalDeclineQuoteConfirmation.show();
          },
          error => {
            console.log(error);
          });
    }
  }

  onCreateNewQuote() {
    this.helper.navigateTo(RoutingKey[PageState.QUOTE]);
  }

  onDone() {
    if (localStorage.getItem('currentUserName1') == null) {
      //this.router.navigate(['/login']);
      this.helper.navigateTo(RoutingKey[PageState.LOGIN]);
    }
    else {
      //this.router.navigate(['/dashboard']);
      this.helper.navigateTo(RoutingKey[PageState.DASHBOARD]);
    }
  }

  updateQuoteModel(statusCode, quoteDeclineReasonTypeCode, quoteDeclineReasonTypeNote) {
    let quoteData = this.quoteService.getQuoteDetails();
    quoteData.quoteRequestData.quoteStatusCode = statusCode;
    quoteData.quoteRequestData.quoteRate = this.selectedRateTab == 1 ? this.quoteRate : "0";
    quoteData.quoteRequestData.marketRate = this.selectedRateTab == 2 ? this.marketRate : "0";
    quoteData.quoteRequestData.rateTabIndicator = this.selectedRateTab;
    quoteData.quoteRequestData.quoteDeclineReasonTypeCode = quoteDeclineReasonTypeCode;
    quoteData.quoteRequestData.quoteDeclineReasonTypeNote = quoteDeclineReasonTypeNote;
    quoteData.quoteRequestData.lastVisitedPage = PageState.QUOTE_RATE;
    this.quoteService.setQuoteDetails(quoteData);
    return quoteData;
  }

  onQuoteDeclineGoback() {
    this.updateQuoteModel(2, 0, '');
    if (localStorage.getItem('currentUserName1') == null) {
      this.modalDeclineQuote.hide();
    }
    else {
      this.quoteService.save()
        .subscribe(
          data => {
            this.modalDeclineQuote.hide();
          },
          error => {
            console.log(error);
          });
    }
  }

  onOthersGoback() {
    this.modalOthers.hide();
  }

  saveForLater() {

    let quoteModel = this.updateQuoteModel(2, 0, '');
    if (quoteModel == null) {
      return;
    }

    if (localStorage.getItem('currentUserName1') == null) {
      //this.localStorageService.setItem('Quote', quoteModel);
      this.modallogin.show();
      return;
    }

    this.quoteService.save().subscribe(
      resdata => {

        if (resdata != null) {
          this.clearModel();
          //this.router.navigate(['/dashboard']);
          this.helper.navigateTo(RoutingKey[PageState.DASHBOARD]);
          return;
        }

      }
    );
  }


  clearModel() {
    this.quoteService.resetQuoteModel();
  }


  requestPickupOrDropoff() {
    if (localStorage.getItem('currentUserName1') == null) {
      // Guest user - TBD
      let quoteModel = this.updateQuoteModel(2, 0, '');

      this.localStorageService.setItem('Quote', quoteModel);
      localStorage.setItem("navigationAction", "requestPickupButton");
      this.modallogin.show();
      return;

    } else {
      // Registered user - quote status = accepted
      let quoteModel = this.updateQuoteModel(5, 0, '');
      this.quoteService.save().subscribe(
        resdata => {
          if (resdata != null) {
            //this.clearModel();
            this.helper.navigateTo(RoutingKey[PageState.REQUEST_PICKUP]);
            return;
          }
        }
      );
    }
  }

  onViewMarketRatePage() {
    this.modalCMF.hide();
    this.selectedRateTab = 1;
    //this.router.navigate(['/quoterate']);
    this.helper.navigateTo(RoutingKey[PageState.QUOTE_RATE]);
  }

  onContinue() {
    this.modalCMF.hide();
    //this.router.navigate(['/requestpickup']);
    this.helper.navigateTo(RoutingKey[PageState.REQUEST_PICKUP]);
  }

  PArateCheck() {
    this.isPARateFound = true; // TODO - change this to API returned value
    if (this.isPARateFound) {
      this.selectedRateTab = 1;
      this.modalCMF.show();
    } else {
      this.helper.navigateTo(RoutingKey[PageState.REQUEST_PICKUP]);
    }
  }

  onTermsAndConditionsClick() {
    this.modalTermsAndConditions.show();
  }

  /**
   * Method to populate quote related details
   **/
  populateQuoteDetails() {
    // Set origin and destination
    this.originText = this.quoteRateModel.airFreightShipmentDetail[0].originLocationPoliticalDivsion2Code ?
      (this.quoteRateModel.airFreightShipmentDetail[0].originLocationPoliticalDivsion2Code + ', ' + this.quoteRateModel.airFreightShipmentDetail[0].originLocationCountryCode) : '';
    this.destinationText = this.quoteRateModel.airFreightShipmentDetail[0].destinationLocationPoliticalDivsion2Code ?
      (this.quoteRateModel.airFreightShipmentDetail[0].destinationLocationPoliticalDivsion2Code + ', ' + this.quoteRateModel.airFreightShipmentDetail[0].destinationLocationCountryCode) : '';

    // Set service
    switch (this.quoteRateModel.airFreightShipmentDetail[0].shipmentSpeedType) {
      case "CA":
        this.serviceText = "Direct";
        break;
      case "CX":
        this.serviceText = "Premium Direct";
        break;
      case "EC":
        this.serviceText = "Consolidated";
        break;
    }

    // Get Chargeable Weight
    this.calculateChargeableWeight();
  }

  /**
   * Method to determine the Chargeable Weight (Dimensional Weight or Actual Weight, which ever is greater)
   **/
  calculateChargeableWeight() {
    let shipmentPieceDetails = this.quoteRateModel.airFreightShipmentDetail[0].shipmentWeightByPeice;
    let dimensionalWeight: number = 0;
    let actualWeight: number = 0;
    let totalActualWeight: number = 0;
    let totalDimensionalWeight: number = 0;

    if (shipmentPieceDetails && shipmentPieceDetails.length > 0) {
      for (let i = 0; i < shipmentPieceDetails.length; i++) {
        if (this.quoteRateModel.airFreightShipmentDetail[0].shipmentUnitOfMeasureTypeCode == 1) {
          // If user has entered dimensions in cm, Dimensional Weight in kg = (l*b*h)/6000
          dimensionalWeight = ((parseInt(shipmentPieceDetails[i].length) * parseInt(shipmentPieceDetails[i].width) * parseInt(shipmentPieceDetails[i].height)) / 6000) *
                               parseInt(shipmentPieceDetails[i].quantity);
          actualWeight = parseInt(shipmentPieceDetails[i].quantity) * parseInt(shipmentPieceDetails[i].weight);
        } else if (this.quoteRateModel.airFreightShipmentDetail[0].shipmentUnitOfMeasureTypeCode == 2) {
          // If user has entered dimensions in inches, Dimensional Weight in lbs = (l*b*h)/166
          dimensionalWeight = ((parseInt(shipmentPieceDetails[i].length) * parseInt(shipmentPieceDetails[i].width) * parseInt(shipmentPieceDetails[i].height)) / 166) *
                              parseInt(shipmentPieceDetails[i].quantity);
          actualWeight = parseInt(shipmentPieceDetails[i].quantity) * parseInt(shipmentPieceDetails[i].weight);
        } else if (this.quoteRateModel.airFreightShipmentDetail[0].shipmentUnitOfMeasureTypeCode == 3) {
          // If user has entered dimensions in inches, converts inches into cm and then Dimensional Weight in kg = (l*b*h)/6000
          dimensionalWeight = (((parseInt(shipmentPieceDetails[i].length) * 2.54) * (parseInt(shipmentPieceDetails[i].width) * 2.54) * (parseInt(shipmentPieceDetails[i].height) * 2.54)) / 6000) *
                              parseInt(shipmentPieceDetails[i].quantity);
          actualWeight = parseInt(shipmentPieceDetails[i].quantity) * parseInt(shipmentPieceDetails[i].weight);
        }

        totalActualWeight += actualWeight;
        totalDimensionalWeight += dimensionalWeight;
      }

      this.chargebaleWeight = totalDimensionalWeight > totalActualWeight ? parseInt(totalDimensionalWeight.toFixed(2)) : parseInt(totalActualWeight.toFixed(2));
      this.chargebaleWeightText = this.quoteRateModel.airFreightShipmentDetail[0].shipmentUnitOfMeasureTypeCode == 2 ?
                                  (this.chargebaleWeight > 0 ? this.chargebaleWeight : 0) + " lbs" :
                                  (this.chargebaleWeight > 0 ? this.chargebaleWeight : 0) + " kg";

      // Set MBP request object
      this.mbpRequestObj.ShipmentWeight = this.chargebaleWeight;

      if (this.quoteRateModel.airFreightShipmentDetail[0].movementTypeCode == 1) {
        this.mbpRequestObj.OriginCode = this.quoteRateModel.airFreightShipmentDetail[0].originAirport;
        this.mbpRequestObj.DestinationCode = this.quoteRateModel.airFreightShipmentDetail[0].destinationAirport;
      } else if (this.quoteRateModel.airFreightShipmentDetail[0].movementTypeCode == 2) {
        this.mbpRequestObj.OriginCode = this.quoteRateModel.airFreightShipmentDetail[0].originLocationPoliticalDivsion2Code;
        this.mbpRequestObj.DestinationCode = this.quoteRateModel.airFreightShipmentDetail[0].destinationAirport;
      } else if (this.quoteRateModel.airFreightShipmentDetail[0].movementTypeCode == 3) {
        this.mbpRequestObj.OriginCode = this.quoteRateModel.airFreightShipmentDetail[0].originAirport;
        this.mbpRequestObj.DestinationCode = this.quoteRateModel.airFreightShipmentDetail[0].destinationLocationPoliticalDivsion2Code;
      } else if (this.quoteRateModel.airFreightShipmentDetail[0].movementTypeCode == 4) {
        this.mbpRequestObj.OriginCode = this.quoteRateModel.airFreightShipmentDetail[0].originLocationPoliticalDivsion2Code;
        this.mbpRequestObj.DestinationCode = this.quoteRateModel.airFreightShipmentDetail[0].destinationLocationPoliticalDivsion2Code;
      } 

      this.mbpRequestObj.ServiceType = "AF";
      this.mbpRequestObj.MovementTypeCode = this.quoteRateModel.airFreightShipmentDetail[0].movementTypeCode;
    }
  }

  // Get MBP details from the API
  getMBPDetails() {
      this.quoteService.getMBPDetails(this.mbpRequestObj).subscribe(
        resdata => {
          if (resdata != null && resdata.MbpPrice != undefined && resdata.MbpPrice != "0") {
            let rate = parseInt(resdata.MbpPrice).toFixed(2);
            this.marketRate = (rate != undefined && rate.length > 0) ? '$' + rate : "$ 0.00";
          } else {
            this.marketRate = "$ 0.00";
          }
          return;
        }
      );
  }

  getE2kRates() {
    this.quoteService.getE2kRates().subscribe(
      resdata => {
        if (resdata != null ) {         
          this.quoteAccessorialData = resdata.responseData;
        } else {
          this.quoteAccessorialData = [];
        }
        return;
      }
    );
}

  /**
   * Icon class for source icon(globe or plane) which depends on page-3 selected tab value
   **/
  sourceIconClass() {
    return this.movementTypeCode == 1 || this.movementTypeCode == 3 ? "glyphicon glyphicon-plane fcolorGry modal-title" : "glyphicon glyphicon-globe fcolorGry modal-title";
  }

  /**
   * Icon class for destination icon(globe or plane) which depends on page-3 selected tab value
   **/
  destinationIconClass() {
    return this.movementTypeCode == 1 || this.movementTypeCode == 2 ? "glyphicon glyphicon-plane fcolorGry modal-title" : "glyphicon glyphicon-globe fcolorGry modal-title";
  }
}
