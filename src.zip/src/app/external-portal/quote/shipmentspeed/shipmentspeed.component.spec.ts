import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ShipmentspeedComponent } from './shipmentspeed.component';

describe('ShipmentspeedComponent', () => {
  let component: ShipmentspeedComponent;
  let fixture: ComponentFixture<ShipmentspeedComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ShipmentspeedComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ShipmentspeedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeDefined();
  });
});
