import { Component, OnInit,ViewChild } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

import { QuoteAPI } from '@app/shared/services';
import {IQuoteData,IQuoteListDetails} from '@app/models/quotes/quote-data'
import {IQuoteDetails} from '@app/models/quotes/quotes-details'
import {IAirFreightShipmentDetail} from '@app/models/quotes/airfreightshipment-detail'
import { ModalComponent } from '@app/shared/helper/modalpopup.component';
import { PageState } from '@app/shared/services/shared/enum';
import { RoutingKey } from '@app/shared/services/shared/config.const';
import { UtilitiesService } from '@app/shared/services/shared/utilities.service';

@Component({
  selector: 'pricing-shipmentspeed',
  templateUrl: './shipmentspeed.component.html',
  styleUrls: ['./shipmentspeed.component.css']
})
export class ShipmentspeedComponent implements OnInit {
  public body: HTMLBodyElement = document.getElementsByTagName('body')[0];
  @ViewChild('modalLogin') modallogin: ModalComponent;
  selectedSpeedType: string;
  selectedShipmentMovement:number;
  speedtype:number=0;
  colType:string;
  quoteId: string; 
  isSaveForLater: boolean = false;
  showLogin = false;
  constructor(private router: Router, private helper: UtilitiesService, private activatedRoute: ActivatedRoute,private quoteService: QuoteAPI<IQuoteData>) { }
  ngOnInit() {
    this.body.classList.remove('login-logo');
    this.selectedSpeedType = this.quoteService.getQuoteDetails().airFreightShipmentDetail[0].shipmentSpeedType;
    this.selectedShipmentMovement=this.quoteService.getQuoteDetails().airFreightShipmentDetail[0].movementTypeCode;
    if(this.selectedShipmentMovement==4)
        this.colType="col-md-4";
    else
        this.colType="col-md-6";


    switch (this.selectedSpeedType) {
      case 'CX': 
        this.speedtype = 1;
        break;
      case 'CA': 
        this.speedtype = 2;
        break;
      case 'EC': 
        this.speedtype = 3;
        break;
      default:
        this.speedtype = 0;
    }
  };
  
  SelectSpeedType(type) {
    if(type=="CX")
    {
      this.speedtype=1;
    }
    else if(type=="CA")
    {
      this.speedtype=2;
    }
    else if(type=="EC")
    {
      this.speedtype=3;
    }
    this.selectedSpeedType = type;
  };
  nextButtonClass() {
    if (this.speedtype>0) {
      return "nextButtonEnabled upsSans_Bd";
    } else {
      return "btn_next upsSans_Bd";
    }
  };
  IsNextButtonDisabled() {
    return (this.speedtype == 0 ) ? true : false;
  }

  OnNextClick() {
    this.updateQuoteModel();
    this.helper.navigateTo(RoutingKey[PageState.MISCELLANEOUS]);
  }
  private back() {
    this.isSaveForLater = false;
    this.updateQuoteModel();
    this.helper.navigateTo(RoutingKey[PageState.SHIPMENT_DATE]);
  }
  updateQuoteModel() {
    let quoteDetails = this.quoteService.getQuoteDetails() as IQuoteData;
    quoteDetails.airFreightShipmentDetail[0].shipmentSpeedType = this.selectedSpeedType;
    this.quoteService.getQuoteDetails().quoteRequestData.lastVisitedPage = PageState.SHIPMENT_SPEED;
   
    this.quoteService.setQuoteDetails(quoteDetails);
    return quoteDetails;
  }
  private saveForLater() {
    this.isSaveForLater = true;
    this.updateQuoteModel();
    this.save();
  }
  private save() {

    var self = this;

    if (localStorage.getItem('currentUserName1') == null) {
      this.showLogin = true;
      this.modallogin.show();
      return;
    }

    this.quoteService.save().subscribe(
      resdata => {
        if (resdata != null) {
          if (self.isSaveForLater) {
            this.quoteService.resetQuoteModel();
            this.helper.navigateTo(RoutingKey[PageState.DASHBOARD]);
          }
        }
      }
    );
  }
}
