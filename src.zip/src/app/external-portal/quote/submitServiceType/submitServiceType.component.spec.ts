import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';

import { SubmitServiceTypeComponent } from './submitServiceType.component';

describe('ShipmentmeasurementComponent', () => {
  let component: SubmitServiceTypeComponent;
  let fixture: ComponentFixture<SubmitServiceTypeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [SubmitServiceTypeComponent],
      schemas: [NO_ERRORS_SCHEMA]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SubmitServiceTypeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create the SubmitServiceType App', () => {
    expect(component).toBeDefined();
  });
});
