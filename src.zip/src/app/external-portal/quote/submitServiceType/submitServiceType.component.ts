import { Component, OnInit,Input } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';


import { QuoteDetail } from '@app/shared/interfaces/entities.interface';
import { QuoteAPI } from '@app/shared/services';
import { UtilitiesService } from '@app/shared/services/shared/utilities.service';

import {IQuoteData,IQuoteListDetails} from '@app/models/quotes/quote-data'
import {IQuoteDetails} from '@app/models/quotes/quotes-details'
import { IAirFreightShipmentDetail } from '@app/models/quotes/airfreightshipment-detail'
import { shipmentServiceType, PageState } from '@app/shared/services/shared/enum';
import { ApplicationUrls, RoutingKey } from '@app/shared/services/shared/config.const';


@Component({
  selector: 'pricing-submitServiceType',
  templateUrl: './submitServiceType.component.html',
  styleUrls: ['./submitServiceType.component.scss'],
  providers: []
})
export class SubmitServiceTypeComponent implements OnInit {
  body: HTMLBodyElement = document.getElementsByTagName('body')[0];
  @Input('isNewQuote') isNewQuote: boolean;
  modelShipmentServiceType: any = {};
  selectedServiceType: number = 0;
  quoteId: string; 

  constructor(private activatedRoute: ActivatedRoute, private quoteService: QuoteAPI<IQuoteData>,
    private helper: UtilitiesService)
  { }

  ngOnInit() {
    this.body.classList.remove('login-logo');
    //if clicked on GetQuote or Create Quote Button from top.
    if (this.isNewQuote) {
      this.clearModel();
    }
    //if you are comming from dashboard

    //if (this.activatedRoute.snapshot.params['id'] != null) {
    //  this.quoteId = this.activatedRoute.snapshot.params['id'];
    //  this.GetQuoteDetailsbyQuoteId(this.quoteId);
    //}
    //else {
      this.modelShipmentServiceType = this.quoteService.getQuoteDetails().quoteRequestData.quoteServiceType;

    if (this.modelShipmentServiceType !=null)
      this.selectedServiceType = parseInt(this.modelShipmentServiceType);
        else
      this.selectedServiceType = 0;     
   // }    
  }

  //GetQuoteDetailsbyQuoteId(quoteId: string) {

  //  var objData =
  //  {
  //    "quoteNumber": quoteId
  //  }

  //  this.quoteService.GetQuoteDetailsbyQuoteId(objData).subscribe(
  //    resdata => {
  //      if (resdata != null ) {
  //        var qouteData=resdata as IQuoteData;
  //        this.quoteService.resetQuoteModel();
  //        this.quoteService.setQuoteDetails(qouteData);
  //        if (this.quoteService.getQuoteDetails().quoteRequestData!=null)
  //        this.selectedServiceType = parseInt(this.quoteService.getQuoteDetails().quoteRequestData.quoteServiceType);
  //      }
  //    }
  //  );
  //}

  onNavigateForOcean() {
    window.open(ApplicationUrls[0].oceanFreightUrl, "_blank");
  }


  onNavigateForDomestic() {
    window.open(ApplicationUrls[1].domesticFreightUrl, "_blank");    
  }

  SelectServiceType(btnNo) {
    this.selectedServiceType = btnNo;
    this.modelShipmentServiceType = btnNo;
  };

  IsButtonActive(btnNo) {
    return this.selectedServiceType === btnNo;
  };

  IsNextButtonDisabled() {
    return (this.selectedServiceType == 0 || !this.selectedServiceType) ? true : false;
  }

  nextButtonClass() {
    if (this.selectedServiceType) {
      return "nextButtonEnabled upsSans_Bd";
    } else {
      return "btn_next upsSans_Bd";
    }
  }

  OnNextClick() {

    switch (this.selectedServiceType) {
      case shipmentServiceType.OceanFreight:
        this.onNavigateForOcean();
        break;
      case shipmentServiceType.AirFreight:
        this.updateQuoteModel();
        this.helper.navigateTo(RoutingKey[PageState.SHIPMENT_FREQUENCY]);
        //this.router.navigate(['/shipmentFrequency']);
        break;
      case shipmentServiceType.Domestic:
        this.onNavigateForDomestic();
        break;
    }
  }

  updateQuoteModel() {
    this.modelShipmentServiceType = this.selectedServiceType.toString();
    let quoteDetails = this.quoteService.getQuoteDetails() as IQuoteData;
    quoteDetails.quoteRequestData.quoteServiceType = this.modelShipmentServiceType?this.modelShipmentServiceType:'';
    quoteDetails.quoteRequestData.quoteNumber = this.quoteId ? this.quoteId : '';
    if (quoteDetails.airFreightShipmentDetail.length == 0) {
      quoteDetails.airFreightShipmentDetail.push(this.quoteService.getEmptyAirFreightShipmentDetail());
    }
    quoteDetails.airFreightShipmentDetail[0].quoteIdentificationNumber = this.quoteId;
    this.quoteService.getQuoteDetails().quoteRequestData.lastVisitedPage = PageState.SUBMIT_SERVICE_TYPE;
    this.quoteService.setQuoteDetails(quoteDetails);
    return quoteDetails;
  }

  clearModel() {
    this.quoteService.resetQuoteModel();
  }
}
