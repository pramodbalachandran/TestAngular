import { Component, OnInit,ViewChild } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

import { QuoteDetail, ShipmentPieceDetails1, shipmentPieceDetailsText } from '@app/shared/interfaces/entities.interface';
import { QuoteAPI } from '@app/shared/services';
import { IQuoteData, IQuoteListDetails } from '@app/models/quotes/quote-data';
import { forEach } from '@angular/router/src/utils/collection';
import { LocalStorageService } from '@app/shared/services';
import { ModalComponent } from '@app/shared/helper/modalpopup.component';
import { PageState } from '@app/shared/services/shared/enum';
import { RoutingKey } from '@app/shared/services/shared/config.const';
import { UtilitiesService } from '@app/shared/services/shared/utilities.service';

const monthNames = ["January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December"
];

@Component({
  selector: 'confirmDetails',
  templateUrl: './confirmDetails.component.html',
  styleUrls: ['./confirmDetails.component.scss'],
  providers: []
})
export class ConfirmDetailsComponent implements OnInit {
  @ViewChild('modalLogin') modallogin: ModalComponent;
  modelShipmentFrequency: any = {};
  private hazardousSelected: Number;
  private perishableSelected: Number;
  private temperatureSelected: Number;
  private hazardous: boolean = false;
  private perishable : boolean = false;
  private temperature: boolean = false;
  private isSaveForLater: boolean = false;
  private quoteDetail: IQuoteData;
  private shipmentType: string;
  private quoteServiceType: string;
  private shipmentMovementText: string;
  private selectedSpeedType: string;
  private originAddressLine1: string;
  private originAddressLine2: string;
  private originAddressLine3: string;
  private originAddressDoor: string;  
  private destinationAddressLine1: string;
  private destinationAddressLine2: string;
  private destinationAddressLine3: string;
  private destinationAddressDoor: string;
  private packageType: string;
  private quantity: string;
  private peiceLength: string;
  private peicewidth: string;
  private peiceHeight: string;
  private peiceWeight: string;
  private totalWeight: string;
  private showTotalWeight: boolean = false;
  private shipmentPieceDetails: ShipmentPieceDetails1[];
  private commodityTypeCode: string;
  private commodityTypeDescriptionText: string;
  private shipmentValue: string;
  private hazardousMaterialsText: string;
  private temperatureControlShipmentText: string;
  private perishableShipmentText: string;
  private shipmentReadyDate: Date;
  private shipmentInsuranceText: string;
  private shipmentCurrencyCode: string = "USD";
  private currencyCodeText: string;
  private shipmentValueIndicator: number = 1;
  private paymentText: string;
  private customerBrokerText: string;
  private movementTypeCode: number;
  private destinationAirport: string;
  private originAirport: string;
  private shipmentPieceDetailsText: shipmentPieceDetailsText[];
  private shipmentUnitWeightText: string;
  private shipmentUnitLengthText: string;
  private shipmentSpeedText: string = "";
  private commodityProductList: string;
  shipmentReadyformattedDate: string;

  constructor(private router: Router, private helper: UtilitiesService,private route: ActivatedRoute, private quoteService: QuoteAPI<IQuoteData>,private localStorageService: LocalStorageService)
  { }

  ngOnInit() {
    this.quoteDetail = this.quoteService.getQuoteDetails();

    // Page 1 data - Service Type
    if (this.quoteDetail.quoteRequestData.quoteServiceType == "2") {
      this.quoteServiceType = "International Air Freight";
    }

    // Page 2 data - Shipment Type
    if (this.quoteDetail.quoteRequestData.quoteTypeCode == 1) {
      this.shipmentType = "One Time";
    }

    // Page 3 data - Movement Type
    this.movementTypeCode = this.quoteDetail.airFreightShipmentDetail[0].movementTypeCode;

    if (this.movementTypeCode == 1) {
        this.shipmentMovementText = "Airport-to-Airport";
        this.originAirport = this.quoteDetail.airFreightShipmentDetail[0].originAirport +
                            (this.quoteDetail.airFreightShipmentDetail[0].originLocationPoliticalDivsion2Code ? ', ' + this.quoteDetail.airFreightShipmentDetail[0].originLocationPoliticalDivsion2Code : '') +
                            (this.quoteDetail.airFreightShipmentDetail[0].originLocationCountryCode ? ', ' + this.quoteDetail.airFreightShipmentDetail[0].originLocationCountryCode : '') +
                            (this.quoteDetail.airFreightShipmentDetail[0].originAirportName ? ', ' + this.quoteDetail.airFreightShipmentDetail[0].originAirportName : '');

        this.destinationAirport = this.quoteDetail.airFreightShipmentDetail[0].destinationAirport +
                            (this.quoteDetail.airFreightShipmentDetail[0].destinationLocationPoliticalDivsion2Code ? ', ' + this.quoteDetail.airFreightShipmentDetail[0].destinationLocationPoliticalDivsion2Code : '') +
                            (this.quoteDetail.airFreightShipmentDetail[0].destinationLocationCountryCode ? ', ' + this.quoteDetail.airFreightShipmentDetail[0].destinationLocationCountryCode : '') +
                            (this.quoteDetail.airFreightShipmentDetail[0].destinationAirportName ? ', ' + this.quoteDetail.airFreightShipmentDetail[0].destinationAirportName : '');
    } else if(this.movementTypeCode == 2) {
        this.shipmentMovementText = "Door-to-Airport";
        this.originAddressLine1 = (this.quoteDetail.airFreightShipmentDetail[0].originAddressLine1Text ? this.quoteDetail.airFreightShipmentDetail[0].originAddressLine1Text : '');
        this.originAddressLine2 = (this.quoteDetail.airFreightShipmentDetail[0].originAddressLine2Text ? this.quoteDetail.airFreightShipmentDetail[0].originAddressLine2Text : '');
        this.originAddressLine3 = (this.quoteDetail.airFreightShipmentDetail[0].originAddressLine3Text ? this.quoteDetail.airFreightShipmentDetail[0].originAddressLine3Text : '');
        this.originAddressDoor = this.quoteDetail.airFreightShipmentDetail[0].originLocationPoliticalDivsion2Code +
                                 ((this.quoteDetail.airFreightShipmentDetail[0].originPoliticalDivision1Name && this.quoteDetail.airFreightShipmentDetail[0].originPoliticalDivision1Name != "0") ?
                                   ', ' + this.quoteDetail.airFreightShipmentDetail[0].originPoliticalDivision1Name + ' ' + this.quoteDetail.airFreightShipmentDetail[0].originLocationPostalCode : '') +
                                 (this.quoteDetail.airFreightShipmentDetail[0].originLocationCountryCode ? ', ' + this.quoteDetail.airFreightShipmentDetail[0].originLocationCountryCode : '');

        this.destinationAirport = this.quoteDetail.airFreightShipmentDetail[0].destinationAirport +
                                  (this.quoteDetail.airFreightShipmentDetail[0].destinationLocationPoliticalDivsion2Code ? ', ' + this.quoteDetail.airFreightShipmentDetail[0].destinationLocationPoliticalDivsion2Code : '') +
                                  (this.quoteDetail.airFreightShipmentDetail[0].destinationLocationCountryCode ? ', ' + this.quoteDetail.airFreightShipmentDetail[0].destinationLocationCountryCode : '') +
                                  (this.quoteDetail.airFreightShipmentDetail[0].destinationAirportName ? ', ' + this.quoteDetail.airFreightShipmentDetail[0].destinationAirportName : '');
    } else if (this.movementTypeCode == 3) {
        this.shipmentMovementText = "Airport-to-Door";
        this.originAirport = this.quoteDetail.airFreightShipmentDetail[0].originAirport +
                             (this.quoteDetail.airFreightShipmentDetail[0].originLocationPoliticalDivsion2Code ? ', ' + this.quoteDetail.airFreightShipmentDetail[0].originLocationPoliticalDivsion2Code : '') +
                             (this.quoteDetail.airFreightShipmentDetail[0].originLocationCountryCode ? ', ' + this.quoteDetail.airFreightShipmentDetail[0].originLocationCountryCode : '') +
                             (this.quoteDetail.airFreightShipmentDetail[0].originAirportName ? ', ' + this.quoteDetail.airFreightShipmentDetail[0].originAirportName : '');

        this.destinationAddressLine1 = (this.quoteDetail.airFreightShipmentDetail[0].destinationAddressLine1Text ? this.quoteDetail.airFreightShipmentDetail[0].destinationAddressLine1Text : '');
        this.destinationAddressLine2 = (this.quoteDetail.airFreightShipmentDetail[0].destinationAddressLine2Text ? this.quoteDetail.airFreightShipmentDetail[0].destinationAddressLine2Text : '');
        this.destinationAddressLine3 = (this.quoteDetail.airFreightShipmentDetail[0].destinationAddressLine3Text ? this.quoteDetail.airFreightShipmentDetail[0].destinationAddressLine3Text : '');
        this.destinationAddressDoor  = this.quoteDetail.airFreightShipmentDetail[0].destinationLocationPoliticalDivsion2Code +
                                       ((this.quoteDetail.airFreightShipmentDetail[0].destinationPoliticalDivision1Name && this.quoteDetail.airFreightShipmentDetail[0].destinationPoliticalDivision1Name != "0") ?
                                       ', ' + this.quoteDetail.airFreightShipmentDetail[0].destinationPoliticalDivision1Name + ' ' + this.quoteDetail.airFreightShipmentDetail[0].destinationLocationPostalCode : '') +
                                       (this.quoteDetail.airFreightShipmentDetail[0].destinationLocationCountryCode ? ', ' + this.quoteDetail.airFreightShipmentDetail[0].destinationLocationCountryCode : '');

    } else if (this.movementTypeCode == 4) {
        this.shipmentMovementText = "Door-to-Door";
        this.originAddressLine1 = (this.quoteDetail.airFreightShipmentDetail[0].originAddressLine1Text ? this.quoteDetail.airFreightShipmentDetail[0].originAddressLine1Text : '');
        this.originAddressLine2 = (this.quoteDetail.airFreightShipmentDetail[0].originAddressLine2Text ? this.quoteDetail.airFreightShipmentDetail[0].originAddressLine2Text : '');
        this.originAddressLine3 = (this.quoteDetail.airFreightShipmentDetail[0].originAddressLine3Text ? this.quoteDetail.airFreightShipmentDetail[0].originAddressLine3Text : '');
        this.originAddressDoor  = this.quoteDetail.airFreightShipmentDetail[0].originLocationPoliticalDivsion2Code +
                                  ((this.quoteDetail.airFreightShipmentDetail[0].originPoliticalDivision1Name && this.quoteDetail.airFreightShipmentDetail[0].originPoliticalDivision1Name != "0") ?
                                    ', ' + this.quoteDetail.airFreightShipmentDetail[0].originPoliticalDivision1Name + ' ' + this.quoteDetail.airFreightShipmentDetail[0].originLocationPostalCode : '') +
                                  (this.quoteDetail.airFreightShipmentDetail[0].originLocationCountryCode ? ', ' + this.quoteDetail.airFreightShipmentDetail[0].originLocationCountryCode : '');

        this.destinationAddressLine1 = (this.quoteDetail.airFreightShipmentDetail[0].destinationAddressLine1Text ? this.quoteDetail.airFreightShipmentDetail[0].destinationAddressLine1Text : '');
        this.destinationAddressLine2 = (this.quoteDetail.airFreightShipmentDetail[0].destinationAddressLine2Text ? this.quoteDetail.airFreightShipmentDetail[0].destinationAddressLine2Text : '');
        this.destinationAddressLine3 = (this.quoteDetail.airFreightShipmentDetail[0].destinationAddressLine3Text ? this.quoteDetail.airFreightShipmentDetail[0].destinationAddressLine3Text : '');
        this.destinationAddressDoor  = this.quoteDetail.airFreightShipmentDetail[0].destinationLocationPoliticalDivsion2Code +
                                       ((this.quoteDetail.airFreightShipmentDetail[0].destinationPoliticalDivision1Name && this.quoteDetail.airFreightShipmentDetail[0].destinationPoliticalDivision1Name != "0") ?
                                         ', ' + this.quoteDetail.airFreightShipmentDetail[0].destinationPoliticalDivision1Name + ' ' + this.quoteDetail.airFreightShipmentDetail[0].destinationLocationPostalCode : '') +
                                       (this.quoteDetail.airFreightShipmentDetail[0].destinationLocationCountryCode ? ', ' + this.quoteDetail.airFreightShipmentDetail[0].destinationLocationCountryCode : '');
    }

    // Page 4 data - Piece Type
    if (this.quoteDetail.airFreightShipmentDetail[0].shipmentUnitOfMeasureTypeCode == 1) {
      this.shipmentUnitWeightText = "kg";
      this.shipmentUnitLengthText = "cm";
    } else if (this.quoteDetail.airFreightShipmentDetail[0].shipmentUnitOfMeasureTypeCode == 2) {
      this.shipmentUnitWeightText = "lb";
      this.shipmentUnitLengthText = "in";
    } else if (this.quoteDetail.airFreightShipmentDetail[0].shipmentUnitOfMeasureTypeCode == 3) {
      this.shipmentUnitWeightText = "kg";
      this.shipmentUnitLengthText = "in";
    }

    this.shipmentPieceDetails = this.quoteDetail.airFreightShipmentDetail[0].shipmentWeightByPeice;
    this.shipmentPieceDetailsText = [];
    if (this.shipmentPieceDetails && this.shipmentPieceDetails.length > 0) {
      for (let i = 0; i < this.shipmentPieceDetails.length; i++) {
        this.shipmentPieceDetailsText.push({
          quantityText: this.shipmentPieceDetails[i].quantity + " " + this.shipmentPieceDetails[i].packageType,
          measurementText: this.shipmentPieceDetails[i].length + " " + this.shipmentUnitLengthText + " x " + this.shipmentPieceDetails[i].width + " " + this.shipmentUnitLengthText + " x " + this.shipmentPieceDetails[i].height + " " + this.shipmentUnitLengthText + " each",
          weightText: this.shipmentPieceDetails[i].weight + " " + this.shipmentUnitWeightText + " each"
        });
      }
    }
    
    if (this.quoteDetail.airFreightShipmentDetail[0].totalWeight != "0") {
        this.totalWeight = this.quoteDetail.airFreightShipmentDetail[0].totalWeight;
        this.showTotalWeight = true;
    }

    // Page 5 data - Commodity & value
    if (this.quoteDetail.airFreightShipmentDetail[0].commodityTypeCode) {
      this.commodityTypeCode = this.quoteDetail.airFreightShipmentDetail[0].commodityTypeCode;
      this.commodityTypeDescriptionText = this.quoteDetail.airFreightShipmentDetail[0].commodityTypeDescriptionText;
      this.shipmentValue = this.quoteDetail.airFreightShipmentDetail[0].shipmentValue ? this.quoteDetail.airFreightShipmentDetail[0].shipmentValue : "Not Provided";
    }

    if (this.quoteDetail.airFreightShipmentDetail[0].commodityNameList != null && this.quoteDetail.airFreightShipmentDetail[0].commodityNameList.length > 0) {
      
      var arr = new Array();
      this.quoteDetail.airFreightShipmentDetail[0].commodityNameList.forEach(function (product) {
        arr.push(product.commodityName.toString());
        });
      this.commodityProductList = arr.join();
    }       


    // Page 6 data - Special Requirement
    if (this.quoteDetail.airFreightShipmentDetail[0].hazardousMaterialsIndicator == 2) {
      this.hazardousMaterialsText = "Not Hazardous";
    }

    if (this.quoteDetail.airFreightShipmentDetail[0].perishableShipmentIndicator == 2) {
      this.perishableShipmentText = "Not Perishable";
    }

    if (this.quoteDetail.airFreightShipmentDetail[0].temperatureControlShipmentIndicator == 2) {
      this.temperatureControlShipmentText = "Not Temperature";
    }

    // Page 7 data - Ready Date
    this.shipmentReadyDate = this.quoteDetail.airFreightShipmentDetail[0].shipmentReadyDate;
    this.shipmentReadyformattedDate = this.getFormattedDate(this.shipmentReadyDate);

    // Page 8 data - Speed -shipmentSpeedType CX , CA, EC - uncomment the below code once the 'shipmentSpeedType' is available in 'airFreightShipmentDetail' collection
    if (this.quoteDetail.airFreightShipmentDetail[0].shipmentSpeedType == "CX") {
      this.shipmentSpeedText = "Speed is most important";
    } else if (this.quoteDetail.airFreightShipmentDetail[0].shipmentSpeedType == "CA") {
      this.shipmentSpeedText = "Both price and speed are equally important";
    } else if (this.quoteDetail.airFreightShipmentDetail[0].shipmentSpeedType == "EC") {
      this.shipmentSpeedText = "Price is most important";
    }

    // Page 9 data - Insurance
    if (this.quoteDetail.airFreightShipmentDetail[0].shipmentInsuranceIndicator == 1) {
      this.shipmentInsuranceText = "Yes: Value:" + this.selectedCurrenySymbol(this.quoteDetail.airFreightShipmentDetail[0].shipmentCurrencyCode) + this.quoteDetail.airFreightShipmentDetail[0].shipmentInsuredValueAmount;
    } else if (this.quoteDetail.airFreightShipmentDetail[0].shipmentInsuranceIndicator == 2) {
      this.shipmentInsuranceText = "No";
    }

    // Page 9 data - Custom Broker
    if (this.quoteDetail.airFreightShipmentDetail[0].isCustomerBroker == 1) {
      this.customerBrokerText = "UPS";
    } else if (this.quoteDetail.airFreightShipmentDetail[0].isCustomerBroker == 2) {
      this.customerBrokerText = "Others";
    }

    // Page 9 data - Payment
    this.paymentText = this.quoteDetail.airFreightShipmentDetail[0].paymentTermTypeCode;
  }

  selectedCurrenySymbol(currencyCode) {
    switch (currencyCode) {
      case "USD":
      case "usd":
        this.currencyCodeText = "$";
        break;
      default:
        this.currencyCodeText = "";
    }
    return this.currencyCodeText;
  }

  SaveForLater() {
    this.isSaveForLater = true;
    let quoteModel = this.updateQuoteModel(1);
    if (quoteModel == null) {
      console.log('No Data');
      return;
    }
    if(localStorage.getItem('currentUserName1') == null) {
      localStorage.setItem('IsGuestUser', 'true');
      this.modallogin.show();
      return;
    }
    else{
        this.quoteService.save()
          .subscribe(
            data => {
              if (data != null) {

                this.clearModel();
                this.helper.navigateTo(RoutingKey[PageState.DASHBOARD]);
                return;
              }
            },
            error => {

            });
      }
  }
  clearModel() {
    this.quoteService.resetQuoteModel();
  }

  OnGetQuoteClick() {
    this.updateQuoteModel(2);
    this.save();
    this.helper.navigateTo(RoutingKey[PageState.QUOTE_RATE]);
    return;
  }

  nextButtonClass() {
      return " nextButtonEnabled upsSans_Bd";
  }

   private save() {
    this.quoteService.save().subscribe(
      resdata => {

        if (resdata['results'] != null && resdata['results'].length > 0) {
        }
      }
    );

  }

  private back() {
    this.helper.navigateTo(RoutingKey[PageState.MISCELLANEOUS]);
  }


  updateQuoteModel(statusCode:number) {
    let quoteModel = this.quoteService.getQuoteDetails();
    quoteModel.quoteRequestData.quoteStatusCode = statusCode ;
    quoteModel.quoteRequestData.lastVisitedPage = PageState.CONFIRM_DETAILS;
    this.quoteService.setQuoteDetails(quoteModel);
    return quoteModel;
  }

  getFormattedDate(dt) {
    if (!dt) {
      return;
    }
    dt = new Date(dt);
    return monthNames[dt.getMonth()] + ' ' + dt.getDate() + ', ' + dt.getFullYear();
  }
}
