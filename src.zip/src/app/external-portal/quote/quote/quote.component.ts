import { Component, OnInit } from '@angular/core';
@Component({
  selector: 'pricing-quote',
  templateUrl: './quote.component.html',
  styleUrls: ['./quote.component.scss'],
})
export class QuoteComponent implements OnInit {
  public body: HTMLBodyElement = document.getElementsByTagName('body')[0];
  private isNewQuote: boolean= true;

  constructor() {}

  ngOnInit() {
    this.body.classList.remove('login-logo');
  }

  gotoNext() {
    
  }
}
