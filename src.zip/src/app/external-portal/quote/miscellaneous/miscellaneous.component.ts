import { Component, OnInit, ViewChild } from '@angular/core';
import { DataTableModule } from 'angular-6-datatable';
import { QuoteAPI } from '@app/shared/services';
import { Router, ActivatedRoute } from '@angular/router';
import { retry } from 'rxjs/operators';
import { LocalStorageService } from '@app/shared/services';
import { ModalComponent } from '@app/shared/helper/modalpopup.component';
import { IQuoteData } from '@app/models/quotes/quote-data';
import { PageState } from '@app/shared/services/shared/enum';
import { RoutingKey } from '@app/shared/services/shared/config.const';
import { UtilitiesService } from '@app/shared/services/shared/utilities.service';

@Component({
  selector: 'pricing-miscellaneous',
  templateUrl: './miscellaneous.component.html',
  styleUrls: ['./miscellaneous.component.css']
})

export class MiscellaneousComponent implements OnInit {
  @ViewChild('modalLogin') modallogin: ModalComponent;

  private paymentSelected = '';
  private customsBrokerSelected:number = -1;
  private shipmentInsuranceSelected:number = -1;

  private model = { ShipmentInsuredValue: '', ShipmentCurrency: 'USD' };
  private quoteModel: IQuoteData;

  constructor(private router: Router, private helper: UtilitiesService,private quoteService: QuoteAPI<IQuoteData>, private localStorageService: LocalStorageService) {
    
  }

  ngOnInit() {
    this.quoteModel = this.quoteService.getQuoteDetails();
    if (this.quoteModel && this.quoteModel.airFreightShipmentDetail) {
      this.model.ShipmentCurrency = this.quoteModel.airFreightShipmentDetail[0].shipmentCurrencyCode;
      this.model.ShipmentInsuredValue = this.quoteModel.airFreightShipmentDetail[0].shipmentInsuredValueAmount;
    }

    this.setPaymentOptionValue();
    this.setCustomsBrokerValue();
    this.setInsuranceOptionValue();
  }


  setPaymentOptionValue() {
    this.paymentSelected = this.quoteModel.airFreightShipmentDetail[0].paymentTermTypeCode;
  }

  setCustomsBrokerValue() {
    this.customsBrokerSelected = this.quoteModel.airFreightShipmentDetail[0].isCustomerBroker;
  }

  setInsuranceOptionValue() {
    this.shipmentInsuranceSelected = this.quoteModel.airFreightShipmentDetail[0].shipmentInsuranceIndicator;
  }

  setSelectedPaymentOption(value) {
    if (value == this.paymentSelected) {
      return;
    }
    this.paymentSelected = value;
  }

  setSelectedCustomsBrokerOption(value) {
    if (value == this.customsBrokerSelected) {
      return;
    }
    this.customsBrokerSelected = value == 'Yes' ? 1 : 2;
  }

  setSelectedShipmentInsuranceOption(value) {
    if (value == this.shipmentInsuranceSelected) {
      return;
    }
    this.shipmentInsuranceSelected = value == 'Yes' ? 1 :2;
  }

  getPaymentSelectedValue() {
    return this.paymentSelected;
  }

  getCustomsBrokerSelectedValue() {
    return this.customsBrokerSelected;
  }

  getShipmentInsuranceSelectedValue() {
    return this.shipmentInsuranceSelected;
  }

  isValidData() {
    if (this.paymentSelected == '' || this.customsBrokerSelected == 0 || this.shipmentInsuranceSelected==0) {
      return false;
    }

    if (this.shipmentInsuranceSelected==1) {
      if (this.model.ShipmentInsuredValue == '') {
        return false;
      }
    }
    
    return true;
  }

  gotToNext() {
    this.updateQuoteModel();
    this.helper.navigateTo(RoutingKey[PageState.CONFIRM_DETAILS]);
  }

  updateQuoteModel() {
    let quoteModel = this.quoteService.getQuoteDetails();
    quoteModel.airFreightShipmentDetail[0].shipmentInsuredValueAmount = this.model.ShipmentInsuredValue;
    quoteModel.airFreightShipmentDetail[0].isCustomerBroker = this.getCustomsBrokerSelectedValue();
    quoteModel.airFreightShipmentDetail[0].shipmentInsuranceIndicator = this.getShipmentInsuranceSelectedValue();
    quoteModel.airFreightShipmentDetail[0].paymentTermTypeCode = this.getPaymentSelectedValue();
    this.quoteService.getQuoteDetails().quoteRequestData.lastVisitedPage = PageState.MISCELLANEOUS;

    this.quoteService.setQuoteDetails(quoteModel);
    return quoteModel;
  }

  onGoback() {
    this.updateQuoteModel();
    this.helper.navigateTo(RoutingKey[PageState.SHIPMENT_SPEED]);
  }

  onSaveLater() {

    let quoteModel = this.updateQuoteModel();
    if (quoteModel == null) {
      console.log('No Data');
      return;
    }

    if (localStorage.getItem('currentUserName1') == null) {
      localStorage.setItem('IsGuestUser', 'true');
      this.modallogin.show();
      return;
    }

    this.quoteService.save()
      .subscribe(
        data => {
          if (data != null) {

            this.clearModel();
            this.helper.navigateTo(RoutingKey[PageState.DASHBOARD]);
            return;
          }
        },
        error => {

        });
  }


  clearModel() {
    this.quoteService.resetQuoteModel();
  }
}
