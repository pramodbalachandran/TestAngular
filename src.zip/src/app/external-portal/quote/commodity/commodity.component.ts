import { Component, OnInit,ViewChild } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import * as _ from 'lodash';

import { QuoteDetail, AboutShipment, A2ADetail, D2ADetail, A2DDetail, D2DDetail, ShippingAddress, getShippingAddress, Commodity } from '@app/shared/interfaces/entities.interface';
import { QuoteAPI, CustomerAPI, LocalStorageService, GeaographyAPI } from '@app/shared/services';
import { getMatIconFailedToSanitizeLiteralError } from '@angular/material';
import { ModalComponent } from '@app/shared/helper/modalpopup.component';
import { IQuoteData, IQuoteListDetails } from '@app/models/quotes/quote-data'
import { IQuoteDetails } from '@app/models/quotes/quotes-details'
import { IAirFreightShipmentDetail, CommodityNameList, CurrencyFormat } from '@app/models/quotes/airfreightshipment-detail'
import { forEach } from '@angular/router/src/utils/collection';
import { element } from 'protractor';
import { PageState } from '@app/shared/services/shared/enum';
import { RoutingKey } from '@app/shared/services/shared/config.const';
import { UtilitiesService } from '@app/shared/services/shared/utilities.service';


@Component({
  selector: 'pricing-commodity',
  templateUrl: './commodity.component.html',
  styleUrls: ['./commodity.component.css']
})
export class CommodityComponent implements OnInit {

  @ViewChild('modalLogin') modallogin: ModalComponent;

  addShipmentValue: number = -1;
  commodityProductTags: string[];
  searchCommodityProductTags: string[] = [] as any[];
  selectedCommodityProductTags: string[];
  selectedCommodityProductTagsbackUp: string[];
  shipmentCurrencyCodeData: any[] = [];
  searchCurrencyCodeData: CurrencyFormat[] = [] as CurrencyFormat[];
  autocompleteCurrencyList: CurrencyFormat[] = [];
  commodityType: any[];
  productNameText: string = "";
  selectedCommodityType: string = "";
  commodityTypeDescriptionText: string = "";
  shipmentCurrencyCode: string = "";
  ShipmentValue: string = "";
  commodityNameLst: CommodityNameList[] = [] as CommodityNameList[];
  shipmentValueIndicator: boolean;
  itemShipMesage: string = "";
  isCurrencySelected: boolean = false;

  private modelCurrency = { localCurrencyCode: '', localeCodes: '', exchangeRateAmount: '' };
  private modelCommodityType = { selectedCommodityType: '', commodityTypeDescriptionText: '' };
  private quoteDetail: IQuoteData;
  commodityNameListRequest =
  {
    "accountNumber": localStorage.getItem('currentUserName1')
  }

  private modelShipmentComodity: Commodity = {
    CommodityTypeCode: '',
    commodityProducts: [],
    shipmentValue: '',
    currecy: ''
  };

  originCountryCode:string= '';
  destinationCountryCode:string= '';
  showAutocomplete: boolean = false;

  constructor(private helper: UtilitiesService,private router: Router, private route: ActivatedRoute, private quoteService: QuoteAPI<any>, private geoGraphyService: GeaographyAPI<any>) {
  }

  ngOnInit() {
    this.bindControls();
  }

  bindControls(): any {
    this.bindIndustrySegment();
  }

  getCurrencyDetail() {

    var self = this;
    this.geoGraphyService.getCurrencyDetailList().subscribe(
      resdata => {

        if (resdata.result != null && resdata.result.results[0] != null && resdata.result.results[0].currencyConversion.length > 0) {
          this.shipmentCurrencyCodeData = resdata.result.results[0]["currencyConversion"];
          this.setCurrentyList(resdata.result.results[0]["currencyConversion"]);

          if (this.shipmentCurrencyCode == "" && this.ShipmentValue == "") {
            this.setDefaultCurrency("UNITED STATES");
          }
          else {
            this.setDefaultCurrency(this.shipmentCurrencyCode);
          }
        }
      }
    );
  }


  populateControls(): any {

    //TO DO
    //throw new Error("Method not implemented.");

    var self = this;

    if (this.quoteService.getQuoteDetails() != null && this.quoteService.getQuoteDetails().airFreightShipmentDetail != null) {

      this.modelCommodityType.selectedCommodityType = this.quoteService.getQuoteDetails().airFreightShipmentDetail[0].commodityTypeCode.toString();

      

      if (this.quoteService.getQuoteDetails().airFreightShipmentDetail[0].commodityNameList != null && this.quoteService.getQuoteDetails().airFreightShipmentDetail[0].commodityNameList.length > 0) {

        this.quoteService.getQuoteDetails().airFreightShipmentDetail[0].commodityNameList.forEach(function (product) {


          self.addProductItem(product.commodityName.toString());
        });
      }
      else {
        localStorage.removeItem('addShipmentValue');
      }
      //come from other page back button or next button
      if (localStorage.getItem('addShipmentValue')) {
        this.addShipmentValue = this.quoteService.getQuoteDetails().airFreightShipmentDetail[0].shipmentValueIndicator == true ? 1 : 2;
      }
      else {
        //page load first time
        this.addShipmentValue = -1;
      }

      this.shipmentCurrencyCode = this.quoteService.getQuoteDetails().airFreightShipmentDetail[0].shipmentCurrencyCode.toString();
      this.shipmentValueIndicator = this.quoteService.getQuoteDetails().airFreightShipmentDetail[0].shipmentValueIndicator;

      this.ShipmentValue = this.shipmentValueIndicator ? this.quoteService.getQuoteDetails().airFreightShipmentDetail[0].shipmentValue.toString() : '';
      if (this.ShipmentValue=='') {
        this.shipmentCurrencyCode = '';
      }
    }
    var self = this;
    this.quoteService.getCommodityProduct(this.commodityNameListRequest).subscribe(
      (resdata: any) => {

        //self.commodityProductTags = resdata.product;
        self.commodityProductTags = resdata.commodityName;
        if (this.commodityProductTags != null && this.commodityProductTags.length > 0)
          self.itemShipMesage = "Here are some things you’ve shipped before:";
        else
          self.itemShipMesage = "No Item shipped before";

      }
    );

    if (this.modelCommodityType.selectedCommodityType == "")
      this.modelCommodityType.selectedCommodityType = "0";
    this.getCurrencyDetail();

  }

  setCurrentyList(data) {
    this.originCountryCode = this.quoteService.getQuoteDetails().airFreightShipmentDetail[0].originLocationCountryCode;
    this.destinationCountryCode = this.quoteService.getQuoteDetails().airFreightShipmentDetail[0].destinationLocationCountryCode;

    this.searchCurrencyCodeData = [];

    var countryCode;

    var currencyList = data.filter(currency => currency['countryName'].toUpperCase() == 'UNITED STATES');
    if (currencyList.length > 0) {
      countryCode = currencyList[0].countryCode;
      this.searchCurrencyCodeData.push(currencyList[0]);
    }

    currencyList = data.filter(currency => currency['countryCode'] == this.originCountryCode);
    if (currencyList.length > 0) {
      if (countryCode != currencyList[0].countryCode) {
        this.searchCurrencyCodeData.push(currencyList[0]);
      }
    }
    

    currencyList = data.filter(currency => currency['countryCode'] == this.destinationCountryCode);
    if (currencyList.length > 0) {
      if (countryCode != currencyList[0].countryCode) {
        this.searchCurrencyCodeData.push(currencyList[0]);
      }
    }

    //this.autocompleteCurrencyList = this.searchCurrencyCodeData;
  }

  bindIndustrySegment(): any {

    var self = this;
    this.quoteService.getCommodityTypeList().subscribe(
      resdata => {

        if (resdata['results'] != null && resdata['results'].length > 0) {

          self.commodityType = resdata['results'][0].commodityTypeList as any[];
          self.populateControls();
        }
      }
    );

  }

  onChange(event: any) {

    var commodityTypeDescText = (_.filter(this.commodityType, function (elem) {
      return elem.commodityTypeCode.trim() == ((event.trim().split(":"))[1]).trim()
    }));

    if (commodityTypeDescText != null)
      this.commodityTypeDescriptionText = commodityTypeDescText[0].commodityTypeDescriptionText;
  }

  validateProductName() {
    //only allow one comma with character and number and space
    var re = new RegExp("^([A-Za-z0-9 ]|[A-Za-z0-9 ],(?=[A-Za-z0-9\s]))+$");
    return re.test(this.productNameText);
  }

  searchProductPramChange() {

    var self = this;

    if (this.productNameText.trim() != "" && this.productNameText.length > 0) {

      if (this.validateProductName()) {

        //comma seperated product

        var product = this.productNameText.split(',');

        product.forEach(function (element) {
          self.addProductItem(element);
        });
      }

      this.productNameText = "";

    }

  }

  selectedProductPram(value: any) {
    this.productNameText = value;
    this.searchCommodityProductTags = new Array();

    this.addProductItem(value);

    this.selectedCommodityProductTagsbackUp.push(value);
  }

  selectedCurrency(value: any) {

    this.shipmentCurrencyCode = value.localCurrencyCode;
    this.isCurrencySelected = true;
    var itemfound = _.find(this.shipmentCurrencyCodeData, function (elem) { return elem.countryCode == value.countryCode; });
    if (itemfound != null && itemfound != undefined) {

      this.modelCurrency.localeCodes = itemfound.localeCodes;
      this.modelCurrency.localCurrencyCode = itemfound.localCurrencyCode;
      this.modelCurrency.exchangeRateAmount = itemfound.exchangeRateAmount;

    }

    //this.searchCurrencyCodeData = new Array();

    this.shipmentfocusOutFunction();
    this.showAutocomplete = false;
  }


  onCurrencyfocus() {
    this.showAutocomplete = true;
    this.autocompleteCurrencyList = this.searchCurrencyCodeData;
  }


  currencyfocusOutFunction() {
    //this.autocompleteCurrencyList = [];
  }

  searchCurrencyPramChange(event) {
    this.showAutocomplete = true;
    this.isCurrencySelected = false;
    if (event.trim() == '') {
      this.autocompleteCurrencyList = this.searchCurrencyCodeData;
      return;
    }

    if (event.length < 3) {
      return;
    }

    this.autocompleteCurrencyList = this.shipmentCurrencyCodeData.filter(currency => currency.countryName.trim().toUpperCase() == event.trim().toUpperCase() || (currency.localCurrencyCode && currency.localCurrencyCode.trim().toUpperCase()) == event.trim().toUpperCase());
    
    //this.isCurrencySelected = false;

    //this.searchCurrencyCodeData = new Array();
    //if (event.length < 3) {
    //  return;
    //}

    //if (this.searchCurrencyCodeData.length == 0) {      
    //  var itemfound = this.shipmentCurrencyCodeData.filter(currency => currency['countryName'] == event.trim().toUpperCase() || currency['localCurrencyCode'] == event.trim().toUpperCase());
    //  if (itemfound != null && itemfound != undefined)
    //    this.searchCurrencyCodeData.push(itemfound[0]);
    //}
  }  

  setSelectedShipmentValue(value) {
    if (value == this.addShipmentValue) {
      return;
    }
    this.addShipmentValue = value == 'Yes' ? 1 : 2;
    this.shipmentValueIndicator = value == 'Yes' ? true : false;

    localStorage.setItem('addShipmentValue', this.addShipmentValue.toString());

    if (this.addShipmentValue != 1) {
      //this.ShipmentValue = "";
      //this.shipmentCurrencyCode = "";
      //this.searchCurrencyCodeData = new Array();
    }
  }

  isValidData() {
    if ((this.modelCommodityType.selectedCommodityType == '0' || this.modelCommodityType.selectedCommodityType == "") || (this.selectedCommodityProductTags == undefined || (this.selectedCommodityProductTags != null && this.selectedCommodityProductTags.length == 0)) || this.addShipmentValue == -1) {
      return false;
    }

    if (this.addShipmentValue == 1) {
      if (this.shipmentCurrencyCode == "" || this.isCurrencySelected == false || this.ShipmentValue == "") {
        return false;
      }
    }

    return true;
  }

  removeItem(item: any) {
    this.selectedCommodityProductTags = _.filter(this.selectedCommodityProductTags, (elem) => elem != item);
    this.productNameText = "";
  }

  addProductItem(item: any) {

    if (this.selectedCommodityProductTags == null || this.selectedCommodityProductTags == undefined)
      this.selectedCommodityProductTags = new Array();

    var itemfound = _.find(this.selectedCommodityProductTags, function (elem) { return elem == item; });
    if (itemfound == undefined)
      this.selectedCommodityProductTags.push(item);

  }

  //set Shipment Value Format
  shipmentfocusOutFunction() {

    if (this.ShipmentValue != "")
      this.ShipmentValue = ((parseFloat(this.ShipmentValue)).toFixed(2)).toString();

    if (this.ShipmentValue != "" && this.modelCurrency.localeCodes != "") {
      var shipmentValue = parseInt(this.ShipmentValue.replace(/,/g, ""));
      this.ShipmentValue = shipmentValue.toLocaleString(this.modelCurrency.localeCodes);
    }

  }


  setDefaultCurrency(event) {

    var itemfound = this.shipmentCurrencyCodeData.filter(currency => currency['countryName'] == event.trim().toUpperCase() || currency['localCurrencyCode'] == event.trim().toUpperCase());
     if (itemfound != null && itemfound != undefined) {

        this.shipmentCurrencyCode = itemfound[0]["localCurrencyCode"];
        this.modelCurrency.localeCodes = itemfound[0]["localeCodes"];
        this.modelCurrency.localCurrencyCode = itemfound[0]["localCurrencyCode"];
       this.modelCurrency.exchangeRateAmount = itemfound[0]["exchangeRateAmount"];
       this.isCurrencySelected = true;

      }     

  }


  saveForLater() {

    this.updateQuoteModel();
    this.save();

  }

  save() {

    var self = this;

    if (localStorage.getItem('currentUserName1') == null) {
      localStorage.setItem('IsGuestUser', 'true');
      this.modallogin.show();
      //alert('Navigate to login not implemented !!');
      return;
    }

    this.quoteService.save().subscribe(
      resdata => {

        if (resdata != null) {

          this.clearModel();
          //localStorage
          //this.router.navigate(['/dashboard']);
          this.helper.navigateTo(RoutingKey[PageState.DASHBOARD]);

        }

      }
    );
  }

  Next() {


    this.updateQuoteModel();
    this.helper.navigateTo(RoutingKey[PageState.COMMODITY_CHARACTERISTICS]);
  }

  back() {
    this.updateQuoteModel();
    this.helper.navigateTo(RoutingKey[PageState.SHIPMENT_MEASUREMENT]);
  }


  updateQuoteModel() {
    let quoteModel = this.quoteService.getQuoteDetails();
    quoteModel.airFreightShipmentDetail[0].commodityTypeCode = this.modelCommodityType.selectedCommodityType
    quoteModel.airFreightShipmentDetail[0].commodityTypeDescriptionText = this.commodityTypeDescriptionText;

    if (this.selectedCommodityProductTags != null && this.selectedCommodityProductTags.length > 0) {

      this.selectedCommodityProductTags.forEach(function (product) {
        let obj = {
          "commodityName": product
        };
        if (quoteModel.airFreightShipmentDetail[0].commodityNameList != null) {
          var itemfound = _.find(quoteModel.airFreightShipmentDetail[0].commodityNameList, function (elem) { return elem.commodityName == product.trim(); });
          if (itemfound == undefined)
            quoteModel.airFreightShipmentDetail[0].commodityNameList.push(obj);
        }
        else {
          quoteModel.airFreightShipmentDetail[0].commodityNameList = [];
          quoteModel.airFreightShipmentDetail[0].commodityNameList.push(obj);
        }

      });
    }

    quoteModel.airFreightShipmentDetail[0].shipmentValueIndicator = this.shipmentValueIndicator;
    quoteModel.airFreightShipmentDetail[0].shipmentCurrencyCode = this.shipmentCurrencyCode;
    quoteModel.airFreightShipmentDetail[0].shipmentValue = this.ShipmentValue;
    quoteModel.quoteRequestData.businessPartyName = localStorage.getItem('currentUserName1');
    this.quoteService.getQuoteDetails().quoteRequestData.lastVisitedPage = PageState.SHIPMENT_COMMODITY;

    this.quoteService.setQuoteDetails(quoteModel);
    return quoteModel;
  }


  addEmptyCurrencyData() {
    this.searchCurrencyCodeData.push({
      countryCode: "",
      countryName: "",
      currencyName: "",
      decimalPlacesQuantity: 0,
      exchangeRateAmount: 0,
      localConversionToUsdAmount: 0,
      localCurrencyCode: "",
      localeCodes: "",
      roundingDirectionText: ""
    });
  }

  clearModel() {
    this.quoteService.resetQuoteModel();
  }

  public onContainerClicked(event: MouseEvent): void {
    if (!(<HTMLElement>event.target).classList.contains('currency-autocomplete')) {
      this.showAutocomplete = false;
    }
  }
}
