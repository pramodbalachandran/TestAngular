import { Component, OnInit, ViewChild } from '@angular/core';
import { QuoteAPI } from '@app/shared/services';
import { NgForm } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { LocalStorageService } from '@app/shared/services';
import { IQuoteData, IQuoteListDetails } from '@app/models/quotes/quote-data'
import { IQuoteDetails } from '@app/models/quotes/quotes-details'
import { UserRegistrationService, ToasterService, CustomerAPI } from '@app/shared/services';
import { IQUOTE, IQuoteStrcuture, IContactSettings } from '@app/shared/interfaces/entities.interface';
import { IAirFreightShipmentDetail } from '@app/models/quotes/airfreightshipment-detail';
import { PageState } from '@app/shared/services/shared/enum';
import { RoutingKey } from '@app/shared/services/shared/config.const';
import { UtilitiesService } from '@app/shared/services/shared/utilities.service';

@Component({
    selector: 'pricing-quotesuccess',
    templateUrl: './quotesuccess.component.html',
    styleUrls: ['./quotesuccess.component.css']
})
export class QuotesuccessComponent implements OnInit {

    body: HTMLBodyElement = document.getElementsByTagName('body')[0];

    // public localObj: any = {
    //     "id": "",
    //     "ContactName": "",
    //     "PhoneNo": "",
    //     "EmailAddress": "",
    //     "Comments": "",
    //     "DoShowEditContactForm": false,
    //     "LastUsedDate": ""
    // };


  constructor(private router: Router, private helper: UtilitiesService,private _customerAPI: CustomerAPI<any>,
        private quoteService: QuoteAPI<IQuoteData>, private localStorageService: LocalStorageService) { }

    ngOnInit() {
        this.body.classList.remove('login-logo');
        

        let fromcontact = localStorage.getItem("navigationAction");
        if (fromcontact != null && fromcontact == "nextcontactbutton") { //guest user coming from login/register page.
           
            this.InsertQuoteContact();
           
            
        }

    }

  onManageQuote() {
    this.helper.navigateTo(RoutingKey[PageState.DASHBOARD]);
  }
    
    // //--------Insert into database.: not required.
    // UpdateContactDetails() {

    //     //this.objcontact.LastUsedDate = Date.now().toString();
    //     //update customer contact details.
    //     //this.quoteService.updateContactDetails(this.objcontact);

    //     var inputUpdateContact = {
    //         "ContactName": this.localObj.ContactName,
    //         "EmailAddress": this.localObj.EmailAddress,
    //         "PhoneNo": this.localObj.PhoneNo,
    //         "UserId": localStorage.getItem('currentUserName1'),
    //         "DoShowEditContactForm": false,
    //         "LastUsedDate": Date.now().toString(),
    //         "id": this.localObj.id
    //     };

    //     this._customerAPI.updateContactsList(inputUpdateContact).subscribe(
    //         resdata => {

    //             if (resdata == null || resdata == undefined) {
    //                 // this.toastr.error('Updation failed');
    //                 return;
    //             }
    //             else { //after success continue.
    //                 this.InsertQuoteContact();
    //             }
    //             // this.toastr.success('Successfully Contact Added!');

    //             //manage display
    //             //this.index = parseInt(localStorage.getItem("index"));
    //         }
    //     );


    // }
    // //--------Insert into database.: not required.
    // InsertContactDetails() {
    //     //insert customer contact details.
    //     //this.objcontact.LastUsedDate = Date.now().toString();
    //     //this.quoteService.insertContactDetails(this.objcontact);

    //     var inputNewContact = {
    //         "ContactName": this.localObj.ContactName,
    //         "EmailAddress": this.localObj.EmailAddress,
    //         "PhoneNo": this.localObj.PhoneNo,
    //         "UserId": localStorage.getItem('currentUserName1'),
    //         "DoShowEditContactForm": false,
    //         "LastUsedDate": Date.now().toString(),
    //         "id": null
    //     };

    //     this._customerAPI.addContactsList(inputNewContact).subscribe(
    //         resdata => {
    //             if (resdata == null || resdata == undefined) {
    //                 //this.toastr.error('Updation failed');
    //                 return;
    //             }
    //             else { //after success continue.
    //                 this.InsertQuoteContact();
    //             }
    //             //this.toastr.success('Successfully Contact Added!');
    //             //manage display

    //         }
    //     );


    // }

    InsertQuoteContact() {

        //checking quote data for just loggedin user become register user

        //Set logged user details in the existing data model for guest users
        let quoteDetail = this.quoteService.getQuoteDetails() as IQuoteData;
        if (quoteDetail != null) {
            quoteDetail.quoteRequestData.businessPartyNumber = localStorage.getItem('currentUserName1');
            this.quoteService.setQuoteDetails(quoteDetail);
            //Save existing data model for guest users
            this.quoteService.save().subscribe(
                resdata => {
                    if (resdata != null) {
                        console.log("success");
                        
                        //clear all.
                        this.quoteService.resetQuoteModel();

                        let navigationAction = localStorage.getItem('navigationAction');
                        let quoteContactDetails = localStorage.getItem('quoteContactDetails');
                        let chkSaveInProfile = localStorage.getItem('chkSaveInProfile');
            
                        if(navigationAction)
                        {
                            localStorage.removeItem("navigationAction");
                        }
                        if(quoteContactDetails){
                            localStorage.removeItem("quoteContactDetails");
                        }    
                        if(chkSaveInProfile){
                            localStorage.removeItem("chkSaveInProfile");
                        }
                        return;
                    }
                    else {
                        console.log("failure");
                        return;
                    }
                }
            );
        }


    }

   

}
