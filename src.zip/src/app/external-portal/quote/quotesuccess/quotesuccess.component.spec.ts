import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { QuotesuccessComponent } from './quotesuccess.component';

describe('QuotesuccessComponent', () => {
  let component: QuotesuccessComponent;
  let fixture: ComponentFixture<QuotesuccessComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ QuotesuccessComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(QuotesuccessComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeDefined();
  });
});
