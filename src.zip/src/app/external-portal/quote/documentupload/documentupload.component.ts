import { Component, OnInit, ViewChild } from '@angular/core';
import { FileUploader, FileItem } from 'ng2-file-upload';
import { retry } from 'rxjs/operators';
import { LocalStorageService } from '@app/shared/services';
import { IAirFreightShipmentDetail } from '@app/models/quotes/airfreightshipment-detail';
import { IQuoteData } from '@app/models/quotes/quote-data';
import { QuoteAttachment } from '@app/models/quotes/quotes-details';
import { QuoteAPI } from '@app/shared/services';
import { Router, ActivatedRoute } from '@angular/router';
import { ModalComponent } from '@app/shared/helper/modalpopup.component';
import { RoutingKey } from '@app/shared/services/shared/config.const';
import { UtilitiesService } from '@app/shared/services/shared/utilities.service';
import { PageState } from '@app/shared/services/shared/enum';
const fileCategoryCode = 'QA001';
//const uploadURL =  'http://localhost:55459/task/named/FileUploadTest';

@Component({
  selector: 'pricing-documentupload',
  templateUrl: './documentupload.component.html',
  styleUrls: ['./documentupload.component.css']
})
export class DocumentUploadComponent implements OnInit {
  public body: HTMLBodyElement = document.getElementsByTagName('body')[0];
  @ViewChild('modalLogin') modallogin: ModalComponent;
  uploader: FileUploader;
  uploadURL: string;
  hasBaseDropZoneOver: boolean;
  savedUplodDocuments: QuoteAttachment[];
  uploadLabelOptions = [{ name: 'Choose a label...', value: '' }, { name: '1', value: '1' }, { name: '2', value: '2' }];

  constructor(private helper: UtilitiesService, private quoteService: QuoteAPI<IQuoteData>, private localStorageService: LocalStorageService) {
    this.uploadURL = quoteService.getBaseURL() + 'task/named/FileUpload';
    //this.uploadURL = 'http://localhost:55459/task/named/FileUpload';

    this.uploader = new FileUploader({
      url: this.uploadURL,
      autoUpload: true,
      allowedMimeType: ['application/pdf', 'application/zip', 'application/x-zip-compressed', 'application/x-zip',
        'application/vnd.ms-powerpoint', 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
        'application/vnd.ms-excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'application/msword','application/vnd.openxmlformats-officedocument.wordprocessingml.document']
    });
    
    this.hasBaseDropZoneOver = false;

    this.uploader.response.subscribe(
      data => {
        if (data==null || data=='' || data==undefined) {
          return;
        }
      },
      error => {
        console.log(error);
      });

    this.uploader.onSuccessItem = (item: any, response: any, status: any, headers: any) => {
        if (item) {
            item.formData = { 'label': this.uploadLabelOptions[0].value, 'documentKey': response };
        }
    };

    this.uploader.onCompleteItem = (item: any, response: any, status: any, headers: any) => {
      //alert('complete');
    };

    this.uploader.onErrorItem = (item: any, response: any, status: any, headers: any) => {
      //alert('error');
    };

    this.uploader.onAfterAddingFile = (item: any) => {
      item.withCredentials = false;
    };
  }

  ngOnInit() {
    this.body.classList.remove('login-logo');
    this.savedUplodDocuments = [];

    var data = this.quoteService.getQuoteDetails();
    if (data != null && data.quoteRequestData != null && data.quoteRequestData.quoteAttachment != null) {
      for (let item of data.quoteRequestData.quoteAttachment) {
          this.savedUplodDocuments.push(item);
      }
    }
  }

  setUploderQueueErrorStatus(index) {
    var queueFile = this.uploader.queue[index];
    if (queueFile) {
      queueFile.isError = true;
      queueFile.isSuccess = false;
    }
  }

  setUploadDocumentKey(index,key) {
    var queueFile = this.uploader.queue[index];
    if (queueFile) {
      queueFile.formData = { 'label': this.uploadLabelOptions[0].value, 'documentKey': key };
    }
  }


  getUploadedItemsCount() {
    return this.uploader.queue.filter(x => x.isSuccess == true).length;
  }

  isDisableNextButton() {
    if (this.getUploadedItemsCount() > 0 || this.savedUplodDocuments.length>0) {
      return !this.isValidUploaderLableData();
    }
    return false;
  }

  fileOverBase(e: any): void {
    this.hasBaseDropZoneOver = e;
  }

  onFileSelected(e: any) {
   
  }

  onFileRemove(item: FileItem) {
    item.remove();
    //TODO: remove file from DB logic
  }

  removeFileInfoFromSavedData(item: QuoteAttachment) {
    var index = this.getIndexOfItem(item);
    if (index != -1) {
      this.savedUplodDocuments[index].availableIndicator = '0';
    }
  }

  getIndexOfItem(value) {
    return typeof value === 'number' ? value : this.savedUplodDocuments.indexOf(value);
  }

  isValidUploaderLableData() {
    var isValid = false;
    isValid = this.uploader.queue.filter(x => x.formData.label == null || x.formData.label == '' || x.formData.label == undefined).length == 0;
    if (isValid) {
      isValid = this.savedUplodDocuments.filter(x => x.availableIndicator=='1' && (x.fileOpportunityProductDescriptionText == null || x.fileOpportunityProductDescriptionText == '' || x.fileOpportunityProductDescriptionText == undefined)).length == 0;
    }
    return isValid;
  }

  isQuoteAttachmentExist() {
    return (this.getUploadedItemsCount() > 0 || this.savedUplodDocuments.filter(x => x.availableIndicator == '1').length > 0);
  }


  onSaveLater() {

    let quoteModel = this.updateQuoteModel();
    if (quoteModel == null) {
      console.log('No Data');
      return;
    }

    if (localStorage.getItem('currentUserName1') == null) {
      localStorage.setItem('IsGuestUser', 'true');
      this.modallogin.show();
      return;
    }

    this.quoteService.save()
      .subscribe(
        data => {
          if (data != null) {
            this.clearModel();
            this.helper.navigateTo(RoutingKey[PageState.DASHBOARD]);
            return;
          }
        },
        error => {

        });
  }

  onGoback() {
    this.updateQuoteModel();
    var redirectUrl = localStorage.getItem('uploadPageRedirectUrl');
    switch (redirectUrl) {
      case "shipmentFrequency":
        localStorage.removeItem('uploadPageRedirectUrl');
        this.helper.navigateTo(RoutingKey[PageState.SHIPMENT_FREQUENCY]);
        break;
      case "commodityCharacteristics":
        localStorage.removeItem('uploadPageRedirectUrl');
        this.helper.navigateTo(RoutingKey[PageState.COMMODITY_CHARACTERISTICS]);
        break;
      default:
        localStorage.removeItem('uploadPageRedirectUrl');
        this.helper.navigateTo(RoutingKey[PageState.SHIPMENT_MEASUREMENT]);
        break;
    }
  }

  gotToNext() {
    this.updateQuoteModel();
    this.helper.navigateTo(RoutingKey[PageState.CONTACT]);
  }

  clearModel() {
    this.quoteService.resetQuoteModel();
  }

  updateQuoteModel() {
    let quoteModel = this.quoteService.getQuoteDetails();
    if (!quoteModel.quoteRequestData.quoteAttachment) {
      quoteModel.quoteRequestData.quoteAttachment = [];
    }
    for (let item of this.uploader.queue) {
      if (item.isSuccess) {
        quoteModel.quoteRequestData.quoteAttachment.push({
          fileName: item.file.name, fileSize: item.file.size,
          fileOpportunityProductDescriptionText: item.formData.label != undefined ? item.formData.label : '', availableIndicator: '1', fileCategoryCode: fileCategoryCode,
          fileLocationName: '', filePathName: item.formData.documentKey != undefined ? item.formData.documentKey : '', fileStatusCode: '1', financialContentIndicator: ''
        });
      }
    }
    this.quoteService.getQuoteDetails().quoteRequestData.lastVisitedPage = PageState.DOCUMENT_UPLOAD;
    this.quoteService.setQuoteDetails(quoteModel);
    return quoteModel;
  }
}
