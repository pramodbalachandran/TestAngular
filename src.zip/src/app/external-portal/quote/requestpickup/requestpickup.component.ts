import { Component, OnInit, ViewChild } from '@angular/core';
import { CustomModalComponent } from '@app/shared/components/custom-modal/custom-modal.component';
import { Router, ActivatedRoute } from '@angular/router';
import { QuoteAPI } from '@app/shared/services';
import { IQuoteData, QuoteData } from '@app/models/quotes/quote-data';
import { LocalStorageService } from '@app/shared/services';
import { ModalComponent } from '@app/shared/helper/modalpopup.component';

@Component({
  selector: 'pricing-requestpickup',
  templateUrl: './requestpickup.component.html',
  styleUrls: ['./requestpickup.component.css']
})
export class RequestPickupComponent implements OnInit {
  @ViewChild('customModalDeclineQuote') modalDeclineQuote: CustomModalComponent;
  @ViewChild('customModalDeclineQuoteConfirmation') modalDeclineQuoteConfirmation: CustomModalComponent;
  @ViewChild('customModalOthers') modalOthers: CustomModalComponent;
  @ViewChild('modalLogin') modallogin: ModalComponent;

  private declineNote = '';
  private showRequestPickup: boolean;
  private movementTypeCode: number;
  private isAcceptChecked: boolean = false;
  private quoteRate: string;

  constructor(private router: Router, private quoteService: QuoteAPI<IQuoteData>, private localStorageService: LocalStorageService) { }

  ngOnInit() {
    this.quoteRate = '0';
  }

  updateQuoteModel(statusCode, quoteDeclineReasonTypeCode,quoteDeclineReasonTypeNote) {
    let quoteData = this.quoteService.getQuoteDetails();
    quoteData.quoteRequestData.quoteStatusCode = statusCode;
    quoteData.quoteRequestData.quoteRate = this.quoteRate;
    quoteData.quoteRequestData.quoteDeclineReasonTypeCode = quoteDeclineReasonTypeCode;
    quoteData.quoteRequestData.quoteDeclineReasonTypeNote = quoteDeclineReasonTypeNote;
    this.quoteService.setQuoteDetails(quoteData);
    return quoteData;
  }

  saveForLater() {

    let quoteModel = this.updateQuoteModel(2, 0, '');
    if (quoteModel == null) {
      return;
    }
    
     if (localStorage.getItem('currentUserName1') == null) {

      this.localStorageService.setItem('Quote', quoteModel);
      this.modallogin.show();
      return;
    }

    this.quoteService.save().subscribe(
      resdata => {

        if (resdata != null) {
            this.clearModel();
            this.router.navigate(['/dashboard']);
          return;
        }

      }
    );
  }


  clearModel() {
    this.quoteService.resetQuoteModel();
  }


}
