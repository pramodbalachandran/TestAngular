import { async, ComponentFixture, TestBed, getTestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';

import { ShipmentmeasurementComponent } from './shipmentmeasurement.component';
import { IQuoteData, IQuoteListDetails } from '@app/models/quotes/quote-data'
import { QuoteAPI } from '@app/shared/services';
import { Enviorment } from '@app/services/shared/config.const';
import { UtilitiesService } from '@app/services/shared/utilities.service';
import { RoutingKey } from '@app/services/shared/config.const';
import { PageState } from '@app/services/shared/enum';
import { ConfigService } from '@app/services/shared/config.service';
import { Router, ActivatedRoute } from '@angular/router';


describe('ShipmentmeasurementComponent', () => {
  let component: ShipmentmeasurementComponent;
  let fixture: ComponentFixture<ShipmentmeasurementComponent>;

  let injector;
  let service: QuoteAPI<IQuoteData>;
  let httpMock: HttpTestingController;

  beforeEach(async(() => {

    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, RouterTestingModule],
      declarations: [ShipmentmeasurementComponent],
      providers: [QuoteAPI, ConfigService, UtilitiesService],
      schemas: [NO_ERRORS_SCHEMA]
    })
      .compileComponents();

    injector = getTestBed();
    service = injector.get(QuoteAPI);
    httpMock = injector.get(HttpTestingController);
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ShipmentmeasurementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });


  //it('ng init', () => {
  //  expect(component).toBeDefined();
  //});
});
