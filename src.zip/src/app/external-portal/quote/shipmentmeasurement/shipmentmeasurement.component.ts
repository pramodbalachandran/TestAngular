import { Component, OnInit, ViewChild, ElementRef  } from '@angular/core';
import { DataTableModule } from 'angular-6-datatable';
import { Router, ActivatedRoute } from '@angular/router';
import { retry } from 'rxjs/operators';
import { LocalStorageService, QuoteAPI } from '@app/shared/services';
import { ModalComponent } from '@app/shared/helper/modalpopup.component';
import { IAirFreightShipmentDetail } from '@app/models/quotes/airfreightshipment-detail';
import { IQuoteData } from '@app/models/quotes/quote-data';
import { RoutingKey } from '@app/shared/services/shared/config.const';
import { UtilitiesService } from '@app/shared/services/shared/utilities.service';
import { PageState } from '@app/shared/services/shared/enum';

@Component({
  selector: 'pricing-shipmentmeasurement',
  templateUrl: './shipmentmeasurement.component.html',
  styleUrls: ['./shipmentmeasurement.component.scss'],
  providers: [DataTableModule]
})
export class ShipmentmeasurementComponent implements OnInit {
  @ViewChild('modalLogin') modallogin: ModalComponent;


  private model: IAirFreightShipmentDetail;
  public body: HTMLBodyElement = document.getElementsByTagName('body')[0];

  unitOfMeasureSelected: number;
  weightOfShipmentSelected: number;
  totalWeightDescription = 'kg';
  showLogin = false;

  public options = ['--Choose a Package Type--', 'Roll', 'Drum', 'Carton', 'Packets', 'Pallet/Skid', 'Piece', 'Loose'];

  constructor(private helper: UtilitiesService, private quoteService: QuoteAPI<IQuoteData>, private localStorageService: LocalStorageService
  ) { }

  ngOnInit() {
   
    this.body.classList.remove('shipment-measurement-logo');
    this.body.classList.remove('login-logo');

    this.unitOfMeasureSelected = 1;
    this.weightOfShipmentSelected = 1;

    var data = this.quoteService.getQuoteDetails();
    if (data != null && data.airFreightShipmentDetail != null) {
      this.model = data.airFreightShipmentDetail[0];
      if (this.model.shipmentWeightByPeice == null) {
        this.model.shipmentWeightByPeice = [];
        this.addEmptyData();
      }
      else if (this.model.shipmentWeightByPeice.length == 0) {
        this.addEmptyData();
      }
      if (this.model.totalWeight == '0') {
        this.model.totalWeight = '';
      }
    }
    this.setUnitOfMeasureSelectedValue();
    this.setWeightOfShipmentSelectedValue();
    this.totalWeightDescription = (this.unitOfMeasureSelected == 1 || this.unitOfMeasureSelected==3) ? 'kg' : 'lb';
  }

  addEmptyData() {
    this.model.shipmentWeightByPeice.push({
      "packageType": this.options[0],
      "quantity": '',
      "length": '',
      "width": '',
      "height": '',
      "weight": '',
      "shipmentVolumeQuantity":'',
      "shipmentUnitOfMeasureTypeCode":'',
      "shipmentWeightUnitOfMeasureTypeCode":'',
      "shipmentActualWeightQuantity":'',
      "shipmentDimensionalUnitOfMeasureTypeCode":'',
      "shipmentDimensionalWeightQuantity":''
    });
  }

  unitOfMeasureSelect(btnNo) {
    if (btnNo == this.unitOfMeasureSelected) {
      return;
    }

    this.unitOfMeasureSelected = btnNo;
    this.totalWeightDescription = (btnNo == 1 || btnNo == 3) ? 'kg' : 'lb';
    this.clearData();
  };

  isActiveUnitOfMeasure(btnNo) {
    return this.unitOfMeasureSelected === btnNo;
  };

  weightOfShipmentSelect(btnNo) {
    if (btnNo == this.weightOfShipmentSelected) {
      return;
    }
    this.weightOfShipmentSelected = btnNo;
    this.clearData();
  };

  isActiveWeightOfShipment(btnNo) {
    return this.weightOfShipmentSelected === btnNo;
  };

  getunitOfMeasureSelectedValue() {
    return this.unitOfMeasureSelected;
  }

  getweightOfShipmentSelectedValue() {
    return this.weightOfShipmentSelected;
  }

  setUnitOfMeasureSelectedValue() {
    if (this.model.shipmentUnitOfMeasureTypeCode == 0) {
      this.model.shipmentUnitOfMeasureTypeCode = 1;
    }
    this.unitOfMeasureSelected = this.model.shipmentUnitOfMeasureTypeCode;
  }

  setWeightOfShipmentSelectedValue() {
    if (this.model.shipmentWeightTypeCode == 0) {
      this.model.shipmentWeightTypeCode = 1;
    }
    this.weightOfShipmentSelected = this.model.shipmentWeightTypeCode;
  }

  clearData() {
    this.model.shipmentWeightByPeice = [];
    this.model.totalWeight = "";
    this.addEmptyData();
  }

  isValidRow() {
    var isValid = false;
    var item = this.model.shipmentWeightByPeice[this.model.shipmentWeightByPeice.length - 1];
    var isTotalWeightShipment = this.isTotalWeightShipment();
    if (!isTotalWeightShipment && (item.packageType == '--Choose a Package Type--' || this.convertToFloat(item.quantity) <= 0 || this.convertToFloat(item.length) <= 0 || this.convertToFloat(item.width) <= 0 || this.convertToFloat(item.height) <= 0 || this.convertToFloat(item.weight) <= 0)) {
      return false;
    }
    else if (isTotalWeightShipment && (item.packageType == '--Choose a Package Type--' || this.convertToFloat(item.quantity) <= 0 || this.convertToFloat(item.length) <= 0 || this.convertToFloat(item.width) <= 0 || this.convertToFloat(item.height) <= 0)) {
      return false;
    }
    return true;
  }

  isValidData() {
    var isValid = true;
    var length = this.model.shipmentWeightByPeice.length;
    if (length < 1) return false;

    var isTotalWeightShipment = this.isTotalWeightShipment();

    if (isTotalWeightShipment && this.convertToFloat(this.model.totalWeight) <= 0) {
      return false;
    }

    for (let item of this.model.shipmentWeightByPeice) {
      if (!isTotalWeightShipment && (item.packageType == '--Choose a Package Type--' || this.convertToFloat(item.quantity) <= 0 || this.convertToFloat(item.length) <= 0 || this.convertToFloat(item.width) <= 0 || this.convertToFloat(item.height) <= 0 || this.convertToFloat(item.weight) <= 0)) {
        isValid = false;
        break;
      }
      else if (isTotalWeightShipment && (item.packageType == '--Choose a Package Type--' || this.convertToFloat(item.quantity) <= 0 || this.convertToFloat(item.length) <= 0 || this.convertToFloat(item.width) <= 0 || this.convertToFloat(item.height) <= 0)) {
        isValid = false;
        break;
      }
    }

    

    return isValid;
  }

  convertToFloat(value) {
    return isNaN(parseFloat(value)) ? 0 : parseFloat(value);
  }
  

  onSaveLater() {
    
    let quoteModel =this.updateQuoteModel();
    if (quoteModel == null) {
      console.log('No Data');
      return;
    }

    if (localStorage.getItem('currentUserName1') == null) {
      this.showLogin = true;
      localStorage.setItem('IsGuestUser', 'true');
      this.modallogin.show();
      return;
    }

    this.quoteService.save()
      .subscribe(
        data => {
          if (data != null) {
            this.clearModel();
            this.helper.navigateTo(RoutingKey[PageState.DASHBOARD]);
            return;
          }
        },
        error => {
            
        });
  }

  onGoback() {
    this.updateQuoteModel();
    this.helper.navigateTo(RoutingKey[PageState.SHIPMENT_MOVEMENT]);
  }

  gotToNext() {
    if (!this.entryIsValid()) {
      return;
    }

    this.updateQuoteModel();

    if (this.isOverSizeShipment() || this.isOverWeightShipment()) {
      this.helper.navigateTo(RoutingKey[PageState.DOCUMENT_UPLOAD]);
    }
    else {
      this.helper.navigateTo(RoutingKey[PageState.SHIPMENT_COMMODITY]);
    }
  }

  clearModel() {
    this.quoteService.resetQuoteModel();
  }

  updateQuoteModel() {
    this.model.shipmentUnitOfMeasureTypeCode = this.getunitOfMeasureSelectedValue();
    this.model.shipmentWeightTypeCode = this.getweightOfShipmentSelectedValue();
    if (!this.isTotalWeightShipment()) {
      this.model.totalWeight = '';
    }
    else {
      for (let item of this.model.shipmentWeightByPeice) {
        item.weight = '0';
      }
    }

    let quoteModel = this.quoteService.getQuoteDetails();
    if (quoteModel.airFreightShipmentDetail.length == 0) {
      quoteModel.airFreightShipmentDetail.push(this.quoteService.getEmptyAirFreightShipmentDetail());
    }
    quoteModel.airFreightShipmentDetail[0].shipmentWeightByPeice = this.model.shipmentWeightByPeice;
    quoteModel.airFreightShipmentDetail[0].totalWeight = (this.convertToFloat(this.model.totalWeight) > 0) ? this.model.totalWeight: '0' ;
    quoteModel.airFreightShipmentDetail[0].shipmentWeightTypeCode = this.model.shipmentWeightTypeCode;
    quoteModel.airFreightShipmentDetail[0].shipmentUnitOfMeasureTypeCode = this.model.shipmentUnitOfMeasureTypeCode;
    this.quoteService.getQuoteDetails().quoteRequestData.lastVisitedPage = PageState.SHIPMENT_MEASUREMENT;
    this.quoteService.setQuoteDetails(quoteModel);
    return quoteModel;
  }

  entryIsValid() {
    var isValid = false;
    if (this.model.shipmentWeightByPeice.length <= 0 || !this.isValidData()) {
      return isValid;
    }

    if (this.isTotalWeightShipment() && this.convertToFloat(this.model.totalWeight) <= 0) {
      return isValid;
    }
    return true;
  }

  isTotalWeightShipment() {
    return this.weightOfShipmentSelected === 2;
  }

  isOverSizeShipment() {
    var overSizeShipment = false;

    var unitofMeasurementByCM = this.getunitOfMeasureSelectedValue() == 1;
    if (!unitofMeasurementByCM) {
      for (let item of this.model.shipmentWeightByPeice) {
        if (parseFloat(item.length) > 120 || parseFloat(item.width) > 83 || parseFloat(item.height) > 76) {
          overSizeShipment = true;
          break;
        }
      }
    }
    else {
      for (let item of this.model.shipmentWeightByPeice) {
        if (parseFloat(item.length) > 304 || parseFloat(item.width) > 210 || parseFloat(item.height) > 193) {
          overSizeShipment = true;
          break;
        }
      }
    }
    return overSizeShipment; 
  }

  isOverWeightShipment() {
    var overWeightShipment = false;

    var totalDimesionalWeight = 0;
    for (let item of this.model.shipmentWeightByPeice) {
      totalDimesionalWeight += (this.convertToFloat(item.weight) * (this.convertToFloat(item.quantity)));
    }

    switch (this.getunitOfMeasureSelectedValue()) {
      case 1: // cm/kg
        if (this.isTotalWeightShipment()) {
          if (this.convertToFloat(this.model.totalWeight) >= 9072) {
            overWeightShipment = true;
            return true;
          }
        }
        else {
          if (totalDimesionalWeight >= 9072) {
            overWeightShipment = true;
          }
        }
        break;
      case 2: // in/lb
        if (this.isTotalWeightShipment()) {
          if (this.convertToFloat(this.model.totalWeight) >= 20000) {
            overWeightShipment = true;
            return true;
          }
        }
        else {
          if (totalDimesionalWeight >= 20000) {
            overWeightShipment = true;
          }
        }
        break;
      case 3: // in/kg
        if (this.isTotalWeightShipment()) {
          if (this.convertToFloat(this.model.totalWeight) >= 9072) {
            overWeightShipment = true;
            return true;
          }
        }
        else {
          if (totalDimesionalWeight >= 9072) {
            overWeightShipment = true;
          }
        }
        break;
      default:
        break;
    }
    return overWeightShipment;
  }

  onRowDelete(item, rowIndex: number) {
    var index = this.getIndexOfItem(item);
    if (index != -1) {
      this.model.shipmentWeightByPeice.splice(index, 1);
      if (this.model.shipmentWeightByPeice.length == 0) {
        this.addEmptyData();
      }
    }
  }

  getIndexOfItem(value) {
    return typeof value === 'number' ? value : this.model.shipmentWeightByPeice.indexOf(value);
  }
}


