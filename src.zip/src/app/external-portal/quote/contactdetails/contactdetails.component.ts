import { Component, OnInit, ViewChild, AfterViewInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { IQuoteData, IQuoteListDetails } from '@app/models/quotes/quote-data'
import { IQuoteDetails } from '@app/models/quotes/quotes-details'
import { UserRegistrationService, ToasterService, CustomerAPI, QuoteAPI, LocalStorageService } from '@app/shared/services';
import { IQUOTE, IQuoteStrcuture, IContactSettings } from '@app/shared/interfaces/entities.interface';
import { IAirFreightShipmentDetail } from '@app/models/quotes/airfreightshipment-detail';

import { ModalComponent } from '@app/shared/helper/modalpopup.component';
import { Console } from '@angular/core/src/console';
import { ICustomer, IContactsDetails } from '@app/models';
import { PageState } from '@app/shared/services/shared/enum';
import { RoutingKey } from '@app/shared/services/shared/config.const';
import { UtilitiesService } from '@app/shared/services/shared/utilities.service';


@Component({
    selector: 'pricing-contactdetails',
    templateUrl: './contactdetails.component.html',
    styleUrls: ['./contactdetails.component.css']
})

export class ContactdetailsComponent implements OnInit, AfterViewInit {

    @ViewChild('modalLogin') modallogin: ModalComponent;

    body: HTMLBodyElement = document.getElementsByTagName('body')[0];
    boolshowContact: boolean = true;
    customerProfileDetails: ICustomer;
    usercontacts: IContactsDetails[] = new Array();
    coredata: IContactsDetails[] = new Array();
    objcontact: IContactsDetails;
    index: number = 0;
    inputNewContact: IContactsDetails;
    addnewflag: boolean = false;


    //private disableSaveCheckBox:boolean=false;
    counter: number;
    isRadioSelected: boolean;
    userid: string;
    tmpComments: string;
    tmpQuoteContactDetails: IQuoteData;
    tmpQuoteDetails: IQuoteData;
    getdataFlag: boolean = false;
    coredatalength: number = 0;
    isGuestUser: boolean = false;
    chkProfile: number = 0;
    sortOrder: number = 2;
    disableSaveProfileCheckBox: boolean = false;
    localObj: any = {
        "id": "",
        "contactName": "",
        "PhoneNo": "",
        "emailAddress": "",
        "phoneNumber": "",
        "doShowEditContactForm": false,
        "lastUsedDate": "",
        "comments": ""
    };

    chkelement: HTMLInputElement;
    element: HTMLInputElement;
    elementlbl: HTMLLabelElement;
    unamePattern = new RegExp("^[a-zA-Z ]{1,100}$");
    quoteId: string;
    toSelectRadio: number = -1;


  constructor(private router: Router, private helper: UtilitiesService,private _customerAPI: CustomerAPI<any>, private quoteService: QuoteAPI<IQuoteData>,
        private toastr: ToasterService) { }


    ngOnInit() {

        this.body.classList.remove('login-logo');
        localStorage.setItem("lastVisitedPage", PageState.CONTACT);
        this.sortarray(2);
        //----------------------------------------------------------------------//
        this.boolshowContact = false;
        this.tmpQuoteContactDetails = this.quoteService.getQuoteDetails() as IQuoteData; //.quoteRequestData

        if (localStorage.getItem('currentUserName1') == null) {
            //---------guest user----------//.

            this.isGuestUser = true;
            this.userid = "xx000000000";//to avoid runtime errors.
            this.boolshowContact = true;
            this.isRadioSelected = false;
            this.counter = 0;

            if (this.tmpQuoteContactDetails != null) {//first preference  model.

                this.objcontact = {
                    contactName: this.tmpQuoteContactDetails.quoteRequestData.ContactName,
                    emailAddress: this.tmpQuoteContactDetails.quoteRequestData.EmailAddress,
                    phoneNumber: this.tmpQuoteContactDetails.quoteRequestData.PhoneNo,
                    doShowEditContactForm: false
                } as IContactsDetails;

                this.tmpComments = this.tmpQuoteContactDetails.quoteRequestData.Comments;
                this.chkProfile = this.tmpQuoteContactDetails.quoteRequestData.contactAddressSaveProfileIndicator;
                this.quoteId = this.tmpQuoteContactDetails.quoteRequestData.id;

            }

        }
        else {//---------normal user----------//.

            this.isGuestUser = false;
            this.userid = localStorage.getItem('currentUserName1');
            this.boolshowContact = false;
            this.isRadioSelected = false;
            this.counter = 0;
            //this.getUsercontacts();

            if (this.tmpQuoteContactDetails != null) {//first preference from model.

                this.objcontact = {
                    contactName: this.tmpQuoteContactDetails.quoteRequestData.ContactName,
                    emailAddress: this.tmpQuoteContactDetails.quoteRequestData.EmailAddress,
                    phoneNumber: this.tmpQuoteContactDetails.quoteRequestData.PhoneNo,
                    doShowEditContactForm: false
                } as IContactsDetails;


                this.tmpComments = this.tmpQuoteContactDetails.quoteRequestData.Comments;
                this.chkProfile = this.tmpQuoteContactDetails.quoteRequestData.contactAddressSaveProfileIndicator;
                this.quoteId = this.tmpQuoteContactDetails.quoteRequestData.id;

                if (this.tmpQuoteContactDetails.quoteRequestData.ContactName.trim().length > 1
                    || this.tmpQuoteContactDetails.quoteRequestData.PhoneNo.trim().length > 1
                    || this.tmpQuoteContactDetails.quoteRequestData.EmailAddress.trim().length > 1) {
                    this.boolshowContact = true;
                    this.addnewflag = true; //hide
                }
                else {
                    this.boolshowContact = false;
                    this.addnewflag = false; //hide
                }

                this.getUsercontacts();
                //this.getToSelectRadioIndex();

            }
            else { //last preference.

                this.objcontact = {
                    contactName: '',
                    emailAddress: '',
                    phoneNumber: '',
                    doShowEditContactForm: false
                } as IContactsDetails;
            }

            //-------------------------Local storage---------------//


        }

        //----------------------------------------------------------------------//
        this.element = document.getElementById("comments") as HTMLInputElement;
        if (this.element != null && this.tmpComments.trim().length > 1) {
            // element.defaultValue = this.tmpComments;
            this.element.value = this.tmpComments;
        }


        //this.getToSelectRadioIndex();



    }
    ngAfterViewInit() {

        //this.getToSelectRadioIndex();


        this.chkelement = document.getElementById("chkSaveInProfile") as HTMLInputElement;
        if (this.chkelement != null) {
            if (this.chkProfile > 0) {
                this.chkelement.checked = true;
            }
            else {
                this.chkelement.checked = false;
            }
        }





    }

    //-----------------------------//
    dropdownselect(e) {

        if (e.target.value == 0 || e.target.value == "0") {
            return;
        }
        else if (e.target.value == 1 || e.target.value == "1") {
            this.sortarray(1);
        }
        else {
            this.sortarray(2);
        }
        //already selected index change now.
        this.getToSelectRadioIndex();

    };
    //-----------------------------//
    sortarray(inval: number) {


        if (this.usercontacts.length <= 0) return; //no values to sort.

        if (inval == 1) { //sort by name
            this.sortOrder = 1;
            this.usercontacts.sort((a, b) => {
                if (b.contactName < a.contactName) return 1;
                else if (b.contactName > a.contactName) return -1;
                else return 0;
            });

            //---------------------------//
            /*this.coredata.sort((a, b) => {
                if (b.contactName < a.contactName) return 1;
                else if (b.contactName > a.contactName) return -1;
                else return 0;
            });*/
        }
        else { //sort by last used date. 
            this.sortOrder = 2;

            this.usercontacts.sort(function (a, b) {

                var dateA: any = a.lastUsedDate == null ? new Date(2000, 11, 24, 10, 33, 30, 0) : new Date(a.lastUsedDate);
                var dateB: any = b.lastUsedDate == null ? new Date(2000, 11, 24, 10, 33, 30, 0) : new Date(b.lastUsedDate);
                return dateB - dateA;
            });

            //---------------------------//
            /*this.coredata.sort(function (a, b) {
                var dateA: any = a.lastUsedDate == null ? new Date(2000, 11, 24, 10, 33, 30, 0) : new Date(a.lastUsedDate);
                var dateB: any = b.lastUsedDate == null ? new Date(2000, 11, 24, 10, 33, 30, 0) : new Date(b.lastUsedDate);
                return dateB - dateA;
            });*/


        }


    }



    back() {//back to previous page.


        this.elementlbl = document.getElementById("lblError") as HTMLLabelElement;
        this.chkelement = document.getElementById("chkSaveInProfile") as HTMLInputElement;

        if (this.chkelement) {
            if (this.chkelement.checked) { //save in profile checkbox checked.



                if (!this.objcontact.contactName && !this.objcontact.phoneNumber && !this.objcontact.emailAddress) {

                    this.elementlbl.innerText = "Please enter name, phone & email fields";
                    this.elementlbl.setAttribute("disabled", "false");
                    return false;
                }

                if (!this.objcontact.phoneNumber && !this.objcontact.emailAddress) {

                    this.elementlbl.innerText = "Please enter phone & email fields";
                    this.elementlbl.setAttribute("disabled", "false");
                    return false;
                }

                if (!this.objcontact.contactName && !this.objcontact.emailAddress) {

                    this.elementlbl.innerText = "Please enter name & email fields";
                    this.elementlbl.setAttribute("disabled", "false");
                    return false;
                }

                if (!this.objcontact.contactName && !this.objcontact.phoneNumber) {

                    this.elementlbl.innerText = "Please enter name & phone fields";
                    this.elementlbl.setAttribute("disabled", "false");
                    return false;
                }


                if (this.objcontact.contactName.trim().length <= 0) {
                    this.elementlbl.innerText = "Please enter a valid name";
                    this.elementlbl.setAttribute("disabled", "false");
                    return;
                }
                if (this.objcontact.phoneNumber.trim().length <= 0) {
                    this.elementlbl.innerText = "Please enter a valid phone";
                    this.elementlbl.setAttribute("disabled", "false");
                    return;
                }

                if (this.objcontact.emailAddress.trim().length <= 0) {
                    this.elementlbl.innerText = "Please enter a valid email";
                    this.elementlbl.setAttribute("disabled", "false");
                    return;
                }

                if (!this.unamePattern.test(this.objcontact.contactName)) {
                    this.elementlbl.innerText = "Please enter a valid name";
                    this.elementlbl.setAttribute("disabled", "false");
                    return;
                }

                if (!this.isValidPhoneNumber(this.objcontact.phoneNumber)) {
                    this.elementlbl.innerText = "Please enter a valid phone, allowed only numeric min.10-max.15-digits";
                    this.elementlbl.setAttribute("disabled", "false");
                    return;
                }

                if (!this.isValidEmail(this.objcontact.emailAddress)) {
                    this.elementlbl.innerText = "Please enter a valid email";
                    this.elementlbl.setAttribute("disabled", "false");
                    return;
                }

            }
        }
        else {

            if (this.objcontact.contactName.trim().length > 0) {
                if (!this.unamePattern.test(this.objcontact.contactName)) {
                    this.elementlbl.innerText = "Please enter a valid name";
                    this.elementlbl.setAttribute("disabled", "false");
                    return;
                }

            }

            if (this.objcontact.phoneNumber.trim().length > 0) {
                if (!this.isValidPhoneNumber(this.objcontact.phoneNumber)) {
                    this.elementlbl.innerText = "Please enter a valid phone, allowed only numeric min.10-max.15-digits";
                    this.elementlbl.setAttribute("disabled", "false");
                    return;
                }

            }

            if (this.objcontact.emailAddress.trim().length > 0) {
                if (!this.isValidEmail(this.objcontact.emailAddress)) {
                    this.elementlbl.innerText = "Please enter a valid email";
                    this.elementlbl.setAttribute("disabled", "false");
                    return;
                }
            }

        }

        //validate duplicate contact details.
        if (this.chkelement && this.chkelement.checked) {
            if (this.coredata.length > 0) {

                if (this.isRadioSelected) {
                    //selected from a radio-list, hence pass index value.

                    if (this.isContactAlreadyExist(this.index)) {
                        this.toastr.error("Contact already existing, duplicate contacts not allowed.");
                        return;

                    }
                    else {
                        //this.InsertContactDetails();
                    }
                }
                else {//newly entered values.

                    if (this.isContactAlreadyExist(-1)) {
                        this.toastr.error("Contact already existing, duplicate contacts not allowed.");
                        return;
                    }
                }
            }
        }

        //this.getModel();
        localStorage.setItem("quoteContactDetails", JSON.stringify(this.getModel(false)))
        this.helper.navigateTo(RoutingKey[PageState.DOCUMENT_UPLOAD]);


    }
    //-----------------------------//
    saveForLater() {//save for later.

        this.elementlbl = document.getElementById("lblError") as HTMLLabelElement;
        this.chkelement = document.getElementById("chkSaveInProfile") as HTMLInputElement;

        if (this.chkelement) {
            if (this.chkelement.checked) { //save in profile checkbox checked.

                if (!this.objcontact.contactName && !this.objcontact.phoneNumber && !this.objcontact.emailAddress) {

                    this.elementlbl.innerText = "Please enter name, phone & email fields";
                    this.elementlbl.setAttribute("disabled", "false");
                    return false;
                }

                if (!this.objcontact.phoneNumber && !this.objcontact.emailAddress) {

                    this.elementlbl.innerText = "Please enter phone & email fields";
                    this.elementlbl.setAttribute("disabled", "false");
                    return false;
                }

                if (!this.objcontact.contactName && !this.objcontact.emailAddress) {

                    this.elementlbl.innerText = "Please enter name & email fields";
                    this.elementlbl.setAttribute("disabled", "false");
                    return false;
                }

                if (!this.objcontact.contactName && !this.objcontact.phoneNumber) {

                    this.elementlbl.innerText = "Please enter name & phone fields";
                    this.elementlbl.setAttribute("disabled", "false");
                    return false;
                }

                if (this.objcontact.contactName.trim().length <= 0) {
                    this.elementlbl.innerText = "Please enter a valid name";
                    this.elementlbl.setAttribute("disabled", "false");
                    return;
                }

                if (this.objcontact.phoneNumber.trim().length <= 0) {
                    this.elementlbl.innerText = "Please enter a valid phone";
                    this.elementlbl.setAttribute("disabled", "false");
                    return;
                }

                if (this.objcontact.emailAddress.trim().length <= 0) {
                    this.elementlbl.innerText = "Please enter a valid email";
                    this.elementlbl.setAttribute("disabled", "false");
                    return;
                }


                if (!this.unamePattern.test(this.objcontact.contactName)) {
                    this.elementlbl.innerText = "Please enter a valid name";
                    this.elementlbl.setAttribute("disabled", "false");
                    return;
                }

                if (!this.isValidPhoneNumber(this.objcontact.phoneNumber)) {
                    this.elementlbl.innerText = "Please enter a valid phone, allowed only numeric min.10-max.15-digits";
                    this.elementlbl.setAttribute("disabled", "false");
                    return;
                }

                if (!this.isValidEmail(this.objcontact.emailAddress)) {
                    this.elementlbl.innerText = "Please enter a valid email";
                    this.elementlbl.setAttribute("disabled", "false");
                    return;
                }


            }
        }
        else {

            if (this.objcontact.contactName.trim().length > 0) {
                if (!this.unamePattern.test(this.objcontact.contactName)) {
                    this.elementlbl.innerText = "Please enter a valid name";
                    this.elementlbl.setAttribute("disabled", "false");
                    return;
                }

            }

            if (this.objcontact.phoneNumber.trim().length > 0) {
                if (!this.isValidPhoneNumber(this.objcontact.phoneNumber)) {
                    this.elementlbl.innerText = "Please enter a valid phone, allowed only numeric min.10-max.15-digits";
                    this.elementlbl.setAttribute("disabled", "false");
                    return;
                }

            }

            if (this.objcontact.emailAddress.trim().length > 0) {
                if (!this.isValidEmail(this.objcontact.emailAddress)) {
                    this.elementlbl.innerText = "Please enter a valid email";
                    this.elementlbl.setAttribute("disabled", "false");
                    return;
                }
            }
        }

        //validate duplicate contact details.
        if (this.chkelement && this.chkelement.checked) {
            if (this.coredata.length > 0) {

                if (this.isRadioSelected) { //selected from a radio-list, hence pass index value.

                    if (this.isContactAlreadyExist(this.index)) {
                        this.toastr.error("Contact already existing, duplicate contacts not allowed.");
                        return;
                        
                    }
                }
                else {//newly entered values.

                    if (this.isContactAlreadyExist(-1)) {
                        this.toastr.error("Contact already existing, duplicate contacts not allowed.");
                        return;
                    }
                }

                //no duplicates..just insert.
                this.InsertContactDetails();


            }
            else { //no data to validate duplicate.

                this.InsertContactDetails();  
            }  
           
        }

        //finally clear.
        if (this.elementlbl) {
            this.elementlbl.innerText = "";
            this.elementlbl.setAttribute("disabled", "true");
        }

        if (this.isGuestUser) { //guest user mode.

            this.getModel(false)
            this.wait(10); //
            this.modallogin.show();
            return;
        }
        else { //normal user mode.



            let fromcontact = localStorage.getItem("navigationAction")
            if (fromcontact != null) {
                localStorage.removeItem("navigationAction");
            }
            let contact = localStorage.getItem("quoteContactDetails")
            if (contact != null) {
                localStorage.removeItem("quoteContactDetails");
            }

            this.getModel(false); //don't store in local.
            this.helper.navigateTo(RoutingKey[PageState.DASHBOARD]);
        }


    }

    //--------------------------------------------//
    isContactAlreadyExist(rowIndex: number) {
        if (!rowIndex) {
            return false;
        }

        var length = this.coredata.filter((contact: IContactsDetails, index) => index != rowIndex && contact.contactName.toLowerCase().trim() == this.objcontact.contactName.toLowerCase().trim()
            && contact.emailAddress.toLowerCase().trim() == this.objcontact.emailAddress.toLowerCase().trim()
            && contact.phoneNumber.toLowerCase().trim() == this.objcontact.phoneNumber.toLowerCase().trim()
        ).length;

        return length > 0;
    }

    //-----------------------------//
    getModel(flag: boolean) {


        this.element = document.getElementById("comments") as HTMLInputElement;
        this.chkelement = document.getElementById("chkSaveInProfile") as HTMLInputElement;


        let quoteData = this.quoteService.getQuoteDetails() as IQuoteData;


        if (quoteData != null) {
            quoteData.quoteRequestData.lastVisitedPage = PageState.CONTACT;
            quoteData.quoteRequestData.ContactName = this.objcontact.contactName;
            quoteData.quoteRequestData.EmailAddress = this.objcontact.emailAddress;
            quoteData.quoteRequestData.PhoneNo = this.objcontact.phoneNumber;

            if (this.element)
                quoteData.quoteRequestData.Comments = this.element.value;

            if (flag) //don't change the status.
                quoteData.quoteRequestData.quoteStatusCode = 7;

            if (this.chkelement) {
                if (this.chkelement.checked) {
                    quoteData.quoteRequestData.contactAddressSaveProfileIndicator = 1;
                }
                else {
                    quoteData.quoteRequestData.contactAddressSaveProfileIndicator = 0;
                }

            }
            else {
                quoteData.quoteRequestData.contactAddressSaveProfileIndicator = 0;
            }

            //set back to QuoteDetails.
            this.quoteService.setQuoteDetails(quoteData);

        }


        this.localObj.contactName = this.objcontact.contactName;
        this.localObj.phoneNumber = this.objcontact.phoneNumber;
        this.localObj.emailAddress = this.objcontact.emailAddress;
        this.localObj.doShowEditContactForm = this.objcontact.doShowEditContactForm;
        //this.localObj.LastUsedDate = this.objcontact.LastUsedDate;
        if (this.element)
            this.localObj.comments = this.element.value;
        return this.localObj;


    }
    //-----------------------------//

    next() {//move next page.


        this.elementlbl = document.getElementById("lblError") as HTMLLabelElement;

        if (!this.objcontact.contactName && !this.objcontact.phoneNumber && !this.objcontact.emailAddress) {

            this.elementlbl.innerText = "Please enter name, phone & email fields";
            this.elementlbl.setAttribute("disabled", "false");
            return false;
        }

        if (!this.objcontact.phoneNumber && !this.objcontact.emailAddress) {

            this.elementlbl.innerText = "Please enter phone & email fields";
            this.elementlbl.setAttribute("disabled", "false");
            return false;
        }

        if (!this.objcontact.contactName && !this.objcontact.emailAddress) {

            this.elementlbl.innerText = "Please enter name & email fields";
            this.elementlbl.setAttribute("disabled", "false");
            return false;
        }

        if (!this.objcontact.contactName && !this.objcontact.phoneNumber) {

            this.elementlbl.innerText = "Please enter name & phone fields";
            this.elementlbl.setAttribute("disabled", "false");
            return false;
        }

        if (this.objcontact.contactName.trim().length <= 0) {
            this.elementlbl.innerText = "Please enter a valid name";
            this.elementlbl.setAttribute("disabled", "false");
            return;
        }
        if (this.objcontact.phoneNumber.trim().length <= 0) {
            this.elementlbl.innerText = "Please enter a valid phone";
            this.elementlbl.setAttribute("disabled", "false");
            return;
        }

        if (this.objcontact.emailAddress.trim().length <= 0) {
            this.elementlbl.innerText = "Please enter a valid email";
            this.elementlbl.setAttribute("disabled", "false");
            return;
        }



        if (!this.unamePattern.test(this.objcontact.contactName)) {
            this.elementlbl.innerText = "Please enter a valid name";
            this.elementlbl.setAttribute("disabled", "false");
            return;
        }

        if (!this.isValidPhoneNumber(this.objcontact.phoneNumber)) {
            this.elementlbl.innerText = "Please enter a valid phone, allowed only numeric min.10-max.15-digits";
            this.elementlbl.setAttribute("disabled", "false");
            return;
        }

        if (!this.isValidEmail(this.objcontact.emailAddress)) {
            this.elementlbl.innerText = "Please enter a valid email";
            this.elementlbl.setAttribute("disabled", "false");
            return;
        }

        //finally clear
        if(this.elementlbl)
        {
            this.elementlbl.innerText = "";
            this.elementlbl.setAttribute("disabled", "true");
        }
        


        if (this.isGuestUser) {//guest user mode.

            localStorage.setItem("navigationAction", "nextcontactbutton");

            //redirect to login/register page..& model going to save at quotesuccess component. 
            this.getModel(true);
            this.modallogin.show();
            return;
        }
        else { //normal user mode.

            this.element = document.getElementById("chkSaveInProfile") as HTMLInputElement;

            //validate duplicate contact details.
            if (this.element && this.element.checked) {

                if (this.coredata.length > 0) {

                    if (this.isRadioSelected) {
                        //selected from a radio-list, hence pass index value.

                        if (this.isContactAlreadyExist(this.index)) {
                            this.toastr.error("Contact already existing, duplicate contacts not allowed.");
                            return;
                        }
                        
                    }
                    else {//newly entered values.

                        if (this.isContactAlreadyExist(-1)) {
                            this.toastr.error("Contact already existing, duplicate contacts not allowed.");
                            return;
                        }

                    }

                    //no duplicates, just insert
                    this.InsertContactDetails();

                }
                else {//no data to validate duplicate. just insert.
                    this.InsertContactDetails();
                }
                
            }

            //fill details into model.
            this.getModel(true);
            this.InsertQuoteContact();
           

        }

    }
    //-----------------------------//
    nextButtonClass() {

        if (!this.IsNextButtonDisabled()) {
            return "nextButtonEnabled upsSans_Bd";
        } else {
            return "btn_next upsSans_Bd";
        }

    }
    //-----------------------------//
    IsNextButtonDisabled() {

        if (!this.objcontact.contactName || !this.objcontact.phoneNumber || !this.objcontact.emailAddress)
            return true;
        else
            return false;
    }

    //---------------add-new contact
    showContactAddress() {


        this.addnewflag = true;
        this.UnCheckRadioSelected();
        this.isRadioSelected = false;


        if (!this.boolshowContact) {
            this.boolshowContact = true;
            this.disableCheckBox(false);
            this.objcontact = {
                contactName: '', emailAddress: '', phoneNumber: '', doShowEditContactForm: false
            } as IContactsDetails;

            return;
        }

        if (this.boolshowContact) {
            this.boolshowContact = false;
            this.disableCheckBox(true);
            this.objcontact = {
                contactName: '', emailAddress: '', phoneNumber: '', doShowEditContactForm: false
            } as IContactsDetails;


            return;
        }


    }
    //----Cancel - button
    CancelContactAddress() {


        this.addnewflag = false;
        this.objcontact = {
            contactName: '', emailAddress: '', phoneNumber: '', doShowEditContactForm: false
        } as IContactsDetails;

        this.boolshowContact = false;

        this.disableCheckBox(false);
        this.UnCheckRadioSelected();

    }
    //-----------------------------//
    UnCheckRadioSelected() { //cancel , uncheck already selected radio.
        if (this.isRadioSelected) {
            for (let i = 0; i < document.getElementsByName("buildTool").length; i++) {
                var element = document.getElementsByName("buildTool")[i] as HTMLInputElement;

                if (element.type.toLowerCase() == "radio" && element.checked) {
                    element.checked = false;
                    break;
                }

            }
        }
    }
    //-----------------------------//
    onNameKeyPress(event: any) {

        if (this.isGuestUser) return;
        this.disableCheckBox(false);
    }

    onPhoneKeyPress(event) {

        if (this.isGuestUser) return;
        this.disableCheckBox(false);
    }

    onEmailKeyPress(event: any) {

        if (this.isGuestUser) return;
        this.disableCheckBox(false);
    }

    //-------------LoadMore----------------//
    LoadMore() { //load 10-more to grid.

        this.getUsercontacts();

    }
    //---------------------------------//
    //on radio button select from the list.
    radioChange(e: number) {

        this.index = e;
        this.boolshowContact = true; //show div .
        let objtmp = this.usercontacts[e] as IContactsDetails;

        if (objtmp) {
            this.objcontact.contactName = objtmp.contactName
            this.objcontact.phoneNumber = objtmp.phoneNumber
            this.objcontact.emailAddress = objtmp.emailAddress
        }

        this.isRadioSelected = true;
        this.disableCheckBox(true);
        this.disableSaveProfileCheckBox = true;
        this.addnewflag = true;

    }
    //---------------------------------//
    wait(ms) {
        var start = new Date().getTime();
        var end = start;
        while (end < start + ms) {
            end = new Date().getTime();
        }
    }

    isDisableSaveProfileCheckBox() {
        return this.disableSaveProfileCheckBox ? "cursornotallowed" : "";
    }

    //--save contact into profile - checkbox
    disableCheckBox(inVal: boolean) {

        var element = document.getElementById("chkSaveInProfile") as HTMLInputElement;
        if (element == null) {
            this.wait(50);
            element = document.getElementById("chkSaveInProfile") as HTMLInputElement;
        }

        if (element != null) {
            if (inVal) { //yes: disable
                if (element.type.toLowerCase() == "checkbox") {
                    element.checked = false;
                    element.disabled = true;

                    element.classList.add("chkcss");
                    this.disableSaveProfileCheckBox = true;
                }

            }
            else { //no:enable
                if (element.type.toLowerCase() == "checkbox") {
                    //element.checked = false;
                    element.disabled = false;
                    element.classList.remove("chkcss");
                    this.disableSaveProfileCheckBox = false;
                }
            }
        }

    }
    //--------------------------//
    sortCoredata()
    {//by default data should be sort on lastused date.
        this.coredata.sort(function (a, b) {

            var dateA: any = a.lastUsedDate == null ? new Date(2000, 11, 24, 10, 33, 30, 0) : new Date(a.lastUsedDate);
            var dateB: any = b.lastUsedDate == null ? new Date(2000, 11, 24, 10, 33, 30, 0) : new Date(b.lastUsedDate);
            return dateB - dateA;
        });

    }
    //---------------------------------//
    getUsercontacts() {

        if (!this.getdataFlag) { //already not fetched from api. go head hit api.

            this._customerAPI.getUserByUserId(localStorage.getItem('currentUserName1'))
                .subscribe(
                data => {
                    if (data) {
                        // console.log(data);
                        //console.log(data.contactsDetails);

                        this.customerProfileDetails = data as ICustomer;

                        if (data.contactsDetails) {

                            for (let i = 0; i < data.contactsDetails.length; i++) {
                                this.coredata.push(data.contactsDetails[i]);
                                //if (i % 2 == 0) break; -- testing.
                            }

                            this.sortCoredata();//by last updated date.
                            this.wait(10);
                            this.getdataFlag = true;
                            this.getData();
                        }

                    }
                    else {
                        console.log('Cannot find data for specified user: ' + localStorage.getItem('currentUserName1'));

                    }
                },
                error => {
                    console.log(error);
                });

        }
        else {
            this.getData();
        }


    }
    //---------------------------------//
    getData() {//fetch only 10-records.

        this.coredatalength = this.coredata.length;
        for (let i = this.counter + 1; i <= this.coredata.length; i++) {
            this.usercontacts.push(this.coredata[i - 1]);

            //if (i % 2 == 0) break; -- testing.
            if (i % 10 == 0) break;
        }

        //this.counter += 2; -- testing.
        this.counter += 10;
        this.sortarray(this.sortOrder);

        console.log("this.usercontacts");
        console.log(this.usercontacts);
        this.getToSelectRadioIndex();

    }

    //-------------------------------------------//
    getToSelectRadioIndex() {
        this.toSelectRadio = -1
        //assume coming from dashboard. quoteid exiting. we have to select radio button as checked.
        for (let i = 0; i < this.usercontacts.length; i++) {
            if (this.usercontacts[i].contactName.toLowerCase().trim() == this.objcontact.contactName.toLowerCase().trim() &&
                this.usercontacts[i].phoneNumber.toLowerCase().trim() == this.objcontact.phoneNumber.toLowerCase().trim() &&
                this.usercontacts[i].emailAddress.toLowerCase().trim() == this.objcontact.emailAddress.toLowerCase().trim()) {
                // console.log(i);
                this.toSelectRadio = i; //to check radio button
                this.isRadioSelected = true; //flag 
                this.index = i; //toupdate in the contact
                break;
            }
        }

        //console.log("getToSelectRadioIndex");
        //console.log(this.objcontact.contactName);
        //console.log(this.objcontact.phoneNumber);
        //console.log( this.objcontact.emailAddress);
        //console.log(this.toSelectRadio);

    }
    //--------------------------------------------------//
    isValidPhoneNumber(value) {
        var pattern = new RegExp("([0-9]{10,15})");
        return pattern.test(value);
    }

    isValidEmail(value) {
        var pattern = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        return pattern.test(value);
    }

    //--------Insert into database.
    InsertContactDetails() {


        this.inputNewContact = {
            contactName: this.objcontact.contactName,
            doShowEditContactForm: false,
            emailAddress: this.objcontact.emailAddress,
            lastUsedDate: new Date(),
            phoneNumber: this.objcontact.phoneNumber
        };

        if (this.customerProfileDetails == null)
            this.customerProfileDetails = this._customerAPI.getCustomerProfileDetails() as ICustomer;

        if (this.isRadioSelected) {//selected from radio list. needs to update that record.

            //sort contact details to map ui radio index exactly to update.
            if (this.sortOrder == 1) {
                this.customerProfileDetails.contactsDetails.sort((a, b) => {
                    if (b.contactName < a.contactName) return 1;
                    else if (b.contactName > a.contactName) return -1;
                    else return 0;
                });
            }
            else if (this.sortOrder == 2) {
                this.customerProfileDetails.contactsDetails.sort(function (a, b) {

                    var dateA: any = a.lastUsedDate == null ? new Date(2000, 11, 24, 10, 33, 30, 0) : new Date(a.lastUsedDate);
                    var dateB: any = b.lastUsedDate == null ? new Date(2000, 11, 24, 10, 33, 30, 0) : new Date(b.lastUsedDate);
                    return dateB - dateA;
                });
            }

            this.customerProfileDetails.contactsDetails[this.index].contactName = this.objcontact.contactName;
            this.customerProfileDetails.contactsDetails[this.index].phoneNumber = this.objcontact.phoneNumber;
            this.customerProfileDetails.contactsDetails[this.index].emailAddress = this.objcontact.emailAddress;
            this.customerProfileDetails.contactsDetails[this.index].lastUsedDate = new Date();
        }
        else {//newly created record.

            this.customerProfileDetails.contactsDetails.push(this.inputNewContact);
        }

        //finally set 
        this._customerAPI.setCustomerProfileDetails(this.customerProfileDetails);

        //----------service-call----------//
        this._customerAPI.updateUserProfile(this.customerProfileDetails)
            .subscribe(
            data => {
                if (data == null || data == undefined) {

                    this.toastr.error('Profile contact update failed,please contact administrator');
                    return;
                }
                //once success then only save quotedetails.
                //this.InsertQuoteContact();
                //this.toastr.success('Successfully contact updated!');
                //this.doShowAddNewContactForm = false;
            },
            error => {
                //this.removeContactsList(this.contact);
                this.toastr.error('Profile contact update failed,please contact administrator');
                return;
            });


    }


    //--------Insert into database.
    InsertQuoteContact() {

        this.quoteService.save().subscribe(
            resdata => {
                if (resdata != null) {

                    let fromcontact = localStorage.getItem("navigationAction")
                    if (fromcontact != null) {
                        localStorage.removeItem("navigationAction");
                    }
                    let contact = localStorage.getItem("quoteContactDetails")
                    if (contact != null) {
                        localStorage.removeItem("quoteContactDetails");
                    }
                    //finally redirect to quote success.
                    this.helper.navigateTo(RoutingKey[PageState.QUOTE_SUCCESS]);
                }
            },
            error => {
                console.log(error);
                //alert(error);
                //this.toastr.error(error) ;
                this.toastr.error('Quotation details update failed,please contact administrator.');
                
            }
        );


    }

    //---get data from the database.
    loaddata() {

        this._customerAPI.getUserByUserId(localStorage.getItem('currentUserName1'))
            .subscribe(
            data => {
                if (data) {
                    this.customerProfileDetails = data;
                    this.coredata = data.contactsDetails as IContactsDetails[];
                    this._customerAPI.setCustomerProfileDetails(data);
                }
                else {
                    console.log('Cannot find data for specified user: ' + localStorage.getItem('currentUserName1'));
                    this.customerProfileDetails = null;
                }
            },
            error => {
                console.log(error);
            });

    }

}
