import { async, ComponentFixture, TestBed, getTestBed } from '@angular/core/testing';
/*mport { HttpClient, HttpResponse, HttpHeaders } from '@angular/common/http';*/
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';

import { ContactdetailsComponent } from './contactdetails.component';
import { IQuoteData, IQuoteListDetails } from '@app/models/quotes/quote-data'
import { QuoteAPI, CustomerAPI, LocalStorageService, ToasterService} from '@app/shared/services';
import { Enviorment } from '@app/services/shared/config.const';
import { UtilitiesService } from '@app/services/shared/utilities.service';
import { RoutingKey } from '@app/services/shared/config.const';
import { PageState, QuoteStatus} from '@app/services/shared/enum';
import { ConfigService } from '@app/services/shared/config.service';
import { Router, ActivatedRoute } from '@angular/router';
import { combineAll } from 'rxjs/operators';

describe('ContactdetailsComponent', () => {

  let component: ContactdetailsComponent;
  let fixture: ComponentFixture<ContactdetailsComponent>;
  let injector;
  let service: QuoteAPI<IQuoteData>;
  //let httpMock: HttpTestingController;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, RouterTestingModule],
      declarations: [ContactdetailsComponent],
      providers: [QuoteAPI, ConfigService, UtilitiesService, CustomerAPI, ToasterService],
      schemas: [NO_ERRORS_SCHEMA]
    })
      .compileComponents();

    injector = getTestBed();
    service = injector.get(QuoteAPI);
    //httpMock = injector.get(HttpTestingController);
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ContactdetailsComponent);
    component = fixture.componentInstance;
    let de: DebugElement;
    fixture.detectChanges();
  });


  //it('checkingNgOnit for viewing frequency tab with approiate value', () => {

  //  switch (Enviorment.type) {

  //    case "dev":
  //      localStorage.setItem('currentUserName1', 'suzuki2018');

  //      break;

  //    case "QA":
  //      localStorage.setItem('currentUserName1', '');

  //      break;

  //    case "UAT":
  //      localStorage.setItem('currentUserName1', '');

  //      break;

  //    case "PROD":
  //      localStorage.setItem('currentUserName1', '');

  //      break;
  //  }
  //  service.resetQuoteModel();
  //  let quotedata = service.getQuoteDetails() as IQuoteData;
  //  quotedata.quoteRequestData.ContactName = "Bingi";
  //  quotedata.quoteRequestData.EmailAddress = "bingi2004@gmail.com";
  //  quotedata.quoteRequestData.PhoneNo = "987654323";
  //  quotedata.quoteRequestData.Comments = "987654323";
  //  quotedata.quoteRequestData.businessPartyNumber = localStorage.getItem('currentUserName1');
  //  quotedata.quoteRequestData.lastVisitedPage = PageState.CONTACT;
  //  service.setQuoteDetails(quotedata);

  //  component.ngOnInit();

  //  expect(component.objcontact.contactName).toEqual("Bingi");

  //});

  //it('checkingNgOnit for viewing frequency tab with approiate value for guest user', () => {

  //  switch (Enviorment.type) {

  //    case "dev":
  //      localStorage.setItem('currentUserName1', null);

  //      break;

  //    case "QA":
  //      localStorage.setItem('currentUserName1', '');

  //      break;

  //    case "UAT":
  //      localStorage.setItem('currentUserName1', '');

  //      break;

  //    case "PROD":
  //      localStorage.setItem('currentUserName1', '');

  //      break;
  //  }
  //  service.resetQuoteModel();
  //  let quotedata = service.getQuoteDetails() as IQuoteData;
  //  quotedata.quoteRequestData.ContactName = "Bingi";
  //  quotedata.quoteRequestData.EmailAddress = "bingi2004@gmail.com";
  //  quotedata.quoteRequestData.PhoneNo = "987654323";
  //  quotedata.quoteRequestData.Comments = "987654323";
  //  quotedata.quoteRequestData.businessPartyNumber = localStorage.getItem('currentUserName1');
  //  quotedata.quoteRequestData.lastVisitedPage = PageState.CONTACT;
  //  service.setQuoteDetails(quotedata);

  //  component.ngOnInit();

  //  expect(component.objcontact.contactName).toEqual("Bingi");

  //});


  //it('ngAfterViewInit', () => {

  //  component.chkelement = {} as HTMLInputElement;
  //  component.chkProfile = 1;
  //  component.ngAfterViewInit();

  //  expect(component.chkProfile).toBeGreaterThan(0);

  //});

  //it('dropdownselect', () => {

  //  //var e = { "target.value": 1};
  //  var e = { target: { value:1} };
  //  component.dropdownselect(e);

    

  //});


  //it('UnCheckRadioSelected', () => {

  //  component.UnCheckRadioSelected();



  //});


  //it('onNameKeyPress', () => {

  //  component.onNameKeyPress({});



  //});

  //it('onPhoneKeyPress', () => {

  //  component.onPhoneKeyPress({});

  //});

  //it('onEmailKeyPress', () => {

  //  component.onEmailKeyPress({});

  //});

  //it('getModel', () => {

  //  component.getModel(false);

  //});


  
  //it('sort contact details for last user date', () => {

  //  component.getdataFlag = false;

  //  component.inputNewContact = {
  //    contactName: "one",
  //    doShowEditContactForm: false,
  //    emailAddress: "one@test.com",
  //    lastUsedDate: new Date(),
  //    phoneNumber: "11111111111111111"
  //  };

  //  component.usercontacts.push(component.inputNewContact)

  //  component.inputNewContact = {
  //    contactName: "two",
  //    doShowEditContactForm: false,
  //    emailAddress: "two@test.com",
  //    lastUsedDate: new Date(),
  //    phoneNumber: "33331111111111111"
  //  };

  //  component.usercontacts.push(component.inputNewContact)
  //  //component.getUsercontacts();
  //  component.sortarray(2);
  // // expect(component.chkProfile).toBeGreaterThan(0);

  //});

  //it('sort contact details for alphabetal', () => {

  //  component.getdataFlag = false;
  //  component.inputNewContact = {
  //    contactName: "one",
  //    doShowEditContactForm: false,
  //    emailAddress: "one@test.com",
  //    lastUsedDate: new Date(),
  //    phoneNumber: "11111111111111111"
  //  };

  //  component.usercontacts.push(component.inputNewContact)

  //  component.inputNewContact = {
  //    contactName: "two",
  //    doShowEditContactForm: false,
  //    emailAddress: "two@test.com",
  //    lastUsedDate: new Date(),
  //    phoneNumber: "33331111111111111"
  //  };

  //  component.usercontacts.push(component.inputNewContact)
  //  //component.getUsercontacts();
  //  component.sortarray(1);
  //  //expect(component.chkProfile).toBeGreaterThan(0);

  //});

  //it('back', () => {

  //  component.boolshowContact = false;
    const chkSaveInProfile = fixture.debugElement.query(By.css('#chkSaveInProfile'));
  //  component.back);
  //  expect(service.getQuoteDetails().quoteRequestData.contactAddressSaveProfileIndicator).toEqual(0);

  //});

  //it('next', () => {

  //   switch (Enviorment.type) {

  //    case "dev":
  //       localStorage.setItem('currentUserName1', 'suzuki2018');

  //      break;

  //    case "QA":
  //      localStorage.setItem('currentUserName1', '');

  //      break;

  //    case "UAT":
  //      localStorage.setItem('currentUserName1', '');

  //      break;

  //    case "PROD":
  //      localStorage.setItem('currentUserName1', '');

  //      break;
  //  }

  //  let quotedata = service.getQuoteDetails() as IQuoteData;    
  //  quotedata.quoteRequestData.businessPartyNumber = localStorage.getItem('currentUserName1');
  //  quotedata.quoteRequestData.lastVisitedPage = PageState.CONTACT;
  //  quotedata.quoteRequestData.ContactName = "TestUser";
  //  quotedata.quoteRequestData.EmailAddress = "testUser@test.com";
  //  quotedata.quoteRequestData.PhoneNo = "9833102855";
  //  quotedata.quoteRequestData.Comments = "testing Comments";
  //  quotedata.quoteRequestData.quoteStatusCode = QuoteStatus.Submitted;
  //  quotedata.quoteRequestData.contactAddressSaveProfileIndicator = 1;
  //  component.isGuestUser = false;
  //  component.element.checked = false;
  //  component.next();
  //  expect(service.getQuoteDetails().quoteRequestData.id).length > 0;
  //  component.element.checked = true;
  //  component.next();
  //  expect(service.getQuoteDetails().quoteRequestData.id).length > 0;


  //});

  //it('next for guest user', () => {

  //  switch (Enviorment.type) {

  //    case "dev":
  //      localStorage.setItem('currentUserName1', null);

  //      break;

  //    case "QA":
  //      localStorage.setItem('currentUserName1', '');

  //      break;

  //    case "UAT":
  //      localStorage.setItem('currentUserName1', '');

  //      break;

  //    case "PROD":
  //      localStorage.setItem('currentUserName1', '');

  //      break;
  //  }

  //  let quotedata = service.getQuoteDetails() as IQuoteData;
  //  quotedata.quoteRequestData.businessPartyNumber = localStorage.getItem('currentUserName1');
  //  quotedata.quoteRequestData.lastVisitedPage = PageState.CONTACT;
  //  quotedata.quoteRequestData.ContactName = "TestUser";
  //  quotedata.quoteRequestData.EmailAddress = "testUser@test.com";
  //  quotedata.quoteRequestData.PhoneNo = "9833102855";
  //  quotedata.quoteRequestData.Comments = "testing Comments";
  //  quotedata.quoteRequestData.quoteStatusCode = QuoteStatus.Submitted;
  //  quotedata.quoteRequestData.contactAddressSaveProfileIndicator = 1;
  //  component.isGuestUser = true;
  //  component.Next();
  //  expect(service.getQuoteDetails().quoteRequestData.id).length > 0;

  //});

  //it('check Saving Quote Data from ContactDetailsPgae for guest user', () => {


  //  switch (Enviorment.type) {

  //    case "dev":
  //      localStorage.setItem('testUserName', null);

  //      break;

  //    case "QA":
  //      localStorage.setItem('currentUserName1', '');

  //      break;

  //    case "UAT":
  //      localStorage.setItem('currentUserName1', '');

  //      break;

  //    case "PROD":
  //      localStorage.setItem('currentUserName1', '');

  //      break;
  //  }

  //  let quotedata = service.getQuoteDetails() as IQuoteData;
  //  quotedata.quoteRequestData.businessPartyNumber = localStorage.getItem('testUserName');
  //  quotedata.quoteRequestData.lastVisitedPage = PageState.CONTACT;
  //  quotedata.quoteRequestData.ContactName = "TestUser";
  //  quotedata.quoteRequestData.EmailAddress = "testUser@test.com";
  //  quotedata.quoteRequestData.PhoneNo = "9833102855";
  //  quotedata.quoteRequestData.Comments = "testing Comments";
  //  quotedata.quoteRequestData.quoteStatusCode = QuoteStatus.NotSubmitted;
  //  quotedata.quoteRequestData.contactAddressSaveProfileIndicator = 1;

  //  service.setQuoteDetails(quotedata);
  //  component.isGuestUser = true;

  //  //service.save();

  //  component.saveForLater();

  //  console.log(service.getQuoteDetails().quoteRequestData.id);
  //  expect(service.getQuoteDetails().quoteRequestData.id).length > 0;
  //  expect(service.getQuoteDetails().quoteRequestData.quoteStatusCode).toBeGreaterThan(0);
  //  expect(service.getQuoteDetails().quoteRequestData.lastVisitedPage).toBeGreaterThan(0);

  //});  

  //it('check Saving Quote Data from ContactDetailsPgae using looged in user ', () => {


  //  switch (Enviorment.type) {

  //    case "dev":
  //      localStorage.setItem('testUserName', 'suzuki2018');

  //      break;

  //    case "QA":
  //      localStorage.setItem('currentUserName1', '');

  //      break;

  //    case "UAT":
  //      localStorage.setItem('currentUserName1', '');

  //      break;

  //    case "PROD":
  //      localStorage.setItem('currentUserName1', '');

  //      break;
  //  }

  //  let quotedata = service.getQuoteDetails() as IQuoteData;    
  //  quotedata.quoteRequestData.businessPartyNumber = localStorage.getItem('testUserName');
  //  quotedata.quoteRequestData.lastVisitedPage = PageState.CONTACT;
  //  quotedata.quoteRequestData.ContactName = "TestUser";
  //  quotedata.quoteRequestData.EmailAddress = "testUser@test.com";
  //  quotedata.quoteRequestData.PhoneNo = "9833102855";
  //  quotedata.quoteRequestData.Comments = "testing Comments";
  //  quotedata.quoteRequestData.quoteStatusCode = QuoteStatus.NotSubmitted;
  //  quotedata.quoteRequestData.contactAddressSaveProfileIndicator = 1;

  //  service.setQuoteDetails(quotedata);
  //  component.isGuestUser = false;

  //  //service.save();

  //  component.saveForLater();

  //  console.log(service.getQuoteDetails().quoteRequestData.id);
  //  expect(service.getQuoteDetails().quoteRequestData.id).length>0;
  //  expect(service.getQuoteDetails().quoteRequestData.quoteStatusCode).toBeGreaterThan(0);
  //  expect(service.getQuoteDetails().quoteRequestData.lastVisitedPage).toBeGreaterThan(0);

  //});

  //it('Highlight next button with appropitate value', () => {

  //  component.objcontact.contactName = "bingi";   
  //  component.objcontact.emailAddress = "testUser@test.com";
  //  component.objcontact.phoneNumber = "9833102855";
   
  //  expect(component.nextButtonClass()).toEqual("nextButtonEnabled upsSans_Bd");

  //});

  //it('showContactAddress', () => {

  //  component.boolshowContact = true;

  //  component.showContactAddress();

  //});

  //it('showContactAddress', () => {
  //  component.boolshowContact = false;

  //  component.showContactAddress();

  //});

  //it('CancelContactAddress', () => {

  //  component.CancelContactAddress();

  //});

  //it('LoadMore', () => {

  //  component.LoadMore();

  //});

  //it('getUsercontacts', () => {

  //  component.getUsercontacts();

  //});
  //it('getData', () => {

  //  component.getData();

  //});
  //it('UpdateContactDetails', () => {

  //  //component.up();

  //});

  //it('InsertContactDetails', () => {

  //  component.InsertContactDetails();

  //});

  //it('InsertQuoteContact', () => {

  //  component.InsertQuoteContact();

  //});


  //it('loaddata', () => {

  //  component.loaddata();

  //});

  //it('isValidEmail', () => {

  //  component.isValidEmail("ss@aa.com");

  //});
  //it('isValidPhoneNumber', () => {

  //  component.isValidPhoneNumber("9833128874");

  //});

  //it('radioChange', () => {

  //  component.radioChange(1);

  //});
  
  it('should create app', () => {
    expect(component).toBeDefined();
  });  
  
});
