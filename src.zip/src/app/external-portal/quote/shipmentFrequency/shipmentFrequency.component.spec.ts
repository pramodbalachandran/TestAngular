import { async, ComponentFixture, TestBed, getTestBed } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';
import { combineAll, expand } from 'rxjs/operators';
import { by } from 'protractor';
import { Router } from '@angular/router';
import { MockBackend } from '@angular/http/testing';


import { ShipmentFrequencyComponent } from './shipmentFrequency.component';
import { IQuoteData, IQuoteListDetails } from '@app/models/quotes/quote-data'
import { QuoteAPI } from '@app/shared/services';
import { Enviorment } from '@app/services/shared/config.const';
import { UtilitiesService } from '@app/services/shared/utilities.service';
import { RoutingKey } from '@app/services/shared/config.const';
import { PageState ,shipmentFrequencyType} from '@app/services/shared/enum';
import { ConfigService } from '@app/services/shared/config.service';
import { QuoteMockAPI } from '@app/services/mock/quoteMock.service';
import { of } from "rxjs";
import { ModalComponent } from '@app/core/shared/helper/modalpopup.component';



describe('ShipmentFrequencyComponent', () => {

  let component: ShipmentFrequencyComponent;
  let fixture: ComponentFixture<ShipmentFrequencyComponent>;
  let element: any;  
   let injector;
   let service: QuoteAPI<IQuoteData>;
  //let httpMock: HttpTestingController;
  let router = {
    navigate: jasmine.createSpy('navigate')
  }
  var modal;

  beforeEach(async(() => {

    //create a module environment for testing the component.
    //It’s similar to NgModules, except that in this case we’re creating a module for testing.

    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, RouterTestingModule],
      declarations: [ShipmentFrequencyComponent],
      //providers: [{ provide: QuoteAPI, useClass: QuoteMockAPI }, ConfigService, UtilitiesService, { provide: Router, useValue: router }],      //There's no real point. If his is just a unit test for the auth guard, then just mock and spy on the mock to check that it's navigate method was called with the login argument
      providers: [ QuoteAPI , ConfigService, UtilitiesService, { provide: Router, useValue: router }],      //There's no real point. If his is just a unit test for the auth guard, then just mock and spy on the mock to check that it's navigate method was called with the login argument
      schemas: [NO_ERRORS_SCHEMA] //either mock the referenced component or simply ignore it using the NO_ERRORS_SCHEMA directive.
      // Other components are not of interest to us in a unit test.
    })
      .compileComponents()

      //.then(() => {

      //  fixture = TestBed.createComponent(ShipmentFrequencyComponent);
      //  component = fixture.componentInstance;
      //   router = {
      //    navigate: jasmine.createSpy('navigate')
      //  }
      //});

      injector = getTestBed();
      service = injector.get(QuoteAPI);    
  }));

  beforeEach(() => {

    //create an instance of the component-under-test.
    //Once we do this we can’t configure the TestBed again, as an error will be thrown.
    var store = {};

    var localStorage = window.localStorage;
    spyOn(localStorage, 'getItem').and.callFake(function (key) {
      return store[key] !== undefined ? store[key] : null;
    });
    spyOn(localStorage, 'setItem').and.callFake(function (key, value) {
      return store[key] = value + '';
    });
    spyOn(localStorage, 'clear').and.callFake(function () {
      store = {};
    });
    spyOn(localStorage, 'removeItem').and.callFake(function (key, value) {
      delete store[key];
    });

     modal = jasmine.createSpyObj('modal', ['show', 'hide']);

    fixture = TestBed.createComponent(ShipmentFrequencyComponent);
    component = fixture.componentInstance;
    element = fixture.nativeElement;
    fixture.detectChanges();
  });

  ////The shipment Frequency component should be define.
  it("should have a defined component ", () => {
    expect(component).toBeDefined();
  });

  ////The shipment Frequency component should exist.
  it('should have a Component', () => {
    expect(component).toBeTruthy();
  });

  ////Component's sidebar title property should be displayed in the template.
  it("Should have a text as 'Let’s create a quote.' ", async(() => {
    let title = fixture.debugElement.query(By.css('.createQHead')).nativeElement;    
    expect(title.textContent).toEqual("Let’s create a quote.");   
  }));

  ////Component's main title property should be displayed in the template.
  it("Should have a text as 'Tell us how often you plan to send this shipment.' ", async(() => {

    let title = fixture.debugElement.query(By.css('.font32')).nativeElement;   
    expect(title.textContent).toEqual("Tell us how often you plan to send this shipment.");

  }));

  ////verify the ngOnit method

  it('checkingNgOnit for viewing frequency tab with approiate value', () => {
        
    let quotedata = service.getQuoteDetails() as IQuoteData;
    quotedata.quoteRequestData.quoteTypeCode = shipmentFrequencyType.OneTime;
    quotedata.quoteRequestData.businessPartyNumber = localStorage.getItem('testUserName');
    quotedata.quoteRequestData.lastVisitedPage = PageState.SHIPMENT_FREQUENCY;
    service.setQuoteDetails(quotedata);

    component.ngOnInit();

    expect(component.frequencySelected).not.toEqual(shipmentFrequencyType.MultipleTimes);    

  });

  it('Setting frequency tab with approiate value', () => {

    component.selectFrequency(shipmentFrequencyType.OneTime);

    expect(component.frequencySelected).toEqual(shipmentFrequencyType.OneTime);
    expect(component.modelShipmentFrequency).not.toEqual(shipmentFrequencyType.MultipleTimes);

  });

  it('Setting frequency tab with approiate value', () => {

    component.selectFrequency(shipmentFrequencyType.OneTime);

    expect(component.frequencySelected).toEqual(shipmentFrequencyType.OneTime);
    expect(component.modelShipmentFrequency).toEqual(shipmentFrequencyType.OneTime);

  });

  it('Highlight Freqncy tab with appropitate value', () => {

    component.frequencySelected = shipmentFrequencyType.OneTime;
    expect(component.isSelectFrequency(shipmentFrequencyType.OneTime)).toBeTruthy();
    expect(component.nextButtonClass()).toEqual("nextButtonEnabled upsSans_Bd");

  });

  it('No tab selected', () => {

    component.frequencySelected = shipmentFrequencyType.OneTime;
    component.IsNextButtonDisabled();
    expect(component.IsNextButtonDisabled()).not.toBeTruthy();

  });

  // test routing to document upload for mode shipmentFrequncy=MultipleTimes"
  it('Tab-2 selected,Next Click with movement to uploadDocument', () => {
    
    component.frequencySelected = shipmentFrequencyType.MultipleTimes;
    component.OnNextClick();

    //Positive case-true case
    expect(router.navigate).toHaveBeenCalledWith(['/documentUpload']);
    
  });

  // test routing to document upload for mode shipmentFrequncy=OneTime"
  it('Tab-1 selected,Next Click with movement to shipmentMovement', () => {

    component.frequencySelected = shipmentFrequencyType.OneTime;
    component.OnNextClick();

    //Positive case-true case
    expect(router.navigate).toHaveBeenCalledWith(['/shipmentmovement']);  

  });

  //check the back button code coverage and fucntionality
  it('Back', () => {
    
        switch (Enviorment.type) {

        case "dev":
          localStorage.setItem('currentUserName1', 'suzuki2018');

          break;

        case "QA":
          localStorage.setItem('currentUserName1', '');

          break;

        case "UAT":
          localStorage.setItem('currentUserName1', '');

          break;

        case "PROD":
          localStorage.setItem('currentUserName1', '');

          break;
    }

    component.modelShipmentFrequency = shipmentFrequencyType.OneTime;
    component.back()   
    expect(router.navigate).toHaveBeenCalledWith(['/submitServiceType']);
  });

  //check the Next button code coverage and fucntionality
  it('Next with Tab-1', () => {

    switch (Enviorment.type) {

      case "dev":
        localStorage.setItem('currentUserName1', 'suzuki2018');

        break;

      case "QA":
        localStorage.setItem('currentUserName1', '');

        break;

      case "UAT":
        localStorage.setItem('currentUserName1', '');

        break;

      case "PROD":
        localStorage.setItem('currentUserName1', '');

        break;
    }

    component.modelShipmentFrequency = shipmentFrequencyType.OneTime;
    component.OnNextClick()
    expect(router.navigate).toHaveBeenCalledWith(['/shipmentmovement']);
  });

  //check the Next button code coverage and fucntionality
  it('Next with Tab-2', () => {

    switch (Enviorment.type) {

      case "dev":
        localStorage.setItem('currentUserName1', 'suzuki2018');

        break;

      case "QA":
        localStorage.setItem('currentUserName1', '');

        break;

      case "UAT":
        localStorage.setItem('currentUserName1', '');

        break;

      case "PROD":
        localStorage.setItem('currentUserName1', '');

        break;
    }

    component.modelShipmentFrequency = shipmentFrequencyType.MultipleTimes;
    component.OnNextClick()
    expect(router.navigate).toHaveBeenCalledWith(['/documentUpload']);
  });
  
  //------------------need to check the modal issue,hence commented//
  //it('SaveFor Later for guest user', () => {
    
  //  component.clearModel();
  //  component.modelShipmentFrequency = shipmentFrequencyType.OneTime;    
  //  component.saveForLater();
  //  expect(modal.show).toHaveBeenCalled();
  //  expect(localStorage.getItem("IsGuestUser")).toHaveBeenCalled(); 


  //});

  // test routing to document upload for mode shipmentFrequncy=OneTime"
  it('clear quote Model', () => {

    component.clearModel();

    expect(service.getQuoteDetails().quoteRequestData.id).toEqual('');   
   
  });

    
});

describe('ShipmentFrequencyComponent with service call', () => {

  let component: ShipmentFrequencyComponent;
  let fixture: ComponentFixture<ShipmentFrequencyComponent>;
  let element: any;

  let injector;
  let service: QuoteAPI<IQuoteData>;
  //let httpMock: HttpTestingController;
  let router = {
    navigate: jasmine.createSpy('navigate')
  }

  beforeEach(async(() => {

    //create a module environment for testing the component.
    //It’s similar to NgModules, except that in this case we’re creating a module for testing.

    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, RouterTestingModule],
      declarations: [ShipmentFrequencyComponent],
      providers: [{ provide: QuoteAPI, useClass: QuoteMockAPI }, ConfigService, UtilitiesService, { provide: Router, useValue: router }],      //There's no real point. If his is just a unit test for the auth guard, then just mock and spy on the mock to check that it's navigate method was called with the login argument
      //providers: [QuoteAPI, ConfigService, UtilitiesService, { provide: Router, useValue: router }],      //There's no real point. If his is just a unit test for the auth guard, then just mock and spy on the mock to check that it's navigate method was called with the login argument
      schemas: [NO_ERRORS_SCHEMA] //either mock the referenced component or simply ignore it using the NO_ERRORS_SCHEMA directive.
      // Other components are not of interest to us in a unit test.
    })
      .compileComponents()   

    injector = getTestBed();
    service = injector.get(QuoteAPI);    
  }));

  beforeEach(() => {

    //create an instance of the component-under-test.
    //Once we do this we can’t configure the TestBed again, as an error will be thrown.

    fixture = TestBed.createComponent(ShipmentFrequencyComponent);
    component = fixture.componentInstance;
    element = fixture.nativeElement;
    fixture.detectChanges();
  });
  
  it('SaveForLater for LoggedInUser', () => {


    switch (Enviorment.type) {

      case "dev":
        localStorage.setItem('currentUserName1', 'suzuki2018');

        break;

      case "QA":
        localStorage.setItem('currentUserName1', '');

        break;

      case "UAT":
        localStorage.setItem('currentUserName1', '');

        break;

      case "PROD":
        localStorage.setItem('currentUserName1', '');

        break;
    }

    component.modelShipmentFrequency = shipmentFrequencyType.OneTime;
    component.saveForLater();
    expect(router.navigate).toHaveBeenCalledWith(['/dashboard']);
    expect(service.getQuoteDetails().quoteRequestData.id).toEqual('75da460a-a948-4ce5-b9f3-47898f3cb7f5');   

  }); 


});


