import { Component, OnInit, ViewChild } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

import { QuoteDetail } from '@app/shared/interfaces/entities.interface';
import { QuoteAPI } from '@app/shared/services';
import { ModalComponent } from '@app/shared/helper/modalpopup.component';
import { UtilitiesService } from '@app/shared/services/shared/utilities.service';

import { shipmentFrequencyType, PageState } from '@app/shared/services/shared/enum';
import { RoutingKey } from '@app/shared/services/shared/config.const';

import {IQuoteData,IQuoteListDetails} from '@app/models/quotes/quote-data'
import {IQuoteDetails} from '@app/models/quotes/quotes-details'
import {IAirFreightShipmentDetail} from '@app/models/quotes/airfreightshipment-detail'

@Component({
  selector: 'pricing-shipmentFrequency',
  templateUrl: './shipmentFrequency.component.html',
  styleUrls: ['./shipmentFrequency.component.scss'],
  providers: []
})
export class ShipmentFrequencyComponent implements OnInit {
   
  public body: HTMLBodyElement = document.getElementsByTagName('body')[0];
  modelShipmentFrequency: any = {};
  frequencySelected: number = 0;  
  showLogin = false;
  @ViewChild('modalLogin') modallogin: ModalComponent;


  constructor(private quoteService: QuoteAPI<IQuoteData>, private helper: UtilitiesService)
  { }

  ngOnInit() {
    this.body.classList.remove('login-logo');
    if (this.quoteService.getQuoteDetails().quoteRequestData != null) {
      this.modelShipmentFrequency = this.quoteService.getQuoteDetails().quoteRequestData.quoteTypeCode;
      if (this.modelShipmentFrequency != "")
        this.frequencySelected = parseInt(this.modelShipmentFrequency);
      else
        this.frequencySelected = 0;

    }
    //else {
    //  this.frequencySelected = 0;  
    //}
  }

  selectFrequency(btnNo) {   
    this.frequencySelected = btnNo;
    this.modelShipmentFrequency = this.frequencySelected;
  };

  isSelectFrequency(btnNo) {
    return this.frequencySelected === btnNo;
  };

  OnNextClick() {
    this.updateQuoteModel();
    if (this.frequencySelected == shipmentFrequencyType.OneTime) {
      this.helper.navigateTo(RoutingKey[PageState.SHIPMENT_MOVEMENT]);
      return;
    }
    else if (this.frequencySelected == shipmentFrequencyType.MultipleTimes) {
      localStorage.setItem('uploadPageRedirectUrl', 'shipmentFrequency');
      this.helper.navigateTo(RoutingKey[PageState.DOCUMENT_UPLOAD]);
      return;
    }
  }

  IsNextButtonDisabled() {
    return (this.frequencySelected == 0) ? true : false;
  }

  nextButtonClass() {
    if (this.frequencySelected) {
      return "buttonYellow pull-right";
    } else {
      return "buttonGrey pull-right";
    }
  }

  save() {

    var self = this;
    if (localStorage.getItem('currentUserName1') == null) {
      localStorage.setItem('IsGuestUser', 'true');
      this.modallogin.show();
      return;
    }

    this.quoteService.save().subscribe(
      resdata => {
        if (resdata != null) {          
           // this.clearModel();
          //this.router.navigate(['/dashboard']);
          this.helper.navigateTo(RoutingKey[PageState.DASHBOARD]);
        }
      }
    );
  }

  saveForLater() {
    this.updateQuoteModel();
    this.save();
  }

   back() {
    this.updateQuoteModel();
    //this.router.navigate(['/submitServiceType']);
    this.helper.navigateTo(RoutingKey[PageState.SUBMIT_SERVICE_TYPE]);
  }
  
  updateQuoteModel() {
    let quotedata = this.quoteService.getQuoteDetails() as IQuoteData;
    quotedata.quoteRequestData.quoteTypeCode = this.modelShipmentFrequency;
    quotedata.quoteRequestData.businessPartyNumber = window.localStorage.getItem('currentUserName1');
    quotedata.quoteRequestData.lastVisitedPage = PageState.SHIPMENT_FREQUENCY;
    this.quoteService.setQuoteDetails(quotedata);
    return quotedata;
  }

  clearModel() {
    this.quoteService.resetQuoteModel();
  }
}
