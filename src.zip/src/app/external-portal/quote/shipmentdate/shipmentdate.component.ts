import { Component, OnInit, ViewChild } from '@angular/core';
import { DataTableModule } from 'angular-6-datatable';
import { QuoteDetail, AboutShipment,LoaderState } from '@app/shared/interfaces/entities.interface';
import { QuoteAPI } from '@app/shared/services';
import { Router, ActivatedRoute } from '@angular/router';
import { retry } from 'rxjs/operators';
import { LocalStorageService, LoaderService } from '@app/shared/services';
import { ModalComponent } from '@app/shared/helper/modalpopup.component';
import { LoaderComponent } from '@app/shared/components/loader/loader.component';
import { NgbDatepickerConfig, NgbCalendar, NgbDateStruct } from '@ng-bootstrap/ng-bootstrap';
import { NgbDate } from '@ng-bootstrap/ng-bootstrap/datepicker/ngb-date';
import { NgbdModalComponent } from '@app/shared/components/modalpopup/modalpopup.component';


import { IQuoteData, IQuoteListDetails } from '@app/models/quotes/quote-data';
import { IQuoteDetails } from '@app/models/quotes/quotes-details';
import { IAirFreightShipmentDetail } from '@app/models/quotes/airfreightshipment-detail';
import { PageState } from '@app/shared/services/shared/enum';
import { RoutingKey } from '@app/shared/services/shared/config.const';
import { UtilitiesService } from '@app/shared/services/shared/utilities.service';

@Component({
  selector: 'pricing-shipmentdate',
  templateUrl: './shipmentdate.component.html',
  styleUrls: ['./shipmentdate.component.css'],
  providers: [NgbdModalComponent]
})
export class ShipmentdateComponent implements OnInit {
  @ViewChild('modalLogin') modallogin: ModalComponent;

  private shipmentMinDate: Date;
  private shipmentDate: Date;
  private isShipmentDateSelected = false;
  private showPopUp:boolean = true;
  private shipmentNext15Days: Date;
  private model: NgbDateStruct;
  
  constructor(private router: Router, private helper: UtilitiesService, private quoteService: QuoteAPI<IQuoteData>, private popupModal: NgbdModalComponent,
    private localStorageService: LocalStorageService, private config: NgbDatepickerConfig, private calendar: NgbCalendar,
    public loaderService: LoaderService) {

    var workingHours = '17:00';

    this.shipmentMinDate = new Date();
    var hours = this.shipmentMinDate.getHours();
    var minutes = this.shipmentMinDate.getMinutes();

    if (hours == parseFloat(workingHours.toString().split(':')[0])) {
      if (minutes > parseFloat(workingHours.toString().split(':')[1])) {
        this.shipmentMinDate.setDate(this.shipmentMinDate.getDate() + 1);
      }
    }
    else if (hours >= parseFloat(workingHours.toString().split(':')[0])) {
      this.shipmentMinDate.setDate(this.shipmentMinDate.getDate() + 1);
    }

    // customize default values of datepickers used by this component tree
    config.minDate = { year: this.shipmentMinDate.getFullYear(), month: this.shipmentMinDate.getMonth() + 1, day: this.shipmentMinDate.getDate() };
    config.maxDate = { year: 2099, month: 12, day: 31 };
    
    // days that don't belong to current month are not visible
    config.outsideDays = 'visible';
    // weekends are disabled
    //config.markDisabled = (date: NgbDate) => calendar.getWeekday(date) >= 6;

    this.shipmentNext15Days = new Date(config.minDate.year, config.minDate.month-1, config.minDate.day);
    this.shipmentNext15Days.setDate(this.shipmentNext15Days.getDate() + 15);

    var data = this.quoteService.getQuoteDetails();
    if (data && data.airFreightShipmentDetail && data.airFreightShipmentDetail[0].shipmentReadyDate) {
      var dt = new Date(data.airFreightShipmentDetail[0].shipmentReadyDate);
      this.showPopUp = false;
      this.model = { year: dt.getFullYear(), month: dt.getMonth()+1, day: dt.getDate() };
      config.startDate = {
        year: this.model.year,
        month: this.model.month,
      };

      setTimeout(() => {
        this.showPopUp = true;
      }, 500);
    }
  }

  ngOnInit() {
   
  }
  
  isDateInNext15Days(e) {
    var dt = new Date(e.year, e.month - 1, e.day);
    if (dt >= new Date(this.shipmentMinDate.getFullYear(), this.shipmentMinDate.getMonth(), this.shipmentMinDate.getDate())) {
      var dateDiff = this.dateDiffInDays(dt, this.shipmentNext15Days);
      if (dateDiff > 0 && dateDiff<= 15) {
        return true;
      }
    } 
    return false;
  }


  onDateSelect(e) {
    this.isShipmentDateSelected = true;
    this.shipmentDate = new Date(e.year, e.month - 1, e.day);
    if (this.dateDiffInDays(this.shipmentMinDate, this.shipmentDate) >= 15 && this.showPopUp) {
      this.popupModal.open('Message - TBD !!');
    }
  }

  onDateClick(e) {
   
  }

  dateDiffInDays(a, b) {
    const _MS_PER_DAY = 1000 * 60 * 60 * 24;
    const utc1 = Date.UTC(a.getFullYear(), a.getMonth(), a.getDate());
    const utc2 = Date.UTC(b.getFullYear(), b.getMonth(), b.getDate());
    return Math.floor((utc2 - utc1) / _MS_PER_DAY);
  }


  isValidData() {
    return true;
  }

  gotToNext() {
    this.updateQuoteModel();
    this.helper.navigateTo(RoutingKey[PageState.SHIPMENT_SPEED]);
  }

  updateQuoteModel() {
    let quoteModel = this.quoteService.getQuoteDetails() as IQuoteData;
    this.quoteService.getQuoteDetails().quoteRequestData.lastVisitedPage = PageState.SHIPMENT_DATE;
    if (this.model && quoteModel.airFreightShipmentDetail) {
      quoteModel.airFreightShipmentDetail[0].shipmentReadyDate = (new Date(this.model.year, this.model.month - 1, this.model.day));
      this.quoteService.setQuoteDetails(quoteModel);
    }
    return quoteModel;
  }

  onGoback() {
    this.updateQuoteModel();
    this.helper.navigateTo(RoutingKey[PageState.COMMODITY_CHARACTERISTICS]);
  }

  onSaveLater() {
    let quoteModel = this.updateQuoteModel();
    if (quoteModel == null) {
      console.log('No Data');
      return;
    }

    if (localStorage.getItem('currentUserName1') == null) {
      localStorage.setItem('IsGuestUser', 'true');
      this.modallogin.show();
      return;
    }

    this.quoteService.save()
      .subscribe(
        data => {
          if (data != null) {

            this.clearModel();
            this.helper.navigateTo(RoutingKey[PageState.DASHBOARD]);
            return;
          }
        },
        error => {

        });
  }


  clearModel() {
    this.quoteService.resetQuoteModel();
  }
}
