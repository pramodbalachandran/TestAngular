import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ShipmentdateComponent } from './shipmentdate.component';

describe('ShipmentdateComponent', () => {
  let component: ShipmentdateComponent;
  let fixture: ComponentFixture<ShipmentdateComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ShipmentdateComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ShipmentdateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeDefined();
  });
});
