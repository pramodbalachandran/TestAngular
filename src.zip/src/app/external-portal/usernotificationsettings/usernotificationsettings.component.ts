import { Component, OnInit, Input } from '@angular/core';
import { ICustomer,INotificationSettings } from '@app/models';
import { UserRegistrationService, ToasterService, CustomerAPI} from '@app/shared/services';
import { Router } from '@angular/router';

@Component({
  selector: 'app-usernotificationsettings',
  templateUrl: './usernotificationsettings.component.html',
   styleUrls: ['../usersettings/usersettings.component.css']
})
export class UserNotificationSettingsComponent implements OnInit {

  @Input() notifcationModel: INotificationSettings;
  @Input() user: ICustomer;
  notifcationModelBackup: INotificationSettings = {
    emailQuoteStatusExpiring: false,
    emailQuoteRespondByUSP: false,
    emailPickupRequest: false,
    emailPreApprovedRate: false,
    emailResetPassword: false,
  }

  constructor(private router: Router,private _customerAPI: CustomerAPI<any>,private toastr: ToasterService) {
  }

  ngOnInit() {


    var EmailPreApprovedRate = this.notifcationModel.emailPreApprovedRate;
    this.notifcationModelBackup.emailPreApprovedRate = EmailPreApprovedRate;

    var EmailPickupRequest = this.notifcationModel.emailPickupRequest;
    this.notifcationModelBackup.emailPickupRequest = EmailPickupRequest;

    var EmailResetPassword = this.notifcationModel.emailResetPassword;
    this.notifcationModelBackup.emailResetPassword = EmailResetPassword;

    var EmailQuoteStatusExpiring = this.notifcationModel.emailQuoteStatusExpiring;
    this.notifcationModelBackup.emailQuoteStatusExpiring = EmailQuoteStatusExpiring;

    var EmailQuoteRespondByUSP = this.notifcationModel.emailQuoteRespondByUSP;
    this.notifcationModelBackup.emailQuoteRespondByUSP = EmailQuoteRespondByUSP;
    
  }

  setNotifcationModelBackup() {
    this.notifcationModelBackup.emailPreApprovedRate = this.notifcationModel.emailPreApprovedRate;
    this.notifcationModelBackup.emailPickupRequest = this.notifcationModel.emailPickupRequest;
    this.notifcationModelBackup.emailResetPassword = this.notifcationModel.emailResetPassword;
    this.notifcationModelBackup.emailQuoteStatusExpiring = this.notifcationModel.emailQuoteStatusExpiring;
    this.notifcationModelBackup.emailQuoteRespondByUSP = this.notifcationModel.emailQuoteRespondByUSP;
  }

    updateNotificationSettings() {
        var userId = localStorage.getItem('currentUserName');
        //this.userService.updateNotificationSettings(userId, this.notifcationModel)
      this._customerAPI.updateNotificationSettingsAPI(userId, this.user, this.notifcationModel)
            .subscribe(
        data => {
          this.setNotifcationModelBackup();
          this.toastr.success('Successfully updated!');
            //this.router.navigate(['/home']);
        },
        error => {
            this.toastr.error('Registration failed');
        });
  }

  resetNotificationSettings(){
    this.notifcationModel.emailPreApprovedRate = this.notifcationModelBackup.emailPreApprovedRate;
    this.notifcationModel.emailPickupRequest = this.notifcationModelBackup.emailPickupRequest;
    this.notifcationModel.emailResetPassword = this.notifcationModelBackup.emailResetPassword ;
    this.notifcationModel.emailQuoteStatusExpiring = this.notifcationModelBackup.emailQuoteStatusExpiring;
    this.notifcationModel.emailQuoteRespondByUSP = this.notifcationModelBackup.emailQuoteRespondByUSP;
  }

}
