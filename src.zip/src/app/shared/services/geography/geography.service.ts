import { Injectable, EventEmitter } from '@angular/core';
import { HttpClient,HttpResponse,HttpHeaders } from '@angular/common/http';
import { Observable, Subject } from 'rxjs';
import { map, take, tap, catchError} from 'rxjs/operators';

import {  } from '../shared/interfaces/entities.interface';
import { ConfigService } from '@app/shared/services/shared/config.service';
import { ICurrencyData } from '@app/models';


@Injectable()

export class GeaographyAPI<T>{

    _baseUrl: string = '';
    _headers: any;
     currencyData: ICurrencyData =this.getEmptyCurrencyModel();

    constructor(private http: HttpClient, private configSvc: ConfigService) {
        this._baseUrl = configSvc.getGeogrpahyApiURI();
        this._headers = configSvc.getHTTPHeader;
  }

  getCurrencyDetailList() {  

    return this.http 
      .get(this._baseUrl + 'task/Named/GetCurrencyDetailList').pipe(
        map((data: any) => {
          if (data['status'] != '201') {        
          }
          return data;
        }), catchError(error => {
          return this.handleError('Something went wrong!')
        })
      );
  }
  Validateaddressdetails(objdAddress: any) {     
    return this.http.post(this._baseUrl + "task/named/ValidateAddressDetails", objdAddress).pipe(
      map((data: any) => {      
        return data;       
      }), catchError(error => {
        return this.handleError('Something went wrong!')
      })
    );    
  }
  getAirportdetails(businessPartyNumber:string) {


    return this.http
      .post(this._baseUrl + 'task/named/Getairportdetailsforautopopulate', { "businessPartyNumber": businessPartyNumber }).pipe(
        map((data: any) => {
          if (data['status'] != '201') {
            //throw new error('Something went wrong')
          }
          return data;
        }), catchError(error => {
          return this.handleError('Something went wrong!')
        })
      );
  }

  getCountries() {
    
    return this.http
      .post(this._baseUrl  + 'task/named/Getcountrylist',{}).pipe(      
        map((data: any) => {
          if (data['status'] != '201') {         
          }
          return data;
        }), catchError(error => {
          return this.handleError('Something went wrong!')
        })
      );
  }

  getStates(countryCode: string) {
    
    return this.http.post(this._baseUrl  + "task/named/Getcountrylist", { "countryCode": countryCode }).pipe(
      map((data: any) => {     
        if (data['status'] != '201') {        
        }
        return data;     
      }), catchError(error => {
        return this.handleError('Something went wrong!')
      })
    );

  }

  getEmptyCurrencyModel(): ICurrencyData {

    return {
      currencyData: []
      }

    //var currency = [];

    //currency.push({
    //  countryCode: '',
    //  countryName: '',
    //  currencyName: '',
    //  decimalPlacesQuantity: 0,
    //  exchangeRateAmount: 0,
    //  localConversionToUsdAmount: 0,
    //  localCurrencyCode: '',
    //  localeCodes: '',
    //  roundingDirectionText: ''
    //})
    //return currency;
  }

  setCurrencyDetails(value: ICurrencyData) {
    this.currencyData = value;
  }

  getCurrencyDetails() {
    return this.currencyData;
  }

  resetCurrencyModel() {
    this.currencyData = this.getEmptyCurrencyModel();
  }

  

  getPostalCodes() {
    //return this.http.get<any>("/assets/postalcode.json");
    return this.http.get("/assets/postalcode.json", { }).pipe(
      map((data: any) => {
        var postalCodes = [];
        for (let item of data) {
          var mask = [];
          for (let m of item.mask) {
            mask.push(m == " " ? ' ' : m == "-" ? '-' : eval(m));
          }
          postalCodes.push({ 'countryCode': item.countryCode, 'length': item.length, mask: mask });
        }
        return postalCodes;
      }), catchError(error => {
        return this.handleError('Something went wrong!')
      })
    );
  }

  //Not updated for all countries
  getPostalCodeArray() {
    var postalCodes = [];
    postalCodes.push({ 'countryCode': 'AR', 'mask': [/[A-Z]/i, /\d/, /\d/, /\d/, /\d/, /[A-Z]/i, /[A-Z]/i, /[A-Z]/i], 'length': 8 });
    postalCodes.push({ 'countryCode': 'AT', 'mask': [/\d/, /\d/, /\d/, /\d/], 'length': 4 });
    postalCodes.push({ 'countryCode': 'AU', 'mask': [/\d/, /\d/, /\d/, /\d/], 'length': 4 });
    postalCodes.push({ 'countryCode': 'BE', 'mask': [/\d/, /\d/, /\d/, /\d/], 'length': 4 });
    postalCodes.push({ 'countryCode': 'BR', 'mask': [/\d/, /\d/, /\d/, /\d/, /\d/, '-',/\d/, /\d/, /\d/], 'length': 9 });
    postalCodes.push({ 'countryCode': 'CA', 'mask': [/[A-Z]/i, /\d/, /[A-Z]/i, ' ', /\d/, /[A-Z]/i, /\d/], 'length': 7 });
    postalCodes.push({ 'countryCode': 'CL', 'mask': [/\d/, /\d/, /\d/, /\d/, /\d/, /\d/, /\d/,], 'length': 7 });
    postalCodes.push({ 'countryCode': 'CN', 'mask': [/\d/, /\d/, /\d/, /\d/, /\d/, /\d/], 'length': 6 });
    postalCodes.push({ 'countryCode': 'CG', 'mask': [], 'length': 0 });
    postalCodes.push({ 'countryCode': 'CZ', 'mask': [/\d/, /\d/, /\d/, '-', /\d/, /\d/], 'length': 6 });
    postalCodes.push({ 'countryCode': 'DK', 'mask': [/\d/, /\d/, /\d/, /\d/], 'length': 4 });
    postalCodes.push({ 'countryCode': 'RU', 'mask': [/\d/, /\d/, /\d/, /\d/, /\d/, /\d/], 'length': 6 });
    postalCodes.push({ 'countryCode': 'FI', 'mask': [/\d/, /\d/, /\d/, /\d/, /\d/], 'length': 5 });
    postalCodes.push({ 'countryCode': 'FR', 'mask': [/\d/, /\d/, /\d/, /\d/, /\d/], 'length': 5 });
    postalCodes.push({ 'countryCode': 'DE', 'mask': [/\d/, /\d/, /\d/, /\d/, /\d/], 'length': 5 });
    postalCodes.push({ 'countryCode': 'GR', 'mask': [/\d/, /\d/, /\d/, '-', /\d/, /\d/], 'length': 6 });
    postalCodes.push({ 'countryCode': 'HK', 'mask': [/\d/, /\d/, /\d/, /\d/, /\d/, /\d/], 'length': 6 });
    postalCodes.push({ 'countryCode': 'HU', 'mask': [/\d/, /\d/, /\d/, /\d/], 'length': 4 });
    postalCodes.push({ 'countryCode': 'IN', 'mask': [/\d/, /\d/, /\d/, /\d/, /\d/, /\d/], 'length': 6 });
    postalCodes.push({ 'countryCode': 'ID', 'mask': [/\d/, /\d/, /\d/, /\d/, /\d/], 'length': 5 });
    postalCodes.push({ 'countryCode': 'IL', 'mask': [/\d/, /\d/, /\d/, /\d/, /\d/, /\d/, /\d/,], 'length': 7 });
    postalCodes.push({ 'countryCode': 'IT', 'mask': [/\d/, /\d/, /\d/, /\d/, /\d/], 'length': 5 });
    postalCodes.push({ 'countryCode': 'JP', 'mask': [/\d/, /\d/, /\d/, '-', /\d/, /\d/, /\d/, /\d/], 'length': 8 });
    postalCodes.push({ 'countryCode': 'KE', 'mask': [/\d/, /\d/, /\d/, /\d/, /\d/], 'length': 5 });
    postalCodes.push({ 'countryCode': 'KR', 'mask': [], 'length': 0 });
    postalCodes.push({ 'countryCode': 'LU', 'mask': [/\d/, /\d/, /\d/, /\d/], 'length': 4 });
    postalCodes.push({ 'countryCode': 'MY', 'mask': [/\d/, /\d/, /\d/, /\d/, /\d/], 'length': 5 });
    postalCodes.push({ 'countryCode': 'MX', 'mask': [/\d/, /\d/, /\d/, /\d/, /\d/], 'length': 5 });
    postalCodes.push({ 'countryCode': 'NL', 'mask': [/\d/, /\d/, /\d/, /\d/, ' ', /[A-Z]/i, /[A-Z]/i], 'length': 7 });
    postalCodes.push({ 'countryCode': 'NZ', 'mask': [/\d/, /\d/, /\d/, /\d/], 'length': 4 });
    postalCodes.push({ 'countryCode': 'NO', 'mask': [/\d/, /\d/, /\d/, /\d/], 'length': 4 });
    postalCodes.push({ 'countryCode': 'PE', 'mask': [/\d/, /\d/, /\d/, /\d/, /\d/], 'length': 5 });
    postalCodes.push({ 'countryCode': 'PH', 'mask': [/\d/, /\d/, /\d/, /\d/], 'length': 4 });
    postalCodes.push({ 'countryCode': 'PL', 'mask': [/\d/, /\d/, '-', /\d/, /\d/,/\d/], 'length': 6 });
    postalCodes.push({ 'countryCode': 'PT', 'mask': [/\d/, /\d/, /\d/, /\d/, '-', /\d/, /\d/, /\d/], 'length':8 });
    postalCodes.push({ 'countryCode': 'RO', 'mask': [/\d/, /\d/, /\d/, /\d/, /\d/, /\d/], 'length': 6 });
    postalCodes.push({ 'countryCode': 'RU', 'mask': [/\d/, /\d/, /\d/, /\d/, /\d/, /\d/], 'length': 6 });
    postalCodes.push({ 'countryCode': 'SG', 'mask': [/\d/, /\d/, /\d/, /\d/, /\d/, /\d/], 'length': 6 });
    postalCodes.push({ 'countryCode': 'SK', 'mask': [/\d/, /\d/, /\d/,'-',  /\d/, /\d/], 'length': 6 });
    postalCodes.push({ 'countryCode': 'ZA', 'mask': [/\d/, /\d/, /\d/, /\d/], 'length': 4 });
    postalCodes.push({ 'countryCode': 'ES', 'mask': [/\d/, /\d/, /\d/, /\d/, /\d/], 'length': 5 });
    postalCodes.push({ 'countryCode': 'SE', 'mask': [/\d/, /\d/, /\d/, '-', /\d/, /\d/], 'length': 6 });
    postalCodes.push({ 'countryCode': 'CH', 'mask': [/\d/, /\d/, /\d/, /\d/], 'length': 4 });
    postalCodes.push({ 'countryCode': 'TW', 'mask': [/\d/, /\d/, /\d/, /\d/, /\d/], 'length': 5 });
    postalCodes.push({ 'countryCode': 'TH', 'mask': [/\d/, /\d/, /\d/, /\d/, /\d/], 'length': 5 });
    postalCodes.push({ 'countryCode': 'TT', 'mask': [], 'length': 0 });
    postalCodes.push({ 'countryCode': 'TR', 'mask': [/\d/, /\d/, /\d/, /\d/, /\d/], 'length': 5 });
    postalCodes.push({ 'countryCode': 'GB', 'mask': [/[A-Z]/i, /[A-Z]/i, /\d/, ' ', /\d/, /[A-Z]/i, /[A-Z]/i], 'length': 7 });
    postalCodes.push({ 'countryCode': 'US', 'mask': [/\d/, /\d/, /\d/, /\d/, /\d/], 'length': 5 });
    postalCodes.push({ 'countryCode': 'VE', 'mask': [/\d/, /\d/, /\d/, /\d/], 'length': 4 });
    postalCodes.push({ 'countryCode': 'VN', 'mask': [/\d/, /\d/, /\d/, /\d/, /\d/, /\d/], 'length': 6 });
    return postalCodes;
  }
  
  private handleError(error: any) {
    var applicationError = error.headers.get('Application-Error');
    var serverError = error.json();
    var modelStateErrors: string = '';

    if (!serverError.type) {
      console.log(serverError);
      for (var key in serverError) {
        if (serverError[key])
          modelStateErrors += serverError[key] + '\n';
      }
    }
    modelStateErrors = modelStateErrors = '' ? null : modelStateErrors;
    return Observable.throw(applicationError || modelStateErrors || 'Server error');
  }
  

}
