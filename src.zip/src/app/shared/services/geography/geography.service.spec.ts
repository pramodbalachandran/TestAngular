import { TestBed, inject } from '@angular/core/testing';
import { HttpClientModule, HttpClient, HttpResponse } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { Observable,of } from 'rxjs'

import { QuoteDetail } from '@app/shared/interfaces/entities.interface';
import { ConfigService } from '@app/services/shared/config.service';
import { GeaographyAPI } from '@app/shared/services';
import { ICurrencyData } from '@app/models';



describe('Quote Service', () => {

  let service;
  let httpTestingController: HttpTestingController;

  // Mock the service like this and add all the functions you have in this fashion
  let GeographyAPIService: GeaographyAPI<ICurrencyData>,
    mockGeoGraphyService = {
      getCurrencyDetailList: jasmine.createSpy('getCurrencyDetailList').and.returnValue(of(
        {
          "result": {
            "pageSize": 100,
            "totalResults": 1,
            "results": [
              {
                "docType": "currencyConversion",
                "docId": "currencyConversion::10162018",
                "docCategory": "referenceCurrency",
                "docStructureVersion": "1",
                "currencyConversion": [
                  {
                    "countryCode": "YU",
                    "countryName": "YUGOSLAVIA",
                    "exchangeRateAmount": 1,
                    "currencyName": "USD",
                    "decimalPlacesQuantity": 2,
                    "roundingDirectionText": null,
                    "localCurrencyCode": null,
                    "localeCodes": "",
                    "localConversionToUsdAmount": null
                  },
                  {
                    "countryCode": "ZW",
                    "countryName": "ZIMBABWE",
                    "exchangeRateAmount": 1,
                    "currencyName": "USD",
                    "decimalPlacesQuantity": 2,
                    "roundingDirectionText": null,
                    "localCurrencyCode": "ZWN",
                    "localeCodes": "",
                    "localConversionToUsdAmount": null
                  }
                ],
                "id": "1ab65b62-1061-0fd2-0ccc-8bfcb9c07840",
                "partitionKey": "currency",
                "lastContinuationToken": null
              }
            ],
            "continuationToken": null
          },
          "id": 1,
          "exception": null,
          "status": 5,
          "isCanceled": false,
          "isCompleted": true,
          "isCompletedSuccessfully": true,
          "creationOptions": 0,
          "asyncState": null,
          "isFaulted": false
        }))
    };

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule
      ],
      providers: [{
        provide: GeaographyAPI,
        useValue: mockGeoGraphyService
      }, ConfigService]
    });
    httpTestingController = TestBed.get(HttpTestingController);
  });

  // Do this trick to inject the service every time, and just use `service` in your tests
  beforeEach(inject([GeaographyAPI], s => {
    service = s;
  }));

  beforeEach(() => {
  });


  afterEach(() => {
    // After every test, assert that there are no more pending requests.
    httpTestingController.verify();
  });

  it('Geography Service should be defined', () => {
    expect(service).toBeDefined();
  });

  it('Geography Service should be created', () => {
    expect(service).toBeTruthy();
  });

  describe('getCurrencyDetailList', () => {

    it('should return getCurrencyDetail List', () => {

      let fakeResponse = null;

      // Call the service function and subscribe to it to catch the fake response coming from the mock.
      service.getCurrencyDetailList().subscribe((data) => {
        // in here value will be whatever you put as returnValue (remember to keep the observable.of())
        fakeResponse = data;
      });

      // expects as in any test.
      expect(fakeResponse).toBeDefined();
      expect(fakeResponse.result.results[0]["currencyConversion"][0]["countryName"]).toBe("YUGOSLAVIA");
      expect(fakeResponse.result.results[0]["currencyConversion"][1]["localCurrencyCode"]).toBe("ZWN");
    });

  });

});







