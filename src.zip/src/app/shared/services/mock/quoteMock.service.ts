import { Injectable, EventEmitter } from '@angular/core';
import { HttpClient, HttpResponse, HttpHeaders } from '@angular/common/http';
import { Observable, Subject } from 'rxjs';
import { map, take, tap, catchError, retry } from 'rxjs/operators';

import { QuoteDetail, IAirportODPair } from '@app/shared/interfaces/entities.interface';
import { ConfigService } from '@app/services/shared/config.service';
import { IQuoteData, IQuoteListDetails } from '@app/models/quotes/quote-data';
import { IQuoteDetails } from '@app/models/quotes/quotes-details';
import { IAirFreightShipmentDetail } from '@app/models/quotes/airfreightshipment-detail';
import { error } from '@angular/compiler/src/util';
import { strictEqual } from 'assert';
import { of } from "rxjs";

@Injectable()
export class QuoteMockAPI<T>{


    quoteDetail: IQuoteData = this.getEmptyQuoteModel();

    constructor() {

    }

    setQuoteDetails(value) {
        this.quoteDetail = value;
    }

    getQuoteDetails() {
        return this.quoteDetail;
    }

    resetQuoteModel() {
        this.quoteDetail = this.getEmptyQuoteModel();
    }

    getQuoteModelshipmentFrequency() {
        return of({
            quoteRequestData: {
                id: '75da460a-a948-4ce5-b9f3-47898f3cb7f5',
                docId: '',
                quoteNumber: '',
                businessPartyName: '',
                businessPartyNumber: '',
                accountNumber: '',
                quoteRequestDate: null,
                quoteStatusCode: 1,
                quoteStatusUpdateDate: '',
                quoteServiceType: '2',
                quoteTypeCode: 1,
                quoteDeclineReasonTypeCode: 0,
                quoteDeclineReasonTypeNote: '',
                quoteRate: '',
                marketRate: '',
                ContactName: '',
                PhoneNo: '',
                EmailAddress: '',
                Comments: '',
                lastVisitedPage: '5',
                rateTabIndicator: 0,
                contactAddressSaveProfileIndicator: 0,
                quoteAttachment: [],
                quoteName :'',
                shipmentReadyDate:null,
                serviceTypes:null,
                customesBrokerage:'',
                termsOfSale:'',
                insuranceRequiredIndicator:false,
                shipmentInsuranceAmount:0,
                defaultCurrency:'',
                quoteNotes:'',
                quoteValidityPeriod:'',
                quoteValidityStartDate:null,
                quoteValidityEndDate: null,
                customerTemplateIndicator: false
            },
            airFreightShipmentDetail: []
        })
    }

    getEmptyQuoteModel(): IQuoteData {
        return {
            quoteRequestData: {
                id: '',
                docId: '',

                quoteNumber: '',
                businessPartyName: '',
                businessPartyNumber: '',
                accountNumber: '',
                quoteRequestDate: null,
                quoteStatusCode: 1,
                quoteStatusUpdateDate: '',
                quoteServiceType: '0',
                quoteTypeCode: 0,
                quoteDeclineReasonTypeCode: 0,
                quoteDeclineReasonTypeNote: '',
                quoteRate: '',
                marketRate: '',
                ContactName: '',
                PhoneNo: '',
                EmailAddress: '',
                Comments: '',
                lastVisitedPage: '',
                rateTabIndicator: 0,
                contactAddressSaveProfileIndicator: 0,
                quoteAttachment: [],
                quoteName :'',
                shipmentReadyDate:null,
                serviceTypes:null,
                customesBrokerage:'',
                termsOfSale:'',
                insuranceRequiredIndicator:false,
                shipmentInsuranceAmount:'',
                defaultCurrency:'',
                quoteNotes:'',
                quoteValidityPeriod:'',
                quoteValidityStartDate:null,
                quoteValidityEndDate: null,
                customerTemplateIndicator:false
            },
            airFreightShipmentDetail: []
        }
    }

    save(): Observable<IQuoteData> {

        this.quoteDetail.quoteRequestData.id = '75da460a-a948-4ce5-b9f3-47898f3cb7f5';
        //this.quoteDetail.airFreightShipmentDetail.id = '77da460a-a948-4ce5-b9f3-47898f3cb7f7';
        return of(this.quoteDetail);
    }



    getAirportODPairLaneDetail(): Observable<IAirportODPair[]> {
        let airports = [];

        airports.push({
            quoteType: 1,
            origin: "IND",
            destination: "US",
            originCode: "IND",
            destinationCode: "US",
            originCountryCode: "IND",
            destinationCountryCode: "US",
            originRegion: "IND",
            destinationRegion: "US"
        }, {
                quoteType: 2,
                origin: "IND",
                destination: "US",
                originCode: "IND",
                destinationCode: "US",
                originCountryCode: "IND",
                destinationCountryCode: "US",
                originRegion: "IND",
                destinationRegion: "US"
            })
        return of(airports);
    }
}
