import { Injectable, EventEmitter } from '@angular/core';
import { HttpClient,HttpResponse,HttpHeaders } from '@angular/common/http';
import { Observable, Subject } from 'rxjs';
import { map, take, tap, catchError} from 'rxjs/operators';
import {  } from '../shared/interfaces/entities.interface';
import { ConfigService } from '@app/shared/services/shared/config.service';
import { ICurrencyData } from '@app/models';
import { of } from "rxjs";

@Injectable()
export class GeaographyMockAPI<T>{

    _baseUrl: string = '';
    _headers: any;
     states = [];

    constructor(private http: HttpClient, private configSvc: ConfigService) {
        this._baseUrl = configSvc.getGeogrpahyApiURI();
        this._headers = configSvc.getHTTPHeader;
  }

  getAirportdetails(businessPartyNumber:string):Observable<any>
  {
    this.states.push({airportCode: "AAR",
      airportName: "AARHUS",
      autopopulateformat: "AAR Ulstrup,Denmark-Aarhus",
      countryCode: "DK",
      countryName: "Denmark",
      isCustomerData: "0",
      politicalDivision2Name: "ULSTRUP"});
  
      this.states.push({airportCode: "ABE",
      airportName: "ALLENTOWN",
      autopopulateformat: "ABE Eckert,United States-Allentown",
      countryCode: "US",
      countryName: "United States",
      isCustomerData: "0",
      politicalDivision2Name: "ECKERT"});
  
      this.states.push({airportCode: "ABE",
      airportName: "ALLENTOWN",
      autopopulateformat: "ABE Forty Fort,United States-Allentown",
      countryCode: "US",
      countryName: "United States",
      isCustomerData: "0",
      politicalDivision2Name: "FORTY FORT"});
  
      this.states.push({airportCode: "ABE",
      airportName: "ALLENTOWN",
      autopopulateformat: "ABE Kohinoor Junction,United States-Allentown",
      countryCode: "US",
      countryName: "United States",
      isCustomerData: "0",
      politicalDivision2Name: "KOHINOOR JUNCTION"});
  
      this.states.push({airportCode: "ABE",
      airportName: "ALLENTOWN",
      autopopulateformat: "ABE Portland,United States-Allentown",
      countryCode: "US",
      countryName: "United States",
      isCustomerData: "0",
      politicalDivision2Name: "PORTLAND"});
  
      this.states.push({airportCode: "ABQ",
      airportName: "ALBUQUERQUE",
      autopopulateformat: "ABQ Roswell,United States-Albuquerque",
      countryCode: "US",
      countryName: "United States",
      isCustomerData: "0",
      politicalDivision2Name: "ROSWELL"});
  
      this.states.push({airportCode: "ABQ",
      airportName: "ALBUQUERQUE",
      autopopulateformat: "ABQ Willard,United States-Albuquerque",
      countryCode: "US",
      countryName: "United States",
      isCustomerData: "0",
      politicalDivision2Name: "WILLARD"});

      return of(this.states);

  }


}
