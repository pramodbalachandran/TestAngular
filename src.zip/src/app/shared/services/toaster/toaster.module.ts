import { Injectable } from '@angular/core';
import { Headers } from '@angular/http';
import { Subject } from 'rxjs';

@Injectable()
export class ToasterService {

  constructor() {

  }

  success(message) {
    toastr.success(message);
  }

  info(message) {
    toastr.info(message);
  }

  warning(message) {
    toastr.warning(message);
  }

  error(message) {
    toastr.error(message);
  }
}

