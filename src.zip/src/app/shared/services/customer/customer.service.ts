import { Injectable, EventEmitter } from '@angular/core';
import { HttpClient,HttpResponse,HttpHeaders } from '@angular/common/http';
import { Observable, Subject } from 'rxjs';
import { map, take, tap, catchError} from 'rxjs/operators';
import { ICustomer, Customer, IContactsDetails, IShippingAddress, IBillingAddress, INotificationSettings, IUpser } from '@app/models';
import { IUser } from '@app/shared/interfaces/entities.interface';
import { ConfigService } from '@app/shared/services/shared/config.service';
import { User,getShippingAddress, ShippingAddress, LoggedInUser, IContactSettings, NotificationSettings} from '@app/shared/interfaces/entities.interface';
import { error } from 'util';

@Injectable()

export class CustomerAPI<T>{

    customerDetail: ICustomer = this.getEmptyUserModel();
    upserDetail: IUpser;
   _baseUrl: string = '';
   _headers: any;
    username: string;
    usernameAccessToken: string;
    user: IUser = {
    id: '',
    CompanyName: '',
    ContactName: '',
    UPSAccountNo: '',
    ContactType: '',
    CountryCode: '',
    PhoneNo: '',
    Extension: '',
    EmailAddress: '',
    UserId: '',
    Password: '',
    ConfirmPassword: '',
    TermsAccepted: false
  };
    loginModel: any = {
    Username: '',
    Password: '',
    };
    logInUser: LoggedInUser = {
    username: ''
  }

  constructor(private http: HttpClient, private configSvc: ConfigService) {
        this._baseUrl = configSvc.getCustomerApiURI();
        this._headers = configSvc.getHTTPHeader;
  }
  
  setCustomerProfileDetails(value) {
    this.customerDetail = value;
  }

  getCustomerProfileDetails() {
    return this.customerDetail;
  }

  setUpserProfileDetails(value) {
    this.upserDetail = value;
  }
  
  getUpserProfileDetails() {
    return this.upserDetail;
  }

  //login process

  ValidateUser(loginModel: any) {    

    return this.http.post(this._baseUrl + 'api/task/ValidateUser', loginModel).pipe(
      map((data: any) => {
        if (data['status'] != '200') {
        }
        return data;
      }), catchError(error => {
        return this.handleError('system error!')
      })
    );   
  }

  //set password

  verifyUser(ForgotPassword: any) {

    return this.http.post(this._baseUrl + 'api/task/ForgotPassword', ForgotPassword).pipe(
      map((data: any) => {
        if (data['status'] != '200') {
        }
        return data;
      }), catchError(error => {
        return this.handleError('Something went wrong!')
      })
    );
  }

  verifyFPCode(OTPModel: any) {

    return this.http.post(this._baseUrl + 'api/task/VerifyFPCode', OTPModel).pipe(
      map((data: any) => {
        if (data['status'] != '200') {
        }
        return data;
      }), catchError(error => {
        return this.handleError('Something went wrong!')
      })
    );
  }

  resetPassword(resetPasswordModel: any) {

    return this.http.post(this._baseUrl + 'api/task/ResetPswd', resetPasswordModel).pipe(
      map((data: any) => {
        if (data['status'] != '204') {
        }
        return data;
      }), catchError(error => {
        return this.handleError('Something went wrong!')
      })
    );
  }
  //set password


  //registration of new user

  create(user: IUser) {

    return this.http.post(this._baseUrl + 'api/task/CreateUser', user).pipe(
      map((data: any) => {
        if (data['status'] != '201') {  
        }
        return data;
      }), catchError(error => {
        return this.handleError('Something went wrong!')
      })
    );   
  }

  createUser(user: ICustomer) {
    return this.http.post(this._baseUrl + 'api/task/CreateUser', user).pipe(
      map((data: any) => {
        return data;
      }), catchError(error => {
        return this.handleError('Something went wrong!')
      })
    );
  }

  createUpser(user: IUpser) {
    return this.http.post(this._baseUrl + 'api/task/CreateUpser', user).pipe(
      map((data: any) => {
        return data;
      }), catchError(error => {
        return this.handleError('Something went wrong!')
      })
    );
  }

  //Get profile details

  getUserByUserId(id: string) {
    return this.http
      .post(this._baseUrl + 'api/task/GetCustomerProfile', {
        "customerId": id
      }).pipe(
        map((data: any) => {
          if (data['results'][0] != null) {
            return (data['results'][0]) as ICustomer;
          }
          return null;
        }), catchError(error => {
          return this.handleError('Something went wrong!')
        })
      );;
  }

  getUpserByUserId(id: string) {
    return this.http
      .post(this._baseUrl + 'api/task/GetUpserProfile', {
        "customerId": id
      }).pipe(
        map((data: any) => {
          if (data['results'][0] != null) {
            return (data['results'][0]) as IUpser;
          }
          return null;
        }), catchError(error => {
          return this.handleError('Something went wrong!')
        })
      );;
  }  

  update(id: string, user: User) {
    return this.http
      .post(this._baseUrl + 'api/task/UpdateCustProfile', user).pipe(
        map((data: any) => {
          return data;
        }), catchError(error => {
          return this.handleError('Something went wrong!')
        })
      );    
  }

  updateNotificationSettingsAPI(id: string, user: ICustomer, notificationSettings: INotificationSettings) {
    user.notificationSettings = notificationSettings;
    return this.updateUserProfile(user);
  }

  //Get Shipping address details

  getExistingShippingAddress(input: getShippingAddress): Observable<any> {

    return this.http.post(this._baseUrl + "api/task/CustShipAddress", input).pipe(
      map((data: any) => {
        return data;
      }), catchError(error => {
        return this.handleError('Something went wrong!')
      })
    );

  }

  createNewShippingAddress(objVal: ShippingAddress): Observable<any> {
    return this.http.post(this._baseUrl + "/api/task/AddShippingAddr", objVal).pipe(
      map((data: any) => {
        return data;   
      }), catchError(error => {
        return this.handleError('Something went wrong!')
      })
    );
  }

  updateShippingAddress(objVal: ShippingAddress): Observable<any> {

    return this.http.post(this._baseUrl + "/api/task/UpdateShipAddr", objVal).pipe(
      map((data: any) => {
        //console.log(data);
        //console.log(JSON.parse(data));
        return data;
        //return JSON.parse(data);
      }), catchError(error => {
        return this.handleError('Something went wrong!')
      })
    );

  }

  //Get Contact Details

  getContactsList() {

    return this.http
      .post(this._baseUrl + 'api/task/GetContacts', {
        "customerId": localStorage.getItem('currentUserName1')
      }).pipe(
        map((data: any) => {  
          return data;     
        }), catchError(error => {
          return this.handleError('Something went wrong!')
        })
      );;
  }

  addContactsList(contactData: any) {

    return this.http
      .post(this._baseUrl + 'api/task/AddContactDetails', contactData).pipe(
        map((data: any) => {
          return data;     
        }), catchError(error => {
          return this.handleError('Something went wrong!')
        })
      );;
  }

  updateContactsList(contactData: IContactSettings) {

    return this.http
      .post(this._baseUrl + 'api/task/UpdateContact', contactData).pipe(
        map((data: any) => {   
          return data;         
        }), catchError(error => {
          return this.handleError('Something went wrong!')
        })
      );;
  }

 

  getCity(countryCode: string, stateCode: string) {
    var objCity = {
      "countryCode": countryCode,
      "cityCode": stateCode
    }

    return this.http.post(this._baseUrl + "task/named/Getcountrylist", objCity).pipe(
      map((data: any) => {
        //console.log(data);
        //console.log(JSON.parse(data));
        if (data['status'] != '201') {
          //throw new error('Something went wrong')
        }
        return data;
        //return JSON.parse(data);
      }), catchError(error => {
        return this.handleError('Something went wrong!')
      })
    );

  }
  
  //Handle errors

  private handleError(error: any) {
    var applicationError = error.headers.get('Application-Error');
    var serverError = error.json();
    var modelStateErrors: string = '';

    if (!serverError.type) {
      console.log(serverError);
      for (var key in serverError) {
        if (serverError[key])
          modelStateErrors += serverError[key] + '\n';
      }
    }
    modelStateErrors = modelStateErrors = '' ? null : modelStateErrors;
    return Observable.throw(applicationError || modelStateErrors || 'Server error');
  }

 
  //other--cold be remove later   


  getUsersCountByEmail(email: string) {
    var url = this._baseUrl + 'api/task/RequestForAssociatedUserIds';

    return this.http
      .post(url, {
        "emailId": email
      }).pipe(
      map((data: any) => {
          return data;
        }), catchError(error => {
          return this.handleError('Something went wrong!')
        })
    );

  }

  getUserNameSuggestion(userId: string) {
    var url = this._baseUrl + 'api/task/GetUsernameSuggestion';

    return this.http
      .post(url, {
        "customerId": userId
      }).pipe(
      map((data: any) => {
          if (data[0] == "Username is Available") {
            return [];
          }
          return data;
        }), catchError(error => {
          return this.handleError('Something went wrong!')
        })
      );

  }

  sendUserIdsMail(email: string) {
    var url = this._baseUrl + 'api/task/EmailMyUserIds';

    return this.http
      .post(url, {
        "EmailId": email
      }).pipe(
        map((data: any) => {
          return data;
        }), catchError(error => {
          return this.handleError('Something went wrong!')
        })
      );
  }

  sendUserIdsMailAPI(email: string) {
    return this.http.post(this._baseUrl + 'api/task/RequestForAssociatedUserIds', {
      "emailId": email
    });

  }

  /* User Settings start*/
  getEmptyUserModel(): ICustomer {
    return {
      id: '',
      docType: '',
      docId: '',
      docStructureVersion: 0,
      partitionkey: '',
      businessPartyName: '',
      businessPartyNumber: '',
      accountNumber: '',
      tempAccountNumber: '',
      companyName: '',
      contactName: '',
      contactType: 'Mobile',
      phoneCountryCode: '',
      phoneNumber: '',
      extension: '',
      password: '',
      confirmPassword: '',
      emailAddress: '',
      userId: '',
      termsAccepted: false,
      contactAddressName: '',
      contactAddress: '',
      contactAddressLine1: '',
      contactAddressLine2: '',
      countryCode: '',
      countryName: '',
      politicalDivision1Code: '', //state
      politicalDivision1Name:'',
      politicalDivision2Name: '', // city
      postalCode: '',
      contactAsBillingAddressIndicator: false,
      defaultCurrency:'',
      contactsDetails: [],
      billingAddress: [],
      shippingAddress: [],
      notificationSettings: { emailPickupRequest: false, emailPreApprovedRate: false, emailQuoteRespondByUSP: false, emailQuoteStatusExpiring: false, emailResetPassword: false }
    }
  }

  resetUserModel() {
    this.customerDetail = this.getEmptyUserModel();
  }

  updateUserProfile(user: ICustomer) {
    return this.http
      .post(this._baseUrl + 'api/task/UpdateCustomerProfile ', user).pipe(
        map((data: any) => {
          return data;
        }), catchError(error => {
          return this.handleError(error);
        }));
  }

  updateUpserProfile(user: IUpser) {
    return this.http
      .post(this._baseUrl + 'api/task/UpdateUpserProfile ', user).pipe(
        map((data: any) => {
          return data;
        }), catchError(error => {
          return this.handleError(error);
        }));
  }

  /* User Settings End*/

}
