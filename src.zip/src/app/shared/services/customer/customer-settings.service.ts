import { Injectable, EventEmitter } from '@angular/core';
import { HttpClient,HttpResponse,HttpHeaders } from '@angular/common/http';
import { Observable, Subject } from 'rxjs';
import { map, take, tap, catchError, retry } from 'rxjs/operators';
import { ConfigService } from '@app/shared/services/shared/config.service';
import { ICustomer, Customer, IContactsDetails,IShippingAddress,IBillingAddress,INotificationSettings } from '@app/models'

@Injectable()
export class CustomerSettingsAPI<T>{

  private _baseUrl: string = '';
  private _headers: any;
  private customerDetail: ICustomer = this.getEmptyUserModel();
  

  constructor(private http: HttpClient, private configSvc: ConfigService) {
      this._baseUrl = configSvc.getQuoteApiURI();
      this._headers = configSvc.getHTTPHeader;
  }

  resetUserModel() {
     this.customerDetail = this.getEmptyUserModel();
  }

  public getEmptyUserModel(): ICustomer {
    return null;
  }

  save(): Observable<any> {
    
    return this.http.post(this._baseUrl + 'task/named/SaveQuotesData', this.customerDetail).pipe(
      map((data: any) => {
        if (data.responseStatus.status == '200') {
          return '';
        }
        else {
          console.log(data);
          return this.handleError(data.responseData)
        }
      }), catchError(error => {
        console.log(error);
        return this.handleError('Internal Server Error!!!')
      })
    );
  }

  update(userId: string,customer:ICustomer) {

    return this.http.post(this._baseUrl + 'task/named/SaveQuotesData', this.customerDetail).pipe(
      map((data: any) => {
        if (data.responseStatus.status == '200') {
          return '';
        }
        else {
          console.log(data);
          return this.handleError(data.responseData)
        }
      }), catchError(error => {
        console.log(error);
        return this.handleError('Internal Server Error!!!')
      })
    );
  }

  getAll() {
    return this.http.get<ICustomer[]>('/api/users');
  }

  getById(id: string) {
    return this.http.post(this._baseUrl + 'GetSavedQuote', { "id": id }).pipe(
      map((data: any) => {
        if (data['results'][0] != null) {
          return (data['results'][0]) as ICustomer;
        }
        return null;
      }), catchError(error => {
        return this.handleError('Internal Server Error!!!')
      })
    );
  }

  getCountries() {
    return this.http.get('/api/users/getCountries');
  }

  getStates(countryCode: string) {
    return this.http.get('/api/users/getStatesByCountryId/' + countryCode);
  }

  private handleError(error: any) {
    var applicationError = error.headers.get('Application-Error');
    var serverError = error.json();
    var modelStateErrors: string = '';

    if (!serverError.type) {
      console.log(serverError);
      for (var key in serverError) {
        if (serverError[key])
          modelStateErrors += serverError[key] + '\n';
      }
    }
    modelStateErrors = modelStateErrors = '' ? null : modelStateErrors;
    return Observable.throw(applicationError || modelStateErrors || 'Server error');
  }

}




