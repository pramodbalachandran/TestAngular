import { Injectable } from '@angular/core';
import { HttpParams, HttpClient } from '@angular/common/http';
import { ShippingAddress, getShippingAddress, User} from '@app/shared/interfaces/entities.interface';
import { Observable, Subject, throwError } from 'rxjs';
import { map, tap, catchError } from 'rxjs/operators';

@Injectable({
    providedIn: 'root'
})
export class ShipingaddresserviceService {


    public addresess: any[];
  private _baseUrl: string = "https://bon-customer-api-uat.azurewebsites.net/api/task/CustShipAddress";
  private _baseUpdateUrl: string = "https://bon-customer-api-uat.azurewebsites.net/api/task/UpdateShipAddr";
  private _baseAddUrl: string = "https://bon-customer-api-uat.azurewebsites.net/api/task/AddShippingAddr";


    constructor(private http: HttpClient) {
        //this._baseUrl = getfrom config
    }

    getExistingShippingAddress(input: getShippingAddress): Observable<any> {
        //return this.getaddresslist();
        //return this.http.get(this._baseUrl + "/assets/user.json");
        //return this.http.post(this._baseUrl, JSON.stringify(input)).pipe(
        //    map((data: any[]) => {
        //        return data;
        //    }), catchError(error => {
        //        return this.handleError('Something went wrong!')
        //    })
        //);
        //console.log("service hitting");
        return this.http.post(this._baseUrl, input).pipe(
            map((data: any) => {
                //console.log(data);
                //console.log(JSON.parse(data));
                return data;
                //return JSON.parse(data);
            }), catchError(error => {
                return this.handleError('Something went wrong!')
            })
        );

    }

    createNewShippingAddress(objVal: ShippingAddress): Observable<any> {
        return this.http.post(this._baseAddUrl, objVal).pipe(
            map((data: any) => {
                //console.log(data);
                //console.log(JSON.parse(data));
                return data;
                //return JSON.parse(data);
            }), catchError(error => {
                return this.handleError('Something went wrong!')
            })
        );


    }
    
    updateShippingAddress(objVal: ShippingAddress): Observable<any> {
        return this.http.post(this._baseUpdateUrl, objVal).pipe(
            map((data: any) => {
                //console.log(data);
                //console.log(JSON.parse(data));
                return data;
                //return JSON.parse(data);
            }), catchError(error => {
                return this.handleError('Something went wrong!')
            })
        );

    }

    private handleError(error: any) {
        var applicationError = error.headers.get('Application-Error');
        var serverError = error.json();
        var modelStateErrors: string = '';

        if (!serverError.type) {
            console.log(serverError);
            for (var key in serverError) {
                if (serverError[key])
                    modelStateErrors += serverError[key] + '\n';
            }
        }

        modelStateErrors = modelStateErrors = '' ? null : modelStateErrors;

        return Observable.throw(applicationError || modelStateErrors || 'Server error');
    }

}
