import { Injectable } from '@angular/core';
import { HttpParams, HttpClient, HttpHeaders } from '@angular/common/http';

import { User, NotificationSettings, RecoveryPassword, IContactSettings} from '@app/shared/interfaces/entities.interface';
import { ConfigService } from '@app/shared/services/shared/config.service';

@Injectable()
export class UserRegistrationService {

  private _baseUrl: string = '';
  private _headers: any;

  constructor(private http: HttpClient, private configSvc: ConfigService) {
    this._baseUrl = configSvc.getCustomerApiURI();
    this._headers = configSvc.getHTTPHeader;
  }
  //constructor(private http: HttpClient, private configService: ConfigService) { }

  getAll() {
    return this.http.get<User[]>('/api/users');
  }

  getById(id: number) {
    return this.http.get('/api/users/' + id);
  }


  getCountries() {
    return this.http.get('/api/users/getCountries');
  }

  getStates(countryId: number) {
    return this.http.get('/api/users/getStatesByCountryId/' + countryId);
  }

  verifyCombanationOfUserIdEmail(recoverPasswordModel: RecoveryPassword) {

    //let params = new HttpParams();
    //params = params.append("userId", id);
    //params = params.append("emailAddress", emailAddress);
    return this.http.post('/api/verifyuserIdEmailAddress', recoverPasswordModel);
  }

  //updateNotificationSettings(id: string, notificationSettings: NotificationSettings) {
  //  return this.http.post('/api/users/updateNotificationSettings/' + id, notificationSettings);
  //}

  //updateNotificationSettingsAPI(id: string, user: User, notificationSettings: NotificationSettings) {
  //  user.NotificationSettings = notificationSettings;
  //  return this.update(id, user);
  //}

  //getUserByUserIdOLD(id: string) {
  //  return this.http.get('/api/users/getUserByUserId/' + id);
  //}

  //getUserByUserId(id: string) {

  //  //let headers = this.configService.getHTTPHeader();
  //  //headers.append('Access-Control-Allow-Origin', '*');

  //  //return this.http
  //  //.post('http://localhost:34672/api/task/CustProfile', {
  //  //    "Cust_Id": id
  //  //}, { headers: headers });

  //  return this.http
  //    .post(this._baseUrl + 'api/task/CustProfile', {
  //      "Cust_Id": id
  //    });

  //  //var options = new RequestOptions({
  //  //    method: RequestMethod.Post
  //  //});

  //  //var req = new Request(options.merge({
  //  //    url: 'http://localhost:34672/api/task/CustProfile'
  //  //}));

  //  //return this.http.post('http://localhost:34672/api/task/CustProfile', {
  //  //    "Cust_Id": id
  //  //},);
  //}


  getUsersCountByEmail(email: string) {
    return this.http.get('/api/users/getUsersCountByEmail/' + email);
  }

  sendUserIdsMail(email: string) {
    return this.http.get('/api/users/sendUserIdsMail/' + email);
  }

  sendUserIdsMailAPI(email: string) {
    return this.http.post(this._baseUrl + 'api/task/RequestForAssociatedUserIds', {
      "emailId": "u78675@maildev.ust-global.com"
    });

  }


  //create(user: User) {
  //  //headers.append('Access-Control-Allow-Origin', '*');
  //  //let bodyString = JSON.stringify(user); 
  //  //let headers = new Headers({ 'Content-Type': 'application/json' }); // ... Set content type to JSON
  //  //let options = new RequestOptions({ headers: headers }); 
  //  return this.http.post('/api/users', user);
  //}

  //update(id: string, user: User) {
  //  return this.http
  //    .post(this._baseUrl + 'api/task/UpdateCustProfile', user);
  //  //return this.http.put('/api/users/' + id, user);
  //}

  //delete(id: number) {
  //  return this.http.delete('/api/users/' + id);
  //}

  //getContactsList() {

  //  return this.http
  //    .post(this._baseUrl + 'api/task/GetContacts', {
  //      "Cust_Id": "001"
  //    });
  //}

  //addContactsList(contactData: any) {

  //  return this.http
  //    .post(this._baseUrl + 'api/task/AddContactDetails', contactData);
  //}

  //updateContactsList(contactData: IContactSettings) {

  //  return this.http
  //    .post(this._baseUrl + 'api/task/UpdateContact', contactData);
  //}

}
