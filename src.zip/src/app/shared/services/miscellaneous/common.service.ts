import { Injectable, EventEmitter } from '@angular/core';
import { HttpClient,HttpResponse,HttpHeaders } from '@angular/common/http';
import { Observable, Subject } from 'rxjs';
import { map, take, tap, catchError} from 'rxjs/operators';

import {  } from '../shared/interfaces/entities.interface';
import { ConfigService } from '@app/shared/services/shared/config.service';

@Injectable()
export class CommonAPI<T>{

    private _baseUrl: string = '';
    private _headers: any;

    constructor(private http: HttpClient, private configSvc: ConfigService) {
      this._baseUrl = configSvc.getMiscellaneousApiURI();
        this._headers = configSvc.getHTTPHeader;
    }
}
