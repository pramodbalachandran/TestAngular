import { Injectable } from '@angular/core';
import { Headers } from '@angular/http';
import { Subject } from 'rxjs';

import { Enviorment } from '@app/shared/services/shared/config.const';

@Injectable()
export class ConfigService {

       _devCustomerApiURI: string;
       _devQuoteApiURI: string;
       _devGeographyApiURI: string;


      _qaCustomerApiURI: string;
      _qaQuoteApiURI: string;
      _qaGeographyApiURI: string;


      _ustCustomerApiURI: string;
      _uatQuoteApiURI: string;
      _uatGeographyApiURI: string;

      _prodCustomerApiURI: string;
      _prodQuoteApiURI: string;
      _prodGeographyApiURI: string;

      _apiURI: string;

    _header: any;

    constructor() {

        //For developers
      //this._apiURI = 'http://localhost:55459/';


      
        
    }
    
  getCustomerApiURI() {

    //alert(Enviorment.type);

    switch (Enviorment.type) {

      case "local":

        return this._apiURI = 'http://localhost:4200/';

      case "dev":

        return this._devCustomerApiURI = "https://bon-customer-api-dev.azurewebsites.net/";  

       

      case "QA":

        return this._qaCustomerApiURI = "https://bon-customer-api-qa.azurewebsites.net/";       



      case "UAT":

        return this._ustCustomerApiURI = "https://bon-customer-api-uat.azurewebsites.net/";
        

 

      case "PROD":
        return "";
    }
  }

  getQuoteApiURI() {

    switch (Enviorment.type) {

      case "local":
       return this._apiURI = 'http://localhost:4200/';

      case "dev":

        return this._devQuoteApiURI = "https://bon-quotes-api-dev.azurewebsites.net/";

       

      case "QA":

        
        return this._qaQuoteApiURI = "https://bon-quotes-api-qa.azurewebsites.net/";
       

        

      case "UAT":

       
        return this._uatQuoteApiURI = "https://bon-quotes-api-uat.azurewebsites.net/";
       

      

      case "PROD":
        return ""
    }
  }

  getGeogrpahyApiURI() {

    switch (Enviorment.type) {

      case "local":
        return this._apiURI = "http://localhost:4200/";

      case "dev":

      return this._devGeographyApiURI = "https://bon-geography-api-dev.azurewebsites.net/";

      case "QA":

       
        return this._qaGeographyApiURI = "https://bon-geography-api-qa.azurewebsites.net/";

        

      case "UAT":
       
        return this._uatGeographyApiURI = "https://bon-geography-api-uat.azurewebsites.net/";

      

      case "PROD":
        return ""
    }
  }

  getPricingApiURI() {

    switch (Enviorment.type) {

      case "local":
        return this._apiURI = "http://localhost:4200/";

      case "dev":



      case "QA":


        return this._qaGeographyApiURI = "https://bon-geography-api-qa.azurewebsites.net/";



      case "UAT":

        return this._uatGeographyApiURI = "https://bon-geography-api-uat.azurewebsites.net/";



      case "PROD":
        break;
    }
  }

  getMiscellaneousApiURI() {

    switch (Enviorment.type) {

      case "local":
        return this._apiURI = "http://localhost:4200/";

      case "dev":



      case "QA":


        return this._qaGeographyApiURI = "https://bon-geography-api-qa.azurewebsites.net/";



      case "UAT":

        return this._uatGeographyApiURI = "https://bon-geography-api-uat.azurewebsites.net/";



      case "PROD":
        break;
    }
  }

    getApiHost() {
        return this._apiURI.replace('api/', '');
    }

    getHTTPHeader() {
        this._header = new Headers({
            // 'Access-Control-Allow-Headers': 'Origin, Content-Type, Accept, Authorization',
            //'Access-Control-Allow-Origin': '*',
            // 'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
            'Content-Type': 'application/json'
        });

        return this._header;

    }  

   
}
