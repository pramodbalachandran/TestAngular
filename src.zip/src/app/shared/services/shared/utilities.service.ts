import { Injectable } from '@angular/core';
import { Router, ActivatedRoute, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';

import { RoutingKey, Portal, UrlKey } from '@app/shared/services/shared/config.const';
import { PageState } from '@app/shared/services/shared/enum';

@Injectable()
export class UtilitiesService {

  constructor(private router: Router) {

  }

    sortByDescending(arrObj: any, sortOn: string) {
        arrObj.sort(function (val1, val2) {
            if (val1.sortOn > val2.sortOn) {
                return -1;
            } else if (val1.sortOn < val2.sortOn) {
                return 1;
            } else {
                return 0;
            }
        });
    }
    urlValidation(url:string){
        var regex = new RegExp("^(http[s]?:\\/\\/(www\\.)?|ftp:\\/\\/(www\\.)?|www\\.){1}([0-9A-Za-z-\\.@:%_\+~#=]+)+((\\.[a-zA-Z]{2,3})+)(/(.)*)?(\\?(.)*)?");
        
        if(regex.test(url)){
         return true
        }else{
          return false;
        }

  }

  navigateTo(pageState: string) {
  

    if (pageState == "/" + UrlKey.ExternalPortal + "/login") {

      this.router.navigate([pageState], { replaceUrl: true });
    }
    else
      this.router.navigate([pageState]);
  }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean {
   
    if (Portal.type == "customerportal") {

      this.router.navigate(['/login']);
      return false;
    }
    else {

      return true;
      
    }
    
  }
  }
   
