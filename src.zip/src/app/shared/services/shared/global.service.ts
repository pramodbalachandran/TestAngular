import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { Observable } from "rxjs";
import {IUSER_MASTER} from '@app/shared/interfaces/entities.interface';

@Injectable()
export class GlobalService {

    private userName= new BehaviorSubject<string>('');
    
    currentUser=this.userName.asObservable();    

    public user: IUSER_MASTER;  

   //this.user:IUSER_MASTER=<IUSER_MASTER>JSON.parse(localStorage.getItem('currentUser'));

   constructor(){
     this.user = JSON.parse(localStorage.getItem('currentUser'));
   }

    getLoggedUser(userName:string){
        this.userName.next(userName);
    }
   
}
