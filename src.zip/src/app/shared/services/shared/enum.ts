export enum shipmentServiceType {
  'OceanFreight' = 1,
  'AirFreight' = 2,
  'Domestic' = 3
}

export enum shipmentFrequencyType {
  'OneTime' = 1,
  'MultipleTimes' =2 
}


export enum ShipmentMovementType {
  'A2A' = 1,
  'D2A' = 2,
  'A2D' = 3,
  'D2D'=4
}

export enum ShipmentSpeedType {
  'Direct' = 'CA',
  'Premium Direct' = 'CX',
  'Consolidated' = 'EC'
}

export enum PageState {
  'LOGIN' = "1",
  'USERSETTINGS' = "2",
  'CHANGEPASSWORD' = "2.5",
  'DASHBOARD' = "3",
  'QUOTE'='3.5',
  'SUBMIT_SERVICE_TYPE' = "4",
  'SHIPMENT_FREQUENCY' = "5",
  'SHIPMENT_MOVEMENT' = "6",
  'SHIPMENT_MEASUREMENT' = "7",
  'SHIPMENT_COMMODITY' = "8",
  'DOCUMENT_UPLOAD' = "9",
  'COMMODITY_CHARACTERISTICS' = "10",
  'SHIPMENT_DATE' = "11",
  'SHIPMENT_SPEED'="12",
  'MISCELLANEOUS' = "13",
  'CONFIRM_DETAILS' = "14",
  'QUOTE_RATE' = "15",
  'REQUEST_PICKUP' = "16",
  'CONTACT' = "17",
  'QUOTE_SUCCESS' = "18",
  'RATECALCULATOR' = "19",
  'RATEDISPLAY' = "20",
  'IPDASHBOARD'="21",
  'IPQUOTE' = "22",
  'SHIPMENT'='23',
  'BULKUPLOAD'='24'
}

export enum UPSersPageState {
  'LOGIN' = "1",
  'RATECALCULATOR' = "2",
  'RATEDISPLAY' = "3"
}

export enum QuoteStatus {

  'NotSubmitted' = 1,
  'Completed' = 2,
  'Submitted' = 3,
  'Declined' = 4,
  'Accepted' = 5,
  'Deleted' = 6,
  'AwaitingUPSResponse' = 7,
  'Expired' = 8
}


export enum LaneAlertType {

  'IGNOREMODIFIEDLANE_SOURCE_SERVICETYPE' = 1,
  'UPDATEALLLANE_SOURCE_SERVICETYPE' = 2,
  'IGNOREMODIFIEDLANE_SOURCE_QUOTEVALIDTY' = 3,
  'UPDATEALLLANE_SOURCE_QUOTEVALIDTY' = 4,
  'IGNOREMODIFIEDLANE_SOURCE_BROKERAGE' = 5,
  'UPDATEALLLANE_SOURCE_BROKERAGE' = 6,
  'IGNOREMODIFIEDLANE_SOURCE_TOS' = 7,
  'UPDATEALLLANE_SOURCE_TOS' = 8
  
}










