export const DataSources = [
  { "Id": 1, "datasource": "D1" },
  { "Id": 2, "datasource": "D2" },
  { "Id": 3, "datasource": "D3" },
  { "Id": 4, "datasource": "D4" },
  { "Id": 6, "datasource": "D5" }
]

export const ApplicationUrls = [
  {  "oceanFreightUrl":   "https://www.ups.com/us/en/help-center/legal-terms-conditions/technology-agreement.page"},
  {  "domesticFreightUrl":"https://www.ups.com/us/en/help-center/legal-terms-conditions/technology-agreement.page" },
  {  "viewIncoterms": "http://ups-scs.com/tools/" },
  {  "technology_Aggrement": "https://www.ups.com/us/en/help-center/legal-terms-conditions/technology-agreement.page"}
]

export const ApplicationKeys = [
  { "tenantId": "e7520e4d-d5a0-488d-9e9f-949faae7dce8" },
  { "clientId": "52282bb8-ff96-4954-ad39-1d3bde788e0e" } 
]

export const UrlKey={
  "InternalPortal":"upsers",
  "ExternalPortal": "bonsai"
}

export const RoutingKey = {
  //External-Portal
  "1": "/" + UrlKey.ExternalPortal + "/login", 
  "2": "/" + UrlKey.ExternalPortal + "/usersettings",
  "2.5": "/" + UrlKey.ExternalPortal + "/changepassword",
  "3": "/" + UrlKey.ExternalPortal + "/dashboard",
  "3.5": "/" + UrlKey.ExternalPortal + "/quote",
  "4": "/" + UrlKey.ExternalPortal + "/quote/submitServiceType" ,
  "5": "/" + UrlKey.ExternalPortal + "/quote/shipmentFrequency",
  "6": "/" + UrlKey.ExternalPortal + "/quote/shipmentmovement",
  "7": "/" + UrlKey.ExternalPortal + "/quote/shipmentmeasurement" ,
  "8": "/" + UrlKey.ExternalPortal + "/quote/commodity",
  "9": "/" + UrlKey.ExternalPortal + "/quote/documentUpload",
  "11": "/" + UrlKey.ExternalPortal + "/quote/shipmentdate",
  "10": "/" + UrlKey.ExternalPortal + "/quote/commodityCharacteristics",
  "12": "/" + UrlKey.ExternalPortal + "/quote/shipmentspeed",
  "13": "/" + UrlKey.ExternalPortal + "/quote/miscellaneous",
  "14": "/" + UrlKey.ExternalPortal + "/quote/confirmDetails",
  "15": "/" + UrlKey.ExternalPortal + "/quote/quoterate",
  "16": "/" + UrlKey.ExternalPortal + "/quote/requestpickup",
  "17": "/" + UrlKey.ExternalPortal + "/quote/contact",
  "18": "/" + UrlKey.ExternalPortal + "/quote/quotesuccess",
  //Internal-Portal
  "19": "/" + UrlKey.InternalPortal + "/ratecalculator",
  "20": "/" + UrlKey.InternalPortal + "/ratedisplay",
  "21": "/" + UrlKey.InternalPortal + "/IPdashboard",
  "22": "/" + UrlKey.InternalPortal + "/quote",
  "23": "/" + UrlKey.InternalPortal + "/quote/shipment",
  "24": "/" + UrlKey.InternalPortal + "/quote/bulkupload"
}


export const monthNames = ["January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December"
];

export const monthShortNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun","Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

export const Enviorment =

 { "type": "dev" }

 // { "type": "QA" }

 // { "type": "UAT" }

 // { "type": "local" }

// { "type": "PROD" }


export const Portal =
 
//{ "type": "customerportal" }
{ "type": "upserportal" }

export const replyUrlKey = {
  
  "LOCAL": "http://localhost:4200/upsers/",
  "DEV": "https://bon-ui-dev.azurewebsites.net/upsers/",
  "QA":"https://bon-ui-qa.azurewebsites.net/upsers/"
}
