import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse, HttpHeaders } from '@angular/common/http';
import { Observable, Subject } from 'rxjs';
import { map, take, tap, catchError, retry } from 'rxjs/operators';


import { QuoteDetail, IAirportODPair, ICurrencyDetails } from '@app/shared/interfaces/entities.interface';
import { ConfigService } from '@app/shared/services/shared/config.service';
import { IQuoteData, IQuoteListDetails } from '@app/models/quotes/quote-data';
import { IQuoteDetails } from '@app/models/quotes/quotes-details';
import { IAirFreightShipmentDetail } from '@app/models/quotes/airfreightshipment-detail';
import { error } from '@angular/compiler/src/util';
import { strictEqual } from 'assert';

@Injectable()

export class QuoteAPI<T>{

    _baseUrl: string = '';
    _headers: any;
    quoteDetail: IQuoteData = this.getEmptyQuoteModel();
    airportODPairDetail: IAirportODPair = this.getEmptyAirportODPair();
    airportODPairLaneDetail: IAirportODPair[] = [];
    currencyDetail: ICurrencyDetails;
    rateCalculatorDetail = [];
    constructor(private http: HttpClient, private configSvc: ConfigService) {
        this._baseUrl = configSvc.getQuoteApiURI();
        this._headers = configSvc.getHTTPHeader;
    }

    setQuoteDetails(value) {
        this.quoteDetail = value;
    }

    getQuoteDetails() {
        if (this.quoteDetail.airFreightShipmentDetail.length == 0) {
            this.quoteDetail.airFreightShipmentDetail.push(this.getEmptyAirFreightShipmentDetail());
        }
        return this.quoteDetail;
    }

    resetQuoteModel() {
        this.quoteDetail = this.getEmptyQuoteModel();
    }



    getEmptyQuoteModel(): IQuoteData {
        return {
            quoteRequestData: {
                id: '',
                docId: '',
                quoteNumber: '',
                businessPartyName: '',
                businessPartyNumber: '',
                accountNumber: '',
                quoteRequestDate: null,
                quoteStatusCode: 1,
                quoteStatusUpdateDate: '',
                quoteServiceType: '0',
                quoteTypeCode: 0,
                quoteDeclineReasonTypeCode: 0,
                quoteDeclineReasonTypeNote: '',
                quoteRate: '',
                marketRate: '',
                ContactName: '',
                PhoneNo: '',
                EmailAddress: '',
                Comments: '',
                lastVisitedPage: '',
                rateTabIndicator: 0,
                contactAddressSaveProfileIndicator: 0,
                quoteAttachment: [],
                quoteName :'',
                shipmentReadyDate:null,
                serviceTypes: { consolidatedECSelected: false, directCASelected: false, premiumDirectCXSelected: false, tempTrueSelected: false,isModified:false },
                customesBrokerage:'',
                termsOfSale:'',
                insuranceRequiredIndicator:false,
                shipmentInsuranceAmount:'',
                defaultCurrency:'',
                quoteNotes:'',
                quoteValidityPeriod:'',
                quoteValidityStartDate:null,
                quoteValidityEndDate:null,
                customerTemplateIndicator:false
            },
            airFreightShipmentDetail: []
        }
    }

    getEmptyAirFreightShipmentDetail(): IAirFreightShipmentDetail {
        return {
            id: '',
            docId: '',
            shipmentDetailIdentificationNumber: '',
            quoteIdentificationNumber: '',
            destinationAirport: '',
            originAirport: '',
            originLocationCountryCode: '',
            originLocationPoliticalDivsion2Code: '',
            originLocationPostalCode: '',
            destinationLocationCountryCode: '',
            destinationLocationPoliticalDivsion2Code: '',
            destinationLocationPostalCode: '',
            movementTypeCode: 0,
            paymentTermTypeCode: '',
            shipmentUnitOfMeasureTypeCode: 0,
            shipmentPalletQuantity:"",
            shipmentLooseUnitQUantity:'',
            commodityTypeCode: '',
            commodityTypeDescriptionText: '',
            commodityNameList: [],
            hazardousMaterialsIndicator: 0,
            hazardousMaterialName:'',
            hazardousMaterialUnitedNationsNumber:'',
            hazardousMaterialUnitedNationsClassificationCode: '',
            hazardousMaterialPackagingGroupText: '',
            shipmentOversizeIndicator: false,
            originAddressLine1Text: '',
            originAddressLine2Text: '',
            originAddressLine3Text: '',
            originPoliticalDivision1Name: '',
            destinationAddressLine1Text: '',
            destinationAddressLine2Text: '',
            destinationAddressLine3Text: '',
            destinationPoliticalDivision1Name: '',
            shipmentInsuranceIndicator: 0,
            shipmentInsuredValueAmount: '',
            shipmentCurrencyCode: '',
            shipmentValue: '',
            temperatureControlShipmentIndicator: 0,
            perishableShipmentIndicator: 0,
            shipmentPalletPercent:'',
            shipmentLooseUnitPercent:'',
            shipmentOriginAddressProfileSaveIndicator: false,
            shipmentDestinationAddressProfileSaveIndicator: false,
            shipmentWeightTypeCode: 0,
            totalWeight: '',
            shipmentWeightByPeice: [],
            shipmentReadyDate: null,
            isCustomerBroker: 0,
            shipmentValueIndicator: false,
            shipmentSpeedType: '',
            originAirportName: '',
            destinationAirportName: '',
            shipmentMethod:'',
            shipmentFrequencyTimePeriodDescriptionText: '',
            shipmentFrequency :0,
            shipmentActualWeight:'',
            shipmentDimensionalWeight:'',
            shipmentActualWeightUnitOfMeasureTypeCode:'',
            shipmentDimensionalWeightUnitOfMeasureTypeCode:'',
            shipmentActualWeightQuantity:'',
            shipmentDimensionalWeightQuantity:'',
            serviceTypes:null,
            termsOfSale: '',
            TOSModified: false,
            quoteValidityPeriod:'',
            quoteValidityStartDate:null,
            quoteValidityEndDate: null,
            quoteValidityModified:false,
            quoteNotes:'',
            shipmentLaneActiveIndicator:false,
            MovementTypeDescriptionText:'',
            originAutopopulationFormat:"",
            destinationAutopopulationFormat:"",
            customesBrokerage: "",
            quoteBrokeragdeModified: false,
            shipmentCommodity:null
               };
    }

    getEmptyAirportODPair(): IAirportODPair {
        return {
            quoteType: 1,
            destination: '',
            destinationCode: '',
            destinationCountryCode: '',
            destinationRegion: '',
            origin: '',
            originCode: '',
            originCountryCode: '',
            originRegion: '',
            originCity: '',
            destinationCity: '',
            originCountry: '',
            destinationCountry: ''
        }
    }

    save() {

        return this.http.post(this._baseUrl + 'task/named/SaveQuotesData', this.quoteDetail).pipe(
            map((data: any) => {
                if (data.responseStatus.status == '200') {
                    this.quoteDetail.quoteRequestData.id = data.responseData.quoteDetailsId;
                    //this.quoteDetail.airFreightShipmentDetail.id = data.responseData.shipmentDetailsId;
                }
                return data;
            }), catchError(error => {
                console.log(error);
                return '' //this.handleError('Internal Server Error!!!')
            })
        );
    }

    get(id: string) {

        return this.http.post(this._baseUrl + 'GetSavedQuote', { "id": id }).pipe(
            map((data: any) => {
                if (data['results'][0] != null) {
                    return (data['results'][0]) as QuoteDetail;
                }
                return null;
            }), catchError(error => {
                return '' //this.handleError('Internal Server Error!!!')
            })
        );

    }

    duplicateQuote(quoteNumber: string) {

        return this.http.post(this._baseUrl + "task/named/CreateDuplicateQuote", { "quoteNumber": quoteNumber }).pipe(
            map((data: any) => {
                if (data != null) {
                    return data;
                }
                return null;
            }), catchError(error => {
                return '' //this.handleError('Internal Server Error!!!')
            })
        );
    }

    deleteQuote(quoteNumber: string) {

        return this.http.post(this._baseUrl + "task/named/DeleteCustomerQuote", { "quoteNumber": quoteNumber }).pipe(
            map((data: any) => {
                if (data != null && data.status == "200") {
                    return data;
                }
                return null;
            }), catchError(error => {
                return '' //this.handleError('Internal Server Error!!!')
            })
        );
    }

    getQuoteList(userId: string): Observable<any> {

        return this.http
            .post(this._baseUrl + 'task/named/GetQuoteList', {
                "quoteNumber": "",
                "accountNumber": userId
            }).pipe(
                map((data: any) => {
                    return data;
                }), catchError(error => {
                    return this.handleError('Something went wrong!')
                })
            );

    }

    getDistinctCity(city: string) {
        return this.http.get<string[]>("http://localhost:4200" + "/assets/city.json");
    }

    getCommodityProduct(objdata: any) {
        return this.http
            .post(this._baseUrl + 'task/named/GetCommodityNameList', objdata).pipe(
                map((data: any) => {
                    return data;
                }), catchError(error => {
                    return this.handleError('Something went wrong!')
                })
            );
    }

    GetQuoteDetailsbyQuoteId(objdata: any) {

        return this.http
            .post(this._baseUrl + 'task/named/GetQuoteDetails', objdata).pipe(
                map((data: any) => {
                    return data;
                }), catchError(error => {
                    return this.handleError('Something went wrong!')
                })
            );
    }

    getWeightBreaksDetails(objdata: any) {
        return this.http
            .post(this._baseUrl + 'task/named/GetWeightBreaksDetails', objdata).pipe(
                map((data: any) => {
                    if (data.responseStatus.status == '200') {
                        return data.responseData;
                    }
                    return null;
                }), catchError(error => {
                    return this.handleError('Something went wrong!')
                })
            );
    }

    getCommodityTypeList() {
        return this.http.post(this._baseUrl + "task/named/GetCommodityTypeList", {}).pipe(
            map((data: any) => {
                return data;
            }), catchError(error => {
                return this.handleError('Something went wrong!')
            })
        );

    }

    printPdf() {

        return this._baseUrl + "task/named/GetPdf";
        //return "http://localhost:55459/task/named/GetPdf";
    }

    downloadPDF() {
        return this._baseUrl + "task/named/GetPdf";
        //return "http://localhost:55459/task/named/GetPdf";
    }

    getBaseURL() {
        return this._baseUrl;
    }

    getFileUploadURL() {
        return this._baseUrl + 'task/named/FileUpload';
    }

    getUPSStandardTemplateURL() {
      return this._baseUrl + 'task/named/GetUPSTemplateFile';
    }

    // Get Market base price details
    getMBPDetails(objdata: any) {
        return this.http
            .post(this._baseUrl + 'task/named/CalculateMBP', objdata).pipe(
                map((data: any) => {
                    return data;
                }), catchError(error => {
                    return this.handleError('Something went wrong!')
                })
            );
    }

    getCurrentIpLocation(): Observable<any> {
        return this.http.get('http://ip-api.com/json').pipe(
            map((data: any) => {
                return data;
            }), catchError(error => {
                return this.handleError('Something went wrong!')
            })
        );
    }

    setAirportODPairLaneDetail(value) {
        this.airportODPairLaneDetail = value;
    }

    getAirportODPairLaneDetail() {
        return this.airportODPairLaneDetail;
    }

    resetAirportODPairLaneDetail() {
        this.setAirportODPairLaneDetail([]);
    }

    setCurrencyDetails(value) {
        this.currencyDetail = value;
    }

    getCurrencyDetails() {
        return this.currencyDetail;
    }

    setRateCalculatorDetail(value) {
        this.rateCalculatorDetail = value;
    }

    getRateCalculatorDetail() {
        return this.rateCalculatorDetail;
    }

    private handleError(error: any) {
        var applicationError = error.headers.get('Application-Error');
        var serverError = error.json();
        var modelStateErrors: string = '';

        if (!serverError.type) {
            console.log(serverError);
            for (var key in serverError) {
                if (serverError[key])
                    modelStateErrors += serverError[key] + '\n';
            }
        }
        modelStateErrors = modelStateErrors = '' ? null : modelStateErrors;
        return Observable.throw(applicationError || modelStateErrors || 'Server error');
    }

    getE2kRates() {
        return this.http.post(this._baseUrl + 'task/named/GetE2kRates', this.quoteDetail).pipe(
            map((data: any) => {
                if (data.responseStatus.status == '200') {
                    this.quoteDetail.quoteRequestData.id = data.responseData.quoteDetailsId;
                }
                return data;
            }), catchError(error => {
                console.log(error);
                return ''
            })
        );
    }
}
