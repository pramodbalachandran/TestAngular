import { TestBed, inject } from '@angular/core/testing';
import { HttpClientModule, HttpClient, HttpResponse } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { Observable,of } from 'rxjs'

import { QuoteDetail } from '@app/shared/interfaces/entities.interface';
import { ConfigService } from '@app/services/shared/config.service';
import { IQuoteData, IQuoteListDetails } from '@app/models/quotes/quote-data';
import { IQuoteDetails } from '@app/models/quotes/quotes-details';
import { IAirFreightShipmentDetail } from '@app/models/quotes/airfreightshipment-detail';
import { error } from '@angular/compiler/src/util';
import { strictEqual } from 'assert';
import { QuoteAPI } from '@app/shared/services';



describe('Quote Service', () => {

  let service;
  let httpTestingController: HttpTestingController;

  // Mock the service like this and add all the functions you have in this fashion
  let QuoteAPIService: QuoteAPI<any>,
    mockQuoteService = {
      getCommodityTypeList: jasmine.createSpy('getCommodityTypeList').and.returnValue(of({
        "pageSize": 100,
        "totalResults": 1,
        "results": [
          {
            "id": "8b5db69e-9452-ca84-2dad-e59552443efe",
            "docType": "commodityType",
            "partitionkey": "reference",
            "commodityTypeList": [
              {
                "commodityTypeCode": "CT001",
                "commodityTypeDescriptionText": "Apparel and Consumer Goods"
              },
              {
                "commodityTypeCode": "CT002",
                "commodityTypeDescriptionText": "Industrial Products"
              }             
            ],
            "lastContinuationToken": null
          }
        ],
        "continuationToken": null
      }))
    };

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule
      ],
      providers: [{
        provide: QuoteAPI,
        useValue: mockQuoteService
      }, ConfigService]
    });
    httpTestingController = TestBed.get(HttpTestingController);
  });

  // Do this trick to inject the service every time, and just use `service` in your tests
  beforeEach(inject([QuoteAPI], s => {
    service = s;
  }));

  beforeEach(() => {
  });


  afterEach(() => {
    // After every test, assert that there are no more pending requests.
    httpTestingController.verify();
  });

  it('Quote Service should be defined', () => {
    expect(service).toBeDefined();
  });

  it('Quote Service should be created', () => {
    expect(service).toBeTruthy();
  });

  describe('getCommodityTypeList', () => {

    it('should return commodityType List', () => {

      let fakeResponse = null;

      // Call the service function and subscribe to it to catch the fake response coming from the mock.
      service.getCommodityTypeList().subscribe((data) => {
        // in here value will be whatever you put as returnValue (remember to keep the observable.of())
        fakeResponse = data;
      });

      // expects as in any test.
      expect(fakeResponse).toBeDefined();
      expect(fakeResponse["results"][0].commodityTypeList[0]["commodityTypeCode"]).toBe("CT001");
      expect(fakeResponse["results"][0].commodityTypeList[1]["commodityTypeDescriptionText"]).toBe("Industrial Products");
    });

  });

});







