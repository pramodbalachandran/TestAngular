
export interface IUSER_MASTER {
  user_id: number;
  user_name: string;
  password: string;
  confirmpassword: string;
  firstName: string;
  lastName: string;

}
export interface IQUOTE {
  QuoteId: string;
  QuoteName: string;
  Description: string;
}

export interface IQuoteStrcuture {
  id: string
  QuoteNumber: string;
  QuoteStatus: string;
  QuoteInitiatedDate: string;
  CustomerName: string;
  QuotePrice: any;
  UserId: string;
  partitionKey: any
}

export interface IUserRegistration {
  CompanyName: string;
  PhoneNo: string;
  ContactName: string;
  EmailAddress: string;
  UserId: string;
  Password: string;
  ConfirmPassword: string;
  TermsAccepted: boolean;
}

export interface IContactSettings {
  id: string;
  PhoneNo: string;
  ContactName: string;
  EmailAddress: string;
  UserId: string;
  DoShowEditContactForm: boolean;
  LastUsedDate: string;
}

export class IUser {
  id: string;
  CompanyName: string;
  ContactName: string;
  UPSAccountNo: string;
  ContactType: string;
  CountryCode: string;
  PhoneNo: string;
  Extension: string;
  EmailAddress: string;
  UserId: string;
  Password: string;
  ConfirmPassword: string;
  TermsAccepted: boolean;
}

export class User {
  CompanyName: string;
  ContactName: string;
  UPSAccountNo: string;
  ContactType: string;
  CountryCode: string;
  PhoneNo: string;
  Extension: string;
  EmailAddress: string;
  UserId: string;
  Password: string;
  ConfirmPassword: string;
  TermsAccepted: boolean;

  ContactAddressName: string;
  ContactAddress: string;
  ContactAddressLine1: string;
  ContactAddressLine2: string;
  CountryId: number;
  StateId: number;
  City: string;
  PostalCode: string;
  SameAsBillingAddress: boolean;
  BillingAddress: string;
  BillingAddressLine1: string;
  BillingAddressLine2: string;
  BillingCountryId: number;
  BillingStateId: number;
  BillingCity: string;
  BillingPostalCode: string;
  NotificationSettings: NotificationSettings
}

export class NotificationSettings {
  EmailQuoteStatusExpiring: boolean;
  EmailQuoteRespondByUSP: boolean;
  EmailPickupRequest: boolean;
  EmailPreApprovedRate: boolean;
  EmailResetPassword: boolean;
}


export class ShippingAddress {
  UserId: string;
  id: string;
  AddressLine1: string;
  AddressLine2: string;
  AddressLine3: string;
  AddressLine4: string;
  Country: string;
  State: string;
  City: string;
  PostalCode: string;
  DoShowEditShippingForm: boolean;
}


export class getShippingAddress {
  customerId: string;
}

export interface RecoveryPassword {
  userId: number;
  recoverMyPasswordEmailAddress: string;
  forgotUserIdemailAddress: string
}


export interface QuoteDetail {
  id: string;
  UserId: string;
  partitionKey: string;
  CurrentPageState: string;
  ShipmentServiceType: string;
  ShipmentSpeedType: string;
  ShipmentFrequencyType: string;
  Status: string;
  ShipmentType: string;
  ShipingA2ADetail: A2ADetail;
  ShipingD2ADetail: D2ADetail;
  ShipingA2DDetail: A2DDetail;
  ShipingD2DDetail: D2DDetail;
  AboutShipment: AboutShipment;
  CommodityCharacteristics: CommodityCharacteristics
  shipmentCommodity: Commodity;
  ShipmentDate: string;
}

export interface AboutShipment {
  PreferUnitsOfMeasurement: string;
  ShipmentWeightTotalOrWeightByPiece: string;
  ShipmentTotalWeight: number;
  ShipmentPieceDetails: ShipmentPieceDetails[];
}

export interface ShipmentPieceDetails {
  PackageType: string;
  Quantity: string;
  Length: string
  Width: string;
  Height: string;
  Weight: string;
}

export interface ShipmentPieceDetails1 {
  packageType: string;
  quantity: string;
  length: string
  width: string;
  height: string;
  weight: string;
}

export interface A2ADetail {
  OriginCityAirport: string;
  DestinationCityAirport: string;
}

export interface D2ADetail {
  OriginShippingAddress: ShippingAddress;
  DestinationCityAirport: string;
}


export interface A2DDetail {
  OriginCityAirport: string;
  DestinationShippingAddress: ShippingAddress;

}

export interface CommodityCharacteristics {
  hazardousSelected: number;
  perishableSelected: number;
  temperatureSelected: number
}

export interface Commodity {
  CommodityTypeCode: string;
  commodityProducts: string[];
  shipmentValue: string;
  currecy: string;
}

export interface D2DDetail {
  OriginShippingAddress: ShippingAddress;
  DestinationShippingAddress: ShippingAddress;
}




export interface LoggedInUser {

  username: string;

}


export interface LoaderState {
  show: boolean;
}

export class shipmentPieceDetailsText {
  quantityText: string;
  measurementText: string;
  weightText: string;
}



export interface IAirportODPair {
  quoteType: number// 1=>ShortTerm, 2 => Long Term
  origin: string;
  destination: string;
  originCode: string;
  destinationCode: string
  originCountryCode: string;
  destinationCountryCode: string;
  originRegion: string;
  destinationRegion: string;
  originCity: string;
  destinationCity: string;
  originCountry: string;
  destinationCountry: string;
}
export interface IQuoteLaneData {
  movementType: string;
  originCity: string;
  desCity: string;
  shipmentdetails: ILaneShipmentData;
}
export interface ILaneShipmentData {
  shipmentType: string;
  shipmentActualWeight: string;
  shipmentDimensionWeight: string;
  shipmentFrequency: string;
  shipmentFrequencyPeriod: string;
  shipmentPeriod: string;
  packageDetails: IShipmentPackageData[];
}
export interface IShipmentPackageData {
  packageActualWeight: string;
  packageDimensionWeight: string;
  packageType: string;
  packageQuantity: string;
  packageVolume: string;
  packageActualWeightUnit: string;
  packageDimensionWeightUnit: string;
  packageVolumeUnit: string;

}
export interface ICurrencyDetails {
  conversionFactor: number;
  defaultCurrency: string;
  currencySetDefault: boolean;
  localeCodes: string;
}

export interface IDraggableItem {
  key: string;
  name: string;
  type: string;
  dragEnabled: boolean;
}

export interface IDroppableItem {
  name: string;
  type: string;
  mappedColumnName: string;
  hide: boolean;
  dropEnabled: boolean;
}
