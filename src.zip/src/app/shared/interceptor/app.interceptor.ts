import { Injectable, Injector } from '@angular/core';
import { HttpEvent, HttpInterceptor, HttpHandler, HttpRequest, HttpResponse } from '@angular/common/http';
import { Observable, pipe } from 'rxjs';
import { tap } from 'rxjs/operators';
import { LoaderService } from '@app/shared/services/loader.service';
import { LocalStorageService } from '@app/shared/services';
@Injectable({
  providedIn: 'root'
})
export class AppInterceptor implements HttpInterceptor {
  constructor(private loaderService: LoaderService, private localStorageService: LocalStorageService) { }
  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    if (!this.localStorageService.getItem('HideLoader')) {
      this.showLoader();
    }
    return next.handle(req).pipe(tap((event: HttpEvent<any>) => {
      if (event instanceof HttpResponse) {
        this.onEnd();
      }
    },
      (err: any) => {
        this.onEnd();
      }));
  }
  private onEnd(): void {
    this.hideLoader();
  }
  private showLoader(): void {
    this.loaderService.show();
  }
  private hideLoader(): void {
    this.loaderService.hide();
  }
}


//import { Injectable, Injector } from '@angular/core';
//import { HttpEvent, HttpInterceptor, HttpHandler, HttpRequest,HttpResponse } from '@angular/common/http';
//import { LocalStorageService } from '../services/localstorage.service';
//import { LoaderService } from '../services/loader.service';
//import { Router } from '@angular/router';
//import { Observable } from 'rxjs/Rx';
//import 'rxjs/add/observable/throw'
//import 'rxjs/add/operator/catch';
//import 'rxjs/add/operator/do';


//@Injectable()
//export class AppInterceptor implements HttpInterceptor {
//    constructor(
//        private router: Router,
//        public localstorage:LocalStorageService,
//        public loaderService:LoaderService
//    ) { }

//    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
//        this.loaderService.show();
//       if(this.localstorage.read('token')){
//        request = request.clone({
//            setHeaders: {
//                "X-access-token": this.localstorage.read('token'),
//                "x-access-code": this.localstorage.read('token')
//            }
//        });

//       }
//        return next.handle(request).do((event: HttpEvent<any>) => {
//            if (event instanceof HttpResponse) {
//                this.loaderService.hide();
//                let body = event.body;
//                let status = body.status;
//                this.localstorage.write('token',body.token);
//               // console.log(this.localstorage.read('token'));
//                if(status == 403){
//                    this.router.navigate(['logout']);
//                }
//            }
//        }, (err: any) => {
      
//        });
//    }
//}
