export enum TemperatureUnit {
  Farenheit = 'F',
  Celsius = 'C'
}
