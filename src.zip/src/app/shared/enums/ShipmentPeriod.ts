export enum ShipmentPeriod {
  Year = 'Volume sent a year',
  Month = 'Volume sent a month',
  Week = 'Volume sent a week',
  Day = 'Volume sent a day'
}
