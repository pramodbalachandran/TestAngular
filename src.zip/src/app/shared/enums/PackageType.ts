export enum PackageType {
  Roll = 'Roll',
  Drum = 'Drum',
  Carton = 'Carton',
  Packets = 'Packets',
  PalletSkid = 'Pallet/Skid',
  Piece = 'Piece',
  Loose = 'Loose'
}
