export enum ShipmentFrequencyPeriod {
  Year = 'times a year',
  Month = 'times a month',
  Week = 'times a week',
  Day = 'times a day'
}
