export enum ShipmentUnitType {
  Weight = 'Dim Weight',
  Volume = 'Volume',
  Metric = 'Metric'
}
