export enum ShipmentType {
  WeightPerShipment = 'Weight per shipment',
  WeightOverTime = 'Weight over time',
  TypicalCargo = 'Typical cargo'
}
