export enum ShipmentUnitName {
  Kg = 'kg',
  Lb = 'lb',
  Cbm = 'cbm',
  Cbf = 'cbf',
  Cm = 'cm',
  Inches = 'inches'
}
