export enum SalesTermConst {
    EXW = 'EXW (Ex Works)',
    CPT = 'CPT (Carriage Paid to)',
    CIP = 'CIP (Carriage and Insurance Paid to)',
    DAT = 'DAT (Delivered at terminal)',
    DAP = 'DAP (Delivered at Place)',
    DOP = 'DOP (Delivery duty Paid)',
    FCA = 'FCA (Free Carrier)',
  }
  