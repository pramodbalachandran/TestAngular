export enum MovementTypeConst {
    ATA = 'ATA,Airport-to-airport',
    DTA = 'DTA,Door-to-airport',
    ATD = 'ATD,Airport-to-door',
    DTD = 'DTD,Door-to-door',
  }
  export enum MovementTypeVal {
    ATA,
    DTA,
    ATD,
    DTD,
  }