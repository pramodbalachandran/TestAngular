import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { LocalStorageService ,QuoteAPI} from '@app/shared/services';
import { ApplicationUrls, RoutingKey } from '@app/shared/services/shared/config.const';
import { UtilitiesService } from '@app/shared/services/shared/utilities.service';
import { PageState } from '@app/shared/services/shared/enum';
import { IQuoteData } from '@app/models/quotes/quote-data'



@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})

export class HeaderComponent implements OnInit {

  body: HTMLBodyElement = document.getElementsByTagName('body')[0];
  userName: string;
  show = false;
  guestUser = true;

  constructor(private router: Router, private localStorageService: LocalStorageService, private helper: UtilitiesService,
    private quoteService: QuoteAPI<IQuoteData>) { }

  ngOnInit() {
    this.body.classList.remove('overlay');
    this.userName = localStorage.getItem('LoggedInUser');
    if (this.userName != null && this.userName != undefined && this.userName != '') {
      this.guestUser = false;
    }
  }

  logOut() {
    localStorage.clear();
    this.clearModel();
    //this.router.navigate(['/bonsai/login'], { replaceUrl: true });
    this.helper.navigateTo(RoutingKey[PageState.LOGIN]);
  }

  // need to remove the below code after proper fix for quoterate navigation after guest user login from quoterate page
  onDashboardClick() {
    localStorage.removeItem("navigationAction");
    localStorage.removeItem("lastVisitedPage");
    this.clearModel();
    this.helper.navigateTo(RoutingKey[PageState.DASHBOARD]);
  }
  onEditsettingClick() {
    this.clearModel();
    this.helper.navigateTo(RoutingKey[PageState.USERSETTINGS]);
  }
  logIn() {
    localStorage.clear();
     //this.router.navigate(['/bonsai/login'], { replaceUrl: true });
    this.helper.navigateTo(RoutingKey[PageState.LOGIN]);
  }

  showorHide() {
    this.show = !this.show;
  };

  isActive(e) {
    return this.show;
  };

  enter(e) {
    this.show = true;
  }

  leave(e) {
    this.show = false;
  }
  getQuote() {
    localStorage.clear();
    this.clearModel();
    this.helper.navigateTo(RoutingKey[PageState.QUOTE]);
  }
  newQuote() {   
    this.clearModel();
    this.helper.navigateTo(RoutingKey[PageState.QUOTE]);
  }

  clearModel() {
    this.quoteService.resetQuoteModel();
  }
}


