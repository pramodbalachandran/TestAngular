import { Component } from '@angular/core';

@Component({
  selector: 'custom-modal-popup',
  template: `
    <div (click)="onContainerClicked($event)"  [style.display]="showModal ? 'block' : 'none'"  tabindex="-1" [ngClass]="{'in': visibleAnimate}"
       [ngStyle]="{'display': visible ? 'block' : 'none','overflow-y': 'auto', 'opacity': visibleAnimate ? 1 : 0}">
        <div class="ngbd-modal-container">
          <div class="popup custom-modal-popup" pd-popup="popupNew" style="display: block;">
          <div class="popup-inner">
                <a class="popup-close" pd-popup-close="popupNew" href="javascript:void(0)" (click)="close()"> </a>
                <ng-content select=".app-modal-body"></ng-content>
            </div>
        </div>

          
        </div>
  </div>
  `,
  styleUrls: ['./custom-modal.component.css']
})
export class CustomModalComponent  {

  public visible = false;
  private visibleAnimate = false;
  private IsmodelShow = false;
  private outsideClickHide = false;

  constructor() { }

  public show(): void {
    this.visible = true;
    setTimeout(() => this.visibleAnimate = true, 100);
  }

  public hide(): void {
    this.visibleAnimate = false;
    setTimeout(() => this.visible = false, 300);
  }

  public onContainerClicked(event: MouseEvent): void {
    if (!this.outsideClickHide) {
      return;
    }
    if ((<HTMLElement>event.target).classList.contains('custom-modal-popup')) {
      this.hide();
    }
  }

  close() {
    this.IsmodelShow = true;// set false while you need open your model popup
    this.hide();
    // do your more code
  }

  public enableHideOnOutsideClick(): void {
    this.outsideClickHide = true;
  }
}
