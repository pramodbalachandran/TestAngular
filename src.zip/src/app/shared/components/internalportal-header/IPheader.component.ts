import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { MsAdalAngular6Service } from 'microsoft-adal-angular6';

import { QuoteAPI, LocalStorageService } from '@app/shared/services';
import { ApplicationUrls, RoutingKey } from '@app/shared/services/shared/config.const';
import { BonsaiConstants } from '@app/shared/constants/bonsaiconstants';
import { UtilitiesService } from '@app/shared/services/shared/utilities.service';
import { PageState } from '@app/shared/services/shared/enum';
import { IQuoteData } from '@app/models/quotes/quote-data'
import { currentId } from 'async_hooks';
import { CustomerAPI } from '@app/shared/services';
import { IUpser } from '@app/models';

@Component({
  selector: 'upsers-app-header',
  templateUrl: './IPheader.component.html',
  styleUrls: ['./IPheader.component.css']
})

export class IPHeaderComponent implements OnInit {

  body: HTMLBodyElement = document.getElementsByTagName('body')[0];
  userName: string;
  show = false;
  guestUser = true;
  @Output() ratePageExitNotificationAlert = new EventEmitter();
  currentUrl: string = "";
  userDetails: IUpser;
  usDollar: string = "USD";
  conversionFactorForUSD = "1";

  constructor(private router: Router, private helper: UtilitiesService,
    private quoteService: QuoteAPI<IQuoteData>, private adalSvc: MsAdalAngular6Service,
    private customerAPI: CustomerAPI<any>, private localStorageService: LocalStorageService) {
  }

  ngOnInit() {
    this.body.classList.remove('overlay');
    if (this.adalSvc.userInfo) {
      this.localStorageService.setItem(BonsaiConstants.loggedInUserDisplayName, this.adalSvc.LoggedInUserName);
      this.localStorageService.setItem(BonsaiConstants.loggedInUserName, this.adalSvc.userInfo.userName);
      if (!this.customerAPI.getUpserProfileDetails()) {
        this.customerAPI.getUpserByUserId(this.adalSvc.userInfo.userName.toLowerCase())
          .subscribe(
            data => {
              if (data) {
                this.userDetails = data as IUpser;
              }
              else {
                this.initUserDetails();
                this.createUser(this.userDetails);
              }
              this.customerAPI.setUpserProfileDetails(this.userDetails);
            },
            error => {
              console.log(error);
            });
      }
    }

    this.userName = this.localStorageService.getItem(BonsaiConstants.loggedInUserDisplayName);
    if (this.userName != null && this.userName != undefined && this.userName != '') {
      this.guestUser = false;
    }
  }

  initUserDetails() {
    this.userDetails = {
      id: '',
      docType: '',
      docId: '',
      docStructureVersion: 0,
      partitionkey: '',
      businessPartyName: this.adalSvc.LoggedInUserName,
      businessPartyNumber: this.adalSvc.userInfo.userName,
      accountNumber: '',
      emailAddress: '',
      userId: this.adalSvc.userInfo.userName,
      defaultCurrency: this.usDollar,
      conversionFactor: this.conversionFactorForUSD
    }
  }

  getUserData() {
    this.customerAPI.getUpserByUserId(this.adalSvc.userInfo.userName.toLowerCase())
      .subscribe(
        data => {
          if (data) {
            this.userDetails = data as IUpser;
          }
          else {
            console.log('Cannot find data for specified user: ' + localStorage.getItem('currentUserName1'));
          }
        },
        error => {
          console.log(error);
        });
  }

  createUser(user: IUpser) {
    this.customerAPI.createUpser(user)
      .subscribe(
        data => {

          if (data.responseStatus.status == '201') {
            setTimeout(() => {
            }, 2000);
          }
          else {
            return;
          }
        },
        error => {
          console.log(error);
        });
  }

  logOut() {
    this.currentUrl = this.router.url;
    if (this.currentUrl.indexOf("/ratedisplay") !== -1) {
      this.showRateCaculatorAlert("LOGOUT")
    }
    else {
      localStorage.clear();
      this.adalSvc.logout();
    }
  }

  newQuote() {
    this.currentUrl = this.router.url;
    if (this.currentUrl.indexOf("/ratedisplay") !== -1) {
      this.quoteService.resetQuoteModel();
      this.showRateCaculatorAlert("IPQUOTE")
    }
    else if (this.currentUrl.indexOf("/quote/shipment") !== -1) {
      this.quoteService.resetQuoteModel();
      this.helper.navigateTo(RoutingKey[PageState.IPQUOTE]);
    }
    else {
      this.quoteService.resetQuoteModel();
      this.helper.navigateTo(RoutingKey[PageState.SHIPMENT]);
    }
  }

  rateCalculator() {
    this.quoteService.resetAirportODPairLaneDetail();
    this.currentUrl = this.router.url;
    if (this.currentUrl.indexOf("/ratedisplay") !== -1) {

      this.showRateCaculatorAlert("RATECALCULATOR")
    }
    else {
      this.helper.navigateTo(RoutingKey[PageState.RATECALCULATOR]);
    }
  }

  showRateCaculatorAlert(navigateTo: string) {
    this.ratePageExitNotificationAlert.emit(navigateTo);
  }
}
