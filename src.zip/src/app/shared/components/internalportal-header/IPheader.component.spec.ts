import { async, ComponentFixture, TestBed, getTestBed, fakeAsync } from '@angular/core/testing';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { Router } from '@angular/router';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';
import { combineAll, expand } from 'rxjs/operators';
import { MsAdalAngular6Service, AuthenticationGuard, MsAdalAngular6Module } from 'microsoft-adal-angular6';
import { Observable, of } from 'rxjs'
import { Component, NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';


import { IPHeaderComponent } from '@app/shared/components/internalportal-header/IPheader.component';
import { UtilitiesService } from '@app/shared/services/shared/utilities.service';
import { RoutingKey } from '@app/shared/services/shared/config.const';
import { PageState } from '@app/shared/services/shared/enum';
import { IQuoteData, QuoteData } from '@app/models/quotes/quote-data';
import { QuoteAPI, routeAnimations } from '@app/shared/services';
import { ConfigService } from '@app/shared/services/shared/config.service';
import { RateDisplayComponent } from '@app/internal-portal/ratedisplay/ratedisplay.component';

describe('IPHeaderComponent from any other page except rate display', () => {
  let component: IPHeaderComponent;
  let fixture: ComponentFixture<IPHeaderComponent>;
  let element: any;
  let injector;
  let service: MsAdalAngular6Service;
  let router = {
    navigate: jasmine.createSpy('navigate'),
    url: jasmine.createSpy('url').and.returnValue("/notRatedisplay")
  }


  let adalAPIService: MsAdalAngular6Service,
    mockADALService = {
      logout: jasmine.createSpy('logout').and.returnValue(of({
      })),  
      LoggedInUserName: jasmine.stringMatching('Smitha Kalliyathuparambil')
    };

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule,
        RouterTestingModule,
        MsAdalAngular6Module.forRoot({
          tenant: 'e7520e4d-d5a0-488d-9e9f-949faae7dce8',
          clientId: '52282bb8-ff96-4954-ad39-1d3bde788e0e',
          redirectUri: "http://localhost:4200/upsers/",
          endpoints: {
            "http://localhost/Api/": "xxx-bae6-4760-b434-xxx"
          },
          navigateToLoginRequestUrl: true
          //cacheLocation: 'localStorage',
        })],
      providers: [QuoteAPI, ConfigService, UtilitiesService, {
        provide: MsAdalAngular6Service,
        useValue: mockADALService
      }, AuthenticationGuard,{ provide: Router, useValue: router }],     
      declarations: [IPHeaderComponent ],
    })
      .compileComponents();

    injector = getTestBed();
    service = injector.get(QuoteAPI);   
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IPHeaderComponent);
    component = fixture.componentInstance;
    element = fixture.nativeElement;
    fixture.detectChanges();

    //mocking local storage

    let store = {};
    const mockLocalStorage = {
      getItem: (key: string): string => {
        return key in store ? store[key] : null;
      },
      setItem: (key: string, value: string) => {
        store[key] = `${value}`;
      },
      removeItem: (key: string) => {
        delete store[key];
      },
      clear: () => {
        store = {};
      }
    };

    spyOn(localStorage, 'getItem')
      .and.callFake(mockLocalStorage.getItem);
    spyOn(localStorage, 'setItem')
      .and.callFake(mockLocalStorage.setItem);
    spyOn(localStorage, 'removeItem')
      .and.callFake(mockLocalStorage.removeItem);
    spyOn(localStorage, 'clear')
      .and.callFake(mockLocalStorage.clear);
    //end of mocking local storage
  });

  ////The  header component should be define.
  it("should have a defined component ", () => {
    expect(component).toBeDefined();
  });

  ////The header component component should exist.
  it('should have a Component', () => {
    expect(component).toBeTruthy();
  });


  it('call ngOnit Method with loggedin ups IP user', () => {
    component.guestUser = true;
    localStorage.setItem('LoggedInUser', 'UPSUer');
    component.ngOnInit();
    expect(localStorage.getItem('LoggedInUser')).toEqual('UPSUer');
    expect(component.guestUser).toEqual(false);
  });
  

  it('call ngOnit Method with guest user', () => {
    component.guestUser = true;
    component.userName = null;    
    component.ngOnInit();
    expect(localStorage.getItem('LoggedInUser')).toEqual(null);
    expect(component.guestUser).toEqual(true);
  });

});

@Component({ template: '<router-outlet></router-outlet>' })
class TestBootstrapComponent { }
@Component({ template: '' })
class TestComponent { }


const testRoutes: Routes = [
  //Test your code wih Azure login page
  
  { path: 'ratedisplay', component: TestBootstrapComponent },
  { path: 'notratedisplay', component: TestComponent }
 

];


describe('IPHeaderComponent call from rate display page', () => {
  let component: IPHeaderComponent;
  let fixture: ComponentFixture<IPHeaderComponent>;
  let element: any;
  let injector;
  let service: MsAdalAngular6Service;
  let router;

   let adalAPIService: MsAdalAngular6Service,
    mockADALService = {
      logout: jasmine.createSpy('logout').and.returnValue(of({
      })),
      LoggedInUserName: jasmine.stringMatching('Smitha Kalliyathuparambil')
    };

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule,
        RouterTestingModule.withRoutes(testRoutes),
        MsAdalAngular6Module.forRoot({
          tenant: 'e7520e4d-d5a0-488d-9e9f-949faae7dce8',
          clientId: '52282bb8-ff96-4954-ad39-1d3bde788e0e',
          redirectUri: "http://localhost:4200/upsers/",
          endpoints: {
            "http://localhost/Api/": "xxx-bae6-4760-b434-xxx"
          },
          navigateToLoginRequestUrl: true
          //cacheLocation: 'localStorage',
        })],
      providers: [QuoteAPI, ConfigService, UtilitiesService, {
        provide: MsAdalAngular6Service,
        useValue: mockADALService
      }, AuthenticationGuard],
      declarations: [IPHeaderComponent, TestBootstrapComponent, TestComponent],
    })
      .compileComponents();

    injector = getTestBed();
    service = injector.get(QuoteAPI);
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(IPHeaderComponent);
    component = fixture.componentInstance;
    element = fixture.nativeElement;
    spyOn(component.ratePageExitNotificationAlert, 'emit');
    router = fixture.debugElement.injector.get(Router);
    fixture.detectChanges();

    //mocking local storage

    let store = {};
    const mockLocalStorage = {
      getItem: (key: string): string => {
        return key in store ? store[key] : null;
      },
      setItem: (key: string, value: string) => {
        store[key] = `${value}`;
      },
      removeItem: (key: string) => {
        delete store[key];
      },
      clear: () => {
        store = {};
      }
    };

    spyOn(localStorage, 'getItem')
      .and.callFake(mockLocalStorage.getItem);
    spyOn(localStorage, 'setItem')
      .and.callFake(mockLocalStorage.setItem);
    spyOn(localStorage, 'removeItem')
      .and.callFake(mockLocalStorage.removeItem);
    spyOn(localStorage, 'clear')
      .and.callFake(mockLocalStorage.clear);
    //end of mocking local storage
  });  


  it('call logout from menu from any page except RateDisplay Page',
    fakeAsync(() => {
      const injector = getTestBed();
      const router = injector.get(Router);
      const fixture = TestBed.createComponent(TestBootstrapComponent);
      fixture.detectChanges();
      // initial navigation
      router.navigate(['/notratedisplay'])
        .then(() => {
          //console.log(router.url);
          //expect(router.url).toEqual('/ratedisplay');
          component.currentUrl = router.url;
          component.logOut();
          expect(mockADALService.logout).toHaveBeenCalled();
        });
    }));


  it('call logout from menu from RateDisplay Page',
    fakeAsync(() => {
      const injector = getTestBed();
      const router = injector.get(Router);
      const fixture = TestBed.createComponent(TestBootstrapComponent);
      fixture.detectChanges();
      // initial navigation
      router.navigate(['/ratedisplay'])
        .then(() => {
          //console.log(router.url);
          //expect(router.url).toEqual('/ratedisplay');
          component.currentUrl = router.url;
          component.logOut();
          expect(component.ratePageExitNotificationAlert.emit).toHaveBeenCalledWith('LOGOUT');
        });
    }));


  it('call rate calculator from menu from RateDisplay Page',
    fakeAsync(() => {
      const injector = getTestBed();
      const router = injector.get(Router);
      const fixture = TestBed.createComponent(TestBootstrapComponent);
      fixture.detectChanges();
      // initial navigation
      router.navigate(['/ratedisplay'])
        .then(() => {
          //console.log(router.url);
          //expect(router.url).toEqual('/ratedisplay');
          component.currentUrl = router.url;
          component.rateCalculator();
          expect(component.ratePageExitNotificationAlert.emit).toHaveBeenCalledWith('RATECALCULATOR');
        });
    }));

  //it('call rate calculator from menu from any page except RateDisplay Page',
  //  fakeAsync(() => {
  //    const injector = getTestBed();
  //    const router = injector.get(Router);
  //    const fixture = TestBed.createComponent(TestBootstrapComponent);
  //    fixture.detectChanges();
  //    // initial navigation
  //    router.navigate(['/upsers/ratecalculator'])
  //      .then(() => {
  //        //console.log(router.url);
  //        //expect(router.url).toEqual('/ratedisplay');
  //        component.currentUrl = router.url;
  //        component.rateCalculator();
  //        expect(router.navigate).toHaveBeenCalledWith(['/upsers/ratecalculator']);
  //      });
  //  }));



  it('call new quote from menu from RateDisplay Page',
    fakeAsync(() => {
      const injector = getTestBed();
      const router = injector.get(Router);
      const fixture = TestBed.createComponent(TestBootstrapComponent);
      fixture.detectChanges();
      // initial navigation
      router.navigate(['/ratedisplay'])
        .then(() => {
          //console.log(router.url);
          //expect(router.url).toEqual('/ratedisplay');
          component.currentUrl = router.url;
          component.newQuote();
          expect(component.ratePageExitNotificationAlert.emit).toHaveBeenCalledWith('IPQUOTE');
        });
    }));

  //it('call new quote from menu from any page except RateDisplay Page',
  //  fakeAsync(() => {
  //    const injector = getTestBed();
  //    const router = injector.get(Router);
  //    const fixture = TestBed.createComponent(TestBootstrapComponent);
  //    fixture.detectChanges();
  //    // initial navigation
  //    router.navigate(['/notratedisplay'])
  //      .then(() => {
  //        //console.log(router.url);
  //        //expect(router.url).toEqual('/ratedisplay');
  //        component.currentUrl = router.url;
  //        component.newQuote();
  //        expect(router.navigate).toHaveBeenCalledWith(['/upsers/quote']);
  //      });
  //  })); 

});
