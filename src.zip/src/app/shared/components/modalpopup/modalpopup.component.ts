import { Component, Input } from '@angular/core';

import { NgbModal, NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'ngbd-modal-content',
  template: `<div class="ngbd-modal-container">
            <div class="popup" pd-popup="popupNew" style="display: block;">
            <div class="popup-inner">
                <p>{{message}}</p>
                <p><a pd-popup-close="popupNew" href="javascript:void(0)" class="btn btn-danger" (click)="activeModal.dismiss('Cross click')">Close</a></p>
                <a class="popup-close" pd-popup-close="popupNew" href="javascript:void(0)" (click)="activeModal.dismiss('Cross click')"> </a>
            </div>
        </div>
      </div>`,

    //template: `
    //<div class="modal-header">
    //  <span class="modal-title">Message</span>
    //  <button type="button" class="close" aria-label="Close" (click)="activeModal.dismiss('Cross click')">
    //    <span aria-hidden="true">&times;</span>
    //  </button>
    //</div>
    //<div class="modal-body">
    //  <p>{{message}}!</p>
    //</div>
    //<div class="modal-footer">
    //  <button type="button" class="btn btn-primary" (click)="activeModal.close('Close click')">Close</button>
    //</div>`,
     styleUrls: ['./modalpopup.component.scss'],
})
export class NgbdModalContent {
    @Input() message;

  constructor(public activeModal: NgbActiveModal) { }
}

@Component({
    selector: 'ngbd-modal-component',
    templateUrl: './modalpopup.component.html',
    styleUrls: ['./modalpopup.component.scss'],
})
export class NgbdModalComponent {
    constructor(private modalService: NgbModal) { }

    open(message) {
        const modalRef = this.modalService.open(NgbdModalContent);
        modalRef.componentInstance.message = message;
    }
}
