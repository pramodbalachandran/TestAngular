import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { RoutingKey } from '@app/shared/services/shared/config.const';
import { UtilitiesService } from '@app/shared/services/shared/utilities.service';
import { PageState } from '@app/shared/services/shared/enum';

@Component({
  selector: 'app-login-header',
  templateUrl: './login-header.component.html',
  styleUrls: ['./login-header.component.css']
})
export class LoginHeaderComponent implements OnInit {
  public userName: string;
  show= false;

  constructor(private _routes: Router, private _helper: UtilitiesService) { }

  ngOnInit() {
     this.userName = localStorage.getItem('currentUserName');
  }

  logOut() { 
    localStorage.clear();
    this._helper.navigateTo(RoutingKey[PageState.LOGIN]);
  }

  showorHide() {
    this.show = !this.show;
  };

  isActive(e) {
    return this.show;
  };

  enter(e) {
    this.show = true;
  }

  leave(e) {
    this.show = false;
  }

  newQuote() {
    this._helper.navigateTo(RoutingKey[PageState.QUOTE]);
  }
}
