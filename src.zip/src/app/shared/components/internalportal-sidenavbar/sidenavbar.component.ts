import { Component, OnInit, Output, EventEmitter} from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'upsers-sidenavbar',
  templateUrl: './sidenavbar.component.html',
  styleUrls: ['./sidenavbar.component.css']
})
export class SideNavbarComponent implements OnInit {

  @Output() ratePageExitNotificationAlert = new EventEmitter();

  constructor(private router: Router) { }

  ngOnInit() {
  }


  showRateCaculatorAlert(navigateTo: string) { // You can give any function name

    let currentUrl = this.router.url;
    if (currentUrl.trim().indexOf("/ratedisplay") !== -1) {

      this.ratePageExitNotificationAlert.emit(navigateTo);
    }

    else {

       //TO DO
      //navigate to pages 
    }    
  }
}
