import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { RouterTestingModule } from '@angular/router/testing';


import { SideNavbarComponent } from './sidenavbar.component'

describe('SideNavbarComponent', () => {
  let component: SideNavbarComponent;
  let fixture: ComponentFixture<SideNavbarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [RouterTestingModule],
      declarations: [SideNavbarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SideNavbarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  ////The shipment Frequency component should be define.
  it("should have a defined component ", () => {
    expect(component).toBeDefined();
  });

  ////The shipment Frequency component should exist.
  it('should have a Component', () => {
    expect(component).toBeTruthy();
  });

  ////Component's sidebar title property should be displayed in the template.
  it("Should have a menu as 'SUMMARY' ", async(() => {
    let title = fixture.debugElement.query(By.css('#divSummary')).nativeElement;
    expect(title.textContent).toEqual(" SUMMARY");
  }));

  ////Component's main title property should be displayed in the template.
  it("Should have a menu as 'QUOTES' ", async(() => {

    let title = fixture.debugElement.query(By.css('#divQuotes')).nativeElement;
    expect(title.textContent).toEqual(" QUOTES");

  }));

  ////Component's main title property should be displayed in the template.
  it("Should have a menu as 'NOTIFICATIONS' ", async(() => {

    let title = fixture.debugElement.query(By.css('#divNotification')).nativeElement;
    expect(title.textContent).toEqual(" NOTIFICATIONS");

  }));
});
