export class ShipmentUOMConstants {
  public static cubicCmToKgFactor = 6000;
  public static cubicCmToInchesFactor = 16.387;
  public static cubicInchesToLbsFactor = 166;
  public static cubicMetersToCubicInchFactor = 1e+6;
  public static kgToLbsFactor = 2.20462262;
  public static cubicFeetToCubicCmFactor = 28316.847;
}
