export class BonsaiConstants {
  public static loggedInUserName = "loggedInUserNameIP";
  public static loggedInUserDisplayName = "loggedInUserDisplayNameIP";
}
