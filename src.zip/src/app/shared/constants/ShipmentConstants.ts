export class ShipmentConstants {
public static gadTooltipMessage = 'This value will be used as the chargeable weight';
public static marginDynamicvalue  = '-120px';
}
