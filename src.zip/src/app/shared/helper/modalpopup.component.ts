import { Component } from '@angular/core';


@Component({
  selector: 'modalpopup',
  template: `
  <div (click)="onContainerClicked($event)"  [style.display]="showModal ? 'block' : 'none'" class="modal fade" tabindex="-1" [ngClass]="{'in': visibleAnimate}"
       [ngStyle]="{'display': visible ? 'block' : 'none','overflow-y': 'auto', 'opacity': visibleAnimate ? 1 : 0}">
    <div  class="modal-dialog modal-lg">
      <div>
        <div>
          <ng-content select=".app-modal-header"></ng-content>
        </div>
        <div class="modal-body">
          <ng-content select=".app-modal-body"></ng-content>
        </div>
      </div>
    </div>
  </div>
  `,
  styles: [`
    .modal {
      background: rgba(0,0,0,0.6);
    }
  `]
})
export class ModalComponent {

  public visible = false;
  private visibleAnimate = false;
  private IsmodelShow=false;
  constructor() { }

  public show(): void {
    this.visible = true;
    setTimeout(() => this.visibleAnimate = true, 100);
  }

  public hide(): void {
    this.visibleAnimate = false;
    setTimeout(() => this.visible = false, 200);
  }

  /**
   * Close login overlay when user clicked outside login window
   * @param event
   */
  public onContainerClicked(event: MouseEvent): void {
    if ((<HTMLElement>event.target).classList.contains('modal') || (<HTMLElement>event.target).tagName == 'PRICING-LOGINREGISTER')  {
      this.hide();
    }
  }

  close() {
    this.IsmodelShow=true;// set false while you need open your model popup
    this.hide();
    // do your more code
  }
}
