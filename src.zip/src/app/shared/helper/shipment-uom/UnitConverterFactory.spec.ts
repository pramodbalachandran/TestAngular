import { KgToLbsConverter } from './converter/KgToLbsConverter';
import { LbhInInchesToLbsConverter } from './converter/LbhInInchesToLbsConverter';
import { LbhInCmToLbsConverter } from './converter/LbhInCmToLbsConverter';
import { CbmToLbsConverter } from './converter/CbmToLbsConverter';
import { CbfToLbsConverter } from './converter/CbfToLbsConverter';
import { NoUnitConversion } from './converter/NoUnitConversion';
import { LbsToKgConverter } from './converter/LbsToKgConverter';
import { LbhInInchesToKgConverter } from './converter/LbhInInchesToKgConverter';
import { LbhInCmToKgConverter } from './converter/LbhInCmToKgConverter';
import { CbmToKgConverter } from './converter/CbmToKgConverter';
import { CbfToKgConverter } from './converter/CbfToKgConverter';
import { ShipmentUnitName } from '@app/shared/enums/ShipmentUnitName';
import { IUnitConverter } from './converter/IUnitConverter';
import { UnitConverterFactory } from './UnitConverterFactory';
describe('UnitConverterFactory', () => {
  let factory: UnitConverterFactory;
  const keys = Object.keys;
  beforeEach(() => {
    factory = new UnitConverterFactory();
  });
  it('should be defined', () => {
    expect(factory).toBeDefined();
  });
  describe('createUnitConverter', () => {
    it('should return appropirate classes when called with different units as from and to', () => {
      const unitsFrom = keys(ShipmentUnitName);
      const unitsTo = keys(ShipmentUnitName);
      unitsFrom.forEach(unitFrom => {
        unitsTo.forEach( unitTo => {
          let converter: IUnitConverter;
          converter = factory.createUnitConverter(ShipmentUnitName[unitFrom], ShipmentUnitName[unitTo]);
          if (ShipmentUnitName[unitTo] === ShipmentUnitName.Kg) {
            switch (ShipmentUnitName[unitFrom]) {
              case ShipmentUnitName.Cbf:
              expect(converter instanceof CbfToKgConverter).toBeTruthy();
              break;
              case ShipmentUnitName.Cbm:
              expect(converter instanceof CbmToKgConverter).toBeTruthy();
              break;
              case ShipmentUnitName.Cm:
              expect(converter instanceof LbhInCmToKgConverter).toBeTruthy();
              break;
              case ShipmentUnitName.Inches:
              expect(converter instanceof LbhInInchesToKgConverter).toBeTruthy();
              break;
              case ShipmentUnitName.Lb:
              expect(converter instanceof LbsToKgConverter).toBeTruthy();
              break;
              default:
              expect(converter instanceof NoUnitConversion).toBeTruthy();
              break;
            }
          } else if (ShipmentUnitName[unitTo] === ShipmentUnitName.Lb) {
            switch (ShipmentUnitName[unitFrom]) {
              case ShipmentUnitName.Cbf:
              expect(converter instanceof CbfToLbsConverter).toBeTruthy();
              break;
              case ShipmentUnitName.Cbm:
              expect(converter instanceof CbmToLbsConverter).toBeTruthy();
              break;
              case ShipmentUnitName.Cm:
              expect(converter instanceof LbhInCmToLbsConverter).toBeTruthy();
              break;
              case ShipmentUnitName.Inches:
              expect(converter instanceof LbhInInchesToLbsConverter).toBeTruthy();
              break;
              case ShipmentUnitName.Kg:
              expect(converter instanceof KgToLbsConverter).toBeTruthy();
              break;
              default:
              expect(converter instanceof NoUnitConversion).toBeTruthy();
              break;
            }
          } else {
            expect(converter instanceof NoUnitConversion).toBeTruthy();
          }
        });
      });
    });
  });
});
