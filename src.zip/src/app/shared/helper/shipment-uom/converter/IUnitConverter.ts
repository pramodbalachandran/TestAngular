// Base interface for unit conversion.
export interface IUnitConverter {
  _converter: IUnitConverter;
  convert(...value: number[]): number[];
  doConversion(...value): number[];
}
