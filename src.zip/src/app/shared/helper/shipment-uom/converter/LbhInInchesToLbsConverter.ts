import { UnitConverter } from './UnitConverter';
import { LBHToCubicConverter } from './LBHToCubicConverter';
import { CubicInchesToLbsConverter } from './CubicInchesToLbsConverter';
// Converts lbh in inches to dimensional weight in lbs.
export class LbhInInchesToLbsConverter extends UnitConverter {
  constructor() {
    super(new LBHToCubicConverter(
      new CubicInchesToLbsConverter()
    ));
  }
  convert(...value: number[]): number[] {
    return value;
  }
}
