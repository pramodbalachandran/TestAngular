import { UnitConverter } from './UnitConverter';
// Convert length, breadh and height to cubic unit.
export class LBHToCubicConverter extends UnitConverter {

  convert(...value: number[]): number[] {
    if (value.length !== 3) {
      throw new Error('Cm must have 3 parameters for length breadth and height');
    }
    return [value[0] * value[1] * value[2]];
  }
}
