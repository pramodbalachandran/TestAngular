import { ShipmentUOMConstants } from '@app/shared/constants/ShipmentUOMConstants';
import { UnitConverter } from './UnitConverter';
// Convert cm to inches.
export class CubicCmToCubicInchesConverter extends UnitConverter {
  private readonly conversionFactor = ShipmentUOMConstants.cubicCmToInchesFactor;
  convert(...value: number[]): number[] {
    if (value.length !== 1) {
      throw new Error('Cubic Cm must only have one parameter.');
    }
    return [value[0] / this.conversionFactor];
  }
}
