import { NoUnitConversion } from './NoUnitConversion';
import { LbsToKgConverter } from './LbsToKgConverter';
import { LbhInInchesToKgConverter } from './LbhInInchesToKgConverter';
import { LbhInCmToLbsConverter } from './LbhInCmToLbsConverter';
import { LBHToCubicConverter } from './LbhToCubicConverter';
import { LbhInCmToKgConverter } from './LbhInCmToKgConverter';
import { CubicInchesToCubicCmConverter } from './CubicInchesToCubicCmConverter';
import { CbmToLbsConverter } from './CbmToLbsConverter';
import { CubicInchesToLbsConverter } from './CubicInchesToLbsConverter';
import { CubicCmToCubicInchesConverter } from './CubicCmToCubicInchesConverter';
import { CubicMetersToCubicCmConverter } from './CubicMetersToCubicCmConverter';
import { CbmToKgConverter } from './CbmToKgConverter';
import { KgToLbsConverter } from './KgToLbsConverter';
import { CbfToLbsConverter } from './CbfToLbsConverter';
import { CubicCmToKgConverter } from './CubicCmToKgConverter';
import { CubicFeetToCubicCmConverter } from './CubicFeetToCubicCmConverter';
import { IUnitConverter } from './IUnitConverter';
import { CbfToKgConverter } from './CbfToKgConverter';
describe('UnitConverters', () => {
  let converter: IUnitConverter;
  function createConverter<T extends IUnitConverter, C extends IUnitConverter>(type: {new(): T}, classes: C[]) {
    describe('create and check constructor for: ' + new type().constructor.name + ' that it', () => {
      beforeEach(() => {
        converter = new type();
      });
      it('should be defined', () => {
        expect(converter).toBeDefined();
      });
      it('should create correct class nesting', () => {
        let nested: IUnitConverter;
        nested = converter;
        if (classes !== null) {
         classes.forEach( expected => {
           nested = nested._converter;
            expect(nested.constructor.name === expected.constructor.name).toBeTruthy();
          });
        } else {
          expect( converter._converter == null).toBeTruthy();
        }
      });
    });
  }

  function test_convert(inputs: number[], outputs: number[], invalids?: number[], error?: string) {
    describe('convert function', () => {
      it('should return correct converted value when provided with correct parameters', () => {
        const convertedVals = converter.convert(...inputs);
        if ( outputs.length === convertedVals.length) {
          for (let i = 0; i < outputs.length; i++) {
            expect(convertedVals[i] === outputs[i]);
          }
          expect( () => { converter.convert(...inputs); }).not.toThrow(new Error(error));
        } else {
          expect(false).toBeTruthy();
          return;
        }
        expect(true).toBeTruthy();
      });
      if (invalids && error) {
        it('should throw error on incorrect parameters', () => {
          expect( () => { converter.convert(...invalids); }).toThrow(new Error(error));
        });
      }
    });
  }

  function test_doConversion(values: number[]) {
    describe('doConversion', () => {
      it('must call convert of current and doConversion of nested variable recursively.', () => {
        let nested = converter;
        const convertSpys = [];
        const doConSpys = [];
        while (true) {
          convertSpys.push(spyOn(nested, 'convert').and.callThrough());
          nested = nested._converter;
          if (nested == null) {
            break;
          }
          doConSpys.push(spyOn(nested, 'doConversion').and.callThrough());
        }
        converter.doConversion(...values);
        convertSpys.forEach( spy => {
          expect(spy).toHaveBeenCalled();
        });
        doConSpys.forEach(spy => {
          expect(spy).toHaveBeenCalled();
        });
      });
    });
  }

  createConverter(CbfToKgConverter, [new CubicFeetToCubicCmConverter(), new CubicCmToKgConverter()]);
  test_convert([1], [1]);
  test_doConversion([1]);
  createConverter(CbfToLbsConverter, [new CubicFeetToCubicCmConverter(),
    new CubicCmToCubicInchesConverter(), new CubicInchesToLbsConverter()]);
  test_convert([1], [1]);
  test_doConversion([1]);
  createConverter(CbmToKgConverter, [new CubicMetersToCubicCmConverter(), new CubicCmToKgConverter()]);
  test_convert([1], [1]);
  test_doConversion([1]);
  createConverter(CbmToLbsConverter, [new CubicMetersToCubicCmConverter(),
    new CubicCmToCubicInchesConverter(), new CubicInchesToLbsConverter()]);
  test_convert([1], [1]);
  test_doConversion([1]);
  createConverter(LbhInCmToKgConverter, [new LBHToCubicConverter(),
    new CubicCmToKgConverter()]);
  test_convert([1, 2, 3], [1, 2, 3]);
  test_doConversion([1, 2, 3]);
  createConverter(LbhInCmToLbsConverter, [new LBHToCubicConverter(),
    new CubicCmToCubicInchesConverter(), new CubicInchesToLbsConverter()]);
  test_convert([1, 2, 3], [1, 2, 3]);
  test_doConversion([1, 2, 3]);
  createConverter(LbhInInchesToKgConverter, [new LBHToCubicConverter(),
    new CubicInchesToCubicCmConverter(), new CubicCmToKgConverter()]);
  test_convert([1, 2, 3], [1, 2, 3]);
  test_doConversion([1, 2, 3]);
  createConverter(LbhInCmToLbsConverter, [new LBHToCubicConverter(),
    new CubicCmToCubicInchesConverter(), new CubicInchesToLbsConverter()]);
  test_convert([1, 2, 3], [1, 2, 3]);
  test_doConversion([1, 2, 3]);
  createConverter(CubicCmToCubicInchesConverter, null);
  test_convert([1], [0.0610237], [1, 2, 3], 'Cubic Cm must only have one parameter.');
  test_doConversion([1]);
  createConverter(CubicCmToKgConverter, null);
  test_convert([6000], [1], [1, 2, 3], 'Cubic Cm must only have one parameter.');
  test_doConversion([1]);
  createConverter(CubicFeetToCubicCmConverter, null);
  test_convert([1], [28316.847], [1, 2, 3], 'Ft must have only one parameter.');
  test_doConversion([1]);
  createConverter(CubicInchesToCubicCmConverter, null);
  test_convert([1], [16.387], [1, 2, 3], 'Cubic Inches must only have one parameter.');
  test_doConversion([1]);
  createConverter(CubicInchesToLbsConverter, null);
  test_convert([166], [1], [1, 2, 3], 'Cubic Inches must only have one parameter.');
  test_doConversion([1]);
  createConverter(CubicMetersToCubicCmConverter, null);
  test_convert([1], [1e+6], [1, 2, 3], 'Meter must have only one parameter.');
  test_doConversion([1]);
  createConverter(KgToLbsConverter, null);
  test_convert([1], [2.20462262], [1, 2, 3], 'Lbs must have only one parameter.');
  test_doConversion([1]);
  createConverter(LBHToCubicConverter, null);
  test_convert([1, 2, 3], [1 * 2 * 3], [1], 'Cm must have 3 parameters for length breadth and height');
  test_doConversion([1, 2, 3]);
  createConverter(LbsToKgConverter, null);
  test_convert([2.20462262], [1], [1, 2], 'Lbs must have only one parameter.');
  test_doConversion([1]);
  createConverter(NoUnitConversion, null);
  test_convert([1], [1], [1, 2], 'convert function expects only one parameter.');
  test_doConversion([1]);

});
