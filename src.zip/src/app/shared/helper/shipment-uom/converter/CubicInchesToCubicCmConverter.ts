import { ShipmentUOMConstants } from '@app/shared/constants/ShipmentUOMConstants';
import { UnitConverter } from './UnitConverter';
/// Converts inches to cm.
export class CubicInchesToCubicCmConverter extends UnitConverter {
  private readonly conversionFactor = ShipmentUOMConstants.cubicCmToInchesFactor;

  convert(...value: number[]): number[] {
    if (value.length !== 1) {
      throw new Error('Cubic Inches must only have one parameter.');
    }
    return [value[0] * this.conversionFactor];
  }
}
