import { UnitConverter } from './UnitConverter';
import { LBHToCubicConverter } from './LBHToCubicConverter';
import { CubicCmToCubicInchesConverter } from './CubicCmToCubicInchesConverter';
import { CubicInchesToLbsConverter } from './CubicInchesToLbsConverter';
// Converts lbh in cm to dimensional weight in lbs.
export class LbhInCmToLbsConverter extends UnitConverter {
  constructor() {
    super(new LBHToCubicConverter(
      new CubicCmToCubicInchesConverter(
        new CubicInchesToLbsConverter()
      )));
  }
  convert(...value: number[]): number[] {
    return value;
  }
}
