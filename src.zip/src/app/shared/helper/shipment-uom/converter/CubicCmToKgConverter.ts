import { ShipmentUOMConstants } from '@app/shared/constants/ShipmentUOMConstants';
import { UnitConverter } from './UnitConverter';
// Converts cubic centimeters to kg dimensional weight.
export class CubicCmToKgConverter extends UnitConverter {
  private readonly kgFactor: number = ShipmentUOMConstants.cubicCmToKgFactor;

  convert(...value: number[]): number[] {
    if (value.length !== 1) {
      throw new Error('Cubic Cm must only have one parameter.');
    }
    return [value[0] / this.kgFactor];
  }
}
