import { ShipmentUOMConstants } from '@app/shared/constants/ShipmentUOMConstants';
import { UnitConverter } from './UnitConverter';
// Converts meters to cm.
export class CubicFeetToCubicCmConverter extends UnitConverter {
  private readonly conversionFactor = ShipmentUOMConstants.cubicFeetToCubicCmFactor;
  convert(...value: number[]): number[] {
    if (value.length !== 1) {
      throw new Error('Ft must have only one parameter.');
    }
    return [value[0] * this.conversionFactor];
  }
}
