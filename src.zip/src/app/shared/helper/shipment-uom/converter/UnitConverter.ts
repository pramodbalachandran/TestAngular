import { IUnitConverter } from './IUnitConverter';

// Abstract class for IUnitConverter.
export abstract class UnitConverter implements IUnitConverter {
  _converter: IUnitConverter;
  abstract convert(...value: number[]): number[];

  // recieves a IUnit converter for decorating the current.
  constructor(converter: IUnitConverter = null) {
    this._converter = converter;
  }

  // Order of execution of the decorator is inward.
  // The outer decorator is executed first and then passed inward.
  doConversion(...value: number[]): number[] {
    let converted = this.convert(...value);
    if (this._converter) {
      converted = this._converter.doConversion(...converted);
    }
    return converted;
  }
}
