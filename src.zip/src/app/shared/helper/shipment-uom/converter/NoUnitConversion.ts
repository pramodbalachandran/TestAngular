import { UnitConverter } from './UnitConverter';
// An empty unit convertor when no conversion required
export class NoUnitConversion extends UnitConverter {
  convert(...value: number[]): number[] {
    if (value.length !== 1) {
      throw new Error('convert function expects only one parameter.');
    }
    return value;
  }
}
