import { UnitConverter } from './UnitConverter';
import { CubicFeetToCubicCmConverter } from './CubicFeetToCubicCmConverter';
import { CubicCmToKgConverter } from './CubicCmToKgConverter';
// Converts CBF to Kg dimensional weight
export class CbfToKgConverter extends UnitConverter {

  constructor() {
    super(new CubicFeetToCubicCmConverter(
      new CubicCmToKgConverter()));
  }
  convert(...value: number[]): number[] {
    return value;
  }
}

