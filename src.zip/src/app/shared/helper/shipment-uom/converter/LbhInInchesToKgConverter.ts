import { UnitConverter } from './UnitConverter';
import { LBHToCubicConverter } from './LBHToCubicConverter';
import { CubicInchesToCubicCmConverter } from './CubicInchesToCubicCmConverter';
import { CubicCmToKgConverter } from './CubicCmToKgConverter';

// Converts LBH in inches to KG dimensional weight.
export class LbhInInchesToKgConverter extends UnitConverter {

  constructor() {
    super(new LBHToCubicConverter(
      new CubicInchesToCubicCmConverter(
        new CubicCmToKgConverter())));
  }

  convert(...value: number[]): number[] {
    return value;
  }
}
