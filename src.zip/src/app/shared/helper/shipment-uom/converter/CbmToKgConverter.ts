import { UnitConverter } from './UnitConverter';
import { CubicMetersToCubicCmConverter } from './CubicMetersToCubicCmConverter';
import { CubicCmToKgConverter } from './CubicCmToKgConverter';
// Converts cubic meters to kg dimensional weight
export class CbmToKgConverter extends UnitConverter {
  constructor() {
    super(new CubicMetersToCubicCmConverter(
      new CubicCmToKgConverter()));
  }
  convert(...value: number[]): number[] {
    return value;
  }
}

