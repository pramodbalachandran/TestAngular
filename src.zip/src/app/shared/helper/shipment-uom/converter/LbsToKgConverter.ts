import { ShipmentUOMConstants } from '@app/shared/constants/ShipmentUOMConstants';
import { UnitConverter } from './UnitConverter';
// Converts weight in lbs to kg.
export class LbsToKgConverter extends UnitConverter {
  private readonly conversionFactor = ShipmentUOMConstants.kgToLbsFactor;
  convert(...value: number[]): number[] {
    if (value.length !== 1) {
      throw new Error('Lbs must have only one parameter.');
    }
    return [value[0] / this.conversionFactor];
  }
}
