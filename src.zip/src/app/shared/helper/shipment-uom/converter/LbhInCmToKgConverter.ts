import { UnitConverter } from './UnitConverter';
import { LBHToCubicConverter } from './LBHToCubicConverter';
import { CubicCmToKgConverter } from './CubicCmToKgConverter';
// Converts LBH in centemeters to KG dimensional weight.
export class LbhInCmToKgConverter extends UnitConverter {

  constructor() {
    super(new LBHToCubicConverter(new CubicCmToKgConverter()));
  }

  convert(...value: number[]): number[] {
    return value;
  }
}
