import { UnitConverter } from './UnitConverter';
import { CubicFeetToCubicCmConverter } from './CubicFeetToCubicCmConverter';
import { CubicCmToCubicInchesConverter } from './CubicCmToCubicInchesConverter';
import { CubicInchesToLbsConverter } from './CubicInchesToLbsConverter';
// Converts cbf to dimensional weight in lbs.
export class CbfToLbsConverter extends UnitConverter {
  constructor() {
    super(new CubicFeetToCubicCmConverter(
      new CubicCmToCubicInchesConverter(
        new CubicInchesToLbsConverter()
      )
    ));
  }
  convert(...value: number[]): number[] {
    return value;
  }
}
