import { UnitConverter } from './UnitConverter';
import { CubicMetersToCubicCmConverter } from './CubicMetersToCubicCmConverter';
import { CubicCmToCubicInchesConverter } from './CubicCmToCubicInchesConverter';
import { CubicInchesToLbsConverter } from './CubicInchesToLbsConverter';
// Converts cbm to dimensional weight in lbs.
export class CbmToLbsConverter extends UnitConverter {
  constructor() {
    super(new CubicMetersToCubicCmConverter(
      new CubicCmToCubicInchesConverter(
        new CubicInchesToLbsConverter()
      )));
  }
  convert(...value: number[]): number[] {
    return value;
  }
}
