import { IUnitConverter } from './converter/IUnitConverter';
import { LbhInCmToKgConverter } from './converter/LbhInCmToKgConverter';
import { LbhInInchesToKgConverter } from './converter/LbhInInchesToKgConverter';
import { CbfToKgConverter } from './converter/CbfToKgConverter';
import { CbmToKgConverter } from './converter/CbmToKgConverter';
import { LbsToKgConverter } from './converter/LbsToKgConverter';
import { NoUnitConversion } from './converter/NoUnitConversion';
import { LbhInCmToLbsConverter } from './converter/LbhInCmToLbsConverter';
import { LbhInInchesToLbsConverter } from './converter/LbhInInchesToLbsConverter';
import { CbfToLbsConverter } from './converter/CbfToLbsConverter';
import { CbmToLbsConverter } from './converter/CbmToLbsConverter';
import { KgToLbsConverter } from './converter/KgToLbsConverter';
import { ShipmentUnitName } from '@app/shared/enums/ShipmentUnitName';
import { Injectable } from '@angular/core';


// Creates the necessary converters for unit conversion based on to and from unit.
// TODO: Need to get rid of the if conditions and switches by implementing reflection using
// typescript decorator. The decorator needs to do the following:
// 1. Insert metadata to and from to the classes needed.
// 2. Maintain a registry of types so that all classes extending UnitConverter can be retrieved.
// With this the factory can check the implementation for necessary metadata and return converters
// accordingly.
@Injectable({
  providedIn: 'root'
})

export class UnitConverterFactory {
  createUnitConverter(from: ShipmentUnitName, to: ShipmentUnitName): IUnitConverter {
    if (to === ShipmentUnitName.Kg) {
      switch (from) {
        case ShipmentUnitName.Cm:
          return new LbhInCmToKgConverter();
        case ShipmentUnitName.Inches:
          return new LbhInInchesToKgConverter();
        case ShipmentUnitName.Cbf:
          return new CbfToKgConverter();
        case ShipmentUnitName.Cbm:
          return new CbmToKgConverter();
        case ShipmentUnitName.Lb:
          return new LbsToKgConverter();
        default:
          return new NoUnitConversion();
      }
    } else if (to === ShipmentUnitName.Lb) {
      switch (from) {
        case ShipmentUnitName.Cm:
          return new LbhInCmToLbsConverter();
        case ShipmentUnitName.Inches:
          return new LbhInInchesToLbsConverter();
        case ShipmentUnitName.Cbf:
          return new CbfToLbsConverter();
        case ShipmentUnitName.Cbm:
          return new CbmToLbsConverter();
        case ShipmentUnitName.Kg:
          return new KgToLbsConverter();
        default:
          return new NoUnitConversion();
      }
    } else {
      return new NoUnitConversion();
    }
  }
}
