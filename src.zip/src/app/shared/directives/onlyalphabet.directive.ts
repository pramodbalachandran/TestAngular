import { Directive, ElementRef, HostListener, Input } from '@angular/core';

@Directive({
  selector: '[Onlyalphabet]'
})
export class Onlyalphabet {

  constructor(private el: ElementRef) { }

  @Input() Onlyalphabet: boolean;

  @HostListener('keydown', ['$event']) onKeyDown(event) {   
    let e = <KeyboardEvent> event;    
    if (this.Onlyalphabet) {
      if ([110,46,8, 9, 27, 13,106,188,32].indexOf(e.keyCode) !== -1 ||
        // Allow: Ctrl+A
        (e.keyCode == 65 && e.ctrlKey === true) ||
        // Allow: Ctrl+C
        (e.keyCode == 67 && e.ctrlKey === true) ||
        // Allow: Ctrl+X
        (e.keyCode == 88 && e.ctrlKey === true) ||
        
        // Allow: home, end, left, right and aplhabet
        (e.keyCode >= 35 && e.keyCode <= 39) || (e.keyCode >= 65 && e.keyCode <= 90)) {
          // let it happen, don't do anything
          return;
        }
        
        // Ensure that it is a number and stop the keypress
        if ((e.shiftKey || (e.keyCode <=57)) && (e.keyCode < 96 || e.keyCode > 105)) {
            e.preventDefault();
      }

      if ((e.keyCode > 96 || e.keyCode < 105)) {
        e.preventDefault();
      }
        //  var specialKeys = new Array();
        // specialKeys.push(35); 
        // specialKeys.push(36); 
        // specialKeys.push(37); 
        // specialKeys.push(38);
        // specialKeys.push(39); 
        // specialKeys.push(40); 
        // specialKeys.push(41); 
        
        // var keyCode = e.keyCode == 0 ? e.charCode : e.keyCode;
        // var ret = ((keyCode >= 48 && keyCode <= 57) || (keyCode >= 65 && keyCode <= 90) 
        // || (keyCode >= 97 && keyCode <= 122) || 
        // (specialKeys.indexOf(e.keyCode) != -1 && e.charCode != e.keyCode));
        // return ret;
      }
  }
}
