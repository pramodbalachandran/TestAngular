import { Pipe, PipeTransform } from '@angular/core';
@Pipe({
    name: 'filterAutopopulate',
    pure: false
})
export class AutopopulateFilterPipe implements PipeTransform {
    transform(State: any[], filterQuery: string): any {
        if (!State || !filterQuery) {
            return State;
        }
        // filter items array, items which match and return true will be kept, false will be filtered out
        return State.filter(state => state.autopopulateformat.indexOf(filterQuery)> -1);
        //return items.filter(item => item.title.indexOf(filter.title) !== -1);







        
    }
}