import { Directive, ElementRef, HostListener } from '@angular/core';

@Directive({
    selector: '[DecimalNumberOnly]'
})
export class DecimalNumberOnlyDirective {
  constructor(private el: ElementRef) {
  }

  @HostListener('keypress', ['$event'])
  onKeyDown(event: KeyboardEvent) {

    let current: string = this.el.nativeElement.value;

    current = current.replace(/[^0-9\.]/g, '');
    if ((event.which != 46 || current.indexOf('.') != -1) && (event.which < 48 || event.which > 57)) {
      event.preventDefault();
    }
  }

  @HostListener('paste', ['$event']) onPaste(e: KeyboardEvent) {
    var value = event['clipboardData'].getData('text/plain');
    if (isNaN(value)) {
      event.preventDefault();
    }
  }
}




