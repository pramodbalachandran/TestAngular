import { Directive, ElementRef, HostListener, Renderer2, OnInit, OnDestroy, Input, Testability } from '@angular/core';
import { forEach } from '@angular/router/src/utils/collection';

@Directive({
    selector: '[popupSelect]',
})
export class PopupSelect implements OnInit, OnDestroy {


    @Input('icon') icon: string = "";
    private iconSpan: HTMLSpanElement;
    private arrowSpan: HTMLSpanElement;
    private containerSpan: HTMLSpanElement;
    private curText: any;

    constructor(private el: ElementRef, private renderer: Renderer2) {
    }

    ngOnDestroy() {
        let nat: HTMLSelectElement;
        nat = this.el.nativeElement;
    }

    ngOnInit() {

        let nat: HTMLSelectElement;
        nat = this.el.nativeElement;
        // Wrap the host element in a span.
        this.containerSpan = this.renderer.createElement('span');
        this.renderer.addClass(this.containerSpan, 'text-nowrap');
        this.renderer.addClass(this.containerSpan, 'popup-select-wrapper');
        this.renderer.insertBefore(nat.parentElement, this.containerSpan, nat);
        this.renderer.removeChild(nat.parentElement,nat);
        this.renderer.removeAttribute(nat, 'popupSelect');
        this.renderer.appendChild(this.containerSpan, nat);

        // Add icon if needed.
        if (/\S/.test(this.icon)) {
            let classArray = this.icon.split(/[ ]+/);
            this.iconSpan = this.renderer.createElement('span');
            let component = this;
            classArray.forEach(function(value){
                component.renderer.addClass(component.iconSpan, value);
            });
            this.renderer.insertBefore(nat.parentElement, this.iconSpan,nat);
            this.renderer.setStyle(this.iconSpan, 'margin-right', '10px');
            this.renderer.listen(this.iconSpan,'click',function(){
                nat.click();
            });
        }

        // Remove default arrow
        this.renderer.setStyle(nat, '-moz-appearance', 'none');
        this.renderer.setStyle(nat, '-webkit-appearance', 'none');
        this.renderer.setStyle(nat, 'appearance', 'none');
        this.renderer.setStyle(nat, 'background-color', 'transparent');

        // Add arrow style.
        this.arrowSpan = this.renderer.createElement('span');
        this.renderer.addClass(this.arrowSpan, 'fa');
        this.renderer.addClass(this.arrowSpan, 'fa-angle-down');
        this.renderer.setStyle(this.arrowSpan, 'margin-left', '-18px');
        this.renderer.setStyle(this.arrowSpan, 'position', 'relative');
        this.renderer.setStyle(this.arrowSpan, 'z-index', '-1');
        this.renderer.appendChild(this.containerSpan, this.arrowSpan);

        this.renderer.listen(this.arrowSpan,'click',function(){
            nat.click();
        });
        

    }

}
