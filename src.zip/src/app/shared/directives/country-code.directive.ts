import { Directive, ElementRef, HostListener } from '@angular/core';

@Directive({
  selector: '[countryCodeOnly]'
})
export class CountryCodeDirective {

  constructor(private el: ElementRef) {
  }

  @HostListener('keypress', ['$event'])
  onKeyPress(event: KeyboardEvent) {
    if (this.el.nativeElement.value == '' && event.which != 43) {
      return false;
    }
    else if (event.which == 43 && this.el.nativeElement.value.length == 0) {
      return true;
    }
    
    if (event.which != 8 && event.which != 0 && (event.which < 48 || event.which > 57)) {
      return false;
    }
  }

  @HostListener('keydown', ['$event'])
  onKeyDown(event: KeyboardEvent) {
    if ((event.keyCode == 8 || event.keyCode == 46) && this.el.nativeElement.value == '+') {
      event.preventDefault();
    }
  }

  @HostListener('paste', ['$event']) onPaste(e: KeyboardEvent) {
    var value = event['clipboardData'].getData('text/plain');
    if (value.substring(0,1) != '+') {
      event.preventDefault();
      return;
    }
    if (isNaN(value.substring(1))) {
      event.preventDefault();
    }
  }

  @HostListener('cut', ['$event']) blockCut(e: KeyboardEvent) {
    if (this.el.nativeElement.value == '+') {
      event.preventDefault();
    }
  }
}




