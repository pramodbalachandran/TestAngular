import { Directive, ElementRef, HostListener, Input } from '@angular/core';

@Directive({
  selector: '[restrictRepeatedChars]'
})
export class RestrictRepeatedCharsDirective {

  @Input('restrictRepeatedChars')
  dontRepeat: string;

  constructor(private el: ElementRef) {
  }

  @HostListener('focusout', ['$event'])
  onFocusOut(event: Event) {
    let current = this.el.nativeElement.value;
    const regEx = new RegExp( '(\\s*' + this.dontRepeat  + '\\s*)+' , 'g');
    this.el.nativeElement.value = current = current.replace(regEx, this.dontRepeat);
  }

  @HostListener('keypress', ['$event'])
  onKeyDown(event: KeyboardEvent) {
    const charCode = this.dontRepeat.charCodeAt(0);
    if (event.which === charCode) {
      const val: string = this.el.nativeElement.value;
      const selStart = (this.el.nativeElement.selectionStart !== undefined ?
        this.el.nativeElement.selectionStart : val.length);

      if (selStart) {
        let toPrev = val.substring(0, selStart - 1);
        let fromNext = val.substring(selStart, val.length - 1);
        toPrev = toPrev.trimRight();
        fromNext = fromNext.trimLeft();
        if ( toPrev.charAt(toPrev.length - 1) === this.dontRepeat ||
            fromNext.charAt(0) === this.dontRepeat) {
          return false;
        }
      }
      return true;
    }
  }

  @HostListener('paste', ['$event']) onPaste(e: KeyboardEvent) {
    setTimeout(() => {
      let current = this.el.nativeElement.value;
      const regEx = new RegExp( '(\\s*' + this.dontRepeat  + '\\s*)+' , 'g');
      this.el.nativeElement.value = current = current.replace(regEx, this.dontRepeat);
    });
  }
}




