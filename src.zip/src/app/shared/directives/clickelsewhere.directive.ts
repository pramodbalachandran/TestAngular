import { Directive, EventEmitter, ElementRef, HostListener, Output, Input } from '@angular/core';

@Directive({ selector: '[clickElsewhere]' })
export class ClickElsewhereDirective {
  @Output() clickElsewhere = new EventEmitter<MouseEvent>();
  @Input() checkEntireDom?: boolean = false;

  constructor(private elementRef: ElementRef) {}

  @HostListener('document:click', ['$event'])
  public onDocumentClick(event: MouseEvent): void {
    const targetElement = event.target as HTMLElement;

      // Check if the click was outside the element
     // (document.contains(targetElement)
      if (targetElement && !this.elementRef.nativeElement.contains(targetElement)
        && (!this.checkEntireDom || document.body.contains(targetElement))
        ) {

         this.clickElsewhere.emit(event);
      }
  }
}
