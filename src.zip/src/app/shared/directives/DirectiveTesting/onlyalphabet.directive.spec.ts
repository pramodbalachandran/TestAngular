import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Component, DebugElement, NO_ERRORS_SCHEMA } from '@angular/core';
import { By } from '@angular/platform-browser';

import { Onlyalphabet } from '@app/directives/onlyalphabet.directive';

//dummy component
@Component({
  template: `<input [Onlyalphabet]="true" type="text" name="sampleName"  />`
})
// tslint:disable-next-line:no-unnecessary-class
class TestAllowOnlyAlphabetComponent {
    allowNumbers = true;
}
describe('Directive: Onlyalphabet', () => {
  let component: TestAllowOnlyAlphabetComponent;
  let fixture: ComponentFixture<TestAllowOnlyAlphabetComponent>;
  let inputEl: DebugElement;


  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TestAllowOnlyAlphabetComponent, Onlyalphabet],
      schemas: [NO_ERRORS_SCHEMA]
    });
    fixture = TestBed.createComponent(TestAllowOnlyAlphabetComponent);
    component = fixture.componentInstance;
    inputEl = fixture.debugElement.query(By.css('input[name="sampleName"]'));
   
  });

  //it('keydown input', () => {
  //  const event = new KeyboardEvent('keydown', { "code": '97' });
  //  inputEl.nativeElement.dispatchEvent(event);
  //  fixture.detectChanges();
    
  //  expect(event.defaultPrevented).toBe(true);
  //});
  //it('Allowing only alphabel,not numeric', () => {

  //  inputEl.nativeElement.value = "1";
  //  const event = new Event('keydown');
  //  inputEl.nativeElement.dispatchEvent(event);
  //  expect(event.defaultPrevented).toBe(true);

  //});

  //it('Allowing only alphabel,not special character', () => {

  //  // This sets the value (I can even put "abc" here and it will work.
  //  inputEl.nativeElement.value = "validuser";

  //  // initialize the keypress event, so the special character is tested in a real world way when the user is using.
  //  inputEl.nativeElement.dispatchEvent(new KeyboardEvent("keypress", { key: "@$%" })); // Nothing happens here!  This was my attempt...

  //  // test
  //  expect(inputEl.nativeElement.value).toBe("validuser");
  //});

  //it('Allowing only alphabel,not white space', () => {

  //  // This sets the value (I can even put "abc" here and it will work.
  //  //spyOn(event, 'preventDefault');

  //  // initialize the keypress event, so the special character is tested in a real world way when the user is using.

  //  //const event = new KeyboardEvent("keydown", { "key": "Enter" });
  //  inputEl.triggerEventHandler({ type: "keydown", s });

  //  spyOn(event, 'preventDefault');
  //  inputEl.nativeElement.dispatchEvent(event); // Nothing happens here!  This was my attempt...

  //  // test
  //  expect(event.preventDefault).toHaveBeenCalled();
  //});

  ////it('Allowing only alphabel,not comma', () => {
  ////  fixture.detectChanges();
  //  //// This sets the value (I can even put "abc" here and it will work.
  //  //inputEl.nativeElement.value = "validuser";

  //  //// initialize the keypress event, so the special character is tested in a real world way when the user is using.
  //  inputEl.nativeElement.dispatchEvent(new KeyboardEvent("keydown", { code: "13" })); // Nothing happens here!  This was my attempt...

  //  //// test
  //  //expect(inputEl.nativeElement.value).toBe("validusers");
  //  //  const event = {
  //  //  target: {
  //  //    value: 1
  //  //  },
  //  //  preventDefault: function () {

  //  //  }
  //  //};
   

  //  //const event = new KeyboardEvent("keydown", { key: 1 });
  //  ////spyOn(event, 'preventDefault');

  //  ////event.keyCode=
  //  //inputEl.triggerEventHandler('keydown', event);
    
  //  //expect(event.defaultPrevented).toBe(true);

  ////});


  ////it('should do something', () => {



  ////  const event = {
  ////    target: {
  ////      value: 1
  ////    },
  ////    preventDefault: function () {

  ////    }
  ////  };

  ////  spyOn(event, 'preventDefault');
  ////  const event = new KeyboardEvent('keydown', { key: 'F' });
  ////  inputEl.triggerEventHandler('keydown', event);
  ////  fixture.detectChanges();
  ////  expect(event.preventDefault).toHaveBeenCalled();
  ////});
});
