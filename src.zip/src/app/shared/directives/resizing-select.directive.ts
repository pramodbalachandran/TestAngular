import { Directive, ElementRef, HostListener, Renderer2, OnInit, OnDestroy, Host } from '@angular/core';
import { NgModel } from '@angular/forms';

@Directive({
    selector: '[resizingSelect][ngModel]',
    providers:[NgModel]
})
export class ResizingSelect implements OnInit, OnDestroy {

    ngOnDestroy() {
        let nat: HTMLSelectElement;
        nat = this.el.nativeElement;
        this.renderer.removeChild(nat.parentElement, this.tmpSelect);
    }
    ngOnInit() {

        this.tmpSelect = this.renderer.createElement(`select`);
        this.tmpOption = this.renderer.createElement('option');
        this.renderer.appendChild(this.tmpSelect, this.tmpOption);
        let nat: HTMLSelectElement;
        nat = this.el.nativeElement;
        this.renderer.setStyle(this.tmpSelect, 'visibility', 'hidden');
        this.renderer.setStyle(this.tmpSelect, 'position', 'absolute');
        this.renderer.setStyle(this.tmpSelect, 'left', '-100');
        this.renderer.setStyle(this.tmpSelect, 'top', '-100');
        this.renderer.appendChild(nat.parentElement, this.tmpSelect);
        this.changeSize();
        this._model.valueChanges.subscribe((event) => {
            this._valueInDirective = event;
            this.changeSize();
          });

    }

    private tmpSelect: HTMLSelectElement;
    private tmpOption: HTMLOptionElement;
    private curText: any;
    private _valueInDirective;

    constructor(private el: ElementRef, private renderer: Renderer2, private _model: NgModel) {
    }

    changeSize() {
        let selOption = this.el.nativeElement.querySelectorAll('option:checked');
        if (selOption.length) {
            if (this.curText) {
                this.renderer.removeChild(this.tmpOption, this.curText);
            }
            this.curText = this.renderer.createText(selOption[0].textContent);
            this.renderer.appendChild(this.tmpOption, this.curText);
            let width = this.tmpSelect.offsetWidth;
            let nat: HTMLSelectElement;
            nat = this.el.nativeElement;
            this.renderer.setStyle(nat, 'width', width + 'px');
        }
    }

    @HostListener('change', ['$event']) onChange(event) {
        this.changeSize();
    }
    @HostListener('ngModelChange',['$event']) onModelChange(event)
    {
        this.changeSize();
    }

}
