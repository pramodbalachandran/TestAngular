import { Directive, ElementRef, HostListener, Input,OnChanges } from '@angular/core';


@Directive({
  selector: '[focus]'
})
class FocusDirective implements OnChanges {
  @Input('focus') focus: boolean = true;

  private el: ElementRef;

  constructor(el: ElementRef) {
    this.el = el;
    console.log(el);
  }

  ngOnChanges() {
    if (this.focus) {
      this.el.nativeElement.focus();
    }
  }

}
