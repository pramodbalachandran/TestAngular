import { Directive, AfterViewInit, ElementRef ,ChangeDetectorRef} from '@angular/core';
@Directive({ selector: '[dynamicFocus]' })
export class DynamicFocusDirective implements AfterViewInit  {
 
  constructor(private el: ElementRef,private cdRef:ChangeDetectorRef) {
  }

  ngAfterViewInit() {
    this.el.nativeElement.focus();
    this.cdRef.detectChanges();
  }

  }