import { QuoteLaneCommodityComponent } from './../internal-portal/quote/quotelanecommodity/quotelanecommodity.component';
import { NgModule, ModuleWithProviders, CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { FormsModule, ReactiveFormsModule, FormGroup } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';
import { DataTableModule } from 'angular-6-datatable';
import { CommonModule } from '@angular/common';
import { ConfigService } from '@app/shared/services/shared/config.service';
import { LocalStorageService, UtilitiesService} from '@app/shared/services';
import { HttpClientModule,HTTP_INTERCEPTORS } from '@angular/common/http';
import { TextMaskModule } from 'angular2-text-mask';
import { AppInterceptor } from '@app/shared/interceptor/app.interceptor';
import { MatFormFieldModule, MatInputModule, MatAutocompleteModule, MatButtonModule, MatProgressSpinnerModule } from '@angular/material';
import { TruncatePipe } from './pipes/limitTo.pipe';
import { Ng4LoadingSpinnerModule } from 'ng4-loading-spinner';
import { ToasterService } from '@app/shared/services/toaster/toaster.module';
import { LoaderComponent } from '@app/shared/components/loader/loader.component';
import { CustomModalComponent } from '@app/shared/components/custom-modal/custom-modal.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { AutocompleteComponent } from '@app/shared/helper/autocomplete.component';
import { NgbdModalComponent, NgbdModalContent } from '@app/shared/components/modalpopup/modalpopup.component';
import { ModalComponent } from '@app/shared/helper/modalpopup.component';
import { LoginRegisterComponent } from '@app/external-portal/login/loginregister/loginregister.component';

/*directives */
import { BlockCopyPasteDirective } from '@app/shared/directives/block-copy-paste.directive';
import { NumberOnlyDirective } from '@app/shared/directives/numbers-only.directive';
import { DecimalNumberOnlyDirective } from '@app/shared/directives/decimal-numbers-only.directive';
import { AlphaNumeric } from '@app/shared/directives/alphaNumeric.directive';
import { CountryCodeDirective } from '@app/shared/directives/country-code.directive';
import { Onlyalphabet } from '@app/shared/directives/onlyalphabet.directive';
import { FileUploadModule } from 'ng2-file-upload';


import { AutopopulateHighlightPipe } from '@app/shared/pipes/highlight.pipe';
import { ClickElsewhereDirective } from '@app/shared/directives/clickelsewhere.directive';
import { OrderModule } from 'ngx-order-pipe';
import { HeaderComponent } from '@app/shared/components/header/header.component';
import { LoginHeaderComponent } from '@app/shared/components/login-header/login-header.component';
import { ResizingSelect } from '@app/shared/directives/resizing-select.directive';
import { DynamicFocusDirective } from '@app/shared/directives/dynamicFocus.directive';
import { FocusRemover } from '@app/shared/directives/removefocus.directive';
import { PopupSelect } from '@app/shared/directives/popup-select.directive';
import { NgSelectModule } from '@ng-select/ng-select';
import { NgDragDropModule } from 'ng-drag-drop';
import { RestrictRepeatedCharsDirective } from '@app/shared/directives/restrictRepeatedChars.directive';

@NgModule({
  imports: [
    FormsModule, CommonModule, RouterModule, ReactiveFormsModule,
    TextMaskModule, HttpClientModule,
    MatInputModule,
    MatAutocompleteModule,
    MatFormFieldModule,
    MatButtonModule,
    MatProgressSpinnerModule,
    DataTableModule,
    NgbModule,
    OrderModule,
    Ng4LoadingSpinnerModule,
    FileUploadModule,
    NgSelectModule,
    NgDragDropModule.forRoot(),
  ],
  declarations: [
    LoaderComponent,
    CustomModalComponent,
    AutopopulateHighlightPipe,
    TruncatePipe,
    HeaderComponent,
    LoginHeaderComponent,
    BlockCopyPasteDirective,
    NumberOnlyDirective,
    DecimalNumberOnlyDirective,
    AlphaNumeric,
    CountryCodeDirective,
    Onlyalphabet,
    AutocompleteComponent,
    NgbdModalComponent,
    NgbdModalContent,
    ModalComponent,
    LoginRegisterComponent,
    ResizingSelect,
    PopupSelect,
    ClickElsewhereDirective,
    DynamicFocusDirective,
    FocusRemover,
    RestrictRepeatedCharsDirective
  ],
  entryComponents: [NgbdModalComponent,NgbdModalContent],
  exports: [
    FormsModule, CommonModule,
    RouterModule, ReactiveFormsModule, TextMaskModule,
    MatInputModule,
    MatAutocompleteModule,
    MatFormFieldModule,
    MatButtonModule,
    MatProgressSpinnerModule,
    Ng4LoadingSpinnerModule,
    LoaderComponent,
    DataTableModule,
    CustomModalComponent,
    NgbModule,
    OrderModule,
    AutopopulateHighlightPipe,
    TruncatePipe,
    HeaderComponent,
    LoginHeaderComponent,
    FileUploadModule,
    BlockCopyPasteDirective,
    NumberOnlyDirective,
    DecimalNumberOnlyDirective,
    AlphaNumeric,
    CountryCodeDirective,
    Onlyalphabet,
    AutocompleteComponent,
    NgbdModalComponent,
    NgbdModalContent,
    ModalComponent,
    LoginRegisterComponent,
    ResizingSelect,
    PopupSelect,
    ClickElsewhereDirective,
    DynamicFocusDirective,
    NgSelectModule,
    FocusRemover,
    NgDragDropModule,
    RestrictRepeatedCharsDirective
  ],
  providers: [
    LocalStorageService, ConfigService, UtilitiesService, ToasterService,
    { provide: HTTP_INTERCEPTORS, useClass: AppInterceptor, multi: true },
  ],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA,
    NO_ERRORS_SCHEMA
  ]
})

export class SharedModule {
  static forRoot(): ModuleWithProviders {
    return {
      ngModule: SharedModule,
    };
  }
}
