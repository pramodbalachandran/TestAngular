import { BrowserModule } from '@angular/platform-browser';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';

import { AppComponent } from './app.component';
import { SharedModule } from './shared/shared.module';
import { AppRoutingModule } from './app-routing.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { QuoteAPI, CustomerAPI, GeaographyAPI } from '@app/shared/services';

@NgModule({
  declarations: [
    AppComponent,
  ],
  imports: [
    BrowserModule, SharedModule.forRoot(), AppRoutingModule, BrowserAnimationsModule, NgbModule.forRoot()  
  ],
  providers: [QuoteAPI, CustomerAPI, GeaographyAPI],
  bootstrap: [AppComponent],
  schemas: [
    CUSTOM_ELEMENTS_SCHEMA,
    NO_ERRORS_SCHEMA
  ]
})
export class AppModule {

  constructor() {

    history.pushState(null, null, location.href);
    window.onpopstate = function () {
      history.go(1);
    };
    window.history.forward();   
  }
}
