import { NgModule } from '@angular/core';
//import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
//import { AppConstants } from './shared/app.constants';
import { ExternalPortalModule } from '@app/external-portal/external-portal.module';
import { InternalPortalModule } from '@app/internal-portal/internal-portal.module';
import { UrlKey } from '@app/shared/services/shared/config.const';
//import { URL } from 'url';

@NgModule({
  imports: [
    RouterModule.forRoot([
      { path: '', redirectTo: UrlKey.InternalPortal , pathMatch: 'full' },
      { path: UrlKey.ExternalPortal, loadChildren: () => ExternalPortalModule },
      { path: UrlKey.InternalPortal, loadChildren: () => InternalPortalModule }
    ])
  ],
  declarations: [],
  exports: [RouterModule]
})
export class AppRoutingModule {  }
