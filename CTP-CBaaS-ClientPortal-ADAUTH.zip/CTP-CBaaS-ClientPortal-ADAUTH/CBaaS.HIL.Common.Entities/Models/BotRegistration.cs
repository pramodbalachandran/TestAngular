﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace CBaaS.HIL.Common.Entities.Models
{
    public partial class BotRegistration
    {
        public int Id { get; set; }
        public long BotConfigId { get; set; }
        [StringLength(200)]
        public string CustomerContact { get; set; }
        public string BotType { get; set; }
        public string ReportSource { get; set; }
        public string ReportConnectionString { get; set; }
        public Guid? ReportId { get; set; }
        public string OfferingType { get; set; }
        public bool IsActive { get; set; }

        public virtual BotConfig BotConfig { get; set; }
    }
}
