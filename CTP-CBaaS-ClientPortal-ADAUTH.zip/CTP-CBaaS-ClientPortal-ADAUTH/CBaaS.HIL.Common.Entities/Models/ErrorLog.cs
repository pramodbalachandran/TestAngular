﻿using System;
using System.Collections.Generic;

namespace CBaaS.HIL.Common.Entities.Models
{
    public partial class ErrorLog
    {
        public long Id { get; set; }
        public string Level { get; set; }
        public string ErrorMessage { get; set; }
        public string StackTrace { get; set; }
        public DateTime CreatedOn { get; set; }
        public string CreatedBy { get; set; }
        public long Botconfigid { get; set; }

        public virtual BotConfig Botconfig { get; set; }
    }
}
