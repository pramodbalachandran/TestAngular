﻿using System;
using System.Collections.Generic;

namespace CBaaS.HIL.Common.Entities.Models
{
    public partial class ActivityLog
    {
        public long Id { get; set; }
        public long RefId { get; set; }
        public string Module { get; set; }
        public string Action { get; set; }
        public string Value { get; set; }
        public string PerformedBy { get; set; }
        public DateTime PerformedOn { get; set; }
    }
}
