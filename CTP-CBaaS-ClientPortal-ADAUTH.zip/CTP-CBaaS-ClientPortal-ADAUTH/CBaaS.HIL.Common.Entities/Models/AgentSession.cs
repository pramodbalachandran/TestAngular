﻿using System;
using System.Collections.Generic;

namespace CBaaS.HIL.Common.Entities.Models
{
    public partial class AgentSession
    {
        public AgentSession()
        {
            AgentBotUserMapping = new HashSet<AgentBotUserMapping>();
        }

        public long Id { get; set; }
        public int UserId { get; set; }
        public string ConnectionId { get; set; }
        public string Status { get; set; }
        public DateTime StartTime { get; set; }
        public DateTime? EndTime { get; set; }
        public string Remarks { get; set; }

        public virtual Users User { get; set; }
        public virtual ICollection<AgentBotUserMapping> AgentBotUserMapping { get; set; }
    }
}
