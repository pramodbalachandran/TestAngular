﻿using System;
using System.Collections.Generic;

namespace CBaaS.HIL.Common.Entities.Models
{
    public partial class ChatLogs
    {
        public int LogId { get; set; }
        public string ConversationId { get; set; }
        public string ActivityId { get; set; }
        public string Username { get; set; }
        public string Email { get; set; }
        public string Question { get; set; }
        public string Answers { get; set; }
        public string Feedback { get; set; }
        public string FeedbackComment { get; set; }
        public DateTime? FeedbackDate { get; set; }
        public DateTime? Date { get; set; }
        public bool? IsHil { get; set; }
        public bool? IsFallback { get; set; }
        public string AgentEmail { get; set; }
    }
}
