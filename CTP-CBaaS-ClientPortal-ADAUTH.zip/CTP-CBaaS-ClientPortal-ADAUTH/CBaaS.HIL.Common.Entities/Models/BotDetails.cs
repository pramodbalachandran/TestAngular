﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBaaS.HIL.Common.Entities.Models
{
    public class BotDetails
    {
        public Guid? ReportId { get; set; }
        public long BotConfigId { get; set; }
        public Guid BotId { get; set; }
        public string DisplayName { get; set; }
        public string ServiceLine { get; set; }
        public int BotRegistrationId { get; set; }
        public string CustomerContact { get; set; }
        public string BotType { get; set; }
        public string ReportSource { get; set; }
        public string ReportConnectionString { get; set; }
        public string OfferingType { get; set; }
    }
}
