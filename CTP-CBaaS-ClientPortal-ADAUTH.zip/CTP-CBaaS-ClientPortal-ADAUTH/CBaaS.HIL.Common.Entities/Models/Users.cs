﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace CBaaS.HIL.Common.Entities.Models
{
    public partial class Users
    {
        public Users()
        {
            AgentSession = new HashSet<AgentSession>();
            UserBotRoles = new HashSet<UserBotRoles>();
        }

        public int Id { get; set; }
        [StringLength(50)]
        public string UserName { get; set; }
        [StringLength(50)]
        public string FirstName { get; set; }
        [StringLength(50)]
        public string LastName { get; set; }
        [StringLength(50)]
        public string NickName { get; set; }
        public bool IsActive { get; set; }
        [StringLength(50)]
        public string Company { get; set; }
        public bool IsExternal { get; set; }

        public virtual ICollection<AgentSession> AgentSession { get; set; }
        public virtual ICollection<UserBotRoles> UserBotRoles { get; set; }
    }
}
