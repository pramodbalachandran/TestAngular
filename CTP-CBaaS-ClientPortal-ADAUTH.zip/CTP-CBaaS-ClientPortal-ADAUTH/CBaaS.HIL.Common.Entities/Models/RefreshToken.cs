﻿using System;
using System.Collections.Generic;

namespace CBaaS.HIL.Common.Entities.Models
{
    public partial class RefreshToken
    {
        public long Id { get; set; }
        public string Token { get; set; }
        public string Username { get; set; }
        public string Refreshtoken1 { get; set; }
        public bool Revoked { get; set; }
        public DateTime Expiry { get; set; }
    }
}
