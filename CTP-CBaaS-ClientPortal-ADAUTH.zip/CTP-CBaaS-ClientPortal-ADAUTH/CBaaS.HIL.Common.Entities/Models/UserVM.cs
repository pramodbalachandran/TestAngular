﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBaaS.HIL.Common.Entities.Models
{
    public class UserVM
    {
        public string UserId { get; set; }
        public string Fullname { get; set; }
        public string EmailAddress { get; set; }
        public bool isExternal { get; set; }
        public bool isActive { get; set; }
    }
}
