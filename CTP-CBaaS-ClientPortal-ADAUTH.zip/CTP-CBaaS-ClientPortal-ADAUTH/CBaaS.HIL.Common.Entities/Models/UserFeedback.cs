﻿using System;
using System.Collections.Generic;

namespace CBaaS.HIL.Common.Entities.Models
{
    public partial class UserFeedback
    {
        public long Id { get; set; }
        public string BotName { get; set; }
        public string UserName { get; set; }
        public string UserEmail { get; set; }
        public string Emotion { get; set; }
        public string Comments { get; set; }
        public string Question { get; set; }
        public string Answer { get; set; }
        public string Luisscore { get; set; }
        public string Luisintent { get; set; }
        public string QnaScore { get; set; }
        public string ChannelType { get; set; }
        public DateTime CreatedDate { get; set; }
        public string Status { get; set; }
        public DateTime? ModifiedDate { get; set; }
        public string ModifiedBy { get; set; }
        public long Botconfigid { get; set; }

        public virtual BotConfig Botconfig { get; set; }
    }
}
