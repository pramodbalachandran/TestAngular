﻿using System;
using System.Collections.Generic;

namespace CBaaS.HIL.Common.Entities.Models
{
    public partial class UserBotRoles
    {
        public int Id { get; set; }
        public int UserId { get; set; }
        public int RoleId { get; set; }
        public long BotConfigId { get; set; }
        public DateTime FromDate { get; set; }
        public DateTime? ToDate { get; set; }

        public virtual BotConfig BotConfig { get; set; }
        public virtual Roles Role { get; set; }
        public virtual Users User { get; set; }
    }
}
