﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBaaS.HIL.Common.Entities.Models
{
    public class UserRolesDetails
    {
        public long BotConfigId { get; set; }
        public string Username { get; set; }
        public string Role { get; set; }
        public string Firstname { get; set; }
        public string Lastname { get; set; }
        public int UserId { get; set; }
        public int RoleId { get; set; }
        public DateTime FromDate { get; set; }
        public DateTime? ToDate { get; set; }
        public bool IsExternal { get; set; }
        
    }
}
