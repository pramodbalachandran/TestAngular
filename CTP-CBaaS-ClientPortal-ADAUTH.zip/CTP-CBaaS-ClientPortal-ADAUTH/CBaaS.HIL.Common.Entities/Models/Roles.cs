﻿using System;
using System.Collections.Generic;

namespace CBaaS.HIL.Common.Entities.Models
{
    public partial class Roles
    {
        public Roles()
        {
            UserBotRoles = new HashSet<UserBotRoles>();
        }

        public int Id { get; set; }
        public string Role { get; set; }
        public string DisplayName { get; set; }

        public virtual ICollection<UserBotRoles> UserBotRoles { get; set; }
    }
}
