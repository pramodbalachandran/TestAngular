﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBaaS.HIL.Common.Entities.Models
{
    public class UserRolesVM
    {
        public int userId;
        public string emailId;
        public List<string> roles;
    }
}
