﻿using System;
using System.Collections.Generic;

namespace CBaaS.HIL.Common.Entities.Models
{
    public partial class FeatureMaster
    {
        public FeatureMaster()
        {
            BotMaster = new HashSet<BotMaster>();
        }

        public int Id { get; set; }
        public string Feature { get; set; }
        public bool Status { get; set; }

        public virtual ICollection<BotMaster> BotMaster { get; set; }
    }
}
