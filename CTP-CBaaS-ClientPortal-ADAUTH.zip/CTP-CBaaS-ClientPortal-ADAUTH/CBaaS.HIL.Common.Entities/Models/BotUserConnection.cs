﻿using System;
using System.Collections.Generic;

namespace CBaaS.HIL.Common.Entities.Models
{
    public partial class BotUserConnection
    {
        public BotUserConnection()
        {
            AgentBotUserMapping = new HashSet<AgentBotUserMapping>();
        }
        public long Id { get; set; }
        public long BotConfigId { get; set; }
        public string BotUserId { get; set; }
        public string BotUserName { get; set; }
        public string ConnectionId { get; set; }
        public string ConversationId { get; set; }

        public virtual BotConfig BotConfig { get; set; }
        public virtual ICollection<AgentBotUserMapping> AgentBotUserMapping { get; set; }
    }
}
