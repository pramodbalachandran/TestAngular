﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace CBaaS.HIL.Common.Entities.Models
{
    public partial class AgentBotUserMapping
    {
        [Key]
        public Guid ChatId { get; set; }
        public long AgentSessionId { get; set; }
        public long BotUserConnectionId { get; set; }
        public DateTime StartTime { get; set; }
        public DateTime? EndTime { get; set; }

        public virtual AgentSession AgentSession { get; set; }
        public virtual BotUserConnection BotUserConnection { get; set; }
    }
}
