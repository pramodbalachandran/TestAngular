﻿using System;
using System.Collections.Generic;

namespace CBaaS.HIL.Common.Entities.Models
{
    public partial class AuthenticationConfig
    {
        public long Id { get; set; }
        public Guid BotId { get; set; }
        public string Scope { get; set; }
        public string Hint { get; set; }
        public long Botconfigid { get; set; }

        public virtual BotConfig Botconfig { get; set; }
    }
}
