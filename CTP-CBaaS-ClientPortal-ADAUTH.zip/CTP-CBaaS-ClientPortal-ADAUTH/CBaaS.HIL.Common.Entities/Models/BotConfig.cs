﻿using System;
using System.Collections.Generic;

namespace CBaaS.HIL.Common.Entities.Models
{
    public partial class BotConfig
    {
        public BotConfig()
        {
            AuthenticationConfig = new HashSet<AuthenticationConfig>();
            BotMaster = new HashSet<BotMaster>();
            BotRegistration = new HashSet<BotRegistration>();
            BotUserConnection = new HashSet<BotUserConnection>();
            ErrorLog = new HashSet<ErrorLog>();
            UserBotRoles = new HashSet<UserBotRoles>();
            UserFeedback = new HashSet<UserFeedback>();
        }

        public long Id { get; set; }
        public string BotHandle { get; set; }
        public string Secret { get; set; }
        public string AppId { get; set; }
        public string Status { get; set; }
        public string ServiceLine { get; set; }
        public string DisplayName { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? ModifiedDate { get; set; }
        public string ModifiedBy { get; set; }
        public string LogDbstring { get; set; }
        public Guid BotId { get; set; }
        public string BotLogoImage { get; set; }
        public string BotTheme { get; set; }
        public string AuthType { get; set; }
        public bool? IsFaqBot { get; set; }

        public virtual ICollection<AuthenticationConfig> AuthenticationConfig { get; set; }
        public virtual ICollection<BotMaster> BotMaster { get; set; }
        public virtual ICollection<BotRegistration> BotRegistration { get; set; }
        public virtual ICollection<BotUserConnection> BotUserConnection { get; set; }
        public virtual ICollection<ErrorLog> ErrorLog { get; set; }
        public virtual ICollection<UserBotRoles> UserBotRoles { get; set; }
        public virtual ICollection<UserFeedback> UserFeedback { get; set; }
    }
}
