﻿using System;
using System.Collections.Generic;

namespace CBaaS.HIL.Common.Entities.Models
{
    public partial class BotMaster
    {
        public int Id { get; set; }
        public int FeatureId { get; set; }
        public bool IsEnabled { get; set; }
        public long BotConfigId { get; set; }
        public string AccessKey { get; set; }
        public string Location { get; set; }
        public string EndPoint { get; set; }
        public string RegionUri { get; set; }
        public string StorageAcctName { get; set; }
        public string StorageAcctKey { get; set; }

        public virtual BotConfig BotConfig { get; set; }
        public virtual FeatureMaster Feature { get; set; }
    }
}
