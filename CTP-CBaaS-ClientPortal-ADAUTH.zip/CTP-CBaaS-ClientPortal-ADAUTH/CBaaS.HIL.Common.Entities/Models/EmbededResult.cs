﻿using Microsoft.PowerBI.Api.V2.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace CBaaS.HIL.Common.Entities.Models
{
    public class EmbededResult
    {
        public string Type { get; set; }
        public string AccessToken { get; set; }
        //public string id { get; set; }
        public string Name { get; set; }
        public string WebUrl { get; set; }
        //public string embedUrl { get; set; }

        public string Id { get; set; }

        public string EmbedUrl { get; set; }

        public EmbedToken EmbedToken { get; set; }

        public int MinutesToExpiration
        {
            get
            {
                var minutesToExpiration = EmbedToken != null ? EmbedToken.Expiration.Value - DateTime.UtcNow : DateTime.UtcNow - DateTime.UtcNow;
                return (int)minutesToExpiration.TotalMinutes;
            }
        }

        public bool? IsEffectiveIdentityRolesRequired { get; set; }

        public bool? IsEffectiveIdentityRequired { get; set; }

        public bool EnableRLS { get; set; }

        public string Username { get; set; }

        public string Roles { get; set; }

        public string ErrorMessage { get; set; }

        public bool IsSpnPowerBi { get; set; }
    }
}
