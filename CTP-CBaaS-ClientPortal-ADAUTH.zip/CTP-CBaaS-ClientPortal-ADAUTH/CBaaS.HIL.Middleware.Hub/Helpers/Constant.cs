﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CBaaS.HIL.Middleware.Hub.Helpers
{
    public static class CommonConstant1
    {
       

    }
}
