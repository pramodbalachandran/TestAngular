﻿using CBaaS.HIL.Middleware.Business.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CBaaS.HIL.Middleware.Hub.Logging
{
    public class ChatlogHelper
    {
        /// <summary>
        /// Add log in ATS or DB as per configuration
        /// </summary>
        /// <param name="context">The Request Context</param>
        /// <param name="answer">The Request Answer</param>
        /// <returns>The Bool Result</returns>
        public async Task AddChatLog(ChatLogModel chatLogModel)
        {
            //try
            //{
            //    //EY.ChatLogger.ICBaaSChatLogger chatLogger = new CBaaSChatLogger(Configuration, MemoryCache);

            //    //IAzureTableStorageManager azureTableManager = await storage.GetTableManager(tableName);
            //    ChatlogATSService obj = new ChatlogATSService();
            //           await obj.AddChatLog(chatLogModel);
            //    }
            //}
            //catch (Exception ex)
            //{
            //    _logger.Error(ex, $"AddLogChat : {ex.Message}");
            //}
        }
    }
}
