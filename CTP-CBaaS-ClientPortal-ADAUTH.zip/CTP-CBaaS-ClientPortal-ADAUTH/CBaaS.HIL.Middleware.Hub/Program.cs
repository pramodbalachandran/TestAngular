using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using NLog;
using NLog.Targets;

namespace CBaaS.HIL.Middleware.Hub
{
    public class Program
    {
        public static void Main(string[] args)
        {
            CreateHostBuilder(args).Build().Run();
        }

        public static IHostBuilder CreateHostBuilder(string[] args) =>
            Host.CreateDefaultBuilder(args)
                .ConfigureWebHostDefaults(webBuilder =>
                {
                    webBuilder.UseStartup<Startup>().ConfigureAppConfiguration(InitConfiguration);
                });

        private static void InitConfiguration(WebHostBuilderContext webHostBuilderContext, IConfigurationBuilder configurationBuilder)
        {

            IConfiguration configuration = configurationBuilder.Build();

            var dbStorageTarget = (DatabaseTarget)LogManager.Configuration.FindTargetByName("database");
            if (dbStorageTarget != null)
            {
                dbStorageTarget.ConnectionString = configuration.GetConnectionString("BotEntities");
                LogManager.ReconfigExistingLoggers();
            }

            if (configuration["SecretUri"] == null || configuration["VaultClientId"] == null || configuration["ClientSecret"] == null)
            {
                throw new Exception("Please configure Key vault settings.");
            }
            configurationBuilder.AddAzureKeyVault(configuration["SecretUri"], configuration["VaultClientId"], configuration["ClientSecret"]);
        }
    }
}
