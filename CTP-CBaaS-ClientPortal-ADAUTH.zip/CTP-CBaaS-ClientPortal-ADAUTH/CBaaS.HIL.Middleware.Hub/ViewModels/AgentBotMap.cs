﻿using System;

namespace CBaaS.HIL.Common.API.Model
{
    public class AgentBotMap
    {
        public Guid ChatId { get; set; }
        public string ConverstionId { get; set; }
        public SupportAgent ConnectedAgent { set; get; }
        public BotUser ConnectedBot { set; get; }
        public DateTime StartTime { get; set; }
        public DateTime EndTime { get; set; }

    }
}
