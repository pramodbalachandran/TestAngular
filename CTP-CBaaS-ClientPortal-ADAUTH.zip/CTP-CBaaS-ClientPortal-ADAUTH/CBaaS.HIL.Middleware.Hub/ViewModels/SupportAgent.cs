﻿namespace CBaaS.HIL.Common.API.Model
{
    public class SupportAgent
    {
        public string AgentName { set; get; }
        public int AgentID { set; get; }
        public bool Available { set; get; }
        public string ConnectionID { set; get; }
    }
}
