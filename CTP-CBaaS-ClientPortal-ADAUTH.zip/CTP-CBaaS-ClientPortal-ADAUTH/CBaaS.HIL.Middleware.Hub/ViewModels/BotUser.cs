﻿namespace CBaaS.HIL.Common.API.Model
{
    public class BotUser
    {
        public string BotID { set; get; }
        public string BotUserName { set; get; }
        public string BotUserID { set; get; }
        public string ConnectionID { set; get; }

    }
}
