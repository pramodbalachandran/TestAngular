using ICommon = CBaaS.HIL.ClientPortal.Business.Interfaces;
using CBaaS.HIL.Common.CoreComponents.Repositories;
using CBaaS.HIL.Common.Data;
using CBaaS.HIL.Middleware.Business.Interfaces;
using CBaaS.HIL.Middleware.Business.Services;
using CBaaS.HIL.Middleware.Hub.Logging;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.IdentityModel.Protocols.OpenIdConnect;
using Microsoft.IdentityModel.Tokens;
using NotificationHub;
using System;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CommonService = CBaaS.HIL.ClientPortal.Business.Services;
using CBaaS.HIL.Common.Helper;

namespace CBaaS.HIL.Middleware.Hub
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            this.configuration = configuration;
        }

        public IConfiguration configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            var clientURLs = configuration.GetValue<string>("ClientURL").Split(",").ToList();
            services.AddDbContext<BaseContext>(options =>
            options.UseSqlServer(configuration.GetConnectionString("BotEntities")));

            services.AddCors(options => options.AddPolicy("CorsPolicy",
            builder =>
            {
                builder.AllowAnyMethod().AllowAnyHeader()
                       .WithExposedHeaders("Token-Expired")
                       .WithOrigins(clientURLs.ToArray())
                       .AllowCredentials();
            }));
          
            services.AddScoped(typeof(ICoreRepository<>), typeof(CoreRepository<>));
            //Dependecy Injection Repo
            services.AddScoped<IBotUserConnectionService, BotUserConnectionService>();
            services.AddScoped<IBotConfigService, BotConfigService>();
            services.AddScoped<IAgentUserConnectionService, AgentUserConnectionService>();
            services.AddScoped<IChatService, ChatService>();
            services.AddScoped<ICustomService, CustomService>();
            services.AddScoped<IUserService, UserService>();
            services.AddScoped<IRefreshTokenService, RefreshTokenService>();

            services.AddScoped<DbContext, BaseContext>();
            JWTTokenConfiguration tokenConfiguration = new JWTTokenConfiguration(this.configuration);
            services.AddSingleton(tokenConfiguration);

            var memoryCache = new MemoryCache(new MemoryCacheOptions());


            //services.AddTransient<IChatlogATSService>(s => new ChatlogATSService());
            services.AddScoped<IChatlogATSService, ChatlogATSService>();
            services.AddScoped<IChatlogSQLService, ChatlogSQLService>();
            services.AddScoped<ICommon.IBotConfigService, CommonService.BotConfigService>();
            services.AddScoped<ICommon.IBotRegistrationService, CommonService.BotRegistrationService>();
            //services.AddScoped<ICommon.ICacheService, CommonService.CacheService>();
            services.AddTransient<ICommon.ICacheService>(s => new CommonService.CacheService(memoryCache));
            services.AddScoped<IChatlogService, ChatlogService>();
            services.AddScoped<ICommon.IUserService, CommonService.UserService>();

            var keyByteArray = Encoding.ASCII.GetBytes(tokenConfiguration.Key);
            var signingKey = new SymmetricSecurityKey(keyByteArray);
            var tokenValidationParameters = new TokenValidationParameters
            {
                ValidateIssuerSigningKey = true,
                IssuerSigningKey = signingKey,

                ValidateIssuer = false,
                ValidIssuer = tokenConfiguration.Issuer,

                ValidateAudience = false,
                ValidAudience = tokenConfiguration.Audience,

                ValidateLifetime = true,

                ClockSkew = TimeSpan.Zero,

                NameClaimType = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/name",

            };



            services.AddAuthentication(options =>
            {
                options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
                options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
            }).AddJwtBearer(options =>
            {
                options.TokenValidationParameters = tokenValidationParameters;
                options.Configuration = new OpenIdConnectConfiguration { TokenEndpoint = tokenConfiguration.Path };
                options.Events = new JwtBearerEvents
                {
                    OnMessageReceived = context =>
                    {
                        var accessToken = context.Request.Query["access_Token"];

                        if (!string.IsNullOrEmpty(accessToken))
                        {
                            context.Token = accessToken;
                        }
                        return Task.CompletedTask;
                    },
                    OnAuthenticationFailed = context =>
                    {
                        if (context.Exception.GetType() == typeof(SecurityTokenExpiredException))
                        {
                            context.Response.Headers.Add("Token-Expired", "true");
                        }
                        return Task.CompletedTask;
                    }
                };
            });

            //services.AddSignalR(hubOptions =>
            //{
            //    //hubOptions.EnableDetailedErrors = true;
            //    hubOptions.ClientTimeoutInterval = TimeSpan.FromSeconds(120);
            //    hubOptions.KeepAliveInterval = TimeSpan.FromSeconds(60);                
            //});

            services.AddSignalR();
            services.AddControllers();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            app.UseHttpsRedirection();
            app.UseRouting();
            app.UseAuthentication();
            app.UseAuthorization();
            app.UseCors("CorsPolicy");
            
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
                endpoints.MapHub<ChatHub>("/chathub");
            });
        }
    }
}
