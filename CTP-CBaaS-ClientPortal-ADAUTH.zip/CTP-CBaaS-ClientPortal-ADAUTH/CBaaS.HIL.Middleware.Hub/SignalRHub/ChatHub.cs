﻿using CBaaS.HIL.ClientPortal.Web.Logging;
using CBaaS.HIL.Common.Entities.Models;
using CBaaS.HIL.Middleware.Business.Interfaces;
using CBaaS.HIL.Middleware.Business.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.SignalR;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace NotificationHub
{
    public class ChatHub : Hub
    {
        private readonly IBotUserConnectionService _botUserConnectionService;
        private readonly IBotConfigService _botConfigService;
        private readonly IAgentUserConnectionService _agentUserConnectionService;
        private readonly IChatService _chatService;
        private readonly IChatlogService _chatLogService;
        private readonly ICustomService _customService;
        private readonly IUserService _userService;
        private const string agentNotfound = "ERR_AGENT_NOT_FOUND";
        private const string duplicateHil = "ERR_DUPLICATE_HIL";
        private const string invalidBotId = "ERR_INVALID_BOTID";

        public ChatHub(IBotUserConnectionService botUserConnectionService,
            IBotConfigService botConfigService,
            IAgentUserConnectionService agentUserConnectionService,
            IChatService chatService,
            ICustomService customService,
            IUserService userService,
            IChatlogService chatLogService)
        {
            _botUserConnectionService = botUserConnectionService;
            _botConfigService = botConfigService;
            _agentUserConnectionService = agentUserConnectionService;
            _chatService = chatService;
            _customService = customService;
            _userService = userService;
            _chatLogService = chatLogService;
        }

        /// <summary>
        /// Connect Bot User to the Hub
        /// </summary>
        /// <param name="botName"></param>
        /// <param name="botUserID"></param>
        [Authorize]
        public async Task BotUserConnect(HilRequest hilRequest)
        {
            try
            {
                string errorMessage = string.Empty;
                Logger.username = hilRequest.BotUserId;                
                BotConfig currentBot = await _botConfigService.GetBotConfigByBotId(hilRequest.BotId);
                if (currentBot != null)
                {
                    _chatService.UpdateClosedAgentBotUserMappingByUserId(hilRequest.BotUserId, currentBot.Id);
                    AgentBotUserMapping duplicateHilConnections = _chatService.GetActiveAgentBotUserMappingByUserId(hilRequest.BotUserId, currentBot.Id);
                    if (duplicateHilConnections != null)//If Alredy user connected 
                    {
                        Logger.LogError(ErrorCode.ResponseCode.E105, "Duplicate HIL request");
                        await Clients.Caller.SendAsync("OnHilError", duplicateHil);
                    }
                    else
                    {
                        Logger.botid = currentBot.Id;
                        BotUserConnection currentBotUser = new BotUserConnection
                        {
                            BotConfigId = currentBot.Id,
                            BotUserName = hilRequest.BotUserName,
                            BotUserId = hilRequest.BotUserId,
                            ConnectionId = Context.ConnectionId,
                            ConversationId = hilRequest.ConversationId
                        };
                        await _botUserConnectionService.AddBotUserConnection(currentBotUser);
                        // await chatService.CloseObsoleteMappings(currentBotUser.BotUserId);
                        AgentSession agentSession = _customService.GetConnectedAgent(currentBotUser.BotConfigId);
                        //AgentSession agentSession = _agentUserConnectionService.GetAgentAbhishri();
                        if (agentSession != null)
                        {

                            Guid chatId = await _chatService.BeginChat(agentSession, currentBotUser);
                            if (chatId != Guid.Empty)
                            {
                                await Clients.Caller.SendAsync("onBotConnected", agentSession.User.NickName, chatId.ToString());
                                await Clients.Client(agentSession.ConnectionId).SendAsync("OnHilRequest", currentBotUser.BotUserName, chatId.ToString(), hilRequest.BotName, hilRequest.HandOffComment, hilRequest.ChatHistory, hilRequest.BotUserId);
                                await _chatLogService.AddUserConnectChatLog(agentSession, hilRequest, errorMessage);
                            }
                            else
                            {
                                errorMessage = "Agent Not Found";
                                Logger.LogError(ErrorCode.ResponseCode.E105, errorMessage);
                                await Clients.Caller.SendAsync("OnHilError", agentNotfound);
                                await _chatLogService.AddUserConnectChatLog(agentSession, hilRequest, errorMessage);
                            }
                        }
                        else
                        {
                            errorMessage = "Agent Not Found";
                            Logger.LogError(ErrorCode.ResponseCode.E105, errorMessage);
                            await Clients.Caller.SendAsync("OnHilError", agentNotfound);
                            await _chatLogService.AddUserConnectChatLog(agentSession, hilRequest, errorMessage);
                        }
                    }
                }
                else
                {
                    Logger.LogError(ErrorCode.ResponseCode.E105, "Invalid BotID");
                    await Clients.Caller.SendAsync("OnHilError", invalidBotId);
                }
            }
            catch (Exception ex)
            {
                Logger.LogError(ErrorCode.ResponseCode.E103, ExceptionHandler.BuildStackTrace(ex));
            }
        }

        /// <summary>
        /// Connect HIL Agent to the hub
        /// </summary>
        /// <param name="agentName"></param>
        /// <param name="userID"></param>
        /// <returns></returns>
        [Authorize]
        public async Task AgentConnect(string agentLoginId)
        {
            try
            {
                Logger.username = agentLoginId;
                Users agentUser = await _userService.GetAgentByUserId(agentLoginId.Trim());
                if (agentUser != null)
                {
                    await _agentUserConnectionService.AddAgentUserToSession(new AgentSession
                    {
                        UserId = agentUser.Id,
                        ConnectionId = Context.ConnectionId,
                        Status = "Active",
                        StartTime = DateTime.Now,
                    });
                    await Clients.Caller.SendAsync("onAgentConnected", agentUser.NickName);
                }
            }
            catch (Exception ex)
            {
                Logger.LogError(ErrorCode.ResponseCode.E103, ExceptionHandler.BuildStackTrace(ex));
            }
        }
        /// <summary>
        /// AgentReconnect
        /// </summary>
        /// <param name="agentLoginId"></param>
        /// <returns></returns>
        [Authorize]
        public async Task AgentReconnect(string agentLoginId)
        {
            try
            {
                Logger.username = agentLoginId;                       
                AgentSession agentSession = _agentUserConnectionService.GetAgentSessionByAgentLoginId(agentLoginId.Trim());
                if (agentSession != null)
                {
                    var clientMappings = _chatService.GetAffectedClientMappings(agentSession.ConnectionId);
                    agentSession.ConnectionId = Context.ConnectionId;
                    agentSession.Status = "Active";
                    agentSession.EndTime = null;
                    await _agentUserConnectionService.UpdateAgentUserSession(agentSession);
                    //Agent Event
                    await Clients.Caller.SendAsync("onAgentConnected", agentSession.User.NickName);
                    //Bot User Event                   
                    if (clientMappings.Count() > 0)
                    {
                        foreach (var item in clientMappings)
                        {
                            await Clients.Client(item.BotUserConnection.ConnectionId).SendAsync("onAgentReconnected", agentSession.User.NickName);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.LogError(ErrorCode.ResponseCode.E103, ExceptionHandler.BuildStackTrace(ex));
            }
        }
        ///// <summary>/
        ///// Send Chat Message
        ///// </summary>
        ///// <param name="connectionId"></param>
        ///// <param name="toUserConnectionId"></param>
        ///// <param name="user"></param>
        ///// <param name="message"></param>
        ///// <param name="toUser"></param>
        ///// <returns></returns>
        [Authorize]
        public async Task Send(Activity chat, bool isAgent = false)
        {
            try
            {
                AgentBotUserMapping agentBotMap = _chatService.GetAgentBotUserMappingByChatId(chat.ChatId);
                if (agentBotMap != null)
                {
                    if (isAgent)
                        await Clients.Client(agentBotMap.BotUserConnection.ConnectionId).SendAsync("ReceiveMessage", chat);
                    else
                        await Clients.Client(agentBotMap.AgentSession.ConnectionId).SendAsync("ReceiveMessage", chat);

                    await _chatLogService.AddConversationChatLog(chat, agentBotMap, isAgent);
                }
            }
            catch (Exception ex)
            {
                Logger.LogError(ErrorCode.ResponseCode.E103, ExceptionHandler.BuildStackTrace(ex));
            }
        }

        /// <summary>
        /// End Chat By Agent Async
        /// </summary>
        /// <param name="chatId"></param>
        /// <returns></returns>
        public async Task EndChatByAgentAsync(Guid chatId, string agentNickName)
        {
            try
            {
                string userConnectionId = await _chatService.EndChatByChatID(chatId);
                await Clients.Client(userConnectionId).SendAsync("onAgentDisconnected", "Success", agentNickName);
                ////Disconnect event loggin not required in chat conversation 
            }
            catch (Exception ex)
            {
                Logger.LogError(ErrorCode.ResponseCode.E103, ExceptionHandler.BuildStackTrace(ex));
            }
        }

        /// Logout By Agent Async
        /// </summary>        
        /// <returns></returns>
        public async Task AgentLogout()
        {
            try
            {
                var userEmailId = Context.UserIdentifier;
                var userDetails = await _userService.GetAgentByUserId(userEmailId);
                var clientMappings = _chatService.GetAffectedClientMappings(Context.ConnectionId);
                if (clientMappings.Count() > 0) // Agent disconnected
                {
                    foreach (var item in clientMappings)
                    {
                        await _agentUserConnectionService.AgentSessionEnd(item.AgentSession.ConnectionId, "Agent logged out");
                        await _chatService.CloseObsoleteMappings(item);
                        await Clients.Client(item.BotUserConnection.ConnectionId).SendAsync("onAgentDisconnected", "Failure", userDetails.NickName);
                        ////Disconnect event loggin not required in chat conversation                        
                    }

                }
                else
                {
                    await _agentUserConnectionService.CloseAllActiveSessions(userDetails.Id);
                }
            }
            catch (Exception ex)
            {
                Logger.LogError(ErrorCode.ResponseCode.E103, ExceptionHandler.BuildStackTrace(ex));
            }
        }

        //public override async Task OnDisconnectedAsync(Exception exception)
        //{
        //    try
        //    {
        //        //Logger.LogEvent("IsCancellationRequested : " + Context.GetHttpContext().RequestAborted.IsCancellationRequested);

        //        var clientMappings = _chatService.GetAffectedClientMappings(Context.ConnectionId);
        //        Users agentUser = await _userService.GetAgentByUserId(Context.UserIdentifier);
        //        //If User is disconnected
        //        var agentMapping = _chatService.GetAffectedAgentMappings(Context.ConnectionId);

        //        if (clientMappings.Count() > 0) // Agent disconnected
        //        { 
        //            //Only when Agent refreshes or closes the browser 
        //            if (Context.GetHttpContext().RequestAborted.IsCancellationRequested)
        //            {
        //                foreach (var item in clientMappings)
        //                {
        //                    await _agentUserConnectionService.AgentSessionEnd(item.AgentSession.ConnectionId, exception?.Message ?? "Agent disconnected");
        //                    await _chatService.CloseObsoleteMappings(item);
        //                    await Clients.Client(item.BotUserConnection.ConnectionId).SendAsync("onAgentDisconnected", "Failure", agentUser.NickName);
        //                    ////Disconnect event loggin not required in chat conversation                        
        //                }   
        //            }
        //        }
        //        else if (agentMapping.Count() > 0)//User
        //        {
        //            foreach (var item in agentMapping)
        //            {
        //                if (!(item.EndTime.HasValue))
        //                {
        //                    await Clients.Client(item.AgentSession.ConnectionId).SendAsync("onBotDisconnected", item.BotUserConnection.BotUserName, item.ChatId);
        //                    await _chatService.CloseObsoleteMappings(agentMapping);
        //                    ////Disconnect event loggin not required in chat conversation                         
        //                }
        //            }
        //        }
        //        else
        //        {
        //            //Only when Agent refreshes or closes the browser 
        //            if (Context.GetHttpContext().RequestAborted.IsCancellationRequested)
        //            {
        //                var userEmailId = Context.UserIdentifier;
        //                var userDetails = await _userService.GetAgentByUserId(userEmailId);
        //                await _agentUserConnectionService.CloseAllActiveSessions(userDetails.Id);
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        Logger.LogError(ErrorCode.ResponseCode.E103, ExceptionHandler.BuildStackTrace(ex));
        //    }
        //}

        public override async Task OnDisconnectedAsync(Exception exception)
        {
            try
            {
                Users agentUser = await _userService.GetAgentByUserId(Context.UserIdentifier);
                //If User is disconnected
                var agentMapping = _chatService.GetAffectedAgentMappings(Context.ConnectionId);
                if (agentMapping.Count() > 0)//User
                {
                    foreach (var item in agentMapping)
                    {
                        if (!(item.EndTime.HasValue))
                        {
                            await Clients.Client(item.AgentSession.ConnectionId).SendAsync("onBotDisconnected", item.BotUserConnection.BotUserName, item.ChatId);
                            await _chatService.CloseObsoleteMappings(agentMapping);
                            ////Disconnect event loggin not required in chat conversation                         
                        }
                    }
                }
                else
                {
                    // Agent disconnected
                    var clientMappings = _chatService.GetAffectedClientMappings(Context.ConnectionId);
                    var userEmailId = Context.UserIdentifier;
                    var userDetails = await _userService.GetAgentByUserId(userEmailId);
                    await _agentUserConnectionService.CloseAllActiveSessions(userDetails.Id);

                    if (clientMappings.Count() > 0)
                    {
                        foreach (var item in clientMappings)
                        {
                            await Clients.Client(item.BotUserConnection.ConnectionId).SendAsync("onAgentDisconnected", "Failure", agentUser.NickName);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.LogError(ErrorCode.ResponseCode.E103, ExceptionHandler.BuildStackTrace(ex));
            }
        }

    }
}
