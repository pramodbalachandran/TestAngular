﻿using System;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using CBaaS.HIL.ClientPortal.Web.Logging;
using CBaaS.HIL.Common.Entities.Models;
using CBaaS.HIL.Middleware.Business.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using CBaaS.HIL.Middleware.Business.Services;
using CBaaS.HIL.Common.Helper;

namespace CBaaS.HIL.Middleware.Hub.Controllers
{
    [AllowAnonymous]
    [ApiController]
    public class TokenController : ControllerBase
    {
        private readonly JWTTokenConfiguration _tokenConfiguration;
        private readonly IRefreshTokenService _refreshTokenService;
        private readonly IConfiguration _configuration;
        private readonly IChatlogService _chatlogService;
        public TokenController(JWTTokenConfiguration tokenConfiguration,
            IConfiguration configuration, IRefreshTokenService refreshTokenService, IChatlogService chatlogService)
        {
            _configuration = configuration;
            _tokenConfiguration = tokenConfiguration;
            _refreshTokenService = refreshTokenService;
            _chatlogService = chatlogService;
        }
        /// <summary>
        /// Generates token by users form data.
        /// </summary>
        /// <returns>Token</returns>
        [Route("token")]
        [HttpPost]
        public IActionResult Post()
        {
            try
            {
                if (!this.HttpContext.Request.Form.TryGetValue("grant_type", out var grant_Type))
                {
                    return this.BadRequest(CommonConstant.InvalidGranTTypeParameter);
                }

                if (!this.HttpContext.Request.Form.TryGetValue("grant_key", out var key))
                {
                    return this.BadRequest(CommonConstant.InvalidGranKeyParameter);
                }

                if (!this.HttpContext.Request.Form.TryGetValue("username", out var userId))
                {
                    return this.BadRequest(CommonConstant.InvalidGranKeyParameter);
                }
                Logger.username = userId;

                if (!JWTWebToken.IsTokenExpired(key, _tokenConfiguration.Key) && grant_Type == "password")
                {
                    string jwtToken = JWTWebToken.GenerateToken(userId, _tokenConfiguration);

                    RefreshToken refreshTokenObj = new RefreshToken
                    {
                        Username = userId,
                        Refreshtoken1 = Guid.NewGuid().ToString(),
                        Expiry = DateTime.UtcNow.Add(_tokenConfiguration.RefreshExpiration),
                        Token = jwtToken
                    };

                    _refreshTokenService.AddRefreshToken(refreshTokenObj);
                    return Ok(new
                    {
                        token = jwtToken,
                        refreshToken = refreshTokenObj.Refreshtoken1
                    });
                }
                Logger.LogError(ErrorCode.ResponseCode.E103, CommonConstant.UnAuthorized);
                return this.BadRequest(CommonConstant.UnAuthorized);
            }
            catch (Exception ex)
            {
                Logger.LogError(ErrorCode.ResponseCode.E103, ExceptionHandler.BuildStackTrace(ex));
                return this.BadRequest(CommonConstant.ErrorMessage);
            }
        }

        [Route("refreshToken")]
        [HttpPost]
        public IActionResult RefreshToken()
        {
            try
            {
                if (!this.HttpContext.Request.Form.TryGetValue("token", out var token))
                {
                    return this.BadRequest(CommonConstant.InvalidRefreshToken);
                }

                if (!this.HttpContext.Request.Form.TryGetValue("refreshToken", out var refreshToken))
                {
                    return this.BadRequest(CommonConstant.InvalidRefreshToken);
                }

                var principal = JWTWebToken.GetPrincipalFromExpiredToken(token, _tokenConfiguration);
                string userId = principal.Identity.Name;
                Logger.username = userId;
                RefreshToken savedRefreshToken = _refreshTokenService.GetRefreshToken(refreshToken);
                if (savedRefreshToken != null)
                {
                    if (savedRefreshToken.Refreshtoken1 != refreshToken)
                        throw new SecurityTokenException(CommonConstant.InvalidRefreshToken);

                    string jwtToken = JWTWebToken.GenerateToken(userId, _tokenConfiguration);

                    RefreshToken refreshTokenObj = new RefreshToken
                    {
                        Username = userId,
                        Refreshtoken1 = Guid.NewGuid().ToString(),
                        Expiry = DateTime.UtcNow.Add(TimeSpan.FromHours(1)),
                        Token = jwtToken
                    };

                    _refreshTokenService.AddRefreshToken(refreshTokenObj);
                    return Ok(new { token = jwtToken, refreshToken = refreshTokenObj.Refreshtoken1 });
                }
                else
                {
                    return this.BadRequest(CommonConstant.InvalidToken);
                }
            }
            catch (SecurityTokenException ex)
            {
                Logger.LogError(ErrorCode.ResponseCode.E104, ExceptionHandler.BuildStackTrace(ex));
                return this.BadRequest(ex.Message);
            }
            catch (Exception ex)
            {
                Logger.LogError(ErrorCode.ResponseCode.E103, ExceptionHandler.BuildStackTrace(ex));
                return this.BadRequest(CommonConstant.ErrorMessage);
            }
        }

        [Route("CacheChatMigration")]
        [HttpGet]
        public async Task<IActionResult> CacheChatMigration()
        {
            bool result = await _chatlogService.MigrateCacheChatLog();
            if (result)
            {
                return this.Ok("Migration has been Completed.");
            }
            return this.BadRequest(CommonConstant.InvalidToken);
        }
    }
}