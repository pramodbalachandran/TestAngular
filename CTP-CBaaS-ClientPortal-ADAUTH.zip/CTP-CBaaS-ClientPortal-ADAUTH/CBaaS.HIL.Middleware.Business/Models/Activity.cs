﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBaaS.HIL.Middleware.Business.Models
{
    public class Activity
    {
        public Guid ChatId { get; set; }
        public string Message { get; set; }
        public string Type { get; set; }
        public DateTime DateTime { get; set; }
    }
}
