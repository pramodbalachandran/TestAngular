﻿using Microsoft.WindowsAzure.Storage.Table;
using System;
using System.Collections.Generic;
using System.Text;

namespace CBaaS.HIL.Middleware.Business.Models
{
    public class ChatLogModel : TableEntity
    {
        /// <summary>
        /// Chat conversation id. This will be unique for single session
        /// </summary>
        public string ConversationId { get; set; }
        /// <summary>
        /// Chat conversation activity id, This will be unique for every conversation
        /// </summary>
        public string ActivityId { get; set; }
        /// <summary>
        /// Logged in user name
        /// </summary>
        public string Username { get; set; }
        /// <summary>
        /// logged in user Email
        /// </summary>
        public string Email { get; set; }
        /// <summary>
        /// Input request of bot user
        /// </summary>
        public string Question { get; set; }
        /// <summary>
        /// Response from Bot for input request
        /// </summary>
        public string Answers { get; set; }
        /// <summary>
        /// Feedback Like/Dislike from bot user to chat conversation 
        /// </summary>
        public string Feedback { get; set; }
        /// <summary>
        /// User comment along with feedback
        /// </summary>
        public string FeedbackComment { get; set; }
        /// <summary>
        /// Feedback date
        /// </summary>
        public DateTime? FeedbackDate { get; set; }
        /// <summary>
        /// Conversation date
        /// </summary>
        public DateTime? Date { get; set; }
        /// <summary>
        /// If user requested for Human in Loop then this will e true
        /// </summary>
        public bool IsHil { get; set; }
        /// <summary>
        /// If Bot doesnt get answer to user input and replying fallback message that time this falg will be true
        /// </summary>
        public bool IsFallback { get; set; }

        /// <summary>
        /// Agent email with feedback
        /// </summary>
        public string AgentEmail { get; set; }
    }
}
