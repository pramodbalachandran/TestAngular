﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBaaS.HIL.Middleware.Business.Models
{
    public class HilRequest
    {
        public string BotId { get; set; }
        public string BotUserName { get; set; }
        public string BotUserId { get; set; }
        public string ConversationId { get; set; }
        public List<BotConversation> ChatHistory { get; set; } = null;
        public string Domain { get; set; } = null;
        public string BotName { get; set; }
        public string HandOffComment { get; set; }

    }
    public class BotConversation
    {
        public string Sender { get; set; }
        public string Message { get; set; }
    }
}
