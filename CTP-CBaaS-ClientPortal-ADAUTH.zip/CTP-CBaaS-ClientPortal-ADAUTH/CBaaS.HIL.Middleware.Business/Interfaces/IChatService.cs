﻿using CBaaS.HIL.Common.Entities.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CBaaS.HIL.Middleware.Business.Interfaces
{
    public interface IChatService
    {
        Task<Guid> BeginChat(AgentSession selectedAgent, BotUserConnection targetBotUser);
        Task CloseObsoleteMappings(string botUserId);
        Task CloseObsoleteMappings(IEnumerable<AgentBotUserMapping> obsoleteMappings);
        Task CloseObsoleteMappings(AgentBotUserMapping obsoleteMapping);
        AgentBotUserMapping GetAgentBotUserMappingByChatId(Guid chatId);
        Task<string> EndChatByChatID(Guid chatId);
        IEnumerable<AgentBotUserMapping> GetAffectedClientMappings(string connectionId);
        IEnumerable<AgentBotUserMapping> GetAffectedAgentMappings(string connectionId);
        AgentBotUserMapping GetActiveAgentBotUserMappingByUserId(string userId, long botId);
        void UpdateClosedAgentBotUserMappingByUserId(string userId, long botId);
    }
}
