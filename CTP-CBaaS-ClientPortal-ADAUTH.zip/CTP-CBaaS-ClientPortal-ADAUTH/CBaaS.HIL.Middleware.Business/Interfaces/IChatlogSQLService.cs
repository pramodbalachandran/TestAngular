﻿using CBaaS.HIL.Middleware.Business.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CBaaS.HIL.Middleware.Business.Interfaces
{
    public interface IChatlogSQLService
    {
        /// <summary>
        /// Add chatlog in SQL or azure table storage as per configuration
        /// </summary>
        /// <param name="chatLogModel">Chatlog model details</param>
        /// <returns>Boolean status</returns>
        Task<bool> AddChatLog(List<ChatLogModel> chatLogModel, string connectionstring);

        /// <summary>
        /// Update feedback chatlog in SQL or azure table storage as per configuration
        /// </summary>
        /// <param name="chatLogModel">Updated feedback Chatlog model</param>
        /// <returns>Boolean status</returns>
        Task<bool> UpdateChatLog(ChatLogModel chatLogModel);

        /// <summary>
        /// Reset cache and update chatlog with data source
        /// </summary>
        /// <returns>Return bool result</returns>
        Task<bool> MigrateChatLog();
    }
}
