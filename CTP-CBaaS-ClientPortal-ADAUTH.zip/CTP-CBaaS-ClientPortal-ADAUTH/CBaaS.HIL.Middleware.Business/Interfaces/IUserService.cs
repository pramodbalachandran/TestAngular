﻿using CBaaS.HIL.Common.Entities.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CBaaS.HIL.Middleware.Business.Interfaces
{
    public interface IUserService
    {
        Task<Users> GetAgentByUserId(string agentLoginId);
    }
}
