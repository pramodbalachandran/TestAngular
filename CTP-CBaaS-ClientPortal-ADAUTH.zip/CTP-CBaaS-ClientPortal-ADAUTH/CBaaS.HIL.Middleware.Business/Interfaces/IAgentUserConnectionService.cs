﻿using CBaaS.HIL.Common.Entities.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CBaaS.HIL.Middleware.Business.Interfaces
{
    public interface IAgentUserConnectionService
    {
        Task<AgentSession> GetAgentSessionByAgentId(int agentId);
		AgentSession GetAgentSessionByAgentLoginId(string agentLoginId);
        Task AddAgentUserToSession(AgentSession agentSession);
		Task UpdateAgentUserSession(AgentSession agentSession);
        Task<AgentSession> AgentSessionEnd(string connectionId, string remarks);
        Task CloseAllActiveSessions(int userId);
        //AgentSession GetAgentAbhishri();
    }
}
