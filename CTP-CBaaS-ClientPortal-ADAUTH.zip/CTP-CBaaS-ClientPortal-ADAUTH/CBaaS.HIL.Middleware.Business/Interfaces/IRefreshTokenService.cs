﻿using CBaaS.HIL.Common.Entities.Models;

namespace CBaaS.HIL.Middleware.Business.Interfaces
{
    public interface IRefreshTokenService 
    {
        RefreshToken GetRefreshToken(int id);
        RefreshToken GetRefreshToken(string token);
        void AddRefreshToken(RefreshToken refreshToken);
    }
}