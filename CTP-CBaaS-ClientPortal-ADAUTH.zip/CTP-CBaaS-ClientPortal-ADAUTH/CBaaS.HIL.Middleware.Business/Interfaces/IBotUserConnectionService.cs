﻿using CBaaS.HIL.Common.CoreComponents.Repositories;
using CBaaS.HIL.Common.Entities.Models;
using System.Threading.Tasks;

namespace CBaaS.HIL.Middleware.Business.Interfaces
{
    public interface IBotUserConnectionService 
    {
        Task AddBotUserConnection(BotUserConnection botUserConnection);
    }
}
