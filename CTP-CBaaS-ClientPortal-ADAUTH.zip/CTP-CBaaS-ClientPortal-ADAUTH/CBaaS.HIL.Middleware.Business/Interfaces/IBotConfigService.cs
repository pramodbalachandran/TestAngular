﻿using CBaaS.HIL.Common.Entities.Models;
using System.Threading.Tasks;

namespace CBaaS.HIL.Middleware.Business.Interfaces
{
    public interface IBotConfigService
    {
        Task<BotConfig> GetBotConfigByBotId(string botId);
    }
}
