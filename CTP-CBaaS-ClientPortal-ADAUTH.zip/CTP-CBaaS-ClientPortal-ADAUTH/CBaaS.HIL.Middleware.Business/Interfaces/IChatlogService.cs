﻿using CBaaS.HIL.Common.Entities.Models;
using CBaaS.HIL.Middleware.Business.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;


namespace CBaaS.HIL.Middleware.Business.Interfaces
{
    public interface IChatlogService
    {
        /// <summary>
        /// On user HIL connect request
        /// </summary>
        /// <param name="agentSession">Agent details</param>
        /// <param name="hilRequest">HIL input details</param>
        /// <param name="errorMessage">Errormessage for agent found</param>
        /// <returns>non return method</returns>
        Task AddUserConnectChatLog(AgentSession agentSession, HilRequest hilRequest, string errorMessage);
        Task AddConversationChatLog(Activity chat, AgentBotUserMapping agentBotMap, bool isAgent);
        Task AddDisconnectChatLog(AgentBotUserMapping agentBotMap, string message, bool isAgent);

        Task<bool> MigrateCacheChatLog();
    }
}
