﻿using CBaaS.HIL.Common.CoreComponents.Repositories;
using CBaaS.HIL.Common.Entities.Models;
using CBaaS.HIL.Middleware.Business.Interfaces;
using CBaaS.HIL.Middleware.Business.Models;
using FastMember;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CBaaS.HIL.Middleware.Business.Services
{
    public class ChatlogSQLService : IChatlogSQLService
    {

        private ICoreRepository<ChatLogs> _business;
        protected IConfiguration configuration;
        protected IMemoryCache memoryCache;
        protected int batchCount;

        public ChatlogSQLService(ICoreRepository<ChatLogs> business, IConfiguration Configuration)
        {
            _business = business;
            configuration = Configuration; 
            batchCount = !string.IsNullOrEmpty(configuration["ChatLogBatchCount"]) ? Convert.ToInt32(configuration["ChatLogBatchCount"]) : 10;
        }

        public async Task<bool> AddChatLog(List<ChatLogModel> chatLogModel, string connectionstring)
        {
            try
            {
                var copyParameters = new[]
                     {
                        "LogId",
                        "ConversationId",
                        "ActivityId",
                        "Username",
                        "Email",
                        "Question",
                        "Answers",
                        "Feedback",
                        "FeedbackComment",
                        "FeedbackDate",
                        "Date",
                        "IsHil",
                        "IsFallback",
                        "AgentEmail"
                    };
                using (SqlConnection destinationCon = new SqlConnection(connectionstring))
                {
                    destinationCon.Open();
                    using (SqlTransaction transaction = destinationCon.BeginTransaction())
                    {
                        using (var sqlCopy = new SqlBulkCopy(destinationCon, SqlBulkCopyOptions.Default, transaction))
                        {
                            try
                            {
                                sqlCopy.DestinationTableName = "chatLogs";
                                sqlCopy.BatchSize = chatLogModel.Count;
                                using (var reader = ObjectReader.Create(chatLogModel, copyParameters))
                                {
                                    sqlCopy.WriteToServer(reader);
                                    transaction.Commit();
                                }
                            }
                            catch (Exception ex)
                            {
                                transaction.Rollback();
                                return false;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return true;
        }

        public async Task<bool> UpdateChatLog(ChatLogModel chatLogModel)
        {
            return true;
        }

        public async Task<bool> MigrateChatLog()
        {
            return true;
        }
    }
}
