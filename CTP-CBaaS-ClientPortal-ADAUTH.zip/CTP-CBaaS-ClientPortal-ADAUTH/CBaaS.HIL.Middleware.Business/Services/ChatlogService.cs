﻿using CommonData = CBaaS.HIL.ClientPortal.Business.Interfaces;
using CBaaS.HIL.Common.Entities.Models;
using CBaaS.HIL.Middleware.Business.Interfaces;
using CBaaS.HIL.Middleware.Business.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CBaaS.HIL.ClientPortal.Business.Interfaces;
using Microsoft.Extensions.Configuration;
using CBaaS.HIL.Middleware.Business.Services;
using CommonService=CBaaS.HIL.ClientPortal.Business.Services;

namespace CBaaS.HIL.Middleware.Hub.Logging
{
    public class ChatlogService : IChatlogService
    {
        private readonly CommonData.IBotRegistrationService _botRegistrationService;
        private readonly CommonData.IBotConfigService _botConfigServices;
        private readonly ICacheService _cacheService;
        private readonly IChatlogATSService _chatlogATSService;
        private readonly IChatlogSQLService _chatlogSQLService;
        private readonly CommonData.IUserService _userService;
        protected int batchCount;
        public ChatlogService(CommonData.IBotRegistrationService botRegistrationService, CommonData.IBotConfigService botConfigService, IChatlogATSService chatlogATSService, ICacheService cacheService, CommonData.IUserService userService, IConfiguration configuration, IChatlogSQLService chatlogSQLService)
        {
            this._botRegistrationService = botRegistrationService;
            this._botConfigServices = botConfigService;
            this._chatlogATSService = chatlogATSService;
            this._cacheService = cacheService;
            this._userService = userService;
            this._chatlogSQLService = chatlogSQLService;
            batchCount = !string.IsNullOrEmpty(configuration["ChatLogBatchCount"]) ? Convert.ToInt32(configuration["ChatLogBatchCount"]) : 10;
        }

        public async Task AddUserConnectChatLog(AgentSession agentSession, HilRequest hilRequest, string errorMessage)
        {
            try
            {
                // Read bot registration details
                var botDetails = await GetBotRegistrationAsync(hilRequest.BotId);
                ChatLogModel chatLogModel = new ChatLogModel();
                //Send request to ATS logging mode
                chatLogModel.ActivityId = Guid.NewGuid().ToString();
                chatLogModel.PartitionKey = hilRequest.ConversationId;
                chatLogModel.ConversationId = hilRequest.ConversationId;
                chatLogModel.Date = new DateTime(DateTime.UtcNow.Year, DateTime.UtcNow.Month, DateTime.UtcNow.Day, DateTime.UtcNow.Hour, DateTime.UtcNow.Minute, DateTime.UtcNow.Second, DateTimeKind.Utc);
                chatLogModel.Answers = string.Empty;
                chatLogModel.Email = hilRequest.BotUserId;
                chatLogModel.IsHil = true;
                chatLogModel.Question = hilRequest.HandOffComment;
                chatLogModel.Answers = errorMessage;
                chatLogModel.Username = hilRequest.BotUserName;
                chatLogModel.AgentEmail = agentSession?.User?.UserName;
                await this.AddChatLogs(chatLogModel, hilRequest.BotId, botDetails);
            }
            catch (Exception)
            {
                //Log exception in platform
            }
        }

        public async Task AddConversationChatLog(Activity chat, AgentBotUserMapping agentBotMap, bool isAgent)
        {
            try
            {
                var BotConfigDetails = _botConfigServices.GetBotConfigById(Convert.ToInt32(agentBotMap.BotUserConnection.BotConfigId));
                string botId = BotConfigDetails.BotId.ToString();
                // Read bot registration details
                var BotDetails = await GetBotRegistrationAsync(botId);
                //TODO: need to check How to remove below db call
                var userDetails = _userService.GetUserByUserId(agentBotMap.AgentSession.UserId);
                ChatLogModel chatLogModel = new ChatLogModel();

                //Send request to ATS logging mode
                chatLogModel.ActivityId = Guid.NewGuid().ToString();
                chatLogModel.PartitionKey = agentBotMap.BotUserConnection.ConversationId;
                chatLogModel.Email = agentBotMap.BotUserConnection.BotUserId;
                chatLogModel.ConversationId = agentBotMap.BotUserConnection.ConversationId;
                chatLogModel.Date = new DateTime(DateTime.UtcNow.Year, DateTime.UtcNow.Month, DateTime.UtcNow.Day, DateTime.UtcNow.Hour, DateTime.UtcNow.Minute, DateTime.UtcNow.Second, DateTimeKind.Utc);
                chatLogModel.IsHil = true;
                if (isAgent)
                {
                    chatLogModel.Answers = chat.Message;
                    chatLogModel.Question = string.Empty;
                }
                else
                {
                    chatLogModel.Answers = string.Empty;
                    chatLogModel.Question = chat.Message;
                }
                chatLogModel.Username = agentBotMap.BotUserConnection.BotUserName;

                chatLogModel.AgentEmail = userDetails.UserName;
                await this.AddChatLogs(chatLogModel, botId, BotDetails);

            }
            catch (Exception)
            {
                //Log exception in platform
            }
        }

        public async Task AddDisconnectChatLog(AgentBotUserMapping agentBotMap, string message, bool isAgent)
        {
            try
            {
                var BotConfigDetails = _botConfigServices.GetBotConfigById(Convert.ToInt32(agentBotMap.BotUserConnection.BotConfigId));
                string botId = BotConfigDetails.BotId.ToString();
                // Read bot registration details
                var BotDetails = await GetBotRegistrationAsync(botId);
                var userDetails = _userService.GetUserByUserId(agentBotMap.AgentSession.UserId);
                ChatLogModel chatLogModel = new ChatLogModel();
                //Send request to ATS logging mode
                chatLogModel.ActivityId = Guid.NewGuid().ToString();
                chatLogModel.PartitionKey = agentBotMap.BotUserConnection.ConversationId;
                chatLogModel.ConversationId = agentBotMap.BotUserConnection.ConversationId;
                chatLogModel.Date = new DateTime(DateTime.UtcNow.Year, DateTime.UtcNow.Month, DateTime.UtcNow.Day, DateTime.UtcNow.Hour, DateTime.UtcNow.Minute, DateTime.UtcNow.Second, DateTimeKind.Utc);
                chatLogModel.Answers = string.Empty;
                chatLogModel.Email = agentBotMap.BotUserConnection.BotUserId;
                chatLogModel.IsHil = true;
                if (isAgent)
                {
                    chatLogModel.Answers = message;
                    chatLogModel.Question = string.Empty;
                }
                else
                {
                    chatLogModel.Answers = string.Empty;
                    chatLogModel.Question = message;
                }
                chatLogModel.Username = agentBotMap.BotUserConnection.BotUserName;
                //TODO: need to check and change Agent email id
                chatLogModel.AgentEmail = userDetails.UserName;
                await this.AddChatLogs(chatLogModel, botId, BotDetails);
            }
            catch (Exception)
            {
                //Log exception in platform
            }
        }

        public async Task<bool> MigrateCacheChatLog()
        {
            try
            {
                //TODO: Passing hardcode user details
                UserRolesVM userList = new UserRolesVM();
                userList.emailId = "userName";
                userList.roles.Add(CommonService.CommonEnum.UserRoles.SuperAdmin.ToString());

                var botList = _botRegistrationService.GetAllBotsList(userList);
                foreach (var botDetails in botList)
                {
                    string ChatlogCache = CommonConstant.HilChatCache + botDetails.BotId.ToString().ToLower();
                    var CacheChat = _cacheService.GetCacheObjectValue(ChatlogCache);
                    List<ChatLogModel> ChatlogList = new List<ChatLogModel>();
                    ChatlogList = (List<ChatLogModel>)CacheChat;
                    if (ChatlogList != null)
                    {
                        if (botDetails.ReportSource == CommonConstant.AzureStorage)
                        {
                            await _chatlogATSService.AddChatLog(ChatlogList, botDetails.ReportConnectionString);
                        }
                        else
                        {
                            await _chatlogSQLService.AddChatLog(ChatlogList, botDetails.ReportConnectionString);
                        }
                    }
                }
                return true;
            }
            catch (Exception )
            {
                return false;
            }

        }

        private async Task<BotRegistration> GetBotRegistrationAsync(string botId)
        {
            BotRegistration botRegistration = new BotRegistration();
            var cacheRegistration = _cacheService.GetCacheObjectValue("Cache_" + botId);
            if (cacheRegistration == null)
            {

                var botConfigData = _botConfigServices.GetBotConfigById(new Guid(botId));
                if (botConfigData != null)
                {
                    botRegistration = _botRegistrationService.GetRegisteredBotById(botConfigData.Id).FirstOrDefault();
                    _cacheService.SetCacheObjectValue("Cache_" + botId, botRegistration);
                }
            }
            else
            {
                botRegistration = (BotRegistration)cacheRegistration;
            }
            return botRegistration;
        }

        private async Task AddChatLogs(ChatLogModel chatLogModel, string botId, BotRegistration botRegistration)
        {
            string ChatlogCache = CommonConstant.HilChatCache + botId.ToLower();
            var CacheChat = _cacheService.GetCacheObjectValue(ChatlogCache);
            List<ChatLogModel> ChatlogList = new List<ChatLogModel>();
            if (CacheChat == null)
            {
                ChatlogList.Add(chatLogModel);
                _cacheService.SetCacheObjectValue(ChatlogCache, ChatlogList);
            }
            else
            {
                ChatlogList = (List<ChatLogModel>)CacheChat;
                ChatlogList.Add(chatLogModel);
                _cacheService.SetCacheObjectValue(ChatlogCache, ChatlogList);
            }

            if (ChatlogList.Count >= batchCount)
            {
                if (botRegistration.ReportSource == CommonConstant.AzureStorage)
                {
                    await _chatlogATSService.AddChatLog(ChatlogList, botRegistration.ReportConnectionString);
                }
                else
                {
                    await _chatlogSQLService.AddChatLog(ChatlogList, botRegistration.ReportConnectionString);
                }
                _cacheService.SetCacheObjectValue(ChatlogCache, null);
            }
        }
    }
}
