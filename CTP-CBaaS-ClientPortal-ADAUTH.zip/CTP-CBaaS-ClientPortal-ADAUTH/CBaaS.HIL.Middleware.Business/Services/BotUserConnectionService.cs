﻿using CBaaS.HIL.Common.CoreComponents.Repositories;
using CBaaS.HIL.Common.Entities.Models;
using CBaaS.HIL.Middleware.Business.Interfaces;
using System;
using System.Threading.Tasks;

namespace CBaaS.HIL.Middleware.Business.Services
{
    public class BotUserConnectionService : IBotUserConnectionService
    {
        private ICoreRepository<BotUserConnection> _business;
        public BotUserConnectionService(ICoreRepository<BotUserConnection> business)
        {
            _business = business;
        }
        public async Task AddBotUserConnection(BotUserConnection botUserConnection)
        {
            try
            {
                await _business.AddAsync(botUserConnection);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
