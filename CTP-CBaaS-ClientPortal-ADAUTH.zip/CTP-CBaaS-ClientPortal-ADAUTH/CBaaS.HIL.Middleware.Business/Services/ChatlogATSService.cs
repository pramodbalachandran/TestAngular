﻿using CBaaS.HIL.Middleware.Business.Interfaces;
using CBaaS.HIL.Middleware.Business.Models;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Auth;
using Microsoft.WindowsAzure.Storage.Table;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CBaaS.HIL.Middleware.Business.Services
{
    public class ChatlogATSService : IChatlogATSService
    {

        CloudStorageAccount storageAccount = null;
        protected CloudTable cloudTable;

        public ChatlogATSService()
        {
        }

        public async Task<bool> AddChatLog(List<ChatLogModel> chatLogModel, string connectionString)
        {
            try
            {
                cloudTable = this.InitializeATS(connectionString);
                await cloudTable.CreateIfNotExistsAsync();
                TableBatchOperation batchOperation = new TableBatchOperation();
                foreach (var chatlog in chatLogModel)
                {
                    chatlog.RowKey = chatlog.ActivityId;
                    chatlog.PartitionKey = "CBaaSLog_HIL";
                    batchOperation.InsertOrReplace(chatlog);
                }
                await cloudTable.ExecuteBatchAsync(batchOperation);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return true;
        }

        public async Task<bool> UpdateChatLog(ChatLogModel chatLogModel)
        {
            return true;
        }

        public async Task<bool> MigrateChatLog(List<ChatLogModel> chatLogModel, string connectionString)
        {
            return true;
        }

        private CloudTable InitializeATS(string connectionString)
        {
            try
            {
                CloudStorageAccount storageAccount = CloudStorageAccount.Parse(connectionString);
                string tableName = "chatlog";
                CloudTableClient client = storageAccount.CreateCloudTableClient();

                // Retrieve a reference to a table.
                CloudTable cloudTable = client.GetTableReference(tableName);

                // Create table if it doesn't already exist.
                cloudTable.CreateIfNotExistsAsync();

                return cloudTable;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
