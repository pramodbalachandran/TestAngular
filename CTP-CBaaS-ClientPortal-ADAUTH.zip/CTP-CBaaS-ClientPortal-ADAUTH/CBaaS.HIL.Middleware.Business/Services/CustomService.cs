﻿using CBaaS.HIL.Common.CoreComponents.Repositories;
using CBaaS.HIL.Common.Data;
using CBaaS.HIL.Common.Entities.Models;
using CBaaS.HIL.Middleware.Business.Interfaces;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace CBaaS.HIL.Middleware.Business.Services
{
    public class CustomService : ICustomService
    {
        BaseContext _dbcontext;
        public CustomService(BaseContext dbcontext)
        {
            _dbcontext = dbcontext;
        }

        public AgentSession GetConnectedAgent(long botConfigId)
        {
            string sql = @"select top 1 ag.* from (
                        select u.Id as userId from [dbo].[UserBotRoles] ur inner join Users U on u.Id=ur.UserId
                        and ur.RoleId=1 and GETDATE() between ur.FromDate and ISNULL( ur.ToDate,'2999-12-31')
                        and u.IsActive=1 and ur.BotConfigId={0}) tmp 
                        inner join AgentSession ag on ag.UserId=tmp.userId
                        and ag.EndTime is null
                        left join(select am.AgentSessionId,count(*) noofchat from AgentBotUserMapping am 
                        where am.EndTime is null
                        group by am.AgentSessionId) tmp2 on tmp2.AgentSessionId=ag.Id
                        order by tmp2.noofchat";

            var selectedAgent = (_dbcontext.AgentSession.FromSqlRaw(sql, botConfigId)).Include(x => x.User).AsNoTracking().FirstOrDefault();
            return selectedAgent;
        }
    }
}
