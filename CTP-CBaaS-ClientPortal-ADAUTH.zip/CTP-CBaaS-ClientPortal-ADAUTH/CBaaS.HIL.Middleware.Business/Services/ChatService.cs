﻿using CBaaS.HIL.Common.CoreComponents.Repositories;
using CBaaS.HIL.Common.Entities.Models;
using CBaaS.HIL.Middleware.Business.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CBaaS.HIL.Middleware.Business.Services
{
    public class ChatService : IChatService
    {
        private ICoreRepository<AgentBotUserMapping> _business;
        public ChatService(ICoreRepository<AgentBotUserMapping> business)
        {
            _business = business;
        }

        public async Task<Guid> BeginChat(AgentSession selectedAgent, BotUserConnection targetBotUser)
        {
            try
            {
                Guid chatId = Guid.NewGuid();
                await _business.AddAsync(
                    new AgentBotUserMapping
                    {
                        ChatId = chatId,
                        AgentSessionId = selectedAgent.Id,
                        BotUserConnectionId = targetBotUser.Id,
                        StartTime = DateTime.Now,

                    });
                return chatId;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return Guid.Empty;
            }
        }

        public async Task CloseObsoleteMappings(string botUserId)
        {
            var currentMappings = _business.FindAll(x =>
            x.BotUserConnection.BotUserId == botUserId &&
            x.EndTime == null, true).ToList();
            try
            {
                foreach (var map in currentMappings)
                {
                    map.EndTime = DateTime.Now;
                    await _business.UpdateAsync(map);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public async Task CloseObsoleteMappings(IEnumerable<AgentBotUserMapping> obsoleteMappings)
        {
            try
            {
                foreach (var map in obsoleteMappings)
                {
                    map.EndTime = DateTime.Now;
                    await _business.UpdateAsync(map);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        public async Task CloseObsoleteMappings(AgentBotUserMapping obsoleteMapping)
        {
            try
            {
                obsoleteMapping.EndTime = DateTime.Now;
                await _business.UpdateAsync(obsoleteMapping);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public async Task<string> EndChatByChatID(Guid chatId)
        {

            AgentBotUserMapping currentMapping = _business.Find(a =>
            a.ChatId == chatId &&
            a.EndTime == null, true);
            try
            {
                currentMapping.EndTime = DateTime.Now;
                await _business.UpdateAsync(currentMapping);
                return currentMapping.BotUserConnection.ConnectionId;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return string.Empty;
            }

        }
        public IEnumerable<AgentBotUserMapping> GetAffectedAgentMappings(string connectionId)
        {
            return _business.FindAll(a => a.BotUserConnection.ConnectionId == connectionId, true);
        }

        public IEnumerable<AgentBotUserMapping> GetAffectedClientMappings(string connectionId)
        {
            return _business.FindAll(a => a.AgentSession.ConnectionId == connectionId, true);
        }
        public AgentBotUserMapping GetAgentBotUserMappingByChatId(Guid chatId)
        {
            return _business.Find(a => a.ChatId == chatId && a.EndTime == null, true);
        }
        public AgentBotUserMapping GetActiveAgentBotUserMappingByUserId(string userId, long botId)
        {
            return _business.Find(a => a.BotUserConnection.BotUserId == userId && a.BotUserConnection.BotConfigId == botId && a.EndTime == null, true);
        }
        public void UpdateClosedAgentBotUserMappingByUserId(string userId, long botId)
        {
            var closedMappings = _business.FindAll(a => a.AgentSession.EndTime != null && a.BotUserConnection.BotUserId == userId && a.BotUserConnection.BotConfigId == botId && a.EndTime == null, true);
            foreach (var mapping in closedMappings)
            {
                mapping.EndTime = DateTime.Now;
                _business.Update(mapping);
            }
        }
    }
}
