﻿using CBaaS.HIL.Common.CoreComponents.Repositories;
using CBaaS.HIL.Common.Entities.Models;
using CBaaS.HIL.Middleware.Business.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CBaaS.HIL.Middleware.Business.Services
{
    public class AgentUserConnectionService : IAgentUserConnectionService
    {
        private ICoreRepository<AgentSession> _business;
        public AgentUserConnectionService(ICoreRepository<AgentSession> business)
        {
            _business = business;
        }

        public async Task AddAgentUserToSession(AgentSession agentSession)
        {
            await CloseAllActiveSessions(agentSession.UserId);
            try
            {
                await _business.AddAsync(agentSession);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        public async Task UpdateAgentUserSession(AgentSession agentSession)
        {
            try
            {
                await _business.UpdateAsync(agentSession);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        public async Task<AgentSession> AgentSessionEnd(string connectionId, string remarks = "")
        {
            var agent = _business.Find(s => s.ConnectionId == connectionId, true);

            if (agent != null)
            {
                agent.EndTime = DateTime.Now;
                agent.Status = "Closed";
                agent.Remarks = remarks;
                try
                {
                    await _business.UpdateAsync(agent);
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
            }
            return agent;
        }

        public async Task CloseAllActiveSessions(int userId)
        {
            var agentSessions = _business.FindAll(s => s.UserId == userId && s.EndTime == null).ToList();
            if (agentSessions.Count() > 0)
            {
                foreach (var agent in agentSessions)
                {
                    agent.EndTime = DateTime.Now;
                    agent.Status = "Closed";
                    await _business.UpdateAsync(agent);
                }
            }
        }

        public Task<AgentSession> GetAgentSessionByAgentId(int agentId)
        {
            return _business.FindAsync(s => s.UserId == agentId && s.EndTime == null);
        }
        //public AgentSession GetAgentSessionByAgentLoginId(string agentId)
        //{
        //    return _business.Find(s => s.User.UserName == agentId && s.EndTime == null, true);
        //}
        public AgentSession GetAgentSessionByAgentLoginId(string agentId)
        {
            var agentSessions = _business.FindAll(s => s.User.UserName == agentId, true);
            var lastSessionId = agentSessions.Max(x => x.Id);
            return agentSessions.FirstOrDefault(x => x.Id == lastSessionId);
        }

        //public AgentSession GetAgentAbhishri()
        //{
        //    return _business.Find(u => u.UserId == 1 && u.EndTime == null, true);
        //}
        public Task<AgentSession> GetConnectedAgent(long botConfigId)
        {
            throw new NotImplementedException();
        }
    }
}
