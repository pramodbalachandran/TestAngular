﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBaaS.HIL.Middleware.Business.Services
{
    public class CommonConstant
    {
        public const string IDAASCertificate = "IDAASCertificate.crt";
        public const string Certificates = "certificates";
        public const string InvalidToken = "Invalid Token";
        public const string ErrorMessage = "Something went wrong";
        public const string EmailAddress = "EmailAddress";
        public const string UnauthorizedMsg = "Unauthorized Request";
        public const string Bearer = "Bearer ";
        public const string UnAuthorized = "UnAuthorized";
        public const string InvalidRefreshToken = "Invalid refresh token";
        public const string InvalidGranTTypeParameter = "Request does not contains grant type parameter";
        public const string InvalidGranKeyParameter = "Request does not contains grant key parameter";

        #region HIL Chat logging
        public const string DatabseLog = "SQL";
        public const string TableStorageLog = "ATS";
        public const string CBaaSLog = "CBaaSLog";
        public const string HilChatCache = "HilChatCache_";
        public const string AzureStorage = "AzureStorage";
        #endregion
    }
}
