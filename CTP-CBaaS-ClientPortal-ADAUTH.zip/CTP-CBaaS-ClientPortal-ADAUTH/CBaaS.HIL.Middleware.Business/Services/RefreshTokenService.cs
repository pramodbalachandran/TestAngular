﻿using CBaaS.HIL.Common.CoreComponents.Repositories;
using CBaaS.HIL.Common.Entities.Models;
using CBaaS.HIL.Middleware.Business.Interfaces;
using System;



namespace CBaaS.HIL.Middleware.Business.Services
{
    public class RefreshTokenService : IRefreshTokenService
    {
        private ICoreRepository<RefreshToken> _business;
        public RefreshTokenService(ICoreRepository<RefreshToken> business)
        {
            _business = business;
        }

        public void AddRefreshToken(RefreshToken refreshToken)
        {
            try
            {
                _business.Add(refreshToken);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public RefreshToken GetRefreshToken(int id)
        {
            try
            {
               return _business.Find(s => s.Id == id);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public RefreshToken GetRefreshToken(string token)
        {
            try
            {
                return _business.Find(s => s.Refreshtoken1 == token);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}