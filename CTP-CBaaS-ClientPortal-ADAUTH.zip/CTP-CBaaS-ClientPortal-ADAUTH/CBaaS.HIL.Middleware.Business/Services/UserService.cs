﻿using CBaaS.HIL.Common.CoreComponents.Repositories;
using CBaaS.HIL.Common.Entities.Models;
using CBaaS.HIL.Middleware.Business.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CBaaS.HIL.Middleware.Business.Services
{
    public class UserService : IUserService
    {
        private ICoreRepository<Users> _business;
        public UserService(ICoreRepository<Users> business)
        {
            _business = business;
        }
        public async Task<Users> GetAgentByUserId(string agentLoginId)
        {
            return await _business.FindAsync(s => 
            s.UserName == agentLoginId.Trim() && 
            s.IsActive == true);
        }
    }
}
