﻿using CBaaS.HIL.ClientPortal.Business.Services;
using Microsoft.Extensions.Configuration;
using Microsoft.Graph;
using Microsoft.IdentityModel.Clients.ActiveDirectory;
using System.Net.Http.Headers;
using System.Threading.Tasks;

namespace CBaaS.HIL.Common.Helper
{
    public class GraphAPIHelper
    {
        private static GraphServiceClient graphClient;
        private readonly IConfiguration _configuration;
        public GraphAPIHelper(IConfiguration configuration)
        {
            this._configuration = configuration;
        }
        
        public async Task<GraphServiceClient> GetGraphServiceClient()
        {
            // Get Access Token and Microsoft Graph Client using access token and microsoft graph v1.0 endpoint
            var delegateAuthProvider = await GetAuthProvider();
            // Initializing the GraphServiceClient
            var graphAPIEndpoint = $"{CommonConstant.GraphAPIUrl}{CommonConstant.GraphAPIVersion}";
            graphClient = new GraphServiceClient(graphAPIEndpoint, delegateAuthProvider);
            return graphClient;
        }
        private  async Task<DelegateAuthenticationProvider> GetAuthProvider()
        {
            var authority = $"{CommonConstant.GraphAPIAuthority}{CommonConstant.GraphAPITenantId}";
            AuthenticationContext authenticationContext = new AuthenticationContext(authority);          
            ClientCredential clientCred = new ClientCredential(CommonConstant.GraphAPIClientId, CommonConstant.GraphAPIClientSecret);
            // ADAL includes an in memory cache, so this call will only send a message to the server if the cached token is expired.
            AuthenticationResult authenticationResult = await authenticationContext.AcquireTokenAsync(CommonConstant.GraphAPIUrl, clientCred);
            var token = authenticationResult.AccessToken;
            var delegateAuthProvider = new DelegateAuthenticationProvider((requestMessage) =>
            {
                requestMessage.Headers.Authorization = new AuthenticationHeaderValue("bearer", token.ToString());
                return Task.FromResult(0);
            });
            return delegateAuthProvider;
        }
    }
}
