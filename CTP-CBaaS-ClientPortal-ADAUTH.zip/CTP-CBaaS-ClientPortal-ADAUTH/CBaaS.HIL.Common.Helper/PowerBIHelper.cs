﻿using CBaaS.HIL.ClientPortal.Business.Services;
using Microsoft.IdentityModel.Clients.ActiveDirectory;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;

namespace CBaaS.HIL.Common.Helper
{
    public class PowerBIHelper
    {
        public static async Task<string> GetPBIAccessToken()
        {
            try
            {
                HttpClient client = new HttpClient();

                var content = new FormUrlEncodedContent(new[]
                {
                  new KeyValuePair<string, string>("grant_type", CommonConstant.PBIGrantType),
                  new KeyValuePair<string, string>("username", CommonConstant.PBIMasterUserName),
                  new KeyValuePair<string, string>("password", CommonConstant.PBIMasterPassword),
                  new KeyValuePair<string, string>("client_id", CommonConstant.PBIAdClientId),
                  new KeyValuePair<string, string>("scope", CommonConstant.PBIScope),
                  new KeyValuePair<string, string>("resource",CommonConstant.PBIResource)
                });

                string accessToken =
                    await client.PostAsync(string.Format(CommonConstant.PBIMSLogInUrl, CommonConstant.PBIAdTenentId), content)
                   .ContinueWith<string>((response) =>
                   {
                       var tokenRes = JsonConvert.DeserializeObject<dynamic>(response.Result.Content.ReadAsStringAsync().Result);
                       return tokenRes == null ? null : tokenRes["access_token"].Value;
                   });
                return accessToken;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static async Task<string> GetPBISPNAccessToken()
        {
            try
            {
                // Authenticate using created credentials
                AuthenticationResult authenticationResult = null;
                // For app only authentication, we need the specific tenant id in the authority url
                var tenantSpecificURL = CommonConstant.PBIAuthorityUrl.Replace("common", CommonConstant.PBISPNTenentId);
                var authenticationContext = new AuthenticationContext(tenantSpecificURL);

                // Authentication using app credentials
                var credential = new ClientCredential(CommonConstant.PBISPNClientId, CommonConstant.PBISpnSecret);
                authenticationResult = await authenticationContext.AcquireTokenAsync(CommonConstant.PBIResource, credential);

                return authenticationResult.AccessToken;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

    }
}
