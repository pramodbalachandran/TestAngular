﻿using Microsoft.IdentityModel.Tokens;
using System;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography.X509Certificates;
using System.Text;

namespace CBaaS.HIL.Common.Helper
{
    public static class JWTWebToken
    {
        public static ClaimsPrincipal GetClaimsPrincipal(string token, byte[] data)
        {
            try
            {
                X509Certificate cert = new X509Certificate(data);
                SecurityKey DefaultX509Key_Public_2048 = new X509SecurityKey(new X509Certificate2(cert));
                SecurityToken validatedToken;
                TokenValidationParameters validationParameters = new TokenValidationParameters();
                validationParameters.ValidateIssuerSigningKey = true;
                validationParameters.IssuerSigningKey = DefaultX509Key_Public_2048;
                validationParameters.ValidateIssuer = false;
                validationParameters.ValidateAudience = false;
                ClaimsPrincipal principal = new JwtSecurityTokenHandler().ValidateToken(token, validationParameters, out validatedToken);
                return principal;
            }
            catch (Exception)
            {
                return null;
            }
        }

        public static string GenerateToken(string uniqueName, JWTTokenConfiguration configuration)
        {
            var token = new JwtSecurityToken(
                issuer: configuration.Issuer,
                audience: configuration.Audience,
                expires: DateTime.UtcNow.Add(configuration.Expiration),
                signingCredentials: GetCredentials(configuration.Key),
                claims: new Claim[]
                {
                    new Claim(ClaimTypes.Name, uniqueName),
                    new Claim(ClaimTypes.NameIdentifier, uniqueName)
                });

            return new JwtSecurityTokenHandler().WriteToken(token);
        }

        private static SigningCredentials GetCredentials(string asymetricKey)
        {
            var bytes = Encoding.ASCII.GetBytes(asymetricKey);
            var key = new SymmetricSecurityKey(bytes);
            return new SigningCredentials(key, SecurityAlgorithms.HmacSha256Signature);
        }

        public static ClaimsPrincipal GetPrincipalFromExpiredToken(string token, JWTTokenConfiguration tokenConfiguration)
        {
            var keyByteArray = Encoding.ASCII.GetBytes(tokenConfiguration.Key);
            var signingKey = new SymmetricSecurityKey(keyByteArray);

            var tokenValidationParameters = new TokenValidationParameters
            {
                ValidateAudience = false, //you might want to validate the audience and issuer depending on your use case
                ValidateIssuer = false,
                ValidateIssuerSigningKey = true,
                IssuerSigningKey = signingKey,
                ValidateLifetime = false //here we are saying that we don't care about the token's expiration date
            };

            var tokenHandler = new JwtSecurityTokenHandler();
            SecurityToken securityToken;
            var principal = tokenHandler.ValidateToken(token, tokenValidationParameters, out securityToken);
            var jwtSecurityToken = securityToken as JwtSecurityToken;
            if (jwtSecurityToken == null || principal == null)
                throw new SecurityTokenException("Invalid token");

            return principal;
        }

        public static bool IsTokenExpired(string token, string tokenConfigurationKey)
        {
            try
            {
                var keyByteArray = Encoding.ASCII.GetBytes(tokenConfigurationKey);
                var signingKey = new SymmetricSecurityKey(keyByteArray);

                var tokenValidationParameters = new TokenValidationParameters
                {
                    ValidateAudience = false, //you might want to validate the audience and issuer depending on your use case
                    ValidateIssuer = false,
                    ValidateIssuerSigningKey = true,
                    IssuerSigningKey = signingKey,
                    ValidateLifetime = true //here we are saying that we don't care about the token's expiration date
                };

                var tokenHandler = new JwtSecurityTokenHandler();
                SecurityToken securityToken;
                var principal = tokenHandler.ValidateToken(token, tokenValidationParameters, out securityToken);
                var jwtSecurityToken = securityToken as JwtSecurityToken;
                if (jwtSecurityToken == null || principal == null)
                {
                    return true;
                }
            }
            catch (SecurityTokenException)
            {
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return false;
        }
    }
}
