﻿using CBaaS.HIL.ClientPortal.Business.Interfaces;
using CBaaS.HIL.Common.CoreComponents.Repositories;
using CBaaS.HIL.Common.Entities.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;

namespace CBaaS.HIL.ClientPortal.Business.Services
{
    public class BotService : CoreRepository<BotUserConnection>, IBotService
    {
        DbContext _dbcontext;
        private IConfiguration _configuration;
        public BotService(IConfiguration configuration, DbContext dbcontext) : base(dbcontext)
        {
            _configuration = configuration;
            _dbcontext = dbcontext;
        }
        public virtual void AddConnectedBotUser(BotUserConnection botUserConnection)
        {
            _dbcontext.Add(botUserConnection);
        }
    }
}
