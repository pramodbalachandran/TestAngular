﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBaaS.HIL.ClientPortal.Business.Services
{
    public static class CommonEnum
    {
        public enum BotType
        {
            Internal,
            External
        }

        public enum ReportSource
        {
            AzureStorage,
            AzureSQLDB
        }

        public enum OfferingType
        {
            SimpleFAQ,
            AdvancedFAQ
        }

        public enum UserRoles
        {
            SuperAdmin,
            ChatbotAdmin,
            BusinessManager,
            Agent
        }
    }
}
