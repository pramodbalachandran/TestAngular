﻿using CBaaS.HIL.ClientPortal.Business.Interfaces;
using CBaaS.HIL.Common.CoreComponents.Repositories;
using CBaaS.HIL.Common.Data;
using CBaaS.HIL.Common.Entities.Models;
using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Transactions;


namespace CBaaS.HIL.ClientPortal.Business.Services
{
    public class BotConfigService : CoreRepository<BotConfig>, IBotConfigService
    {
        BaseContext _dbcontext;

        public BotConfigService(BaseContext dbcontext) : base(dbcontext)
        {
            _dbcontext = dbcontext;
        }

        /// <summary>
        /// Get BotConfig data for logged in user roles
        /// </summary>
        /// <returns>List<BotConfig></returns>
        public List<BotConfig> GetBotList(List<string> userDetails)
        {
            try
            {
                List<BotConfig> availableBots = new List<BotConfig>();
                var userRoles = userDetails[1].Split(Convert.ToChar(",")).ToList();
                if (userRoles.Contains(CommonEnum.UserRoles.SuperAdmin.ToString()))
                {
                    availableBots = _dbcontext.BotConfig.ToList();
                }
                else
                {
                    availableBots = (from u in _dbcontext.Users
                                     join ubr in _dbcontext.UserBotRoles
                                     on u.Id equals ubr.UserId
                                     join r in _dbcontext.Roles
                                     on ubr.RoleId equals r.Id
                                     join bc in _dbcontext.BotConfig
                                     on ubr.BotConfigId equals bc.Id
                                     where u.UserName.ToLower() == userDetails[0].ToLower()
                                     && userRoles.Contains(r.Role)
                                     && bc.Status.ToLower() == "active"
                                     select bc
                                 ).Distinct().ToList();
                }


                return availableBots;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        /// <summary>
        /// Get bot config data specific to logged in user email id
        /// </summary>
        /// <returns>List<BotConfig></returns>
        public List<BotConfig> GetBotConfigByUserId(string userEmailId)
        {
            try
            {
                var botConfigByUserId = (from u in _dbcontext.Users
                                         join ubr in _dbcontext.UserBotRoles
                                         on u.Id equals ubr.UserId
                                         join r in _dbcontext.Roles
                                         on ubr.RoleId equals r.Id
                                         join bc in _dbcontext.BotConfig
                                         on ubr.BotConfigId equals bc.Id
                                         where u.UserName.ToLower() == userEmailId.ToLower()
                                         && bc.Status.ToLower() == "active"
                                         select bc
                                ).Distinct().ToList();


                return botConfigByUserId;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        /// <summary>
        /// Get bot config data specific to logged in user id
        /// </summary>
        /// <returns>List<BotConfig></returns>
        public List<BotConfig> GetBotConfigByUserId(int userId)
        {
            try
            {
                var botConfigByUserId = (from u in _dbcontext.Users
                                         join ubr in _dbcontext.UserBotRoles
                                         on u.Id equals ubr.UserId
                                         join r in _dbcontext.Roles
                                         on ubr.RoleId equals r.Id
                                         join bc in _dbcontext.BotConfig
                                         on ubr.BotConfigId equals bc.Id
                                         where u.Id == userId
                                         && bc.Status.ToLower() == "active"
                                         select bc
                                ).Distinct().ToList();


                return botConfigByUserId;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        /// <summary>
        /// Get bot config data specific to bot config id
        /// </summary>
        /// <returns>BotConfig</returns>
        public BotConfig GetBotConfigById(int botConfigId)
        {
            try
            {
                var botConfigById = _dbcontext.BotConfig.FirstOrDefault(x => x.Id == botConfigId);

                return botConfigById;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Get list of all the bots in BotRegistration table
        /// </summary>
        /// <returns>IEnumerable<BotConfig></returns>
        public List<BotRegistration> GetAllRegisteredBotList(List<string> userDetails)
        {
            try
            {
                var userRoles = userDetails[1].Split(Convert.ToChar(",")).ToList();

                var registeredBots = (from u in _dbcontext.Users
                                      join ubr in _dbcontext.UserBotRoles
                                      on u.Id equals ubr.UserId
                                      join r in _dbcontext.Roles
                                      on ubr.RoleId equals r.Id
                                      join bc in _dbcontext.BotConfig
                                      on ubr.BotConfigId equals bc.Id
                                      join br in _dbcontext.BotRegistration
                                      on bc.Id equals br.BotConfigId
                                      where u.UserName.ToLower() == userDetails[0].ToLower()
                                      && userRoles.Contains(r.Role)
                                      && bc.Status.ToLower() == "active"
                                      select br
                                ).Distinct().ToList();


                return registeredBots;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        /// <summary>
        /// Get Bot Config data as per Bot Id
        /// </summary>
        /// <param name="botId"></param>
        /// <returns>BotConfig</returns>
        public BotConfig GetBotConfigById(Guid botId)
        {
            try
            {
                var botConfigData = (from bc in _dbcontext.BotConfig
                                     where bc.BotId == botId
                                     && bc.Status.ToLower() == "active"
                                     select new BotConfig
                                     {
                                         Id = bc.Id,
                                         BotId = bc.BotId,
                                         DisplayName = bc.DisplayName,
                                         ServiceLine = bc.ServiceLine
                                     }).FirstOrDefault();

                //var botConfigData = _dbcontext.BotConfig.Where(x => x.BotId == botId).Select(x => new
                //{
                //    x.Id,
                //    x.BotId,
                //    x.DisplayName,
                //    x.ServiceLine
                //});

                return botConfigData;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

    }
}
