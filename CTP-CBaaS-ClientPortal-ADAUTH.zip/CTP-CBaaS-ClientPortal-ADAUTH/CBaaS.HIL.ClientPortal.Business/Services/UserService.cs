﻿using CBaaS.HIL.ClientPortal.Business.Interfaces;
using CBaaS.HIL.Common.CoreComponents.Repositories;
using CBaaS.HIL.Common.Data;
using CBaaS.HIL.Common.Entities.Models;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.Transactions;

namespace CBaaS.HIL.ClientPortal.Business.Services
{
    public class UserService : CoreRepository<UserBotRoles>, IUserService
    {
        BaseContext _dbcontext;

        public UserService(BaseContext dbcontext) : base(dbcontext)
        {
            _dbcontext = dbcontext;
        }

        /// <summary>
        /// Returns user roles as per user id
        /// </summary>
        /// <param name="emailId"></param>
        /// <returns>List<string></returns>
        public List<string> GetUserRolesById(int id)
        {
            var userRoles = (from u in _dbcontext.Users
                             join ur in _dbcontext.UserBotRoles
                             on u.Id equals ur.UserId
                             join r in _dbcontext.Roles
                             on ur.RoleId equals r.Id
                             where u.Id == id
                             && u.IsActive == true
                             && (ur.ToDate == null || ur.ToDate >= DateTime.Now)
                             select r.Role).Distinct().ToList();

            return userRoles;
        }

        /// <summary>
        /// Returns user as per user email id
        /// </summary>
        /// <param name="emailId"></param>
        /// <returns>List<string></returns>
        public Users GetUserByEmail(string emailId)
        {
            var user = (from u in _dbcontext.Users
                        where u.UserName.ToLower() == emailId.ToLower()
                        && u.IsActive == true
                        select u).FirstOrDefault();

            return user;
        }

        /// <summary>
        /// Returns user as per user email id
        /// </summary>
        /// <param name="emailId"></param>
        /// <returns>List<string></returns>
        public Users GetUserByUserId(int userId)
        {
            var user = (from u in _dbcontext.Users
                        where u.Id == userId
                        select u).FirstOrDefault();

            return user;
        }

        /// <summary>
        /// Returns user roles as per user email id
        /// </summary>
        /// <param name="emailId"></param>
        /// <returns>List<string></returns>
        public List<string> GetUserRolesByEmail(string emailId)
        {
            var userRoles = (from u in _dbcontext.Users
                             join ur in _dbcontext.UserBotRoles
                             on u.Id equals ur.UserId
                             join r in _dbcontext.Roles
                             on ur.RoleId equals r.Id
                             where u.UserName.ToLower() == emailId.ToLower()
                             && u.IsActive == true
                             && (ur.ToDate == null || ur.ToDate >= DateTime.Now)
                             select r.Role).Distinct().ToList();

            return userRoles;
        }

        /// <summary>
        /// Returns user bot roles as per user email id
        /// </summary>
        /// <param name="emailId"></param>
        /// <param name="botId"></param>
        /// <returns></returns>
        public List<string> GetUserBotRoles(string emailId, int botId)
        {
            var userBotRoles = (from u in _dbcontext.Users
                                join ur in _dbcontext.UserBotRoles
                                on u.Id equals ur.UserId
                                join r in _dbcontext.Roles
                                on ur.RoleId equals r.Id
                                where u.UserName.ToLower() == emailId.ToLower()
                                && ur.BotConfigId == botId
                                && u.IsActive == true
                                && (ur.ToDate == null || ur.ToDate >= DateTime.Now)
                                select r.Role).Distinct().ToList();

            return userBotRoles;
        }

        /// <summary>
        /// Add new user bot roles in  UserBotRoles table
        /// </summary>
        /// <param name="userRolesDetails"></param>
        public string AddUserBotRoles(UserRolesDetails userRolesDetails, string loggedInUserId)
        {
            try
            {
                //check if user exists, if not then add
                var userId = AddUserIfNotExist(userRolesDetails.Username, userRolesDetails.IsExternal, loggedInUserId);
                if (userId == 0)
                {
                    return CommonConstant.InvalidUser;
                }
                List<UserRolesDetails> userBotRolesList = new List<UserRolesDetails>();

                var role = _dbcontext.Roles.FirstOrDefault(x => x.Role == userRolesDetails.Role.Replace(" ", ""));
                if (role != null)
                {
                    using (TransactionScope scope = new TransactionScope())
                    {
                        var existingUserRole = _dbcontext.UserBotRoles.FirstOrDefault(x => x.UserId == userId
                                                                     && x.RoleId == role.Id
                                                                     && x.BotConfigId == userRolesDetails.BotConfigId
                                                                     && (x.ToDate == null || x.ToDate >= DateTime.Now));
                        if (existingUserRole == null)
                        {
                            UserBotRoles userBotRoles = new UserBotRoles();
                            userBotRoles.UserId = userId;
                            userBotRoles.RoleId = role.Id;
                            userBotRoles.BotConfigId = userRolesDetails.BotConfigId;
                            userBotRoles.FromDate = DateTime.Now;

                            _dbcontext.UserBotRoles.Add(userBotRoles);
                            _dbcontext.SaveChanges();

                            JsonSerializerSettings settings = new JsonSerializerSettings()
                            {
                                ReferenceLoopHandling = ReferenceLoopHandling.Ignore
                            };
                            ActivityLog activityLog = new ActivityLog()
                            {
                                Action = "Add",
                                RefId = userBotRoles.Id,
                                Module = "User Bot Roles",
                                Value = JsonConvert.SerializeObject(userBotRoles, settings),
                                PerformedBy = loggedInUserId,
                                PerformedOn = DateTime.UtcNow
                            };
                            _dbcontext.ActivityLog.Add(activityLog);
                            _dbcontext.SaveChanges();
                        }
                        scope.Complete();
                    }
                }
                return CommonConstant.Success;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Add new user in Users table if not exists
        /// </summary>
        /// <param name="userName"></param>
        /// <returns></returns>
        public int AddUserIfNotExist(string userName, bool isExternal, string loggedInUserId)
        {
            var user = _dbcontext.Users.FirstOrDefault(x => x.UserName.ToLower() == userName.ToLower() && x.IsActive == true);
            if (user == null)
            {
                if (isExternal)
                {
                    return 0;
                }
                else
                {
                    Users newUser = new Users();
                    newUser.UserName = userName;
                    var userDetails = userName.Split(".").ToList();
                    newUser.FirstName = userDetails[0];
                    newUser.LastName = Regex.Replace(userDetails[1].Split("@")[0], @"\d", "");
                    newUser.NickName = userDetails[0];
                    newUser.IsActive = true;
                    newUser.IsExternal = false;
                    _dbcontext.Users.Add(newUser);
                    _dbcontext.SaveChanges();

                    JsonSerializerSettings settings = new JsonSerializerSettings()
                    {
                        ReferenceLoopHandling = ReferenceLoopHandling.Ignore
                    };
                    ActivityLog activityLog = new ActivityLog()
                    {
                        Action = "Add",
                        RefId = newUser.Id,
                        Module = "Internal User",
                        Value = JsonConvert.SerializeObject(newUser, settings),
                        PerformedBy = loggedInUserId,
                        PerformedOn = DateTime.UtcNow
                    };
                    _dbcontext.ActivityLog.Add(activityLog);
                    _dbcontext.SaveChanges();

                    return newUser.Id;
                }
            }
            else
            {
                return user.Id;
            }
        }

        /// <summary>
        /// Delete existing user role data from UserBotRoles table
        /// </summary>
        /// <param name="userRolesDetails"></param>
        public void DeleteUserRole(UserRolesDetails userRolesDetails, string loggedInUserId)
        {
            try
            {
                using (TransactionScope scope = new TransactionScope())
                {
                    var userRoleToDelete = _dbcontext.UserBotRoles.FirstOrDefault(x => x.UserId == userRolesDetails.UserId
                                                                     && x.RoleId == userRolesDetails.RoleId
                                                                     && x.BotConfigId == userRolesDetails.BotConfigId
                                                                     && (x.ToDate == null || x.ToDate >= DateTime.Now));
                    if (userRoleToDelete != null)
                    {
                        _dbcontext.UserBotRoles.Remove(userRoleToDelete);

                        JsonSerializerSettings settings = new JsonSerializerSettings()
                        {
                            ReferenceLoopHandling = ReferenceLoopHandling.Ignore
                        };
                        ActivityLog activityLog = new ActivityLog()
                        {
                            Action = "Delete",
                            RefId = userRoleToDelete.Id,
                            Module = "User Bot Roles",
                            Value = JsonConvert.SerializeObject(userRoleToDelete, settings),
                            PerformedBy = loggedInUserId,
                            PerformedOn = DateTime.UtcNow
                        };
                        _dbcontext.ActivityLog.Add(activityLog);
                        _dbcontext.SaveChanges();
                    }
                    scope.Complete();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        /// <summary>
        /// On BotRegistration delete - Delete existing users role data from UserBotRoles table
        /// </summary>
        /// <param name="botConfigId"></param>
        public void DeleteBotRoles(long botConfigId, string loggedInUserId)
        {
            try
            {
                using (TransactionScope scope = new TransactionScope())
                {
                    var botRolesToDelete = _dbcontext.UserBotRoles.Where(x => x.BotConfigId == botConfigId && x.BotConfigId != 0);
                    if (botRolesToDelete != null && botRolesToDelete.Any())
                    {
                        _dbcontext.UserBotRoles.RemoveRange(botRolesToDelete);
                        
                        JsonSerializerSettings settings = new JsonSerializerSettings()
                        {
                            ReferenceLoopHandling = ReferenceLoopHandling.Ignore
                        };
                        ActivityLog activityLog = new ActivityLog()
                        {
                            Action = "Delete",
                            RefId = botRolesToDelete.FirstOrDefault().Id,
                            Module = "User Bot Roles",
                            Value = JsonConvert.SerializeObject(botRolesToDelete, settings),
                            PerformedBy = loggedInUserId,
                            PerformedOn = DateTime.UtcNow
                        };
                        _dbcontext.ActivityLog.Add(activityLog);
                        _dbcontext.SaveChanges();
                    }
                    scope.Complete();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        /// <summary>
        /// On user delete - Delete existing users role data from UserBotRoles table
        /// </summary>
        /// <param name="userId"></param>
        public void DeleteUserRoles(int userId, string loggedInUserId)
        {
            try
            {
                using (TransactionScope scope = new TransactionScope())
                {
                    var userRolesToDelete = _dbcontext.UserBotRoles.Where(x => x.UserId == userId);
                    if (userRolesToDelete != null && userRolesToDelete.Any())
                    {
                        _dbcontext.UserBotRoles.RemoveRange(userRolesToDelete);
                        
                        JsonSerializerSettings settings = new JsonSerializerSettings()
                        {
                            ReferenceLoopHandling = ReferenceLoopHandling.Ignore
                        };
                        ActivityLog activityLog = new ActivityLog()
                        {
                            Action = "Delete",
                            RefId = userRolesToDelete.FirstOrDefault().UserId,
                            Module = "User Bot Roles",
                            Value = JsonConvert.SerializeObject(userRolesToDelete, settings),
                            PerformedBy = loggedInUserId,
                            PerformedOn = DateTime.UtcNow
                        };
                        _dbcontext.ActivityLog.Add(activityLog);
                        _dbcontext.SaveChanges();
                    }
                    scope.Complete();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        /// <summary>
        /// Get all roles from Roles table
        /// </summary>
        /// <param name="userDetails"></param>
        /// <returns></returns>
        public List<Roles> GetRoles()
        {
            try
            {
                List<Roles> roles = new List<Roles>();
                roles = _dbcontext.Roles.Where(x => x.Role != CommonEnum.UserRoles.SuperAdmin.ToString()).ToList();

                return roles;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Get all USer Roles from UserBotRoles table
        /// </summary>
        /// <param name="botConfigId"></param>
        /// <returns></returns>
        public List<UserRolesDetails> GetAllUsersAllRoles(long botConfigId)
        {
            try
            {
                var userBotRolesList = (from ubr in _dbcontext.UserBotRoles
                                        join u in _dbcontext.Users
                                        on ubr.UserId equals u.Id
                                        join r in _dbcontext.Roles
                                        on ubr.RoleId equals r.Id
                                        where ubr.BotConfigId == botConfigId
                                        && u.IsActive == true
                                        //&& ubr.FromDate < DateTime.Now
                                        && (ubr.ToDate == null || ubr.ToDate >= DateTime.Now)
                                        select new UserRolesDetails
                                        {
                                            Username = u.UserName,
                                            Role = r.DisplayName,
                                            UserId = ubr.UserId,
                                            RoleId = ubr.RoleId,
                                            BotConfigId = ubr.BotConfigId,
                                            FromDate = ubr.FromDate,
                                            ToDate = ubr.ToDate
                                        }).Distinct().ToList();

                return userBotRolesList;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        /// <summary>
        /// Add new User 
        /// </summary>
        /// <param name="user"></param>
        public string AddUpdateUserRegistration(Users user, string loggedInUserId)
        {
            try
            {
                string msg = string.Empty;
                using (TransactionScope scope = new TransactionScope())
                {
                    //Internal & External user update 
                    if (user.Id != 0)
                    {
                        var existingUser = _dbcontext.Users.FirstOrDefault(x => x.Id.Equals(user.Id));
                        if (existingUser != null)
                        {
                            existingUser.UserName = user.UserName;
                            existingUser.FirstName = user.FirstName;
                            existingUser.LastName = user.LastName;
                            if (string.IsNullOrEmpty(user.NickName))
                                existingUser.NickName = user.FirstName;
                            else
                                existingUser.NickName = user.NickName;
                            existingUser.Company = user.Company;
                            existingUser.IsExternal = user.IsExternal;
                            existingUser.IsActive = user.IsActive;
                            _dbcontext.Users.Update(existingUser);

                            msg = "Success";
                            JsonSerializerSettings settings = new JsonSerializerSettings()
                            {
                                ReferenceLoopHandling = ReferenceLoopHandling.Ignore
                            };
                            ActivityLog activityLog = new ActivityLog()
                            {
                                Action = "Edit",
                                RefId = user.Id,
                                Module = user.IsExternal ? "External User" : "Internal User",
                                Value = JsonConvert.SerializeObject(user, settings),
                                PerformedBy = loggedInUserId,
                                PerformedOn = DateTime.UtcNow
                            };
                            _dbcontext.ActivityLog.Add(activityLog);
                            _dbcontext.SaveChanges();
                        }
                    }
                    //Enternal user registration
                    else
                    {
                        var existingUser = _dbcontext.Users.FirstOrDefault(u => u.UserName.ToLower() == user.UserName.ToLower());
                        if (existingUser == null)
                        {
                            if (string.IsNullOrEmpty(user.NickName))
                                user.NickName = user.FirstName;
                            _dbcontext.Users.Add(user);
                            _dbcontext.SaveChanges();
                            msg = "Success";

                            var newId = _dbcontext.Users.Select(x => x.Id).Max();
                            JsonSerializerSettings settings = new JsonSerializerSettings()
                            {
                                ReferenceLoopHandling = ReferenceLoopHandling.Ignore
                            };
                            ActivityLog activityLog = new ActivityLog()
                            {
                                Action = "Add",
                                RefId = newId,
                                Module = "External User",
                                Value = JsonConvert.SerializeObject(user, settings),
                                PerformedBy = loggedInUserId,
                                PerformedOn = DateTime.UtcNow
                            };
                            _dbcontext.ActivityLog.Add(activityLog);
                            _dbcontext.SaveChanges();
                        }
                        else
                        {
                            msg = "User Already Exists";
                        }
                    }
                    scope.Complete();
                }
                return msg;

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Change isActive status to false on User deletion
        /// </summary>
        /// <param name="userId"></param>
        public void DeleteUser(int userId, string loggedInUserId)
        {
            try
            {
                using (TransactionScope scope = new TransactionScope())
                {
                    var user = _dbcontext.Users.FirstOrDefault(x => x.Id == userId);

                    if (user != null)
                    {
                        user.IsActive = false;
                        JsonSerializerSettings settings = new JsonSerializerSettings()
                        {
                            ReferenceLoopHandling = ReferenceLoopHandling.Ignore
                        };
                        ActivityLog activityLog = new ActivityLog()
                        {
                            Action = "Edit",
                            RefId = user.Id,
                            Module = user.IsExternal ? "External User" : "Internal User",
                            Value = JsonConvert.SerializeObject(user, settings),
                            PerformedBy = loggedInUserId,
                            PerformedOn = DateTime.UtcNow
                        };
                        _dbcontext.ActivityLog.Add(activityLog);
                        _dbcontext.SaveChanges();

                    }
                    scope.Complete();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<UserVM> GetExternalUsers(string user)
        {
            try
            {
                var userList = _dbcontext.Users.Select(m => new UserVM
                {
                    EmailAddress = m.UserName,
                    Fullname = m.FirstName + " " + m.LastName,
                    isExternal = m.IsExternal,
                    isActive = m.IsActive
                })
                .Where(m => m.Fullname.StartsWith(user) && m.isExternal && m.isActive).Take(20).ToList();

                return userList;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public List<Users> GetAllUsers()
        {
            try
            {
                var userList = _dbcontext.Users.Where(x => x.IsActive).ToList();

                return userList;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public UserRolesVM GetUserRolesFromSession(string userDetails)
        {
            try
            {
                var userRolesDetails = new UserRolesVM();
                userRolesDetails = JsonConvert.DeserializeObject<UserRolesVM>(userDetails);
                return userRolesDetails;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


    }
}
