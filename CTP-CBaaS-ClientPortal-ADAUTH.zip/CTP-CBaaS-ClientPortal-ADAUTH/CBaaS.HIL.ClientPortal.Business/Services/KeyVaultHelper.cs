﻿using CBaaS.HIL.ClientPortal.Business.Interfaces;
using Microsoft.Extensions.Configuration;
using System.Threading.Tasks;

namespace CBaaS.HIL.ClientPortal.Business.Services
{
    public class KeyVaultHelper : IKeyVaultHelper
    {
        public IConfiguration Configuration { get; }
        public KeyVaultHelper(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public async Task ReadApplicationConfiguration()
        {
            await Task.Run(() => CommonConstant.ClientId = Configuration.GetValue<string>("IdaasClientId"));
            await Task.Run(() => CommonConstant.TenantId = Configuration.GetValue<string>("Tenant"));
            await Task.Run(() => CommonConstant.ClientPortalIdaasClientId = Configuration.GetValue<string>("ClientPortal-IdaasClientId"));
            await Task.Run(() => CommonConstant.ClientPortalIdaasClientSecret = Configuration.GetValue<string>("ClientPortal-IdaasClientSecret"));
            await Task.Run(() => CommonConstant.ClientPortalIdaasIssuer = Configuration.GetValue<string>("ClientPortal-IdaasIssuer"));
            await Task.Run(() => CommonConstant.ClientPortalRedirectURL = Configuration.GetValue<string>("ClientPortal-RedirectURL"));
            await Task.Run(() => CommonConstant.HILURL = Configuration.GetValue<string>("HILURL"));
            
            //Power BI 
            await Task.Run(() => CommonConstant.PBIMasterUserName = Configuration.GetValue<string>("PBIMasterUserName"));
            await Task.Run(() => CommonConstant.PBIMasterPassword = Configuration.GetValue<string>("PBIMasterPassword"));
            await Task.Run(() => CommonConstant.PBIAdClientId = Configuration.GetValue<string>("PBIAdClientId"));
            await Task.Run(() => CommonConstant.PBIAdTenentId = Configuration.GetValue<string>("PBIAdTenentId"));
            await Task.Run(() => CommonConstant.PBIWorkspaceId = Configuration.GetValue<string>("PBIWorkspaceId"));
            await Task.Run(() => CommonConstant.PBISpnSecret = Configuration.GetValue<string>("PBISpnSecret"));
            await Task.Run(() => CommonConstant.PBISPNTenentId = Configuration.GetValue<string>("PBISPNTenentId"));
            await Task.Run(() => CommonConstant.PBISPNClientId = Configuration.GetValue<string>("PBISPNClientId"));

            await Task.Run(() => CommonConstant.SignalRAuthEncryptionKey = Configuration.GetValue<string>("SignalRAuthEncyptionSecretKey"));


            //Graph API
            // To get Prod users in dev, use Prod configurations
            await Task.Run(() => CommonConstant.UsePRODGraphAPIConfigInDEV = Configuration.GetValue<string>("UsePRODGraphAPIConfigInDEV"));
            if (CommonConstant.UsePRODGraphAPIConfigInDEV == null || CommonConstant.UsePRODGraphAPIConfigInDEV.ToLower() == "false")
            {
                await Task.Run(() => CommonConstant.GraphAPIAuthority = Configuration.GetValue<string>("GraphAPIAuthority"));
                await Task.Run(() => CommonConstant.GraphAPITenantId = Configuration.GetValue<string>("GraphAPITenantId"));
                await Task.Run(() => CommonConstant.GraphAPIClientId = Configuration.GetValue<string>("VaultClientId")); 
                await Task.Run(() => CommonConstant.GraphAPIClientSecret = Configuration.GetValue<string>("ClientSecret"));

            }
            else
            {
                await Task.Run(() => CommonConstant.GraphAPIAuthority = Configuration.GetValue<string>("PRODGraphAPIAuthority")); 
                await Task.Run(() => CommonConstant.GraphAPITenantId = Configuration.GetValue<string>("PRODGraphAPITenantId")); 
                await Task.Run(() => CommonConstant.GraphAPIClientId = Configuration.GetValue<string>("PRODGraphAPIVaultClientId")); 
                await Task.Run(() => CommonConstant.GraphAPIClientSecret = Configuration.GetValue<string>("PRODGraphAPIClientSecret"));

            }
        }
    }
}
