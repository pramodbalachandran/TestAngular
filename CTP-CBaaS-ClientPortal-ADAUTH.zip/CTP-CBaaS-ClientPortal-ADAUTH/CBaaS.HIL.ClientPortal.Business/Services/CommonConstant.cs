﻿namespace CBaaS.HIL.ClientPortal.Business.Services
{
    public static class CommonConstant
    {
        #region KeyVault secrets
        public static string ClientId { get; set; }
        public static string TenantId { get; set; }
        public static string ClientPortalIdaasClientId { get; set; }
        public static string ClientPortalIdaasClientSecret { get; set; }
        public static string ClientPortalIdaasIssuer { get; set; }
        public static string ClientPortalRedirectURL { get; set; }
        public static string SignalRAuthEncryptionKey { get; set; }
        public static string GraphAPIAuthority { get; set; }
        public static string GraphAPITenantId { get; set; }
        public static string HILURL { get; set; }

        public static string UsePRODGraphAPIConfigInDEV { get; set; }
        public static string GraphAPIClientId { get; set; }
        public static string GraphAPIClientSecret { get; set; }

        //Power BI Constant

        public static string PBIMasterUserName { get; set; }
        public static string PBIMasterPassword { get; set; }
        public static string PBISpnSecret { get; set; }
        public static string PBIWorkspaceId { get; set; }
        public static string PBIAdClientId { get; set; }
        public static string PBIAdTenentId { get; set; }
        public static string PBISPNTenentId { get; set; }
        public static string PBISPNClientId { get; set; }

        #endregion

        #region String Constants
        public const string IDAASCertificate = "IDAASCertificate.crt";
        public const string Certificates = "certificates";
        public const string Authorization = "Authorization";
        public const string EmailAddress = "EmailAddress";
        public const string PreferredUsername = "preferred_username";
        public const string Bearer = "Bearer ";
        public const string ValidationSuccessful = "Validation successful";
        //public const string GraphAPIUrl = "https://graph.windows.net/";
        public const string GraphAPIUrl = "https://graph.microsoft.com/";
        public const string GraphAPIVersion = "v1.0";
        public const string Success = "Success";

        #region Cache keys
        public const string CertificateData = "CertificateData";
        public const string UserEmailId = "userEmailId";
        #endregion
        #region User Roles
        public const string Agent = "Agent";
        public const string ChatbotAdmin = "ChatbotAdmin";
        public const string SuperAdmin = "SuperAdmin";
        public const string BusinessManager = "BusinessManager";
        #endregion       
        #region IDaaS Url properties
        public const string GrantType = "grant_type";
        public const string AuthorizationCode = "authorization_code";
        public const string ClientSecret = "client_secret";
        public const string RedirectUri = "redirect_uri";
        public const string Code = "code";
        #endregion
        #region Error Messages
        public const string UnauthorizedMsg = "Unauthorized Request";
        public const string InValidToken = "Invalid Access Token";
        public const string GenericErrorMsg = "Something went wrong";
        public const string NullMsg = "Null values inserted";
        public const string InvalidBotType = "Invalid Bot Type";
        public const string InvalidReportSource = "Invalid Report Source";
        public const string InvalidOfferingType = "Invalid Offering Type";
        public const string InvalidBotId = "Invalid Bot Id";
        public const string DuplicateBotRegistration = "Bot already registered";
        public const string InvalidConnectionString = "Invalid connection string, please update valid connection string in database";
        public const string UserRoleAlreadyExist = "User Role already exists";
        public const string InvalidRole = "Invalid Role";
        public const string NoBotsFound = "No Bots found!";
        public const string BotDoesNotExist = "Bot doesn't exist!";
        public const string BotRegistrationModelInvalid = "Bot Registration Model is invalid!";
        public const string AccessCodeNull = "Access code is null or empty";
        public const string DuplicateUser = "User Already Exists";
        public const string InvalidUser = "User does not exist";
        #endregion

        #region Power BI
        public static string PBIResource = "https://analysis.windows.net/powerbi/api";
        public static string PBIScope = "openid";
        public static string PBIGrantType = "password";
        public static string PBIAPIUrl = "https://api.powerbi.com/";
        public static string PBIMSLogInUrl = "https://login.microsoftonline.com/{0}/oauth2/token";
        public static string PBIAuthorityUrl = "https://login.microsoftonline.com/common/";
        public static string ServicePrincipal = "ServicePrincipal";
        #endregion

        #endregion
    }
}
