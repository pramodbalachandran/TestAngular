﻿using CBaaS.HIL.ClientPortal.Business.Interfaces;
using Microsoft.Extensions.Caching.Memory;
using System;
using System.Collections.Generic;
using System.Text;

namespace CBaaS.HIL.ClientPortal.Business.Services
{
    public class CacheService : ICacheService
    {
        private readonly IMemoryCache _cache;

        public CacheService(IMemoryCache cache)
        {
            this._cache = cache;
        }

        public string GetCacheValue(string key)
        {
            var cacheValue = _cache.Get<string>(key);
            return cacheValue;
        }

        public byte[] GetCacheByteValue(string key)
        {
            var cacheValue = _cache.Get<byte[]>(key);
            return cacheValue;
        }

        public void SetCacheValue(string key, string value)
        {
            _cache.Set<string>(key, value, TimeSpan.FromMinutes(60));
        }

        public void SetCacheByteValue(string key, byte[] value)
        {
            _cache.Set<byte[]>(key, value, TimeSpan.FromMinutes(60));
        }

        public void SetCacheObjectValue(string key, object value)
        {
            _cache.Set<object>(key, value);
        }

        public object GetCacheObjectValue(string key)
        {
            var cacheValue = _cache.Get<object>(key);
            return cacheValue;
        }

        public void RemoveKey(string key)
        {
            _cache.Remove(key);            
        }
    }
}
