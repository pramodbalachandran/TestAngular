﻿using CBaaS.HIL.ClientPortal.Business.Interfaces;
using CBaaS.HIL.Common.CoreComponents.Repositories;
using CBaaS.HIL.Common.Data;
using CBaaS.HIL.Common.Entities.Models;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using Microsoft.WindowsAzure.Storage;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Transactions;

namespace CBaaS.HIL.ClientPortal.Business.Services
{
    public class BotRegistrationService : CoreRepository<BotRegistration>, IBotRegistrationService
    {
        BaseContext _dbcontext;
        private readonly IConfiguration _configuration;

        public BotRegistrationService(BaseContext dbcontext, IConfiguration configuration) : base(dbcontext)
        {
            _dbcontext = dbcontext;
            _configuration = configuration;
        }
        /// <summary>
        /// Get all registered bots list for logged in user, from BotRegistration table
        /// </summary>
        /// <returns>List<BotRegistration></returns>
        public List<BotDetails> GetAllAccessedBotList(UserRolesVM userRoles)
        {
            try
            {
                List<BotDetails> botDetails = new List<BotDetails>();
                if (userRoles.roles.Contains(CommonEnum.UserRoles.SuperAdmin.ToString()))
                {
                    botDetails = (from bc in _dbcontext.BotConfig
                                  join br in _dbcontext.BotRegistration
                                  on bc.Id equals br.BotConfigId
                                  where br.IsActive == true
                                  && bc.Status.ToLower() == "active"
                                  select new BotDetails
                                  {
                                      BotConfigId = br.BotConfigId,
                                      DisplayName = bc.DisplayName,
                                      ReportId = br.ReportId,
                                      ServiceLine = bc.ServiceLine,
                                      BotRegistrationId = br.Id,
                                      CustomerContact = br.CustomerContact,
                                      BotType = br.BotType,
                                      OfferingType = br.OfferingType,
                                      BotId = bc.BotId
                                  }
                                 ).Distinct().ToList();
                }
                else
                {
                    botDetails = (from u in _dbcontext.Users
                                  join ubr in _dbcontext.UserBotRoles
                                  on u.Id equals ubr.UserId
                                  join r in _dbcontext.Roles
                                  on ubr.RoleId equals r.Id
                                  join bc in _dbcontext.BotConfig
                                  on ubr.BotConfigId equals bc.Id
                                  join br in _dbcontext.BotRegistration
                                  on bc.Id equals br.BotConfigId
                                  where u.UserName.ToLower() == userRoles.emailId.ToLower()
                                  && userRoles.roles.Contains(r.Role)
                                  && r.Role != "Agent"
                                  && br.IsActive == true
                                  && bc.Status.ToLower() == "active"
                                  select new BotDetails
                                  {
                                      BotConfigId = br.BotConfigId,
                                      DisplayName = bc.DisplayName,
                                      ReportId = br.ReportId,
                                      ServiceLine = bc.ServiceLine,
                                      BotRegistrationId = br.Id,
                                      CustomerContact = br.CustomerContact,
                                      BotType = br.BotType,
                                      OfferingType = br.OfferingType,
                                      BotId = bc.BotId
                                  }

                                 ).Distinct().ToList();
                }

                return botDetails;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        /// <summary>
        /// Get all registered bots list for logged in user, from BotRegistration table
        /// </summary>
        /// <returns>List<BotRegistration></returns>
        public List<BotDetails> GetAllBotsList(UserRolesVM userRoles)
        {
            try
            {
                List<BotDetails> botDetails = new List<BotDetails>();
                if (userRoles.roles.Contains(CommonEnum.UserRoles.SuperAdmin.ToString()))
                {
                    botDetails = (from bc in _dbcontext.BotConfig
                                  join br in _dbcontext.BotRegistration
                                  on bc.Id equals br.BotConfigId
                                  where br.IsActive == true
                                  && bc.Status.ToLower() == "active"
                                  select new BotDetails
                                  {
                                      BotConfigId = br.BotConfigId,
                                      DisplayName = bc.DisplayName,
                                      ReportId = br.ReportId,
                                      ServiceLine = bc.ServiceLine,
                                      BotRegistrationId = br.Id,
                                      CustomerContact = br.CustomerContact,
                                      BotType = br.BotType,
                                      ReportSource = br.ReportSource,
                                      ReportConnectionString = br.ReportConnectionString,
                                      OfferingType = br.OfferingType,
                                      BotId = bc.BotId
                                  }
                                 ).Distinct().ToList();
                }
                else
                {
                    botDetails = (from u in _dbcontext.Users
                                  join ubr in _dbcontext.UserBotRoles
                                  on u.Id equals ubr.UserId
                                  join r in _dbcontext.Roles
                                  on ubr.RoleId equals r.Id
                                  join bc in _dbcontext.BotConfig
                                  on ubr.BotConfigId equals bc.Id
                                  join br in _dbcontext.BotRegistration
                                  on bc.Id equals br.BotConfigId
                                  where u.UserName.ToLower() == userRoles.emailId.ToLower()
                                  && userRoles.roles.Contains(r.Role)
                                  && r.Role != "Agent"
                                  && br.IsActive == true
                                  && bc.Status.ToLower() == "active"
                                  select new BotDetails
                                  {
                                      BotConfigId = br.BotConfigId,
                                      DisplayName = bc.DisplayName,
                                      ReportId = br.ReportId,
                                      ServiceLine = bc.ServiceLine,
                                      BotRegistrationId = br.Id,
                                      CustomerContact = br.CustomerContact,
                                      BotType = br.BotType,
                                      ReportSource = br.ReportSource,
                                      ReportConnectionString = br.ReportConnectionString,
                                      OfferingType = br.OfferingType,
                                      BotId = bc.BotId
                                  }

                                 ).Distinct().ToList();
                }

                return botDetails;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        /// <summary>
        /// Get registered bots list by bot config id from BotRegistration table
        /// </summary>
        /// <returns>List<BotRegistration></returns>
        public List<BotRegistration> GetRegisteredBotById(long botConfigId)
        {
            try
            {
                var registeredBotById = _dbcontext.BotRegistration.Where(x => x.BotConfigId == botConfigId && x.IsActive == true).ToList();

                return registeredBotById;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        /// <summary>
        /// Get registered bots list by Id, from BotRegistration table
        /// </summary>
        /// <returns>IEnumerable<BotConfig></returns>
        public List<BotRegistration> GetRegisteredBotById(int botRegistrationId)
        {
            try
            {
                var registeredBotById = _dbcontext.BotRegistration.Where(x => x.Id == botRegistrationId && x.IsActive == true).ToList();

                return registeredBotById;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        /// <summary>
        /// Get registered bot details by Id, from BotRegistration table
        /// </summary>
        /// <returns>IEnumerable<BotConfig></returns>
        public BotDetails GetRegisteredBotInfo(int botRegistrationId)
        {
            try
            {
                var registeredBotInfo = (from br in _dbcontext.BotRegistration
                                         join bc in _dbcontext.BotConfig
                                         on br.BotConfigId equals bc.Id
                                         where br.Id == botRegistrationId
                                         && bc.Status.ToLower() == "active"
                                         select new BotDetails
                                         {
                                             BotConfigId = br.BotConfigId,
                                             DisplayName = bc.DisplayName,
                                             ServiceLine = bc.ServiceLine,
                                             BotRegistrationId = br.Id,
                                             CustomerContact = br.CustomerContact,
                                             BotType = br.BotType,
                                             OfferingType = br.OfferingType.Trim(),
                                             BotId = bc.BotId,
                                             ReportId = br.ReportId
                                         }).FirstOrDefault();

                return registeredBotInfo;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        /// <summary>
        /// Add new Bot Registration or update existing
        /// </summary>
        /// <param name="botRegistrationDetails"></param>
        public void AddUpdateBotRegistration(BotRegistration botRegistrationDetails, string loggedInUserId)
        {
            try
            {
                using (TransactionScope scope = new TransactionScope())
                {
                    botRegistrationDetails.ReportSource = CommonEnum.ReportSource.AzureStorage.ToString();
                    botRegistrationDetails.ReportConnectionString = string.Empty;
                    botRegistrationDetails.OfferingType = botRegistrationDetails.OfferingType.Trim();
                    if (botRegistrationDetails.Id != 0)
                    {
                        var existingBot = _dbcontext.BotRegistration.FirstOrDefault(x => x.Id.Equals(botRegistrationDetails.Id));
                        if (existingBot != null)
                        {
                            existingBot.BotConfigId = botRegistrationDetails.BotConfigId;
                            existingBot.CustomerContact = botRegistrationDetails.CustomerContact;
                            existingBot.BotType = botRegistrationDetails.BotType;
                            existingBot.ReportId = botRegistrationDetails.ReportId;
                            existingBot.OfferingType = botRegistrationDetails.OfferingType;
                            existingBot.IsActive = botRegistrationDetails.IsActive;
                            _dbcontext.BotRegistration.Update(existingBot);                            

                            JsonSerializerSettings settings = new JsonSerializerSettings()
                            {
                                ReferenceLoopHandling = ReferenceLoopHandling.Ignore
                            };

                            ActivityLog activityLog = new ActivityLog()
                            {
                                Action = "Edit",
                                RefId = botRegistrationDetails.Id,
                                Module = "Bot Registration",
                                Value = JsonConvert.SerializeObject(botRegistrationDetails, settings),
                                PerformedBy = loggedInUserId,
                                PerformedOn = DateTime.UtcNow
                            };
                            _dbcontext.ActivityLog.Add(activityLog);
                            _dbcontext.SaveChanges();

                        }
                    }
                    else
                    {
                        _dbcontext.BotRegistration.Add(botRegistrationDetails);
                        _dbcontext.SaveChanges();

                        var newId = _dbcontext.BotRegistration.Select(x => x.Id).Max();
                        JsonSerializerSettings settings = new JsonSerializerSettings()
                        {
                            ReferenceLoopHandling = ReferenceLoopHandling.Ignore
                        };
                        ActivityLog activityLog = new ActivityLog()
                        {
                            Action = "Add",
                            RefId = newId,
                            Module = "Bot Registration",
                            Value = JsonConvert.SerializeObject(botRegistrationDetails, settings),
                            PerformedBy = loggedInUserId,
                            PerformedOn = DateTime.UtcNow
                        };
                        _dbcontext.ActivityLog.Add(activityLog);
                        _dbcontext.SaveChanges();

                    }
                    scope.Complete();
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Validate Bot Registration details before add/update
        /// </summary>
        /// <param name="botRegistration"></param>
        /// <returns>bool</returns>
        public string ValidateBotRegistration(BotRegistration botRegistration)
        {
            string validationMsg = string.Empty;
            bool isConStrValid = false;
            var validOfferingTypes = _configuration.GetValue<string>("ClientPortalOfferingType").Split(",").ToList();
            validOfferingTypes = validOfferingTypes.Select(t => t.Trim()).ToList();
            if (string.IsNullOrEmpty(botRegistration.CustomerContact) ||
                string.IsNullOrEmpty(botRegistration.BotType))
            {
                return validationMsg = CommonConstant.NullMsg;
            }
            else if (!Enum.IsDefined(typeof(CommonEnum.BotType), botRegistration.BotType.Trim()))
            {
                return validationMsg = CommonConstant.InvalidBotType;
            }
            else if (!validOfferingTypes.Contains(botRegistration.OfferingType.Trim()))
            {
                return validationMsg = CommonConstant.InvalidOfferingType;
            }
            var validBot = _dbcontext.BotConfig.FirstOrDefault(x => x.Id.Equals(botRegistration.BotConfigId) && x.Status.Equals("Active"));
            if (validBot == null)
            {
                return validationMsg = CommonConstant.InvalidBotId;
            }
            var oldBotRegistration = _dbcontext.BotRegistration.FirstOrDefault(x => x.BotConfigId.Equals(botRegistration.BotConfigId) && x.IsActive);
            if (botRegistration.Id == 0)
            {
                if (oldBotRegistration != null)
                    return validationMsg = CommonConstant.DuplicateBotRegistration;
            }
            else
            {
                if (oldBotRegistration != null && oldBotRegistration.Id != botRegistration.Id)
                {
                    return validationMsg = CommonConstant.DuplicateBotRegistration;
                }
                var existingBot = _dbcontext.BotRegistration.FirstOrDefault(x => x.Id.Equals(botRegistration.Id));
                if (existingBot != null && !string.IsNullOrEmpty(existingBot.ReportConnectionString))
                {
                    if (String.Equals(existingBot.ReportSource.Trim().Replace(" ", ""), CommonEnum.ReportSource.AzureSQLDB.ToString(), StringComparison.OrdinalIgnoreCase))
                    {
                        isConStrValid = IsValidSQLConnectionString(existingBot.ReportConnectionString);
                    }
                    else if (String.Equals(existingBot.ReportSource.Trim().Replace(" ", ""), CommonEnum.ReportSource.AzureStorage.ToString(), StringComparison.OrdinalIgnoreCase))
                    {
                        isConStrValid = IsValidStorageConnectionString(existingBot.ReportConnectionString);
                    }
                    if (!isConStrValid)
                    {
                        return validationMsg = CommonConstant.InvalidConnectionString;
                    }
                }
            }

            return validationMsg = CommonConstant.ValidationSuccessful;

        }


        /// <summary>
        /// Validate connection string
        /// </summary>
        /// <param name="connectionString"></param>
        /// <returns>bool</returns>
        public bool IsValidSQLConnectionString(string connectionString)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    try
                    {
                        con.Open();
                        return true;
                    }
                    catch (Exception)
                    {
                        return false;
                    }
                    finally
                    {
                        con.Close();
                    }
                }
            }
            catch (Exception)
            {
                return false;
            }
        }

        /// <summary>
        /// Validate connection string
        /// </summary>
        /// <param name="connectionString"></param>
        /// <returns>bool</returns>
        public bool IsValidStorageConnectionString(string connectionString)
        {
            try
            {
                CloudStorageAccount sa = CloudStorageAccount.Parse(connectionString);
                if (sa != null)
                    return true;
                else
                    return false;
            }
            catch (Exception)
            {
                return false;
            }
        }

        /// <summary>
        /// Change isActive status to false on Bot Registration deletion
        /// </summary>
        /// <param name="botRegistrationId"></param>
        public long DeleteBotRegistration(int botRegistrationId, string loggedInUserId)
        {
            try
            {
                long botConfigId = 0;
                using (TransactionScope scope = new TransactionScope())
                {
                    var botRegistration = _dbcontext.BotRegistration.FirstOrDefault(x => x.Id == botRegistrationId);
                    botConfigId = botRegistration.BotConfigId;

                    if (botRegistration != null)
                    {
                        botRegistration.IsActive = false;

                        JsonSerializerSettings settings = new JsonSerializerSettings()
                        {
                            ReferenceLoopHandling = ReferenceLoopHandling.Ignore
                        };

                        ActivityLog activityLog = new ActivityLog
                        {
                            Action = "Edit",
                            RefId = botRegistration.Id,
                            Module = "Bot Registration",
                            Value = JsonConvert.SerializeObject(botRegistration, settings),
                            PerformedBy = loggedInUserId,
                            PerformedOn = DateTime.UtcNow
                        };
                        _dbcontext.ActivityLog.Add(activityLog);
                        _dbcontext.SaveChanges();
                    }
                    scope.Complete();
                }
                return botConfigId;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
