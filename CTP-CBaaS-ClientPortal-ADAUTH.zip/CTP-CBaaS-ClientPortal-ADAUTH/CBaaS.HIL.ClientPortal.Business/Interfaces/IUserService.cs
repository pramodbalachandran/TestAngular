﻿using CBaaS.HIL.Common.CoreComponents.Repositories;
using CBaaS.HIL.Common.Entities;
using CBaaS.HIL.Common.Entities.Models;
using System.Collections.Generic;

namespace CBaaS.HIL.ClientPortal.Business.Interfaces
{
    public interface IUserService : ICoreRepository<UserBotRoles>
    {
        List<string> GetUserRolesById(int id);
        Users GetUserByEmail(string emailId);
        Users GetUserByUserId(int userId);
        List<string> GetUserRolesByEmail(string emailId);
        List<string> GetUserBotRoles(string emailId, int botId);
        string AddUserBotRoles(UserRolesDetails userRolesDetails, string loggedInUserId);
        void DeleteUserRole(UserRolesDetails userRolesDetails, string loggedInUserId);
        List<Roles> GetRoles();
        List<UserRolesDetails> GetAllUsersAllRoles(long botConfigId);
        string AddUpdateUserRegistration(Users user, string loggedInUserId);
        List<UserVM> GetExternalUsers(string user);
        List<Users> GetAllUsers();
        UserRolesVM GetUserRolesFromSession(string userDetails);       
        void DeleteBotRoles(long botConfigId, string loggedInUserId);
        void DeleteUserRoles(int userId, string loggedInUserId);
        void DeleteUser(int userId, string loggedInUserId);

    }
}
