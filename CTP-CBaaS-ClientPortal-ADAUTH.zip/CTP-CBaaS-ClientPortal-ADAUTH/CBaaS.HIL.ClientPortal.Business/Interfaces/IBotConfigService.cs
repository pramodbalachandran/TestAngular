﻿using CBaaS.HIL.Common.CoreComponents.Repositories;
using CBaaS.HIL.Common.Entities.Models;
using System;
using System.Collections.Generic;

namespace CBaaS.HIL.ClientPortal.Business.Interfaces
{
    public interface IBotConfigService : ICoreRepository<BotConfig>
    {
        List<BotConfig> GetBotList(List<string> userDetails);
        List<BotConfig> GetBotConfigByUserId(string userEmailId);
        List<BotConfig> GetBotConfigByUserId(int userId);
        BotConfig GetBotConfigById(int botConfigId);
        List<BotRegistration> GetAllRegisteredBotList(List<string> userDetails);
        BotConfig GetBotConfigById(Guid botId);
    }
}
