﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CBaaS.HIL.ClientPortal.Business.Interfaces
{
    public interface ICacheService
    {
        string GetCacheValue(string key);
        byte[] GetCacheByteValue(string key);
        void SetCacheByteValue(string key, byte[] value);
        void SetCacheValue(string key, string value);
        void RemoveKey(string key);
        void SetCacheObjectValue(string key, object value);
        object GetCacheObjectValue(string key);
    }
}
