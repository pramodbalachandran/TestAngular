﻿using CBaaS.HIL.Common.CoreComponents.Repositories;
using CBaaS.HIL.Common.Entities.Models;

namespace CBaaS.HIL.ClientPortal.Business.Interfaces
{
    public interface IBotService : ICoreRepository<BotUserConnection>
    {
        void AddConnectedBotUser(BotUserConnection botUserConnection);
    }
}
