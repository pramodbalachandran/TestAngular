﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace CBaaS.HIL.ClientPortal.Business.Interfaces
{
    public interface IKeyVaultHelper
    {
        Task ReadApplicationConfiguration();
    }
}
