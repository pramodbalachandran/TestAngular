﻿using CBaaS.HIL.Common.CoreComponents.Repositories;
using CBaaS.HIL.Common.Entities;
using CBaaS.HIL.Common.Entities.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace CBaaS.HIL.ClientPortal.Business.Interfaces
{
    public interface IBotRegistrationService : ICoreRepository<BotRegistration>
    {
        List<BotDetails> GetAllAccessedBotList(UserRolesVM userRoles);
        List<BotDetails> GetAllBotsList(UserRolesVM userRoles);
        List<BotRegistration> GetRegisteredBotById(long botConfigId);
        List<BotRegistration> GetRegisteredBotById(int botRegistrationId);
        void AddUpdateBotRegistration(BotRegistration botRegistrationDetails, string loggedInUserId);
        string ValidateBotRegistration(BotRegistration botRegistration);
        long DeleteBotRegistration(int botRegistrationId, string loggedInUserId);
        BotDetails GetRegisteredBotInfo(int botRegistrationId);
    }
}
