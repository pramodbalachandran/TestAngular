import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { HomeComponent } from './components/shared/home/home.component';
import { BotlookupComponent } from './components/administration/botlookup/botlookup.component';
import { BotregisterComponent } from './components/administration/botregister/botregister.component';
import { DashboardmenuComponent } from './components/dashboard/dashboardmenu/dashboardmenu.component';
import { BotdashboardComponent } from './components/dashboard/botdashboard/botdashboard.component';
import { AdministrationmenuComponent } from './components/administration/administrationmenu/administrationmenu.component';
import { UserrolemanagementComponent } from './components/administration/userrolemanagement/userrolemanagement.component';
import { ConversationsmenuComponent } from './components/conversation/conversationsmenu/conversationsmenu.component';
import { HilconversationsComponent } from './components/conversation/hilconversations/hilconversations.component';
import { AuthenticationComponent } from './components/shared/authentication/authentication.component';
import { AuthGuard } from './guards/auth/auth.guard';
import { SignoutComponent } from './components/shared/signout/signout.component';
import { ErrorComponent } from './components/shared/error/error.component';
import { UserregisterComponent } from './components/administration/userregister/userregister.component';
import { UserlookupComponent } from './components/administration/userlookup/userlookup.component';


const routes: Routes = [
  { path: '', component: AuthenticationComponent,  canActivate: [AuthGuard]},
  { path: 'home', component: HomeComponent, data: { breadcrumb: 'HOME' }, canActivate: [AuthGuard] },
  {
    path: 'conversations', component: ConversationsmenuComponent, data: { breadcrumb: 'CONVERSATIONS' }, canActivate: [AuthGuard], canActivateChild: [AuthGuard],
    children: [
      { path: 'hilconversations', component: HilconversationsComponent, data: { breadcrumb: 'HIL CONVERSATIONS' }}
    ]
  },
  {
    path: 'dashboard', component: DashboardmenuComponent, data: { breadcrumb: 'DASHBOARD' }, canActivate: [AuthGuard], canActivateChild: [AuthGuard],
    children: [
      { path: 'botdashboard', component: BotdashboardComponent, data: { breadcrumb: 'BOT ANALYTICS' }}
    ]
  },
  {
    path: 'administration', component: AdministrationmenuComponent, data: { breadcrumb: 'ADMINISTRATION' }, canActivate: [AuthGuard], canActivateChild: [AuthGuard],
    children: [
      { path: 'botlookup', component: BotlookupComponent, data: { breadcrumb: 'BOT LOOKUP' } },
      { path: 'botregister', component: BotregisterComponent, data: { breadcrumb: 'BOT REGISTER' } },
      { path: 'botregisteredit', component: BotregisterComponent, data: { breadcrumb: 'BOT REGISTER EDIT' } },
      { path: 'userrolemanagement', component: UserrolemanagementComponent, data: { breadcrumb: 'USER-ROLE MANAGEMENT' } },
      { path: 'userregister', component: UserregisterComponent, data: { breadcrumb: 'USER REGISTER' } },
      { path: 'userregisteredit', component: UserregisterComponent, data: { breadcrumb: 'USER REGISTER EDIT' } },
      { path: 'userlookup', component: UserlookupComponent, data: { breadcrumb: 'USER LOOKUP' } },
      
    ]
  },
  { path: 'signout', component: SignoutComponent},
  { path: 'error', component: ErrorComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
