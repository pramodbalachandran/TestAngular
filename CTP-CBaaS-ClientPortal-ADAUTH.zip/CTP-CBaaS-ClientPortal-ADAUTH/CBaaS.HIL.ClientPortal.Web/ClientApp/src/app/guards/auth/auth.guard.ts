import { Injectable, Inject } from '@angular/core';
import { CanActivate, CanActivateChild, CanLoad, Route, UrlSegment, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree, Router } from '@angular/router';
import { Observable, concat } from 'rxjs';
import { DOCUMENT, Location } from '@angular/common';
import { IUserRoleDetails } from 'src/app/models/user-role-details';
import { IUserDetails } from 'src/app/models/user';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AuthenticationService } from 'src/app/services/core/authentication/authentication.service';
import { ConfigurationSettings } from 'src/app/models/configuration.settings';
import { UserService } from 'src/app/services/core/user/user.service';
import { DataService } from 'src/app/services/shared/data/data.service';
import { CommunicationService } from 'src/app/services/shared/communication/communication.service';
import { ConnectedStatusService } from 'src/app/services/shared/connection-status/connected-status.service';
import * as Msal from 'msal';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate, CanActivateChild, CanLoad {
  private path: string;
  public tokenValue: any;
  private IdaasConfig: any;
  private locationUrl: any;
  public hilUrl: string;
  public msalInstance:any;
  public userRoleDetails: IUserRoleDetails[] = [];
  public userDetails: IUserDetails;

  constructor(
    private router: Router,
    private authenticationService: AuthenticationService,
    @Inject(DOCUMENT) private document: Document,
    private httpClient: HttpClient,
    private configurationSettings: ConfigurationSettings,
    private location: Location,
    private userService: UserService,
    private dataService: DataService,
    private communication: CommunicationService,
    private connectedStatusService: ConnectedStatusService
  ) { }
  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
    let isActivated = this.isAuthenticatedUser(next);
    return isActivated;
  }
  canActivateChild(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
    let isActivated = this.isAuthenticatedUser(next);
    return isActivated;
  }
  canLoad(
    route: Route,
    segments: UrlSegment[]): Observable<boolean> | Promise<boolean> | boolean {
    return true;
  }

  private isAuthenticatedUser(route: ActivatedRouteSnapshot) {
    this.locationUrl = this.location;
    this.configurationSettings.hostUrl = this.locationUrl._platformLocation.location.origin;

    if (!this.configurationSettings.hilUrl || this.configurationSettings.hilUrl == '') {
      this.configurationSettings.hilUrl = sessionStorage.getItem('hilUrl');
    }

    //always authenticate when user navigates to Login component ("")
    if (route.routeConfig.path == "") {
      sessionStorage.clear();
      localStorage.clear();
      //this.communication.deleteHubConnection();
    }

    //get token from sessionStorage
    const token = sessionStorage.getItem('access_token');
    const code = sessionStorage.getItem('code');

    if (!sessionStorage.getItem('path')) {
      sessionStorage.setItem('path', route.routeConfig.path);

    }

    if (token) {
      this.dataService.sendUsername(sessionStorage.getItem('userName'));
      return true;
    }
    else if (route.queryParams.code) {

      let code = route.queryParams.code;

      if (!sessionStorage.getItem('code')) {

        sessionStorage.setItem('code', code);

          this.authenticationService.getAccessToken(code)
              .subscribe(
                  res => {
                      this.tokenValue = res;
                      sessionStorage.setItem('access_token', this.tokenValue.value);
                      this.path = sessionStorage.getItem('path');
                      this.setUser();
                  },
                  (error) => {
                      console.log(error);
                  });
      }
    }
    else {
      this.authenticationService.getIdaasConfiguration()
        .subscribe(
          res => {            
            this.IdaasConfig = res;
            sessionStorage.setItem('hilUrl', this.IdaasConfig["HILURL"]);//store the hilUrl         
                if (route.queryParams.scope && route.queryParams.hint && this.IdaasConfig && route.queryParams.scope.toLowerCase() == 'eycb') {
                // not logged in so redirect to login page with the return url and scope
                    this.document.location.href = this.IdaasConfig["IdaasUrl"] +
                        '?client_id=' + this.IdaasConfig["IdaasClientId"] +
                        '&redirect_uri=' + this.IdaasConfig["IdaasRedirectUri"] +
                        '&response_type=' + this.configurationSettings.idaas_response_type +
                        '&scope=' + route.queryParams.scope +
                        '&hint=' + route.queryParams.hint +
                        '&grant_type=' + this.configurationSettings.idaas_grant_type;
            }
            else {
                this.authenticateADUser();
            }
          },
          (error) => {            
          }
        )
    }
    }

    private authenticateADUser() {
        const msalConfig = {
            auth: {
                //clientId: '1d5f28af-a654-40a7-aa28-49b04a6e773b',
                //lientId: '66255d28-0531-46d5-98b4-b7439d78a058',
                //authority: 'https://login.microsoftonline.com/5b973f99-77df-4beb-b27d-aa0c70b8482c'
                clientId: 'b63f3f50-3e98-436b-be59-ecc0293c6af2',
                authority: 'https://login.microsoftonline.com/ca165557-f92c-40b1-b653-2cad6f6460d7'
            },
        };

        this.msalInstance = new Msal.UserAgentApplication(msalConfig);

        this.msalInstance.handleRedirectCallback((error, response) => {
            // handle redirect response or error
            console.log(error);
            console.log(response);
        });

        let loginRequest = {
            scopes: ["user.read", 'openid', 'profile']
        };

        this.msalInstance.loginPopup(loginRequest)
            .then(response => {
                let user = this.msalInstance.getAccount();
                console.log(user);
                sessionStorage.setItem('access_token', response.idToken.rawIdToken);
                this.path = sessionStorage.getItem('path');
                this.setUser();
            })
            .catch(err => {
                // handle error
            });
    }

    private setUser() {
        this.userService.getLoggedInUserRoles()
            .subscribe(
                result => {
                    if (result) {
                        this.userRoleDetails = result;
                        sessionStorage.setItem('userEmailId', this.userRoleDetails[0].username);
                        sessionStorage.setItem('userName', this.userRoleDetails[0].firstname);
                        this.dataService.sendUsername(this.userRoleDetails[0].firstname);
                        let agent = this.userRoleDetails.filter(x => x.role.toLowerCase() === 'agent');
                        let resultArray = this.userRoleDetails.map(x => x.role).join(",");
                        sessionStorage.setItem('userRoles', resultArray.toString());
                        this.dataService.sendUsername(sessionStorage.getItem('userName'));
                        if (agent && agent.length > 0) {//if user type is Agent then create hubconnection
                            this.configurationSettings.userRole = 'Agent';
                            if (!localStorage.getItem("agentConnected") || localStorage.getItem("agentConnected") != 'true') {
                                this.communication.CreateAgentConnection(sessionStorage.getItem('userEmailId'));
                            }
                        }
                        this.router.navigate(['/home']);
                    }
                },
                (error) => {
                });
    }
}
