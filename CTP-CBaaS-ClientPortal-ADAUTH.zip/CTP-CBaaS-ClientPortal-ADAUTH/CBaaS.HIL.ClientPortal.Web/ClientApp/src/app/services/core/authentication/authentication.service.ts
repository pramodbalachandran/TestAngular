import { Injectable } from '@angular/core';
import { HttpHeaders, HttpClient, HttpParams, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { ConfigurationSettings } from 'src/app/models/configuration.settings';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

  public tokenValue: any;
    private httpOptions = {
        headers: new HttpHeaders({ 'Content-Type': 'application/json', 'Accept': 'application/json' })
    };
    constructor(private http: HttpClient,
        private configurationSettings: ConfigurationSettings) { }

    login() { }

    logout() {
        // remove user from local storage and set current user to null
        sessionStorage.removeItem('access_token');
    }


    getIdaasConfiguration(): Observable<any> {
        return this.http.get(this.configurationSettings.idaas_api_endpoint + '/GetIdaasConfiguration');
    }

    getAccessToken(code: string): Observable<string> {
        let params = new HttpParams();
        params = params.set('code', code);
        return this.http.post<string>(this.configurationSettings.idaas_api_endpoint + '/GetAccessToken', params);
    }

    handleError(error: HttpErrorResponse) {
        let errorMessage = `Error Code: ${error.status}\nMessage: ${error.message}`;
        return throwError(errorMessage)
    }

}
