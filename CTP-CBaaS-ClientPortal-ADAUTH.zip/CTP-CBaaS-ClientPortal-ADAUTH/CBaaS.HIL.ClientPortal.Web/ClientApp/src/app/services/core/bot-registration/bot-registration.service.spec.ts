import { TestBed } from '@angular/core/testing';

import { BotRegistrationService } from './bot-registration.service';

describe('BotRegistrationService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: BotRegistrationService = TestBed.get(BotRegistrationService);
    expect(service).toBeTruthy();
  });
});
