import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { IBotRegistration } from 'src/app/models/bot-registration';
import { ConfigurationSettings } from 'src/app/models/configuration.settings';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class BotRegistrationService {

  constructor(private http: HttpClient,
    private configurationSettings: ConfigurationSettings) { }

  getRegisteredBots(): Observable<any> {
    return this.http.get(this.configurationSettings.botregistration_api_endpoint + '/GetAccessedBots');
  }

  getBotConfigData(botId: any): Observable<any> {
    return this.http.get(this.configurationSettings.botregistration_api_endpoint + '/GetBotConfigData?botId=' + botId);
  }

  getRegisteredBotDetails(botRegistrationId: number): Observable<any> {
    return this.http.get(this.configurationSettings.botregistration_api_endpoint + '/GetRegisteredBotDetails?botRegistrationId=' + botRegistrationId);
  }

  getBotOfferingTypes(): Observable<any> {
    return this.http.get(this.configurationSettings.botregistration_api_endpoint + '/GetBotOfferingTypes');
  }

  addUpdateBotRegistration(botRegistration: IBotRegistration): Observable<IBotRegistration> {
    return this.http.post<IBotRegistration>(this.configurationSettings.botregistration_api_endpoint, botRegistration);

  }

  deleteBotRegistration(botRegistration: any): Observable<any> {
    return this.http.delete(this.configurationSettings.botregistration_api_endpoint + "/DeleteRegisteredBot?botRegistrationId=" + botRegistration.data.botRegistrationId);
  }
}
