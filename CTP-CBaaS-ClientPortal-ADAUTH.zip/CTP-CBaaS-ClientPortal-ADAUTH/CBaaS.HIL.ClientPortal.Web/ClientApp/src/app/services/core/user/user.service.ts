import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { IUserRoleDetails } from 'src/app/models/user-role-details';
import { ConfigurationSettings } from 'src/app/models/configuration.settings';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { IUserDetails } from 'src/app/models/user';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  private httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json', 'Accept': 'application/json' })
  };
  constructor(private http: HttpClient,
    private configurationSettings: ConfigurationSettings) { }

  getRoles(): Observable<any> {
    return this.http.get(this.configurationSettings.user_api_endpoint + '/GetRoles');
    //.pipe(catchError(this.handleError));
  }

  addUserRoles(userBotRoles: IUserRoleDetails[]): Observable<any> {
    return this.http.post<IUserRoleDetails>(this.configurationSettings.user_api_endpoint + '/PostUserBotRoles', userBotRoles);
    //.pipe(catchError(this.handleError));
  }

  deleteUserRole(userBotRole: IUserRoleDetails): Observable<any> {
    return this.http.post(this.configurationSettings.user_api_endpoint + '/DeleteUserRole', userBotRole);
  }

  getAllUserRoles(botConfigId: number): Observable<any> {
    return this.http.get(this.configurationSettings.user_api_endpoint + "/GetUserRoles?botConfigId=" + botConfigId);
  }

  getLoggedInUserRoles(): Observable<any> {
    return this.http.get(this.configurationSettings.user_api_endpoint + "/GetLoggedInUserRoles");
  }

  getMachingUsers(user: string, userType: string): Observable<any> {
    return this.http.get(this.configurationSettings.user_api_endpoint + "/GetMatchingUsers?user=" + user + "&userType=" + userType);
  }

  getLoggedInUserDetails(): Observable<any> {
    return this.http.get(this.configurationSettings.user_api_endpoint + "/GetLoggedInUserDetails");
  }

  addUpdateUserRegistration(user: IUserDetails): Observable<any> {
    return this.http.post<IUserDetails>(this.configurationSettings.user_api_endpoint + '/AddUpdateUser', user);
  } 

  getAllUsers(): Observable<any> {
    return this.http.get(this.configurationSettings.user_api_endpoint + "/GetAllUsers");
  }

  deleteUser(user: any): Observable<any> {
    return this.http.delete(this.configurationSettings.user_api_endpoint + "/DeleteUser?userId=" + user.data.id);
  }
  
}
