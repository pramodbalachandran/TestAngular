import { Injectable } from '@angular/core';
import { HttpHeaders, HttpClient, HttpParams } from '@angular/common/http';
import { ConfigurationSettings } from 'src/app/models/configuration.settings';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class TokenService {

  private httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json', 'Accept': 'application/json' })
  }
  constructor(private http: HttpClient,
    private configurationSettings: ConfigurationSettings) { 

    }
    GetMiddlewareAccessToken(hilCode:any): Observable<any> {
      let params = new HttpParams();
      params = params.set('grant_key', hilCode);
      params = params.set('grant_type','password');
      params = params.set('username',sessionStorage.getItem('userEmailId'));
      return this.http.post<string>(this.configurationSettings.hilUrl + '/token', params);
     // xhr.send('grant_type=password' + '&username=' + userId + '&grant_key=' + accesstoken);
    }

    getRefreshToken(): Observable<any> {
      let params = new HttpParams();
      params = params.set('token', localStorage.getItem('accessToken'));
      params = params.set('refreshToken',localStorage.getItem('refreshToken'));      
      return this.http.post<string>(this.configurationSettings.hilUrl + '/refreshToken', params);
     // xhr.send('grant_type=password' + '&username=' + userId + '&grant_key=' + accesstoken);
    }
    GetHumanHandOffToken(username: string): Observable<any> {
      let params = new HttpParams();
      params = params.set('username', username);
       return this.http.post<string>(this.configurationSettings.idaas_api_endpoint + '/GetHumanHandOffToken', params);

       
    }
  
}
