import { Injectable } from '@angular/core';
import { HubConnection, HubConnectionBuilder } from '@microsoft/signalr';
import { IConversation } from 'src/app/models/iconversation';
import { ConfigurationSettings } from 'src/app/models/configuration.settings';
import { TokenService } from '../../core/token/token.service';
import { ToastrService } from 'ngx-toastr';
import { Observable } from 'rxjs';
import { of } from 'rxjs';
import { DataService } from 'src/app/services/shared/data/data.service';
import { ToasterService } from '../../../services/shared/toaster/toaster.service';
import { ConnectedStatusService } from '../connection-status/connected-status.service';
import { Router } from '@angular/router';


@Injectable({
  providedIn: 'root'
})
export class CommunicationService {

  private _hubConnection: HubConnection;
  public _connectionStatus: boolean;
  public connectedStatus: boolean = false;

  master = 'Master';
  agentNickName: string;
  agentLoginId: string;
  conversations = [] as Array<IConversation>;
  hilToken: string;

  constructor(private configurationSettings: ConfigurationSettings,
    private dataService: DataService,
    private tokenService: TokenService,
    private toastr: ToastrService,
    private toasterService: ToasterService,
    private connectedStatusService: ConnectedStatusService,
    private router: Router) {
  }

  public SetHubConnection(hubCon: HubConnection) {
    this._hubConnection = hubCon;
  }

  public GetHubConnection(): HubConnection {
    return this._hubConnection;
  }

  public CreateHubConnection(reconnect: boolean) {
    if (!reconnect) {
      localStorage.removeItem('conversations');
      localStorage.removeItem('connectedBots');
    }
    this._hubConnection = new HubConnectionBuilder()
      .withUrl(this.configurationSettings.hilUrl + "/chathub", {
        accessTokenFactory: function () {
          return localStorage.getItem('accessToken');
        }
      })
      .build();
    this._hubConnection
      .start()
      .then(() => this.agentConnect(reconnect))
      .catch(err => this.changeConnectedStatus()
      );
    this._hubConnection.serverTimeoutInMilliseconds = 1000 * 60 * 500;
    this.agentLoginId = sessionStorage.getItem("userEmailId");//Get Agent Name

    this._hubConnection.on("onAgentConnected", (nickName: string) => {

      this.connectedStatus = true;//Set Agent connection status as true
      this.agentNickName = nickName;
      this._connectionStatus = true;
      this.connectedStatusService.sendAgentConnectedStatus(true);
      localStorage.setItem("agentConnected", "true");
    });
  }

  changeConnectedStatus() {
    this._connectionStatus = false;
    this.connectedStatusService.sendAgentConnectedStatus(false);
    this.toasterService.error("Error while establishing connection")
  }

  public CreateAgentConnection(userEmailId): void {
    this.tokenService.GetHumanHandOffToken(userEmailId)
      .subscribe(
        res => {
          this.hilToken = res.value;
          this.tokenService.GetMiddlewareAccessToken(this.hilToken)
            .subscribe(
              res => {
                let objToken = res;
                localStorage.setItem('accessToken', objToken.token);
                localStorage.setItem('refreshToken', objToken.refreshToken);
                this.CreateHubConnection(false);
              },
              (error) => {
                this.toasterService.error("Error occured");
              }
            );
        },
        (error) => {
          this.toasterService.error("Error occured");
        }
      )
  }

  agentConnect(reconnect: boolean) {
    let method = reconnect ? "AgentReconnect" : "AgentConnect";
    this._hubConnection
      .invoke(method, this.agentLoginId)
      .then(() => {
        if (!reconnect)
          this.router.navigate(['/conversations/hilconversations'])
      })
      .catch(err => {
        //this.toasterService.error("Error : " + err.message.toString());
      })
  }

  getRefreshToken() {
    this.tokenService.getRefreshToken()
      .subscribe(
        res => {
          let objToken = res;
          localStorage.setItem('accessToken', objToken.token);
          localStorage.setItem('refreshToken', objToken.refreshToken);
          this.agentConnect(false);
        },
        (error) => {
          this.toasterService.error("Error occured");
        }
      );
  }

  deleteHubConnection() {
    if (this._hubConnection) {
      this._hubConnection
        .invoke('AgentLogout')
        .then(() => { this.connectedStatusService.sendAgentConnectedStatus(false); })
        .catch(err => {
          console.log(err);
        })
      // this._hubConnection
      //   .stop()
      //   .then(() => {
      //     this.connectedStatus = false;
      //   })
      //   .catch(err => this.toasterService.error("Error while establishing connection"));
    }
  }
}
