import { Injectable, EventEmitter, Output } from '@angular/core';
import { Observable, Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DataService {

  @Output() change: EventEmitter<boolean> = new EventEmitter();
  private subject = new Subject<any>();
  constructor() { }

  toggle(data) {
    this.change.emit(data);
  }

  sendUsername(username: string) {
    this.subject.next({ text: username });
  }

  clearUsername() {
    this.subject.next();
  }

  getUsername(): Observable<any> {
    return this.subject.asObservable();
  }

}
