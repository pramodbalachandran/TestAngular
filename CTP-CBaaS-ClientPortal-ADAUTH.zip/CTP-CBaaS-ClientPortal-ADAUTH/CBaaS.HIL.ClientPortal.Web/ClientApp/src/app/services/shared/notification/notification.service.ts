import { Inject, Injectable } from '@angular/core';
import { LocalstorageService } from '../localstorage/localstorage.service';
import { EventEmitter, Output } from '@angular/core';
import { Observable, Subject } from 'rxjs';
import { IConversation } from '../../../models/iconversation';
import { PushNotificationsService } from 'ng-push';
import { DOCUMENT } from '@angular/common';

@Injectable({
  providedIn: 'root'
})
export class NotificationService {

  private subject = new Subject<any>();
  public connectedBotDetails: any;
  public connectedBotDetail: IConversation;
  public notification: any;

  constructor(private localstorageService: LocalstorageService,
              private _pushNotifications: PushNotificationsService,
              @Inject(DOCUMENT) private document: Document) { }

  getHilConversationNotification(): Observable<any> {
    return this.subject.asObservable();
  }

  sendHilConversationNotification(activity: IConversation) {
      if (this.localstorageService.get("connectedBots")) {
        this.connectedBotDetails = this.localstorageService.get("connectedBots");

        if (this.connectedBotDetails) {
          this.connectedBotDetail = this.connectedBotDetails.find(x => x.ChatId == activity.ChatId);

          this.notification = { type: "Message", from: this.connectedBotDetail['BotUserName'], dateTime: activity.DateTime, ChatId: activity.ChatId};

          this.subject.next({ notification: this.notification });

          //push notification
          if (this.document.visibilityState != 'visible') {

            var notifyTime = activity.DateTime;

            var date = notifyTime.getDate() + '-' + (notifyTime.getMonth() + 1) + '-' + notifyTime.getFullYear();
            var time = notifyTime.getHours() + ":" + notifyTime.getMinutes();
            var dateTime = time + ' | ' + date;

            let options = {
              body: "Message from " + this.connectedBotDetail['BotUserName'] + "\r\n" + dateTime.toString(),
              icon: "assets/images/message.png"
            };

            this._pushNotifications.create('Message', options).subscribe();
          }
          //end push notification
        }
      }
  }


  clearAllNotifications(): Observable<any> {
    this.subject.next();
    return this.subject.asObservable();
  }
}
