import { Injectable, Output, EventEmitter } from '@angular/core';
import { Subject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ConnectedStatusService {

  @Output() change: EventEmitter<boolean> = new EventEmitter();
  private subject = new Subject<any>();
  constructor() { }

  toggle(data) {
    this.change.emit(data);
  }  

  clearAgentConnectedStatus() {
    this.subject.next();
  }

  getAgentConnectedStatus(): Observable<any> {
    return this.subject.asObservable();
  }

  sendAgentConnectedStatus(agentConnectedStatus: boolean) {
    this.subject.next({ status: agentConnectedStatus });
  }
}
