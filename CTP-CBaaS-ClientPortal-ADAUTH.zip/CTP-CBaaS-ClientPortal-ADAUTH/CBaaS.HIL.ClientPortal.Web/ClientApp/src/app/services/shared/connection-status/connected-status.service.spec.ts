import { TestBed } from '@angular/core/testing';

import { ConnectedStatusService } from './connected-status.service';

describe('ConnectedStatusService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ConnectedStatusService = TestBed.get(ConnectedStatusService);
    expect(service).toBeTruthy();
  });
});
