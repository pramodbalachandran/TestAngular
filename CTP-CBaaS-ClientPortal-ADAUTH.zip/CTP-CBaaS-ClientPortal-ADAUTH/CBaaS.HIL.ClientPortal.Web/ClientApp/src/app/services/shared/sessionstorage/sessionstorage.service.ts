import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class SessionstorageService {

  constructor() { }

  _issessionStorageSupport(): boolean {
    var issessionStorageSupport = window.sessionStorage ? true : false;
    if (!issessionStorageSupport) {
      throw "Unsupportive browser for sessionStorage operations";
    }
    return issessionStorageSupport;
  }

  _issessionStorageEmpty(): boolean {
    var issessionStorageEmpty = sessionStorage.length <= 0 ? true : false;
    if (issessionStorageEmpty) {
      throw "localStrorage account is empty";
    }
    return issessionStorageEmpty;
  }

  getAll(): Array<any> {
    if (this._issessionStorageSupport() && !this._issessionStorageEmpty()) {
      var sessionStorageData = [];
      for (let i = 0; i < sessionStorage.length; i++) {
        let key = sessionStorage.key(i);
        let value = sessionStorage.getItem(key);
        sessionStorageData.push({ key: key, value: value });
      }
      //console.table(sessionStorageData);
      return sessionStorageData;
    }
  }

  get(key: string): string {
    if (this._issessionStorageSupport() && !this._issessionStorageEmpty()) {
      if (sessionStorage.getItem(key)) {
        let value = null;
        try {
          value = JSON.parse(sessionStorage.getItem(key));
        } catch (err) {
          value = sessionStorage.getItem(key);
        }
        //console.table([{"key":key,"value":value}]);
        return value;
      }
    }
  }

  set(key: string, value: any): boolean {
    switch (typeof value) {
      case "string": sessionStorage.setItem(key, value); break;

      case "number":
      case "boolean": sessionStorage.setItem(key, value.toString()); break;

      case "object": sessionStorage.setItem(key, JSON.stringify(value)); break;
    }
    //console.table([{"key":key,"value":sessionStorage.getItem(key)}]);
    return (sessionStorage.getItem(key)) ? true : false;
  }

  remove(key: string): boolean {
    try {
      sessionStorage.removeItem(key);
    } catch (err) {      
    }
    return (!sessionStorage.getItem(key)) ? true : false;
  }

  clear(): void {
    sessionStorage.clear();
  }

}
