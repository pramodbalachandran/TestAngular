import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class LocalstorageService {

  constructor() { }

  _isLocalStorageSupport(): boolean {
    var isLocalStorageSupport = window.localStorage ? true : false;
    if (!isLocalStorageSupport) {
      throw "Unsupportive browser for localstorage operations";
    }
    return isLocalStorageSupport;
  }

  _isLocalStorageEmpty(): boolean {
    var isLocalStorageEmpty = localStorage.length <= 0 ? true : false;
    if (isLocalStorageEmpty) {
      throw "localStrorage account is empty";
    }
    return isLocalStorageEmpty;
  }

  getAll(): Array<any> {
    if (this._isLocalStorageSupport() && !this._isLocalStorageEmpty()) {
      var localStorageData = [];
      for (let i = 0; i < localStorage.length; i++) {
        let key = localStorage.key(i);
        let value = localStorage.getItem(key);
        localStorageData.push({ key: key, value: value });
      }
      //console.table(localStorageData);
      return localStorageData;
    }
  }

  get(key: string): string {
    if (this._isLocalStorageSupport() && !this._isLocalStorageEmpty()) {
      if (localStorage.getItem(key)) {
        let value = null;
        try {
          value = JSON.parse(localStorage.getItem(key));
        } catch (err) {
          value = localStorage.getItem(key);
        }
        //console.table([{"key":key,"value":value}]);
        return value;
      }
    }
  }

  set(key: string, value: any): boolean {
    switch (typeof value) {
      case "string": localStorage.setItem(key, value); break;

      case "number":
      case "boolean": localStorage.setItem(key, value.toString()); break;

      case "object": localStorage.setItem(key, JSON.stringify(value)); break;
    }
    //console.table([{"key":key,"value":localStorage.getItem(key)}]);
    return (localStorage.getItem(key)) ? true : false;
  }

  remove(key: string): boolean {
    try {
      localStorage.removeItem(key);
    } catch (err) {      
    }
    return (!localStorage.getItem(key)) ? true : false;
  }

  clear(): void {
    localStorage.clear();
  }
}
