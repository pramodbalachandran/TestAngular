import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BotHistoryComponent } from './bot-history.component';

describe('BotHistoryComponent', () => {
  let component: BotHistoryComponent;
  let fixture: ComponentFixture<BotHistoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BotHistoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BotHistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
