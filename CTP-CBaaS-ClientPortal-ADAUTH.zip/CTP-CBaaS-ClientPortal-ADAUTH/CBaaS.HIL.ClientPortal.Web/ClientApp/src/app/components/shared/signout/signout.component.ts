import { Component, OnInit } from '@angular/core';
import { DataService } from 'src/app/services/shared/data/data.service';
import { CommunicationService } from 'src/app/services/shared/communication/communication.service';

@Component({
  selector: 'app-signout',
  templateUrl: './signout.component.html',
  styleUrls: ['./signout.component.scss']
})
export class SignoutComponent implements OnInit {

  constructor(private dataService : DataService,
    private communicationService : CommunicationService) { }

  ngOnInit() {
    sessionStorage.clear();
    localStorage.clear();
    this.communicationService.deleteHubConnection();
    this.dataService.sendUsername('User');  
  }

}
