import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HandoffCommentComponent } from './handoff-comment.component';

describe('HandoffCommentComponent', () => {
  let component: HandoffCommentComponent;
  let fixture: ComponentFixture<HandoffCommentComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HandoffCommentComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HandoffCommentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
