import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { BotRegistrationService } from 'src/app/services/core/bot-registration/bot-registration.service';
import { ToastrService } from 'ngx-toastr';
import { ToasterService } from '../../../services/shared/toaster/toaster.service';
import { Router, NavigationStart, RouterEvent } from '@angular/router';
import { UserService } from 'src/app/services/core/user/user.service';
import { filter } from 'rxjs/operators';


@Component({
  selector: 'app-warning-popup',
  templateUrl: './warning-popup.component.html',
  styleUrls: ['./warning-popup.component.scss']
})
export class WarningPopupComponent implements OnInit {
  public warningFor: string;
  _routerSubscription: any;
  public fromConversation: boolean = false;
  userRoles: string[];
  public isAgent: boolean = false;
  constructor(private dialogRef: MatDialogRef<WarningPopupComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private botService: BotRegistrationService,
    private userService: UserService,
    private toasterService: ToasterService,
    private router: Router) { }

  ngOnInit() {
    this._routerSubscription = this.router.events
    .pipe(
      filter((event: RouterEvent) => event instanceof NavigationStart),
      filter(() => !!this.dialogRef)
    )
    .subscribe(() => {
      this.dialogRef.close();
    });
    
    if (this.data == 'expiredToken')
      this.warningFor = 'expiredToken';
    else if (this.data == 'endChat')
      this.warningFor = 'endChat';
    else if (this.data == 'connectionClosed')
      this.warningFor = 'connectionClosed';
    else if (this.data.data.botRegistrationId)
      this.warningFor = 'deleteBotRegistration'
    else if (this.data.data.firstName)
      this.warningFor = 'deleteUser'
    else
      this.warningFor = 'deleteUserRole'

    if (sessionStorage.getItem("lastActiveTab") == "conversation") {
      this.fromConversation = true;
    }

    this.userRoles = sessionStorage.getItem('userRoles') ? sessionStorage.getItem('userRoles').split(',') : [];
    let agent = this.userRoles.find(ob => ob.toLowerCase() === 'agent');
    if (agent)
      this.isAgent = true;

  }
  onCloseCancel() {
    this.dialogRef.close('CANCEL');
    if (this.data == 'expiredToken')
      this.router.navigate(['/conversations/hilconversations']);
  }

  onConfirmOk() {
    if (typeof (this.data) == 'string') {
      if (this.data == 'endChat') {
        sessionStorage.setItem('endChat', 'true');
        this.dialogRef.close('CONFIRM');
      }
      else {
        this.dialogRef.close('CONFIRM');
        this.router.navigate(['/']);
      }
    }
    else {
      if (this.data.data.botRegistrationId) {
        this.botService.deleteBotRegistration(this.data)
          .subscribe((data) => {
            this.dialogRef.close('CONFIRM');
            this.toasterService.warn("Record deleted");
          },
            (error) => {
              this.dialogRef.close('CONFIRM');
              this.toasterService.error("Error occured");
            }
          )
      }
      else if (this.data.data.firstName) {
        this.userService.deleteUser(this.data)
          .subscribe((data) => {
            this.dialogRef.close('CONFIRM');
            this.toasterService.warn("Record deleted");
          },
            (error) => {
              this.dialogRef.close('CONFIRM');
              this.toasterService.error("Error occured");
            }
          )
      }
      else {
        this.userService.deleteUserRole(this.data.data)
          .subscribe(
            res => {
              this.dialogRef.close('CONFIRM');
              this.toasterService.success("Successfully deleted User role");
            },
            (error) => {
              this.dialogRef.close('CONFIRM');
              this.toasterService.error("Error Occured while deleting User role");
            }
          )
      }
    }

  }

}
