import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { NavigationStart, RouterEvent, Router } from '@angular/router';
import { filter } from 'rxjs/operators';

@Component({
  selector: 'app-privacy-statement',
  templateUrl: './privacy-statement.component.html',
  styleUrls: ['./privacy-statement.component.scss']
})
export class PrivacyStatementComponent implements OnInit {
  _routerSubscription: any;
  constructor(private dialogRef: MatDialogRef<PrivacyStatementComponent>,
    @Inject(MAT_DIALOG_DATA) public data: string,
    private router: Router) { }

  ngOnInit() {
    this._routerSubscription = this.router.events
      .pipe(
        filter((event: RouterEvent) => event instanceof NavigationStart),
        filter(() => !!this.dialogRef)
      )
      .subscribe(() => {
        this.dialogRef.close();
      });
  }

  onClose() {
    this.dialogRef.close('Close');
  }

}
