import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material';
import { PrivacyStatementComponent } from '../privacy-statement/privacy-statement.component';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.scss']
})
export class FooterComponent implements OnInit {

  constructor(private dialogPrivacyStatement: MatDialog) { }
  privacystatement: string;
  ngOnInit() {
    this.privacystatement = "";//set the privacy content
  }
  showPrivacyStatement() {
    let dialogRef = this.dialogPrivacyStatement.open(PrivacyStatementComponent, {
      height: '75%',
      width: '80%',
      autoFocus: false,
      data: this.privacystatement
    });
    dialogRef.afterClosed().subscribe(result => {

    })
  }
}
