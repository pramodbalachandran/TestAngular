import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { BotRegistrationService } from 'src/app/services/core/bot-registration/bot-registration.service';
import { IChartService } from 'ag-grid-community';
import { IChatHistory } from 'src/app/models/chat-history';
import { NavigationStart, RouterEvent, Router } from '@angular/router';
import { filter } from 'rxjs/operators';

@Component({
  selector: 'app-bot-history',
  templateUrl: './bot-history.component.html',
  styleUrls: ['./bot-history.component.scss']
})
export class BotHistoryComponent implements OnInit {
  chatHistory: IChatHistory[] = [];
  _routerSubscription: any;
  constructor(private dialogRef: MatDialogRef<BotHistoryComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private router: Router) {
    this.chatHistory = JSON.parse(this.data);
    }   

  ngOnInit() {
    this._routerSubscription = this.router.events
     .pipe(
       filter((event: RouterEvent) => event instanceof NavigationStart),
       filter(() => !!this.dialogRef)
     )
     .subscribe(() => {
       this.dialogRef.close();
     });
    this.chatHistory = JSON.parse(this.data);
  }
  onClose() {
    this.dialogRef.close('Close');
  }
}
