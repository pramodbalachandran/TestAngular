import { Component, OnInit } from '@angular/core';
import { ConfigurationSettings } from 'src/app/models/configuration.settings';
import { IUserRoleDetails } from 'src/app/models/user-role-details';
import { Subscription } from 'rxjs';
import { UserService } from 'src/app/services/core/user/user.service';
import { Router } from '@angular/router';
import { DataService } from 'src/app/services/shared/data/data.service';
import { CommunicationService } from 'src/app/services/shared/communication/communication.service';
import { MessageService } from 'src/app/services/shared/message/message.service';
import { NotificationService } from '../../../services/shared/notification/notification.service';
import { ConnectedStatusService } from 'src/app/services/shared/connection-status/connected-status.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent {

  notifications: any[] = [];
  isAgentHubConnection: boolean = false;
  isExpanded = false;
  isLoggedOut = false;
  public userRoles: string[] = [];
  isSuperAdmin: boolean = false;
  isAgent: boolean = false;
  isChatbotAdmin: boolean = false;
  isBusinessManager: boolean = false;
  configurations: ConfigurationSettings;
  userRoleDetails: IUserRoleDetails[] = [];
  userName: string = '';
  subscription: Subscription;
  newNotification: boolean = false;
  constructor(private userService: UserService,
    private messageService: MessageService,
    private router: Router,
    private configuration: ConfigurationSettings,
    private dataService: DataService,
    private notificationService: NotificationService,
    private communicationService: CommunicationService,
    private connectedStatusService: ConnectedStatusService) {
    this.configurations = configuration;

    this.subscription = this.notificationService.getHilConversationNotification().subscribe(notification => {
      if (notification && this.router.url != '/conversations/hilconversations') {
        this.notifications.push(notification);
      }
    });

    this.subscription = this.notificationService.clearAllNotifications().subscribe(notification => {
      if (!notification)
        this.notifications = [];
    });

    this.subscription = this.dataService.getUsername().subscribe(username => {
      if (username) {
        this.userName = username.text;
        if (this.userName && this.userName != '') {
          if (this.userName == 'User') {
            this.isSuperAdmin = false;
            this.isChatbotAdmin = false;
            this.isBusinessManager = false;
            this.isAgent = false;
            this.isLoggedOut = true;
          }
          else {
            this.userRoles = sessionStorage.getItem('userRoles') ? sessionStorage.getItem('userRoles').split(',') : [];
            let superAdmin = this.userRoles.find(ob => ob.toLowerCase() === 'superadmin' || ob.toLowerCase() === 'super admin');
            let chatbotAdmin = this.userRoles.find(ob => ob.toLowerCase() === 'chatbotadmin' || ob.toLowerCase() === 'chatbot admin');
            let businessManager = this.userRoles.find(ob => ob.toLowerCase() === 'businessmanager' || ob.toLowerCase() === 'business manager');
            let agent = this.userRoles.find(ob => ob.toLowerCase() === 'agent');
            if (superAdmin) {
              this.isSuperAdmin = true;
            }
            if (chatbotAdmin) {
              this.isChatbotAdmin = true;
            }
            if (agent) {
              this.isAgent = true;
            }
            if (businessManager) {
              this.isBusinessManager = true;
            }
          }
        }
      }
    });
    //if (this.isAgent) {
    this.subscription = this.connectedStatusService.getAgentConnectedStatus().subscribe(agentConnectedStatus => {
      this.isAgentHubConnection = agentConnectedStatus.status;
    });
    //}
  }
  collapse() {
    this.isExpanded = false;
  }

  toggle() {
    this.isExpanded = !this.isExpanded;
  }

  ngOnDestroy() {
    // unsubscribe to ensure no memory leaks
    this.subscription.unsubscribe();
  }
  public StopNotifictionAlert(): void {
    this.newNotification = false;
  }

  public removeNotification(item: any): void {
    this.notifications = this.notifications.filter(function (obj) {
      return (obj.notification.type !== item.notification.type
        && obj.notification.from !== item.notification.from
        && obj.notification.dateTime !== item.notification.dateTime);
    });
    this.navigateToConversations(item);
    //this.notificationService.clearAllNotifications();
  }
  public navigateToConversations(item: any) {
    if (this.router.url != '/conversations/hilconversations') {
      this.router.navigate(['/conversations/hilconversations']);
      localStorage.setItem("navigatedChatId", item.notification.ChatId);
      this.notificationService.clearAllNotifications();
      this.notifications = [];
    }
  }
}
