import { Component, OnInit, EventEmitter, Input, Output, ChangeDetectorRef } from '@angular/core';
import { HubConnection, HubConnectionBuilder } from '@microsoft/signalr';
import { IConversation } from '../../../models/iconversation';
import { CommunicationService } from '../../../services/shared/communication/communication.service';
import { MessageService } from '../../../services/shared/message/message.service';
import { IChatHistory } from 'src/app/models/chat-history';
import { TokenService } from 'src/app/services/core/token/token.service';
import { MatDialog } from '@angular/material';
import { HandoffCommentComponent } from '../../shared/handoff-comment/handoff-comment.component';
import { NotificationService } from '../../../services/shared/notification/notification.service';
import { ToasterService } from '../../../services/shared/toaster/toaster.service';
import { WarningPopupComponent } from '../../shared/warning-popup/warning-popup.component';
import { BotHistoryComponent } from '../../shared/bot-history/bot-history.component';
import { ConnectedStatusService } from 'src/app/services/shared/connection-status/connected-status.service';

@Component({
  selector: 'app-hilconversations',
  templateUrl: './hilconversations.component.html',
  styleUrls: ['./hilconversations.component.scss']
})
export class HilconversationsComponent implements OnInit {

  private _hubConnection: HubConnection;
  agentLoginId = '';
  activeBotUserName = '';
  activeBotUserId = '';
  activeBotName = '';
  activeBotHandOffComment = '';
  activeChatbotHistory: IChatHistory[] = [];
  agentNickName = '';
  hilRequest = false;
  connectedStatus = false;
  message = '';
  mm = {} as IConversation;
  conversations = [] as Array<IConversation>;
  activeConversations = [] as Array<IConversation>;
  activeConversationsByChatID = [] as Array<IConversation>;
  activeConversationId = '';
  messages = [];
  connectedBots = [];
  duplicateChat: any;
  agentName: string;
  scrollerHt: any;


  constructor(private service: CommunicationService,
    private toasterService: ToasterService,
    private notificationService: NotificationService,
    private messageService: MessageService,
    private tokenService: TokenService,
    private dialogComment: MatDialog,
    private dialogChatHistory: MatDialog,
    private dialogWarning: MatDialog,
    private changeDetector: ChangeDetectorRef,
    private connectedStatusService: ConnectedStatusService) {
  }
  ngAfterViewInit() {
    this.onNavigationFromNotifications();//set connected Bot based on notification selection
  }
  ngAfterViewChecked() {
    this.changeDetector.detectChanges();//refresh the chat window after row selection from notification
  }
  ngOnInit() {
    this.initialiseConversationTab();
  }

  initialiseConversationTab() {
    this._hubConnection = this.service.GetHubConnection();
    this.clearAllNotifications();
    var conBots = localStorage.getItem("connectedBots");
    if (conBots != null) {
      this.connectedBots = JSON.parse(conBots);
    }

    var conv = localStorage.getItem("conversations");
    if (conv != null) {
      this.conversations = JSON.parse(conv);
    }

    if (this._hubConnection) {
      //on HIL request handler
      let onHilRequestHandler = (botUserName: string, chatId: string, botName: string, handOffComment: string, chatHistory: IChatHistory[], botUserId: string) => {
        const chatInfo =
        {
          ChatId: chatId,
          BotUserName: botUserName,
          BotName: botName,
          HandOffComment: handOffComment,
          ChatHistory: chatHistory,
          BotUserId: botUserId
        }

        this.duplicateChat = this.connectedBots.find(x => x.BotUserName == botUserName && x.botName == botName);

        if (this.duplicateChat) {
          //this.connectedBots.slice(this.connectedBots.indexOf(this.duplicateChat)); // slice is used to select an element from array and not remove
          this.connectedBots.splice(this.connectedBots.indexOf(this.duplicateChat), 1);
          //this.connectedBots.splice(this.duplicateChat,this.connectedBots.indexOf(this.duplicateChat))
          //if (!this.connectedBots.find(x => x.botName == chatInfo.BotName && x.botUserName == chatInfo.BotUserName))
          this.connectedBots.push(chatInfo);
        }
        else {
          this.connectedBots.push(chatInfo);
        }
        // if (this.activeConversationId == '') {
        //   this.activeConversationId = chatInfo.ChatId;
        // }
        localStorage.setItem("connectedBots", JSON.stringify(this.connectedBots));
        this.toasterService.info(botUserName + " Connected");
      };

      this._hubConnection.off("OnHilRequest");
      this._hubConnection.on("OnHilRequest", onHilRequestHandler);

      //on receive message handler
      let onReceiveMessageHandler = (chat) => {
        const activity: IConversation = {
          ChatId: chat.chatId,
          Message: chat.message,
          Type: 'receive',
          DateTime: new Date(),
        };

        //apply css on new message arrival
        if (this.connectedBots.length > 1 && this.activeConversationId !== chat.chatId && document.getElementById(chat.chatId)) {
          this.applyBadgeOnConnectedBot(document.getElementById(chat.chatId).classList, 'new-chat-notification');
          //document.getElementById(chat.chatId).classList.remove('active-chat');
          //var activeChatList = document.getElementsByClassName("active-chat");
          //for (var i = 0; i < activeChatList.length; i++) {
          //  activeChatList[i].classList.remove('active-chat');
          //}
          //document.getElementById(chat.chatId).classList.add('new-chat-notification');
        }

        this.conversations.push(activity);

        this.activeConversations = this.conversations.filter(x => x.ChatId == this.activeConversationId);
        localStorage.setItem("conversations", JSON.stringify(this.conversations));
        this.scrollToBottom();
        this.sendNotification(activity);
      };

      this._hubConnection.off("ReceiveMessage");
      this._hubConnection.on("ReceiveMessage", onReceiveMessageHandler);


      //on Bot Disconnected handler
      let onBotDisconnectedHandler = (botName, chatId) => {
        if (this.activeConversationId == chatId) {
          this.activeConversations = [];
          const endChat = this.connectedBots.find(x => x.ChatId == chatId);
          if (endChat != null) {
            this.connectedBots.splice(this.connectedBots.indexOf(endChat), 1);
            this.hilRequest = false;
            this.toasterService.error(botName + " Disconnected");
          }
        }
        else {
          //remove the conversations for disconnected user which is other than active conversation user
          this.activeConversationsByChatID = this.conversations.filter(x => x.ChatId == chatId);
          if (this.activeConversationsByChatID) {
            this.conversations = this.conversations.filter(activity =>
              !this.activeConversationsByChatID.includes(activity)
            );
            localStorage.setItem("conversations", JSON.stringify(this.conversations));
            this.scrollToBottom();
          }

          //remove the connected bot entry for disconnected user
          const endChat = this.connectedBots.find(x => x.ChatId == chatId);
          if (endChat != null) {
            this.connectedBots.splice(this.connectedBots.indexOf(endChat), 1);
            this.hilRequest = false;
            this.toasterService.error(botName + " Disconnected");
          }
        }
        localStorage.setItem("connectedBots", JSON.stringify(this.connectedBots))
      };

      this._hubConnection.off("onBotDisconnected");
      this._hubConnection.on("onBotDisconnected", onBotDisconnectedHandler);

      this._hubConnection.onclose(() => {
        if (this.connectedBots.length > 0)
          this.toasterService.warn("Connection closed, re-establishing connection..");
        this.connectedStatusService.sendAgentConnectedStatus(false);
        if (sessionStorage.getItem('userEmailId') && sessionStorage.getItem('userEmailId') != '') {
          this.service.CreateHubConnection(true);
          setTimeout(() => {
            this.initialiseConversationTab();
          }, 3000);
        }
      }
      );
    }
    else {
      localStorage.clear();
      this.connectedBots = [];
      this.openWarning('connectionClosed');
    }
  }

  closeHubConnection() {
    if (this._hubConnection) {
      this._hubConnection
        .stop()
        .then(() => {
          this.connectedStatus = false;
        })
        .catch(err => this.toasterService.error("Error while establishing connection"));
    }
  }

  openWarning(value: string) {
    let dialogRef = this.dialogWarning.open(WarningPopupComponent, {
      height: '27%',
      width: '35%',
      autoFocus: false,
      data: value
    });
    dialogRef.afterClosed().subscribe(result => {

    })
  }

  public onNavigationFromNotifications(): void {
    if (localStorage.getItem("navigatedChatId")) {
      var navigatedChatId = localStorage.getItem("navigatedChatId");
      const navigatedBot = JSON.parse(localStorage.getItem("connectedBots")).find(x => x.ChatId == navigatedChatId);
      if (navigatedBot) {
        this.SetSelectedChat(document.getElementById(navigatedChatId), navigatedBot);
      }
      localStorage.removeItem("navigatedChatId");
    }
  }

  public sendNotification(activity: IConversation): void {
    this.notificationService.sendHilConversationNotification(activity);
  }

  public clearAllNotifications(): void {
    this.notificationService.clearAllNotifications();
  }

  public sendMessage(): void {
    const activity: IConversation = {
      ChatId: this.activeConversationId,
      Message: this.message,
      Type: 'send',
      DateTime: new Date(),
    };
    if (this._hubConnection) {
      this._hubConnection
        .invoke('Send', activity, true)
        .then(() => {
          this.conversations.push(activity);
          this.activeConversations = this.conversations.filter(x => x.ChatId == this.activeConversationId);
          this.message = '';
          localStorage.setItem("conversations", JSON.stringify(this.conversations));
          this.scrollToBottom();
        })

        .catch(err => {
          //TODO with status code
          if (err.message === "Failed to invoke 'Send' because user is unauthorized") {
            this.getRefreshToken();
          }
        })
    }
  }

  getRefreshToken() {
    this.tokenService.getRefreshToken()
      .subscribe(
        res => {
          let objToken = res;
          localStorage.setItem('accessToken', objToken.token);
          localStorage.setItem('refreshToken', objToken.refreshToken);
          this.sendMessage();
        },
        (error) => {
          //this.toastr.error("Error occured !!!");
        }
      );
  }
  applyBadgeOnConnectedBot(element: any, cssClass: any): void {
    if (element) {
      element.add(cssClass);
    }
  }
  removeBadgeOnConnectedBot(element: any, cssClass: any): void {
    if (element) {
      element.remove(cssClass);
    }
  }

  removeSelectionFromConnectedBots(): void {
    var connectedBotList = document.getElementsByClassName('active-chat');
    for (var i = 0; i < connectedBotList.length; i++) {
      connectedBotList[i].classList.remove('active-chat');
    }
  }

  scrollToBottom(): void {
    this.scrollerHt = document.getElementById("msgWindow") ? document.getElementById("msgWindow").scrollHeight : 0;
  }

  setActiveConnectedBot(bot: any): void {
    this.activeBotUserName = bot.BotUserName;
    this.activeBotUserId = bot.BotUserId;
    this.activeBotName = bot.BotName;
    this.activeBotHandOffComment = bot.HandOffComment;
    this.activeChatbotHistory = bot.ChatHistory;
    this.activeConversationId = bot.ChatId;
    this.activeConversations = this.conversations.filter(x => x.ChatId == this.activeConversationId);
    //localStorage.setItem("activeChatId", bot.ChatId);
    //event.target.classList.remove('new-chat-notification');
    ////make all active chats as inactive
    //var list = document.getElementsByClassName("active-chat");
    //for (var i = 0; i < list.length; i++) {
    //  list[i].classList.remove('active-chat');
    //}
    //event.target.classList.add('active-chat');
  }

  showSelectedChat() {
    this.hilRequest = true;
  }

  SetSelectedChat(event, bot): void {
    //set bot as currently active one in the connected bot list
    this.setActiveConnectedBot(bot);

    //reload the active chat css on connected bot list
    if (event)
      this.removeBadgeOnConnectedBot((event.classList ? event.classList : event.target.classList), 'new-chat-notification');
    this.removeSelectionFromConnectedBots();
    if (event)
      this.applyBadgeOnConnectedBot((event.classList ? event.classList : event.target.classList), 'active-chat');
    this.showSelectedChat();
  }

  EndSelectedChat(): void {
    this._hubConnection
      .invoke('EndChatByAgentAsync', this.activeConversationId, sessionStorage.getItem("userName"))
      .then(() => {
        this.activeConversations = [];
        const endChat = this.connectedBots.find(x => x.ChatId == this.activeConversationId);
        if (endChat != null) {
          this.connectedBots.splice(this.connectedBots.indexOf(endChat), 1);
          this.hilRequest = false;
          localStorage.setItem("connectedBots", JSON.stringify(this.connectedBots));
          //this.toasterService.info();
        }
      })
  }
  AgentLogOut(): void {
    this._hubConnection
      .stop()
      .then(() => {
        //this.toasterService.warn("Agent logged-out");
      })
      .catch(err => this.toasterService.error("Error while establishing connection"));
  }

  showComment(activeBotHandOffComment: string) {
    let dialogRef = this.dialogComment.open(HandoffCommentComponent, {
      height: '45%',
      width: '35%',
      autoFocus: false,
      data: activeBotHandOffComment
    });
    dialogRef.afterClosed().subscribe(result => {

    })
  }

  showConfirmationPopUp() {
    sessionStorage.removeItem('endChat');
    let dialogRef = this.dialogWarning.open(WarningPopupComponent, {
      height: '27%',
      width: '35%',
      autoFocus: false,
      data: 'endChat'
    });
    dialogRef.afterClosed().subscribe(result => {
      if (sessionStorage.getItem('endChat') == 'true')
        this.EndSelectedChat();
    })
  }

  showBotChatHistory(activeChatbotHistory: IChatHistory[]) {
    let dialogRef = this.dialogComment.open(BotHistoryComponent, {
      height: '60%',
      width: '60%',
      autoFocus: false,
      data: JSON.stringify(activeChatbotHistory)
    });
    dialogRef.afterClosed().subscribe(result => {

    })
  }
}
