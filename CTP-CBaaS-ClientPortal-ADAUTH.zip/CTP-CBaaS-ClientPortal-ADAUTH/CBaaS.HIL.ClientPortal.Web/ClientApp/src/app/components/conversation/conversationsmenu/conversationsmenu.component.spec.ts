import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConversationsmenuComponent } from './conversationsmenu.component';

describe('ConversationsmenuComponent', () => {
  let component: ConversationsmenuComponent;
  let fixture: ComponentFixture<ConversationsmenuComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConversationsmenuComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConversationsmenuComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
