import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HilconversationsComponent } from './hilconversations.component';

describe('HilconversationsComponent', () => {
  let component: HilconversationsComponent;
  let fixture: ComponentFixture<HilconversationsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HilconversationsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HilconversationsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
