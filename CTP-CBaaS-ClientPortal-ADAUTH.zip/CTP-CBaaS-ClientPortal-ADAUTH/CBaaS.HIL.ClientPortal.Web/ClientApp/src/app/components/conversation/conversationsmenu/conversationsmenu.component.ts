import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-conversationsmenu',
  templateUrl: './conversationsmenu.component.html',
  styleUrls: ['./conversationsmenu.component.scss']
})
export class ConversationsmenuComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    sessionStorage.setItem("lastActiveTab", "conversation");
  }

}
