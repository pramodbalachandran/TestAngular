import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboardmenu',
  templateUrl: './dashboardmenu.component.html',
  styleUrls: ['./dashboardmenu.component.scss']
})
export class DashboardmenuComponent implements OnInit {

  constructor() { }

  ngOnInit() {    
  }

}
