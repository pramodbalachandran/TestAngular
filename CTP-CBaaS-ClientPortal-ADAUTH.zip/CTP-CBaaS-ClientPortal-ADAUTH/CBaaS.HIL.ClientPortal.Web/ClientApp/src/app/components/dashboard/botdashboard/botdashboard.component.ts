import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import * as pbi from 'powerbi-client';
import { BotRegistrationService } from 'src/app/services/core/bot-registration/bot-registration.service';
import { ConfigurationSettings } from 'src/app/models/configuration.settings';
import { ToasterService } from '../../../services/shared/toaster/toaster.service';


@Component({
    selector: 'app-botdashboard',
    templateUrl: './botdashboard.component.html',
    styleUrls: ['./botdashboard.component.scss']
})
export class BotdashboardComponent implements OnInit {

    @ViewChild('reportContainer', null) embeddedReport: ElementRef;
    config: any;
    botList: any;
    BotListMessage: string;
    report: pbi.Embed;
    ReportConfig: any; 
    constructor(private httpClient: HttpClient,
        private botRegistrationService: BotRegistrationService,
        private configurationSetting: ConfigurationSettings,
        private toasterService: ToasterService) { }

    ngOnInit() {
        //Taking accessed bot list
        this.botRegistrationService.getRegisteredBots()
            .subscribe(
                res => {
                    sessionStorage.setItem("lastActiveTab", "dashboard");
                    this.botList = res;
                    const models = pbi.models;
                    if (this.botList.length > 0) {
                        //Calling Get report call
                        var url = this.configurationSetting.hostUrl + "/api/dashboard?reportId=" + this.botList[0].reportId;
                        this.httpClient.get<any>(url)
                            .subscribe(config => {
                                this.ReportConfig = config;
                                debugger;
                                if (!config.isSpnPowerBi) {
                                    let reportContainer = this.embeddedReport.nativeElement;
                                    let powerbi = new pbi.service.Service(pbi.factories.hpmFactory, pbi.factories.wpmpFactory, pbi.factories.routerFactory);
                                    let report1 = powerbi.embed(reportContainer, config);
                                } else {
                                    if (config.errorMessage != '' && config.errorMessage != null) { 
                                        this.ReportConfig.errorMessage = config.errorMessage;
                                    }
                                    else {
                                        let reportContainer = this.embeddedReport.nativeElement;
                                        let powerbi = new pbi.service.Service(pbi.factories.hpmFactory, pbi.factories.wpmpFactory, pbi.factories.routerFactory);

                                        var embedConfig = {
                                            type: 'report',
                                            tokenType: models.TokenType.Embed,
                                            accessToken: config.embedToken.token,
                                            embedUrl: config.embedUrl,
                                            id: config.id,
                                            permissions: models.Permissions.All,
                                        };
                                        let report1 = powerbi.embed(reportContainer, embedConfig);
                                    }
                                }
                            });
                    } else {
                        this.toasterService.warn("No BOT(s) available");
                    }                    
                },
                (error) => {
                    this.toasterService.error("Unable to fetch BOT(s) details at the moment");
                }

            )


    }

    onBotChange(reportId) {
        this.ReportConfig.errorMessage = ""; 
        var url = this.configurationSetting.hostUrl + "/api/dashboard?reportId=" + reportId;
        let reportContainer = this.embeddedReport.nativeElement;
        let powerbi = new pbi.service.Service(pbi.factories.hpmFactory, pbi.factories.wpmpFactory, pbi.factories.routerFactory);
        powerbi.reset(reportContainer);
        const models = pbi.models;
        this.httpClient.get<any>(url)
            .subscribe(config => {
                debugger;
                this.ReportConfig = config;
                if (!config.isSpnPowerBi) {
                    let report1 = powerbi.embed(reportContainer, config);
                } else {
                    this.report = config;
                    if (config.errorMessage != '' && config.errorMessage != null) { 
                        this.ReportConfig.errorMessage = config.errorMessage;
                    }
                    else {
                        let reportContainer = this.embeddedReport.nativeElement;
                        let powerbi = new pbi.service.Service(pbi.factories.hpmFactory, pbi.factories.wpmpFactory, pbi.factories.routerFactory);

                        var embedConfig = {
                            type: 'report',
                            tokenType: models.TokenType.Embed,
                            accessToken: config.embedToken.token,
                            embedUrl: config.embedUrl,
                            id: config.id,
                            permissions: models.Permissions.All,
                        };
                        let report1 = powerbi.embed(reportContainer, embedConfig);
                    }
                }
            });
    }

}
