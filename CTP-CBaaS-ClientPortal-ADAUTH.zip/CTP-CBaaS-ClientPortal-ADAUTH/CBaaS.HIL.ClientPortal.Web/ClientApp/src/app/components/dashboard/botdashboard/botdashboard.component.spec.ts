import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BotdashboardComponent } from './botdashboard.component';

describe('BotdashboardComponent', () => {
  let component: BotdashboardComponent;
  let fixture: ComponentFixture<BotdashboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BotdashboardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BotdashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
