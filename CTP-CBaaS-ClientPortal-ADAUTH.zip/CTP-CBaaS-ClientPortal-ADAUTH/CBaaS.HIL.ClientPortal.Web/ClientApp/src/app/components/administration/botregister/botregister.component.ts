import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { IBotInfo } from 'src/app/models/bot-info';
import { Subscription } from 'rxjs';
import { IBotRegistration } from 'src/app/models/bot-registration';
import { BotRegistrationService } from 'src/app/services/core/bot-registration/bot-registration.service';
import { ToasterService } from 'src/app/services/shared/toaster/toaster.service';

@Component({
  selector: 'app-botregister',
  templateUrl: './botregister.component.html',
  styleUrls: ['./botregister.component.scss']
})
export class BotregisterComponent implements OnInit {

  newBotRegisterForm: FormGroup;
  OfferingType: FormControl;
  BotId: FormControl;
  BotName: FormControl;
  BotType: FormControl;
  ClientName: FormControl;
  ServiceLine: FormControl;
  //SourceType: FormControl;
  //SourceDetails: FormControl;
  ReportId: FormControl;
  status: string;
  botConfigDetails: {
    botId: any,
    displayName: string,
    serviceLine: string,
    id: number
  }
  botRegistrationDetails: IBotRegistration;
  botRegistrationId: number;
  botConfigId: number;
  registeredBotData: IBotInfo;
  private _subscriptions = new Subscription();
  offeringTypes: string[] = [];
  public addBotRegistration: boolean = false;
  public hasError: boolean = false;
  constructor(private _botRegistrationService: BotRegistrationService,
    private _toaster: ToasterService,
    private router: Router,
    private route: ActivatedRoute) { }
  //private spinner: NgxSpinnerService) { }

  ngOnInit() {
    this.hasError = false;
    this.OfferingType = new FormControl('', Validators.required)
    this.BotId = new FormControl('', Validators.required)
    this.BotName = new FormControl({ value: '', disabled: true }, Validators.required)
    this.BotType = new FormControl('', Validators.required)
    this.ClientName = new FormControl('', Validators.compose([Validators.required, Validators.maxLength(200)]))
    this.ServiceLine = new FormControl({ value: '', disabled: true }, Validators.required)
    //this.SourceType = new FormControl('', Validators.required)
    //this.SourceDetails = new FormControl('', Validators.required)
    this.ReportId = new FormControl('', Validators.pattern(/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i))
    this.newBotRegisterForm = new FormGroup({
      OfferingType: this.OfferingType,
      BotId: this.BotId,
      BotName: this.BotName,
      BotType: this.BotType,
      ClientName: this.ClientName,
      ServiceLine: this.ServiceLine,
      //SourceType: this.SourceType,
      //SourceDetails: this.SourceDetails,
      ReportId: this.ReportId
    })
    this._subscriptions.add(
      this._botRegistrationService.getBotOfferingTypes()
        .subscribe(
          res => {
            this.offeringTypes = res;
          },
          (error) => {
            this._toaster.error("Something went wrong !!!");
            this.hasError = true;
          }
        )
    )
    //For Edit
    this._subscriptions.add(
      this.route.queryParams.subscribe(params => {
        this.botRegistrationId = params['Id'];
      }));

    if (this.botRegistrationId && this.botRegistrationId != 0) {
      this._subscriptions.add(
        this._botRegistrationService.getRegisteredBotDetails(this.botRegistrationId)
          .subscribe(
            res => {
              this.registeredBotData = res;
              this.ServiceLine.setValue(this.registeredBotData.serviceLine);
              this.BotName.setValue(this.registeredBotData.displayName);
              this.BotId.setValue(this.registeredBotData.botId);
              this.newBotRegisterForm.controls['BotId'].disable();
              this.OfferingType.setValue(this.registeredBotData.offeringType);
              this.BotType.setValue(this.registeredBotData.botType);
              this.ClientName.setValue(this.registeredBotData.customerContact);              
              this.ReportId.setValue(this.registeredBotData.reportId);
            },
            (error) => {
              this._toaster.error("Something went wrong !!!");
              this.hasError = true;
            }
          )
      )
    }
  }

  registerBotSave(formValues) {
    this.addBotRegistration = true;
    //Bot Registration Edit
    if (this.botRegistrationId && this.botRegistrationId != 0) {
      this.botRegistrationDetails = {
        botConfigId: this.registeredBotData.botConfigId,
        customerContact: formValues.ClientName,
        botType: formValues.BotType,        
        offeringType: formValues.OfferingType,
        isActive: true,
        id: this.registeredBotData.botRegistrationId,
        reportId: formValues.ReportId == "" ? null : formValues.ReportId
      }
    }
    // New Bot Registration
    else {
      this.botRegistrationDetails = {
        botConfigId: this.botConfigDetails.id,
        customerContact: formValues.ClientName,
        botType: formValues.BotType,       
        offeringType: formValues.OfferingType,
        isActive: true,
        id: 0,
        reportId: formValues.ReportId == "" ? null : formValues.ReportId
      }
    }
    this._subscriptions.add(
      this._botRegistrationService.addUpdateBotRegistration(this.botRegistrationDetails)
        .subscribe(
          res => {
            this.addBotRegistration = false;
            if (this.botRegistrationId && this.botRegistrationId != 0)
              this._toaster.success("Bot registration updated successfully!!");
            else
              this._toaster.success("Bot registered successfully!!");
            this.newBotRegisterForm.reset();
            this.router.navigate(['administration/botlookup']);
          },
          (error) => {
            this.addBotRegistration = false;
          }
        )
    )
  }

  resetform() {
    this.newBotRegisterForm.reset();
  }

  valuechange(event) {

    this._subscriptions.add(
      this._botRegistrationService.getBotConfigData(event.currentTarget.value)
        .subscribe(
          res => {
            if (res) {
              this.hasError = false;
              this.OfferingType.enable();
              this.ClientName.enable();
              this.ReportId.enable();
              this.BotType.enable();
              this.botConfigDetails = res;
              this.ServiceLine.setValue(this.botConfigDetails.serviceLine);
              this.BotName.setValue(this.botConfigDetails.displayName);
            }
            else {
              this._toaster.error("Bot Not Found");
              this.hasError = true;
              this.ServiceLine.setValue("");
              this.BotName.setValue("");
              this.OfferingType.disable();
              this.ClientName.disable();
              this.ReportId.disable();
              this.BotType.disable();
            }
          },
          (error) => {
            this.hasError = true;
            this.ServiceLine.setValue("");
            this.BotName.setValue("");
            this.OfferingType.disable();
            this.ClientName.disable();
            this.ReportId.disable();
            this.BotType.disable();
          }
        )
    )
  }

  ngOnDestroy(): void {
    this._subscriptions.unsubscribe();
  }


}
