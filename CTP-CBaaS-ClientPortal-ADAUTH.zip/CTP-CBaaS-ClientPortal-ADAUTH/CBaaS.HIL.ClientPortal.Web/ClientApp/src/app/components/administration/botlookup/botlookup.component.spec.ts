import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BotlookupComponent } from './botlookup.component';

describe('BotlookupComponent', () => {
  let component: BotlookupComponent;
  let fixture: ComponentFixture<BotlookupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BotlookupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BotlookupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
