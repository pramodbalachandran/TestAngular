import { Component, OnInit } from '@angular/core';
import { Inject } from '@angular/core';
import { UserService } from 'src/app/services/core/user/user.service';
import { ToastrService } from 'ngx-toastr';
import { Subscription } from 'rxjs';
import { IUserRoleDetails } from 'src/app/models/user-role-details';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';
import { ConfigurationSettings } from 'src/app/models/configuration.settings';
import { startWith, map, debounceTime, tap, switchMap, finalize } from 'rxjs/operators';
import { IRoles } from 'src/app/models/roles';
import { ActivatedRoute } from '@angular/router';
import { ToasterService } from '../../../services/shared/toaster/toaster.service';
import { MatDialog } from '@angular/material';
import { WarningPopupComponent } from '../../shared/warning-popup/warning-popup.component';

@Component({
  selector: 'app-userrolemanagement',
  templateUrl: './userrolemanagement.component.html',
  styleUrls: ['./userrolemanagement.component.scss']
})
export class UserrolemanagementComponent implements OnInit {
  paginationPageSize = 5;
  newUserRoleForm: FormGroup;
  UserName: FormControl;
  Role: FormControl;
  UserType: FormControl;
  public roles: IRoles[] = [];
  public userRoles: IUserRoleDetails[] = [];
  public botConfigId: number;
  public botData: any;
  public selectedRole: string = '';
  private _subscriptions = new Subscription();
  isSearching: boolean;
  filteredOptions: any;
  private gridApi;
  private gridColumnApi;
  public columnDefs: any[] = [];
  public sortingOrder;
  public defaultColDef;
  public addUserRole: boolean = false;
  public userType: string;
  public selectedUserId: string;
  constructor(private userService: UserService,
    private toasterService: ToasterService,
    private toastr: ToastrService,
    private http: HttpClient,
    private configurationSettings: ConfigurationSettings,
    private route: ActivatedRoute,
    private dialogWarning: MatDialog) {
    this.isSearching = false;
  }


  rowData = [];
  ngOnInit() {
    this.botData = JSON.parse(sessionStorage.getItem('botData'));
    this.botConfigId = this.botData.botConfigId;
    this.createColumnDefs();
    this.UserType = new FormControl('', Validators.required)
    this.UserName = new FormControl({ value: '', disabled: true }, Validators.compose([Validators.required, Validators.pattern(/^([a-zA-Z0-9_\-\.]+)@([a-zA-Z0-9_\-\.]+)\.([a-zA-Z]{2,5})$/)]))
    this.Role = new FormControl({ value: '', disabled: true }, Validators.required)

    this.newUserRoleForm = new FormGroup({
      UserName: this.UserName,
      Role: this.Role,
      UserType: this.UserType
    })

    this._subscriptions.add(
      this.userService.getRoles()
        .subscribe(
          res => {
            this.roles = res;
            this.getAllUserRoles(this.botConfigId);
          },
          (error) => {
            this.toasterService.error("Unable to retrive User-Roles");
          }
        )
    )
  }

  getAllUserRoles(botConfigId: number) {
    this._subscriptions.add(
      this.userService.getAllUserRoles(botConfigId)
        .subscribe(
          res => {
            this.rowData = res;
          },
          (error) => {
            this.toasterService.error("Unable to retrive User-Roles");
          }
        )
    )
  }

  onItemChange(Value) {
    this.userType = this.newUserRoleForm.value.UserType;
    this.UserName.setValue("");
    this.Role.setValue("");
    this.UserName.enable();
    this.Role.enable();
    this.peoplePickerFn();
  }

  onSelectionChanged(selectedUser) {
    this.selectedUserId = selectedUser;
  }

  peoplePickerFn() {
    this.UserName.valueChanges
      .pipe(
        debounceTime(300),
        map(value => value ? typeof value === 'string' ? value.length >= 3 ? value : [] : value.emailAddress : []),
        tap(() => {
          this.filteredOptions = [];
          this.isSearching = true;
        }),
        switchMap(value => this.http.get(this.configurationSettings.user_api_endpoint + "/GetMatchingUsers?user=" + value + "&userType=" + this.userType)
          .pipe(
            finalize(() => {
              this.isSearching = false
            }),
          )
        )
      )
      .subscribe(data => {
        if (data) {
          this.filteredOptions = data;
        }
      });
  }

  registerUserSave(formValues) {
    if (this.selectedUserId != formValues.UserName) {
      this.toasterService.error("Invalid user");
    }
    else {
      //this.spinner.show();    
      for (let i = 0; i < formValues.Role.length; i++) {
        this.userRoles[i] = {
          botConfigId: this.botConfigId,
          username: formValues.UserName,
          userId: 0,
          roleId: this.roles.findIndex(item => item.displayName === formValues.Role[i]) > -1 ? this.roles[this.roles.findIndex(item => item.displayName === formValues.Role[i])].id : 0,
          role: formValues.Role[i],
          firstname: "",
          lastname: "",
          isExternal: formValues.UserType == 'External' ? true : false
        };
      }
      let data = this.rowData.find(ob => ob.username.toLowerCase() === formValues.UserName.toLowerCase() && ob.role === formValues.Role[0]);
      if (!data || data === null) {
        this.addUserRole = true;
        this._subscriptions.add(
          this.userService.addUserRoles(this.userRoles)
            .subscribe(
              res => {
                this.toasterService.success("successfully added User role");
                this.newUserRoleForm.markAsUntouched();
                this.newUserRoleForm.reset();
                this.rowData = res;
                this.UserName.disable();
                this.Role.disable();
                this.peoplePickerFn();
                this.addUserRole = false;
              },
              (error) => {
                //this.spinner.hide();
                //this.toastr.error("Error Occured!");
                //this.toasterService.error("Error Occured while adding User role");              
                this.addUserRole = false;
              }
            )
        )
      }
      else {
        // this.spinner.hide();
        //this.toastr.error("User role already exists!")
        this.toasterService.error("User role mapping already exists");
      }
    }
  }

  ngOnDestroy(): void {
    this._subscriptions.unsubscribe();
  }


  createColumnDefs() {
    const customComparator = (valueA, valueB) => {
      valueA = valueA ? valueA : '';
      valueB = valueB ? valueB : '';
      return valueA.toLowerCase().localeCompare(valueB.toLowerCase());
    };
    const columnDefs = [
      { headerName: 'User', field: 'username', width: 200, comparator: customComparator, filter: true, sortable: true, sortingOrder: ["asc", "desc"] },
      { headerName: 'Role', field: 'role', width: 100, comparator: customComparator, filter: true, sortable: true, sortingOrder: ["asc", "desc"] },
      { headerName: 'Delete', width: 90, cellRenderer: this.deleteCellRenderer.bind(this) },
    ]
    this.columnDefs = columnDefs;    
  }

  deleteCellRenderer(userRole: any) {
    const element = document.createElement('span');

    let template = '<i class="fa fa-trash" aria-hidden="true" style="cursor: pointer;"></i>';
    element.innerHTML = template;
    element.addEventListener('click', () => {
      this.openWarning(userRole);
    });
    return element;
  }

  openWarning(userRole: any) {
    let dialogRef = this.dialogWarning.open(WarningPopupComponent, {
      height: '27%',
      width: '35%',
      autoFocus: false,
      data: userRole
    });
    dialogRef.afterClosed().subscribe(result => {
      this.getAllUserRoles(userRole.data.botConfigId);
    })
  }

  onGridReady(params) {
    this.gridApi = params.api;
    this.gridApi.sizeColumnsToFit();
    this.gridColumnApi = params.columnApi;
    this.gridApi.setDomLayout("autoHeight");
  }

}
