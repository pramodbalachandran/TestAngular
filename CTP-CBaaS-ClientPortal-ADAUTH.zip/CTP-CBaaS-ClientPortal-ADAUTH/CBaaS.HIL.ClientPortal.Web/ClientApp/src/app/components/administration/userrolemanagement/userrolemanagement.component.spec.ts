import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserrolemanagementComponent } from './userrolemanagement.component';

describe('UserrolemanagementComponent', () => {
  let component: UserrolemanagementComponent;
  let fixture: ComponentFixture<UserrolemanagementComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserrolemanagementComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserrolemanagementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
