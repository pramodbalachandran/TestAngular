import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-administrationmenu',
  templateUrl: './administrationmenu.component.html',
  styleUrls: ['./administrationmenu.component.scss']
})
export class AdministrationmenuComponent implements OnInit {
  public userRoles: string[] = [];
  public canDoBotRegistration: boolean = false;
  constructor() { }

  ngOnInit() {
    this.userRoles = sessionStorage.getItem('userRoles') ? sessionStorage.getItem('userRoles').split(',') : [];
    let botRegistrationView = this.userRoles.find(ob => ob.toLowerCase() === 'superadmin' || ob.toLowerCase() === 'super admin');
    if (botRegistrationView) {
      this.canDoBotRegistration = true;
    }    
  }

}
