import { Component, OnInit } from '@angular/core';
import { UserrolemanagementComponent } from '../userrolemanagement/userrolemanagement.component';
import { Subscription } from 'rxjs';
import { ConfigurationSettings } from 'src/app/models/configuration.settings';
import { BotRegistrationService } from 'src/app/services/core/bot-registration/bot-registration.service';
import { ToastrService } from 'ngx-toastr';
import { Router } from '@angular/router';
import { IUserRoleDetails } from 'src/app/models/user-role-details';
import { IBotRegistration } from 'src/app/models/bot-registration';
import { WarningPopupComponent } from '../../shared/warning-popup/warning-popup.component';
import { MatDialog } from '@angular/material';
import { SessionstorageService } from 'src/app/services/shared/sessionstorage/sessionstorage.service';
import { ToasterService } from 'src/app/services/shared/toaster/toaster.service';

@Component({
  selector: 'app-botlookup',
  templateUrl: './botlookup.component.html',
  styleUrls: ['./botlookup.component.scss']
})
export class BotlookupComponent implements OnInit {

  paginationPageSize = 10;
  public columnDefs: any[] = [];
  public rowData: IBotRegistration[] = [];
  private userRoles: string[] = [];
  private userRoleDetails: IUserRoleDetails[] = [];
  public canDoBotRegistration: boolean = false;
  public canAddUserRole: boolean = false;
  private width: string;
  private gridApi;
  public domLayout;
  private gridColumnApi;
  private _subscriptions = new Subscription();
  public sortingOrder;
  public defaultColDef;
  configurations: ConfigurationSettings;
  constructor(private botRegistrationService: BotRegistrationService,
    private toasterService: ToasterService,
    private toastr: ToastrService,
    private router: Router,
    private dialogWarning: MatDialog,
    private configuration: ConfigurationSettings,
    private sessionStorageService: SessionstorageService) {
    this.configurations = configuration;
  }

  ngOnInit() {
    this.getUserRoles();
    this.domLayout = "autoHeight";
    this.createRowData();
  }

  createColumnDefs() {
    const customComparator = (valueA, valueB) => {      
      valueA = valueA ? valueA : '';
      valueB = valueB ? valueB : '';
      return valueA.toLowerCase().localeCompare(valueB.toLowerCase());
    };
    const columnDefs = [
      { headerName: 'Bot Id', field: 'botId', width: 250, filter: true, comparator: customComparator, sortable: true, sortingOrder: ["asc", "desc"] },
      { headerName: 'Bot Name', field: 'displayName', width: 100, filter: true, comparator: customComparator, sortable: true, sortingOrder: ["asc", "desc"] },
      { headerName: 'Service Line', field: 'serviceLine', width: 110, filter: true, comparator: customComparator, sortable: true, sortingOrder: ["asc", "desc"] },
      { headerName: 'Offering Type', field: 'offeringType', width: 125, filter: true, comparator: customComparator, sortable: true, sortingOrder: ["asc", "desc"] },
      { headerName: 'Bot Type', field: 'botType', width: 90, filter: true, comparator: customComparator, sortable: true, sortingOrder: ["asc", "desc"] },
      { headerName: 'Engagement/Client Name', field: 'customerContact', width: 185, filter: true, comparator: customComparator, sortable: true, sortingOrder: ["asc", "desc"] },
      { headerName: 'Add User/Role', width: 120, hide: !this.canAddUserRole, cellRenderer: this.addUserRoleCellRenderer.bind(this) },
      { headerName: 'Edit', field: 'botRegistrationId', width: 60, left: 637, hide: !this.canDoBotRegistration, cellRenderer: this.editCellRenderer.bind(this) },
      { headerName: 'Delete', width: 60, hide: !this.canDoBotRegistration, cellRenderer: this.deleteCellRenderer.bind(this) },
    ]
    this.columnDefs = columnDefs;

  }

  getUserRoles() {
    this.userRoles = sessionStorage.getItem('userRoles') ? sessionStorage.getItem('userRoles').split(',') : [];
    let botRegistrationView = this.userRoles.find(ob => ob.toLowerCase() === 'superadmin' || ob.toLowerCase() === 'super admin');
    if (botRegistrationView) {
      this.canDoBotRegistration = true;
      this.canAddUserRole = true;
    }
    else {
      let userRolesAdd = this.userRoles.find(ob => ob.toLowerCase() === 'superadmin' || ob.toLowerCase() === 'super admin' || ob.toLowerCase() === 'chatbotadmin' || ob.toLowerCase() === 'chatbot admin');
      if (userRolesAdd) {
        this.canAddUserRole = true;
      }
    }

  }
  createRowData() {
    this._subscriptions.add(
      this.botRegistrationService.getRegisteredBots()
        .subscribe(
          res => {            
            this.rowData = res;
            sessionStorage.setItem("lastActiveTab", "administration");
            this.createColumnDefs();
          },
          (error) => {
            this.toasterService.error("Unable to retrive BOT(s) details");
          }
        )
    )
  }

  editCellRenderer(param) {
    const element = document.createElement('span');
    let cellValue = "Edit";
    let template = '<i class="fa fa-edit" aria-hidden="true" style="cursor: pointer;"></i>';
    element.innerHTML = template;
    element.addEventListener('click', (event) => {

      this.router.navigate(['administration/botregisteredit'],
        { queryParams: { Id: param.value } });
    });
    return element;
  }

  deleteCellRenderer(botRegistration: any) {
    const element = document.createElement('span');

    let template = '<i class="fa fa-trash" aria-hidden="true" style="cursor: pointer;"></i>';
    element.innerHTML = template;
    element.addEventListener('click', () => {
      this.openWarning(botRegistration);
    });
    return element;
  }

  openWarning(botRegistration: any) {
    let dialogRef = this.dialogWarning.open(WarningPopupComponent, {
      height: '27%',
      width: '35%',
      autoFocus: false,
      data: botRegistration
    });
    dialogRef.afterClosed().subscribe(result => {
      this.createRowData();
    })
  }


  addUserRoleCellRenderer(botInfo: any) {
    let botData = JSON.stringify(botInfo.data);
    const element = document.createElement('span');
    let template = '<i class="fa fa-plus" aria-hidden="true" style="cursor: pointer;"></i>';
    element.innerHTML = template;
    element.addEventListener('click', () => {
      sessionStorage.removeItem('botData');
      sessionStorage.setItem('botData', botData);
      this.router.navigate(['administration/userrolemanagement']);
    });
    return element;
  }

  onGridReady(params) {
    this.gridApi = params.api;
    this.gridApi.sizeColumnsToFit();
    this.gridColumnApi = params.columnApi;
    this.gridApi.setDomLayout("autoHeight");
    //this.gridApi.paginationGoToPage(2);   
  }

  ngOnDestroy(): void {
    this._subscriptions.unsubscribe();
  }
}
