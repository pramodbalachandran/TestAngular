import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AdministrationmenuComponent } from './administrationmenu.component';

describe('AdministrationmenuComponent', () => {
  let component: AdministrationmenuComponent;
  let fixture: ComponentFixture<AdministrationmenuComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AdministrationmenuComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AdministrationmenuComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
