import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BotregisterComponent } from './botregister.component';

describe('BotregisterComponent', () => {
  let component: BotregisterComponent;
  let fixture: ComponentFixture<BotregisterComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BotregisterComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BotregisterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
