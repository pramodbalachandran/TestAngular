import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { IUserDetails } from 'src/app/models/user';
import { UserService } from 'src/app/services/core/user/user.service';
import { ToasterService } from 'src/app/services/shared/toaster/toaster.service';
import { Router, ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-userregister',
  templateUrl: './userregister.component.html',
  styleUrls: ['./userregister.component.scss']
})
export class UserregisterComponent implements OnInit {
  newUserRegisterForm: FormGroup;
  //userType : FormControl;
  firstName: FormControl;
  lastName: FormControl;
  emailId: FormControl;
  company: FormControl;

  userRegistrationDetails: IUserDetails;
  userId: number = 0;
  public addUser: boolean = false;
  private _subscriptions = new Subscription();

  constructor(private _userService: UserService,
    private _toaster: ToasterService,
    private router: Router,
    private route: ActivatedRoute) { }

  ngOnInit() {
    //this.userType = new FormControl('', Validators.required)
    this.firstName = new FormControl('',  Validators.compose([Validators.required, Validators.maxLength(50)]))
    this.lastName = new FormControl('',  Validators.compose([Validators.required, Validators.maxLength(50)]))
    this.emailId = new FormControl('', Validators.compose([Validators.required, Validators.maxLength(50), Validators.pattern(/^([a-zA-Z0-9_\-\.]+)@([a-zA-Z0-9_\-\.]+)\.([a-zA-Z]{2,5})$/)]))
    this.company = new FormControl('',Validators.maxLength(50))

    this.newUserRegisterForm = new FormGroup({
      //userType: this.userType,
      emailId: this.emailId,
      firstName: this.firstName,
      lastName: this.lastName,
      company: this.company
    })

    //For Edit
    this._subscriptions.add(
      this.route.queryParams.subscribe(params => {
        this.userId = parseInt(params['Id']);
        this.userId = isNaN(this.userId) ? 0 : this.userId;
      }));

    if (this.userId && this.userId != 0) {
      this.userRegistrationDetails = JSON.parse(sessionStorage.getItem('userData'));
      this.firstName.setValue(this.userRegistrationDetails.firstName);
      this.lastName.setValue(this.userRegistrationDetails.lastName);
      this.emailId.setValue(this.userRegistrationDetails.userName);
      this.company.setValue(this.userRegistrationDetails.company);
    }
  }

  registerUserSave(formValues) {
    this.addUser = true;
    //Update User Registration (Internal & External)
    if (this.userId && this.userId != 0) {
      this.userRegistrationDetails = {
        userName: formValues.emailId,
        firstName: formValues.firstName,
        lastName: formValues.lastName,
        isExternal: this.userRegistrationDetails.isExternal,
        isActive: true,
        company: formValues.company,
        id: this.userId,
        userType: this.userRegistrationDetails.userType,
        status: "true"
      }
    }
    // New User Registration only External
    else {
      this.userRegistrationDetails = {
        userName: formValues.emailId,
        firstName: formValues.firstName,
        lastName: formValues.lastName,
        isExternal: true,//formValues.userType == 'External' ? true : false,  
        isActive: true,
        company: formValues.company,
        id: 0,
        userType: 'External',//formValues.userType,
        status: "true"
      }
    }

    this._subscriptions.add(
      this._userService.addUpdateUserRegistration(this.userRegistrationDetails)
        .subscribe(
          res => {
            if (this.userId && this.userId != 0)
              this._toaster.success("User info updated successfully!!");
            else
              this._toaster.success("User registered successfully!!");
            this.newUserRegisterForm.reset();
            this.addUser = false;
            this.router.navigate(['administration/userlookup']);
          },
          (error) => {
            this.addUser = false;
          }
        )
    )
  }

  resetform() {
    this.newUserRegisterForm.reset();
  }

}
