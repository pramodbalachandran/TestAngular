import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/app/services/core/user/user.service';
import { ToasterService } from 'src/app/services/shared/toaster/toaster.service';
import { MatDialog } from '@angular/material';
import { SessionstorageService } from 'src/app/services/shared/sessionstorage/sessionstorage.service';
import { Router } from '@angular/router';
import { WarningPopupComponent } from '../../shared/warning-popup/warning-popup.component';
import { Subscription } from 'rxjs';
import { IUserDetails } from 'src/app/models/user';

@Component({
  selector: 'app-userlookup',
  templateUrl: './userlookup.component.html',
  styleUrls: ['./userlookup.component.scss']
})
export class UserlookupComponent implements OnInit {
  domLayout: string;
  paginationPageSize = 10;
  public columnDefs: any[] = [];
  public rowData: IUserDetails[] = [];
  private gridApi;
  private gridColumnApi;
  public userData: any[] = [];
  public sortingOrder;
  public defaultColDef;
  private _subscriptions = new Subscription();
  constructor(private userService: UserService,
    private toasterService: ToasterService,
    private router: Router,
    private dialogWarning: MatDialog) { }

  ngOnInit() {
    this.domLayout = "autoHeight";
    this.createRowData();
  }

  createColumnDefs() {
    const customComparator = (valueA, valueB) => {      
      valueA = valueA ? valueA : '';
      valueB = valueB ? valueB : '';
      return valueA.toLowerCase().localeCompare(valueB.toLowerCase());
    };
    const columnDefs = [
      { headerName: 'Email Id', field: 'userName', width: 200, comparator: customComparator, filter: true, sortable: true, sortingOrder: ["asc", "desc"] },
      { headerName: 'First Name', field: 'firstName', width: 110, comparator: customComparator, filter: true, sortable: true, sortingOrder: ["asc", "desc"] },
      { headerName: 'Last Name', field: 'lastName', width: 120, comparator: customComparator, filter: true, sortable: true, sortingOrder: ["asc", "desc"] },
      { headerName: 'User Type', field: 'userType', width: 110, comparator: customComparator, filter: true, sortable: true, sortingOrder: ["asc", "desc"] },
      { headerName: 'Company', field: 'company', width: 100, comparator: customComparator, filter: true, sortable: true, sortingOrder: ["asc", "desc"] },
      // { headerName: 'Status', field: 'status', width: 100, comparator : customComparator, filter: true, sortable : true, sortingOrder:["asc", "desc"] },
      { headerName: 'Edit', width: 60, left: 637, cellRenderer: this.editCellRenderer.bind(this) },
      { headerName: 'Delete', width: 60, cellRenderer: this.deleteCellRenderer.bind(this) },
    ]
    this.columnDefs = columnDefs;
  }


  createRowData() {
    this._subscriptions.add(
      this.userService.getAllUsers()
        .subscribe(
          res => {          
            this.userData = res;
            this.userData.forEach(element => {
              element.userType = element.isExternal == false ? 'Internal' : 'External';
              element.status = element.isActive == false ? 'Inactive' : 'Active';
            });            
            this.rowData = this.userData;
            this.createColumnDefs();
          },
          (error) => {
            this.toasterService.error("Unable to retrive User(s) details");
          }
        )
    )
  }

  editCellRenderer(userDetails: any) {
    const element = document.createElement('span');
    let cellValue = "Edit";
    let template = '<i class="fa fa-edit" aria-hidden="true" style="cursor: pointer;"></i>';
    element.innerHTML = template;
    element.addEventListener('click', (event) => {
      sessionStorage.removeItem('userData');
      let userData = JSON.stringify(userDetails.data);
      sessionStorage.setItem('userData', userData);
      this.router.navigate(['administration/userregisteredit'],
        { queryParams: { Id: userDetails.data.id } });
    });
    return element;
  }

  deleteCellRenderer(userDetails: any) {
    const element = document.createElement('span');

    let template = '<i class="fa fa-trash" aria-hidden="true" style="cursor: pointer;"></i>';
    element.innerHTML = template;
    element.addEventListener('click', () => {
      this.openWarning(userDetails);
    });
    return element;
  }

  openWarning(userDetails: any) {
    let dialogRef = this.dialogWarning.open(WarningPopupComponent, {
      height: '35%',
      width: '35%',
      autoFocus: false,
      data: userDetails
    });
    dialogRef.afterClosed().subscribe(result => {
      this.createRowData();
    })
  }

  onGridReady(params) {
    this.gridApi = params.api;
    this.gridApi.sizeColumnsToFit();
    this.gridColumnApi = params.columnApi;
    this.gridApi.setDomLayout("autoHeight");
    //this.gridApi.paginationGoToPage(2);  
  }

  ngOnDestroy(): void {
    this._subscriptions.unsubscribe();
  }

}
