import { Injectable } from '@angular/core';
import { HttpRequest, HttpHandler, HttpEvent, HttpInterceptor } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { Router } from '@angular/router';
import { ToasterService } from '../../services/shared/toaster/toaster.service';
import { MatDialog } from '@angular/material';
import { WarningPopupComponent } from 'src/app/components/shared/warning-popup/warning-popup.component';


@Injectable()
export class ErrorInterceptor implements HttpInterceptor {
  public userRoles: string[] = [];
  constructor(private toasterService: ToasterService, private router: Router, private dialogWarning: MatDialog) {

  }

  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    return next.handle(request).pipe(catchError(err => {

      if (err.status === 401) {
        //this.userRoles = sessionStorage.getItem('userRoles') ? sessionStorage.getItem('userRoles').split(',') : [];
        //let agent = this.userRoles.find(ob => ob.toLowerCase() === 'agent');
        //if (agent && err.error && err.error == "Error: Invalid Access Token") {
        if (err.error && err.error == "Error: Invalid Access Token") {
          this.openWarning('expiredToken');
        }
        else
          this.router.navigate(['/error']);
      }
      if (err.error && err.error.value && err.error.value.length <= 50) {
        this.toasterService.error(err.error.value);
      }
      else if (err.error && err.error.length <= 50) {
        this.toasterService.error(err.error);
      }
      else if (err.error.errors && err.error.errors.botId) {
        this.toasterService.error(err.error.errors.botId);
      }
      const error = err.error.message || err.statusText;
      return throwError(error);
    }))
  }
  openWarning(value: any) {
    let dialogRef = this.dialogWarning.open(WarningPopupComponent, {
      height: '35%',
      width: '35%',
      autoFocus: false,
      data: value
    });
    dialogRef.afterClosed().subscribe(result => {

    })
  }
}
