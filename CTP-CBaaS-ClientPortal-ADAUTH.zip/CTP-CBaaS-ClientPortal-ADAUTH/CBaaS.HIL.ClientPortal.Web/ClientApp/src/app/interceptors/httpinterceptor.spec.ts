import { Httpinterceptor } from './httpinterceptor';

describe('Httpinterceptor', () => {
  it('should create an instance', () => {
    expect(new Httpinterceptor()).toBeTruthy();
  });
});
