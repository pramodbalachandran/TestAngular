import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AgGridModule } from 'ag-grid-angular';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './components/shared/header/header.component';
import { FooterComponent } from './components/shared/footer/footer.component';
import { HomeComponent } from './components/shared/home/home.component';
import { DialogComponent } from './components/shared/dialog/dialog.component';
import { NotificationComponent } from './components/shared/notification/notification.component';
import { ToasterComponent } from './components/shared/toaster/toaster.component';
import { BotregisterComponent } from './components/administration/botregister/botregister.component';
import { BotlookupComponent } from './components/administration/botlookup/botlookup.component';
import { BreadcrumbComponent } from './components/shared/breadcrumb/breadcrumb.component';
import { DashboardmenuComponent } from './components/dashboard/dashboardmenu/dashboardmenu.component';
import { BotdashboardComponent } from './components/dashboard/botdashboard/botdashboard.component';
import { AdministrationmenuComponent } from './components/administration/administrationmenu/administrationmenu.component';
import { UserrolemanagementComponent } from './components/administration/userrolemanagement/userrolemanagement.component';
import { ConversationsmenuComponent } from './components/conversation/conversationsmenu/conversationsmenu.component';
import { HilconversationsComponent } from './components/conversation/hilconversations/hilconversations.component';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { ConfigurationSettings } from './models/configuration.settings';
import { AuthenticationInterceptor } from './interceptors/authentication/authentication.interceptor';
import { ErrorInterceptor } from './interceptors/error/error.interceptor';
import { ToastrModule } from 'ngx-toastr';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NotifierModule, NotifierOptions } from "angular-notifier";
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NameinitialsPipe } from './pipes/nameinitials/nameinitials.pipe';
import { SignoutComponent } from './components/shared/signout/signout.component';
import { MatDialogModule } from '@angular/material/dialog';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material';
import { MatSelectModule } from '@angular/material/select';
import { MatTableModule } from '@angular/material/table';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatRadioModule } from '@angular/material/radio';
import { WarningPopupComponent } from './components/shared/warning-popup/warning-popup.component';
import { BotHistoryComponent } from './components/shared/bot-history/bot-history.component';
import { HandoffCommentComponent } from './components/shared/handoff-comment/handoff-comment.component';
import { AuthenticationComponent } from './components/shared/authentication/authentication.component';
import { ErrorComponent } from './components/shared/error/error.component';
import { UserregisterComponent } from './components/administration/userregister/userregister.component';
import 'hammerjs';
import { UserlookupComponent } from './components/administration/userlookup/userlookup.component';
import { PrivacyStatementComponent } from './components/shared/privacy-statement/privacy-statement.component';
import { PushNotificationsModule } from 'ng-push';

const customNotifierOptions: NotifierOptions = {
    position: {
        horizontal: {
            position: 'left',
            distance: 12
        },
        vertical: {
            position: 'bottom',
            distance: 12,
            gap: 10
        }
    },
    theme: 'material',
    behaviour: {
        autoHide: 5000,
        onClick: 'hide',
        onMouseover: 'pauseAutoHide',
        showDismissButton: true,
        stacking: 4
    },
    animations: {
        enabled: true,
        show: {
            preset: 'slide',
            speed: 300,
            easing: 'ease'
        },
        hide: {
            preset: 'fade',
            speed: 300,
            easing: 'ease',
            offset: 50
        },
        shift: {
            speed: 300,
            easing: 'ease'
        },
        overlap: 150
    }
};
@NgModule({
    declarations: [
        AppComponent,
        HeaderComponent,
        FooterComponent,
        HomeComponent,
        DialogComponent,
        NotificationComponent,
        ToasterComponent,
        BotregisterComponent,
        BotlookupComponent,
        BreadcrumbComponent,
        DashboardmenuComponent,
        BotdashboardComponent,
        AdministrationmenuComponent,
        UserrolemanagementComponent,
        ConversationsmenuComponent,
        HilconversationsComponent,
        NameinitialsPipe,
        SignoutComponent,
        WarningPopupComponent,
        BotHistoryComponent,
        HandoffCommentComponent,
        AuthenticationComponent,
        ErrorComponent,
        UserregisterComponent,
        UserlookupComponent,
        PrivacyStatementComponent

    ],
    imports: [
        BrowserModule,
        AppRoutingModule,
        HttpClientModule,
        AgGridModule.withComponents(null),
        ToastrModule.forRoot(),
        BrowserAnimationsModule,
        NotifierModule.withConfig(customNotifierOptions),
        FormsModule,
        ReactiveFormsModule,
        MatDialogModule,
        MatAutocompleteModule,
        MatFormFieldModule,
        MatSelectModule,
        MatTableModule,
        MatPaginatorModule,
        MatInputModule,
        MatRadioModule,
        PushNotificationsModule 
    ],    
    entryComponents:[      
      WarningPopupComponent,
      HandoffCommentComponent,
      BotHistoryComponent,
      PrivacyStatementComponent
    ],
    providers: [
        { provide: HTTP_INTERCEPTORS, useClass: AuthenticationInterceptor, multi: true },
        { provide: HTTP_INTERCEPTORS, useClass: ErrorInterceptor, multi: true },
        ConfigurationSettings
    ],
    bootstrap: [AppComponent]
})
export class AppModule { }
