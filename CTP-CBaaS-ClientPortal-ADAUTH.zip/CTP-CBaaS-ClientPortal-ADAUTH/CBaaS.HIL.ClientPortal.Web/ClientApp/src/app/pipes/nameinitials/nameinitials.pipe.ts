import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'nameinitials'
})
export class NameinitialsPipe implements PipeTransform {

  transform(value: any, ...args: any[]): any {
    var fullName = value;
    var matches = fullName.match(/\b(\w)/g);
    var acronym = matches ? matches.join('') : ' ';
    return acronym.toUpperCase();
  }

}
