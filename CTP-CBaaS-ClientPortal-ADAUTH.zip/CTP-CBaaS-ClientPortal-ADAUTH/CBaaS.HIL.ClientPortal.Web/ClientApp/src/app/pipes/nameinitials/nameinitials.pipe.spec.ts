import { NameinitialsPipe } from './nameinitials.pipe';

describe('NameinitialsPipe', () => {
  it('create an instance', () => {
    const pipe = new NameinitialsPipe();
    expect(pipe).toBeTruthy();
  });
});
