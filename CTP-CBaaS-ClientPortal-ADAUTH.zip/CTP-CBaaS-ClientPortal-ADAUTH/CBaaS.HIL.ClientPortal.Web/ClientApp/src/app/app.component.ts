import { Component } from '@angular/core';
import { PushNotificationsService } from 'ng-push';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'ClientApp';

  constructor(private _pushNotifications: PushNotificationsService) {

    if (!("Notification" in window)) {
      alert("This browser does not support desktop notification");
    }
    else if (this._pushNotifications.permission === "granted") {
      var today = new Date();
      var date = today.getDate() + '-' + (today.getMonth() + 1) + '-' + today.getFullYear();
      var time = today.getHours() + ":" + today.getMinutes();
      var dateTime = time + ' | ' + date;

      let options = {
        body: "Push notification(s) enabled\r\n" + dateTime.toString(),
        icon: "assets/images/pushnotification-default.png"
      };
      
      this._pushNotifications.create('Cbaas Client Portal', options).subscribe();
    }
    else if (this._pushNotifications.permission !== "denied") {
      this._pushNotifications.requestPermission();
    }
  }
}
