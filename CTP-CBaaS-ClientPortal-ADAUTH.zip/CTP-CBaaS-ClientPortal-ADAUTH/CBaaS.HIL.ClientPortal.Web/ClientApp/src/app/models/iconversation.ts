import { Time } from "@angular/common";

export interface IConversation {
  ChatId: string,
  Message: string,
  Type: string,
  DateTime: Date
}
