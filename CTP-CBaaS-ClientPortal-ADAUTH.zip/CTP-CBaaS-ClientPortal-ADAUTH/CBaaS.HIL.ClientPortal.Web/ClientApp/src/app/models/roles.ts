export interface IRoles{
    id: number,
    role: string,
    displayName : string
}