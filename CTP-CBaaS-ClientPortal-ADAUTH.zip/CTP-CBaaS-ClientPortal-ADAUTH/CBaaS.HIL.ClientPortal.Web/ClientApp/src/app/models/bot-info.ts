export interface IBotInfo {
    botRegistrationId : number,
    botId : string,
    botConfigId : number,
    displayName : string,
    serviceLine : string,
    offeringType : string,
    botType : string,   
    customerContact : string,   
    reportId : any
}
