export interface IUserDetails{
    id : number,    
    userName: string,
    firstName : string,
    lastName : string,
    status : string,
    company : string,
    userType : string,
    isExternal : boolean,
    isActive : boolean
}