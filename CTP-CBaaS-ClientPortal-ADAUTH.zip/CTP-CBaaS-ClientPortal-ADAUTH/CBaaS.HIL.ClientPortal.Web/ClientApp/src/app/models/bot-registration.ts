export interface IBotRegistration {
    id : number,    
    botConfigId : number,   
    offeringType : string,
    botType : string,   
    customerContact : string,   
    reportId : any,
    isActive : boolean
}
