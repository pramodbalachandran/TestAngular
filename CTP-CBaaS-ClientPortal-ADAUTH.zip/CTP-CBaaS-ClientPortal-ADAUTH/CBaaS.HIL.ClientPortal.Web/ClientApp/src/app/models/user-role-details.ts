export interface IUserRoleDetails{
    userId : number,
    roleId : number,
    botConfigId : number,
    username: string,
    firstname : string,
    lastname : string,
    role : string,
    isExternal: boolean
}