export interface Inotification {
  type:string;

}
