export interface IChatHistory{    
    sender: string,
    message : string
}