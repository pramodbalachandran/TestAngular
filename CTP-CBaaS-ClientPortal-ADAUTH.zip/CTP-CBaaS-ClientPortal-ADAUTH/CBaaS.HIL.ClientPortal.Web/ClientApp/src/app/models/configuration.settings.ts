export class ConfigurationSettings {   
    public hostUrl = ''; 
    public hilUrl = '';        
    public userRole: string = '';    
    public idaas_response_type = 'code';    
    public idaas_grant_type = 'authorization_code';    
    public user_api_endpoint = this.hostUrl + '/api/User';
    public idaas_api_endpoint = this.hostUrl + '/api/Token';
    public botregistration_api_endpoint = this.hostUrl + '/api/BotRegistration';       
}
