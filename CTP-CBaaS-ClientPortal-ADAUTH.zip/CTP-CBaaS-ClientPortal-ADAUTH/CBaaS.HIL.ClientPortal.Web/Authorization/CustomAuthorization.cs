﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Security.Claims;
using System.Threading.Tasks;
using CBaaS.HIL.ClientPortal.Web.Helpers;
using EY.Azure.Storage.Blob;
using EY.Azure.Storage.Blob.Interface;
using Microsoft.AspNetCore.Session;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.Configuration;
using CBaaS.HIL.ClientPortal.Business.Interfaces;
using Microsoft.Extensions.Caching.Memory;
using CBaaS.HIL.ClientPortal.Business.Services;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;

namespace CBaaS.HIL.ClientPortal.Web.Authorization
{
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, AllowMultiple = true, Inherited = true)]
    public class CustomAuthorization : Attribute, IAuthorizationFilter
    {
        public string Roles { get; set; }
        public void OnAuthorization(AuthorizationFilterContext filterContext)
        {
            byte[] data;
            bool isUserAuthorized = false;
            List<Claim> claims = null;
            List<string> requiredRoles = Roles.Split(Convert.ToChar(",")).ToList();
            var services = filterContext.HttpContext.RequestServices;
            ICacheService cacheService = (ICacheService)services.GetService(typeof(ICacheService));
            var cachedValue = cacheService.GetCacheByteValue(CommonConstant.CertificateData);
            // Check if value exists in cache, get from memory cache, otherwise go to Azure Blob storage           
            if (cacheService == null || cachedValue == null)
            {
                IBlobStorage blobStorage = (IBlobStorage)services.GetService(typeof(AzureBlobDocumentStorage));
                IConfiguration configuration = (IConfiguration)services.GetService(typeof(IConfiguration));
                blobStorage = new AzureBlobDocumentStorage(configuration.GetValue<string>("CBaaSAzureStorage:AccountName"), configuration.GetValue<string>("CBaaSAzureStorage:AccountKey"));
                var task = Task.Run(async () => await blobStorage.GetDocumentBytesAsync(CommonConstant.IDAASCertificate, CommonConstant.Certificates));
                data = task.Result;
                cacheService.SetCacheByteValue(CommonConstant.CertificateData, data);
            }
            else
            {
                data = cachedValue;
            }

            if (filterContext != null)
            {
                if (!String.IsNullOrEmpty(filterContext.HttpContext.Request.Headers[CommonConstant.Authorization]))
                {
                    var authHeader = filterContext.HttpContext.Request.Headers[CommonConstant.Authorization];
                    string rawAccessToken = authHeader.ToString().Substring(CommonConstant.Bearer.Length).Trim();
                    string userId = GetUserId(rawAccessToken,data);
                    if (string.IsNullOrWhiteSpace(userId))
                    {
                        //this.HandleUnauthorizedRequest(filterContext);
                        filterContext.HttpContext.Response.StatusCode = 401;
                        //var msg = new HttpResponseMessage(HttpStatusCode.Unauthorized);
                        //filterContext.Result = new JsonResult(msg);
                        filterContext.Result = new ContentResult
                        {
                            Content = $"Error: {CommonConstant.InValidToken}",
                            ContentType = "text/plain",
                            StatusCode = (int?)HttpStatusCode.Unauthorized
                        };
                    }
                    else
                    {
                        //// Check if user has authorized role
                        IUserService userService = (IUserService)services.GetService(typeof(IUserService));
                        AuthorizeUserRoles authUserRoles = new AuthorizeUserRoles(userService, cacheService);
                        var userRoles = authUserRoles.GetUserRoles(userId);
                        filterContext.HttpContext.Session.SetString("userRoles", JsonConvert.SerializeObject(userRoles));
                        isUserAuthorized = requiredRoles.Select(x => x)
                              .Intersect(userRoles.roles)
                              .Any();//authUserRoles.IsInRole(userId, requiredRoles);

                        if (!isUserAuthorized)
                        {
                            this.HandleUnauthorizedRequest(filterContext);
                        }
                    }
                }
                else
                {
                    this.HandleUnauthorizedRequest(filterContext);
                }
            }
            else
            {
                this.HandleUnauthorizedRequest(filterContext);
            }
        }

        private string GetUserId(string token, byte[] data)
        {
            try
            {
                string userId;
                List<Claim> claims = Security.GetClaims(token);
                if (claims!=null && claims.Count > 0)
                {
                    userId = claims.FirstOrDefault(x => x.Type.Equals(CommonConstant.PreferredUsername, StringComparison.OrdinalIgnoreCase)).Value;
                }
                else
                {
                    ClaimsPrincipal claimPrincipal = Security.GetClaimsPrincipal(token, data);
                    userId = claimPrincipal.Claims?.FirstOrDefault(x => x.Type.Equals(CommonConstant.EmailAddress, StringComparison.OrdinalIgnoreCase))?.Value;
                }
                return userId;
            }
            catch (Exception)
            {
                return null;
            }
        }

        /// <summary>
        /// Handling of Unauthorized incoming requests
        /// </summary>
        /// <param name="filterContext"></param>
        public void HandleUnauthorizedRequest(AuthorizationFilterContext filterContext)
        {
            filterContext.HttpContext.Response.StatusCode = 401;
            //var msg = new HttpResponseMessage(HttpStatusCode.Unauthorized);
            //filterContext.Result = new JsonResult(msg);
            filterContext.Result = new ContentResult
            {
                Content = $"Error: {CommonConstant.UnauthorizedMsg}",
                ContentType = "text/plain",
                StatusCode = (int?)HttpStatusCode.Unauthorized
            };
        }
    }
}
