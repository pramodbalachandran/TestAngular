﻿using CBaaS.HIL.ClientPortal.Business.Interfaces;
using CBaaS.HIL.ClientPortal.Business.Services;
using CBaaS.HIL.Common.CoreComponents.Repositories;
using CBaaS.HIL.Common.Data;
using CBaaS.HIL.Common.Helper;
using EY.Azure.Storage.Blob;
using EY.Azure.Storage.Blob.Interface;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.SpaServices.AngularCli;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using System;

namespace CBaaS.HIL.ClientPortal.Web
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddControllersWithViews();
            // In production, the Angular files will be served from this directory
            services.AddSpaStaticFiles(configuration =>
            {
                configuration.RootPath = "ClientApp/dist";
            });
            services.AddAuthorization(options =>
            {
                options.AddPolicy("Bearer", new AuthorizationPolicyBuilder()
               .AddAuthenticationSchemes(JwtBearerDefaults.AuthenticationScheme‌​)
               .RequireAuthenticatedUser().Build());
            });

            services.AddSingleton<IKeyVaultHelper>(s => new KeyVaultHelper(Configuration));

            var serviceProvider = services.BuildServiceProvider();
            var botSettings = serviceProvider.GetService<IKeyVaultHelper>();
            botSettings.ReadApplicationConfiguration();
            services.AddDbContext<BaseContext>(options =>
       options.UseSqlServer(Configuration.GetConnectionString("BotEntities")));

            services.AddScoped(typeof(ICoreRepository<>), typeof(CoreRepository<>));
            services.AddScoped<IBotService, BotService>();
            services.AddScoped<DbContext, BaseContext>();
            services.AddScoped<IUserService, UserService>();
            services.AddScoped<IBotConfigService, BotConfigService>();
            services.AddScoped<IBotRegistrationService, BotRegistrationService>();
            services.AddScoped<ICacheService, CacheService>();
            services.AddSingleton<IBlobStorage, AzureBlobDocumentStorage>();
            services.AddSingleton<GraphAPIHelper>();
            services.AddMemoryCache();
            services.AddSession(options =>
            {               
                options.IdleTimeout = TimeSpan.FromMinutes(60);                
            });
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Error");
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }
            app.UseAuthentication();
            
            app.UseSession();

            app.UseHttpsRedirection();                       
            app.UseStaticFiles();
            if (!env.IsDevelopment())
            {
                app.UseSpaStaticFiles();
            }

            app.UseRouting();
            app.UseAuthorization();
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllerRoute(
                    name: "default",
                    pattern: "{controller}/{action=Index}/{id?}");
            });

            app.UseSpa(spa =>
            {
                // To learn more about options for serving an Angular SPA from ASP.NET Core,
                // see https://go.microsoft.com/fwlink/?linkid=864501

                spa.Options.SourcePath = "ClientApp";

                if (env.IsDevelopment())
                {
                    spa.UseAngularCliServer(npmScript: "start");
                }
            });
        }
    }
}
