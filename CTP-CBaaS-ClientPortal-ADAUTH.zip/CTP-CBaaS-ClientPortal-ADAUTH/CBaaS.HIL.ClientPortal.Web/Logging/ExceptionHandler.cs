﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CBaaS.HIL.ClientPortal.Web.Logging
{
    public static class ExceptionHandler
    {
        public static string BuildStackTrace(Exception ex)
        {
            string errorString = string.Empty;

            errorString = ex.Message + " : " + ex.StackTrace;
            return errorString;
        }
    }

    public class DBConnectionException : Exception
    {
        public DBConnectionException(string message) : base(message)
        {
        }
    }
    public class ADAuthenticationException : Exception
    {
        public ADAuthenticationException(string message) : base(message)
        {
        }
    }
    public class JSONFormatException : Exception
    {
        public JSONFormatException(string message) : base(message)
        {
        }
    }
    public class InvalidIOTypeException : Exception
    {
        public InvalidIOTypeException(string message) : base(message)
        {
        }
    }
    public class InvalidSourceTypeException : Exception
    {
        public InvalidSourceTypeException(string message) : base(message)
        {
        }
    }
    public class InvalidTargetTypeException : Exception
    {
        public InvalidTargetTypeException(string message) : base(message)
        {
        }
    }
    public class InaccessibleSourceException : Exception
    {
        public InaccessibleSourceException(string message) : base(message)
        {
        }
    }
    public class InaccessibleTargetException : Exception
    {
        public InaccessibleTargetException(string message) : base(message)
        {
        }
    }
    public class ClassificationException : Exception
    {
        public ClassificationException(string message) : base(message)
        {
        }
    }
   
}
