﻿
using NLog;
using System;

namespace CBaaS.HIL.ClientPortal.Web.Logging
{
    public static class Logger
    {
        private static string userName;
        private static long botId;
        public static string username
        {
            get { return userName; }
            set
            {
                if (userName != value)
                {
                    userName = value;
                }
            }
        }

        public static long botid
        {
            get { return botId; }
            set
            {
                if (botId != value)
                {
                    botId = value;
                }
            }
        }

        /// <summary>
        /// To log the exception and user details to database
        /// </summary>
        /// <param name="errorMsg">errorMsg</param>
        /// <param name="stacktrace">stacktrace</param>
        public static void LogError(ErrorCode.ResponseCode errorCode, string errorDetail)
        {
            try
            {
                NLog.Logger logger = LogManager.GetCurrentClassLogger();
                GlobalDiagnosticsContext.Set("stack_trace", errorDetail);
                GlobalDiagnosticsContext.Set("username", username);
                GlobalDiagnosticsContext.Set("botid", botid);

                string errorMessage = " ";
                if (errorCode.ToString() != null)
                {
                    errorMessage = errorCode + ": " + ErrorCode.ToStringEnums(errorCode);
                }
                logger.Error(errorMessage);
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        /// To log the error message along with current user details to database
        /// </summary>
        /// <param name="errorMsg">errorMsg</param>
        public static void LogEvent(ErrorCode.ResponseCode errorCode)
        {
            try
            {               
                NLog.Logger logger = LogManager.GetCurrentClassLogger();
                GlobalDiagnosticsContext.Set("stack_trace", " ");
                GlobalDiagnosticsContext.Set("username", username == null ? "signinuser" : userName);
                GlobalDiagnosticsContext.Set("botid", botId);

                string errorMessage = "";
                if (errorCode.ToString() != null)
                {
                    errorMessage = errorCode + ": " + ErrorCode.ToStringEnums(errorCode);
                }
                logger.Info(errorMessage);
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        /// To log the event and user details to database
        /// </summary>
        /// <param name="eventMsg">eventMsg</param>
        public static void LogEvent(string eventMsg)
        {
            try
            {
                NLog.Logger logger = LogManager.GetCurrentClassLogger();
                GlobalDiagnosticsContext.Set("stack_trace", " ");
                GlobalDiagnosticsContext.Set("userID", username);
                GlobalDiagnosticsContext.Set("BotID", botId);
                logger.Info(eventMsg);
            }
            catch (Exception)
            {
                throw;
            }
        }

    
    }
}
