﻿using System;
using System.ComponentModel;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;

namespace CBaaS.HIL.ClientPortal.Web.Logging
{
    public class ErrorCode
    {
        public enum ResponseCode
        {
            [Description("Operation completed successfully")]
            E100,            
            [Description("User cannot be Authenticated")]
            E101,           
            [Description("Invalid operation")]
            E102,
            [Description("Process failed")]
            E103,
            [Description("Unable to Read Cache value")]
            E104,            
            [Description("Unable to Set Cache value")]
            E105,
            [Description("Not Found")]
            E106,
            [Description("Validation Failed")]
            E107,
            [Description("Model Invalid")]
            E108
        }
        /// <summary>
        /// Retrieve message description for error/success code.
        /// </summary>
        /// <param name="en">error/success code</param>
        /// <returns></returns>
        public static string ToStringEnums(Enum en)
        {
            Type type = en.GetType();

            MemberInfo[] memInfo = type.GetMember(en.ToString());
            if (memInfo != null && memInfo.Length > 0)
            {
                object[] attrs = memInfo[0].GetCustomAttributes(typeof(DescriptionAttribute), false);
                if (attrs != null && attrs.Length > 0)
                    return ((DescriptionAttribute)attrs[0]).Description;
            }
            return en.ToString();
        }
    }
}
