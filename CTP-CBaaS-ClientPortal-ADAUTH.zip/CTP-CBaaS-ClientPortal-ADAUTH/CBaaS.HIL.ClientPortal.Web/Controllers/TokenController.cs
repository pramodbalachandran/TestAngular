﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using CBaaS.HIL.ClientPortal.Business.Interfaces;
using CBaaS.HIL.ClientPortal.Business.Services;
using CBaaS.HIL.ClientPortal.Web.Helpers;
using CBaaS.HIL.ClientPortal.Web.Logging;
using CBaaS.HIL.Common.Helper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;


namespace CBaaS.HIL.ClientPortal.Web.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TokenController : ControllerBase
    {
        private readonly ICacheService _cacheService;
        private readonly IConfiguration _configuration;

        public TokenController(ICacheService cacheService, IConfiguration configuration)
        {
            this._cacheService = cacheService;
            this._configuration = configuration;
        }

        [HttpGet]
        [Route("GetIdaasConfiguration")]
        public IActionResult GetIdaasConfiguration()
        {
            try
            {
                Dictionary<string, string> IdaasConfiguration = new Dictionary<string, string>();
                IdaasConfiguration.Add("IdaasUrl", CommonConstant.ClientPortalIdaasIssuer + "as/authorization.oauth2");
                IdaasConfiguration.Add("IdaasClientId", CommonConstant.ClientPortalIdaasClientId);
                IdaasConfiguration.Add("IdaasRedirectUri", CommonConstant.ClientPortalRedirectURL);
                IdaasConfiguration.Add("HILURL", CommonConstant.HILURL);
                //IdaasConfiguration.Add("IdaasRedirectUri", "http://localhost:3551/home");
                //IdaasConfiguration.Add("HILURL", "http://localhost:50000");
                return Ok(IdaasConfiguration);
            }
            catch(Exception ex)
            {
                Logger.LogError(ErrorCode.ResponseCode.E103, ExceptionHandler.BuildStackTrace(ex));
                throw ex;
            }
           
        }

        [HttpPost]
        [Route("GetAccessToken")]
        public async Task<IActionResult> GetAccessToken([FromForm] string code)
        {
            if (!ModelState.IsValid)
            {
                Logger.LogError(ErrorCode.ResponseCode.E108, CommonConstant.BotRegistrationModelInvalid);
                return BadRequest(ModelState);
            }
            if (string.IsNullOrEmpty(code))
            {
                Logger.LogError(ErrorCode.ResponseCode.E101, CommonConstant.AccessCodeNull);
                return BadRequest();
            }
            try
            {
                var accessToken = await Security.GetAccessToken(code);

                _cacheService.RemoveKey(CommonConstant.UserEmailId);
                _cacheService.RemoveKey(CommonConstant.CertificateData);

                return Ok(new JsonResult(accessToken));
            }
            catch (Exception ex)
            {
                Logger.LogError(ErrorCode.ResponseCode.E103, ExceptionHandler.BuildStackTrace(ex));
                return BadRequest(new JsonResult(CommonConstant.GenericErrorMsg));
            }
        }


        [HttpPost]
        [Route("GetHumanHandOffToken")]
        public IActionResult GetHumanHandOffToken([FromForm]string username)
        {
            try
            {
                JWTTokenConfiguration tokenConfiguration = new JWTTokenConfiguration(this._configuration);
                tokenConfiguration.Expiration = TimeSpan.FromMinutes(2);
                string token = JWTWebToken.GenerateToken(username, tokenConfiguration);
                return Ok(new JsonResult(token));
            }
            catch (Exception ex)
            {
                Logger.LogError(ErrorCode.ResponseCode.E103, ExceptionHandler.BuildStackTrace(ex));
                return BadRequest(new JsonResult(CommonConstant.GenericErrorMsg));
            }            
        }
    }
}