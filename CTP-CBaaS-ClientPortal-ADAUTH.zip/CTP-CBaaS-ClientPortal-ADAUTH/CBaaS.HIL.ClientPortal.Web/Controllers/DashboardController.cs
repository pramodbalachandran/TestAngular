﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Rest;
using Newtonsoft.Json.Linq;
using Microsoft.PowerBI.Api.V2;
using Microsoft.PowerBI.Api.V2.Models;
using Microsoft.IdentityModel.Clients.ActiveDirectory;
using Newtonsoft.Json;
using CBaaS.HIL.Common.Helper;
using CBaaS.HIL.Common.Entities.Models;
using CBaaS.HIL.ClientPortal.Web.Authorization;
using CBaaS.HIL.ClientPortal.Web.Logging;
using CBaaS.HIL.ClientPortal.Business.Services;
using CBaaS.HIL.ClientPortal.Business.Interfaces;

namespace CBaaSClientPortal.Web.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DashboardController : ControllerBase
    {
        private readonly IUserService _userService;
        private readonly IConfiguration _configuration;
        private readonly IBotRegistrationService _botRegistrationService;

        public DashboardController(IUserService userService, IConfiguration configuration, IBotRegistrationService botRegistrationService)
        {
            this._userService = userService;
            this._configuration = configuration;
            this._botRegistrationService = botRegistrationService;
        }

        public async Task<EmbededResult> Index(string botid = null)
        {
            try
            {
                return await GetReport(botid);
            }
            catch (Exception ex)
            {
                Logger.LogError(ErrorCode.ResponseCode.E103, ExceptionHandler.BuildStackTrace(ex));
                throw ex;
            }

        }

        [HttpGet]
        [CustomAuthorization(Roles = "SuperAdmin,ChatbotAdmin,BusinessManager")]
        public async Task<EmbededResult> GetReport(string reportId = null)
        {
            try
            {
                var userDetails = _userService.GetUserRolesFromSession(HttpContext.Session.GetString("userRoles"));
                Logger.username = userDetails.emailId;
                var registeredBots = _botRegistrationService.GetAllAccessedBotList(userDetails).ToList();

                if (_configuration["PowerBiAuthType"] != CommonConstant.ServicePrincipal)
                {
                    //string token =await this.GetAccessToken();
                    string token = await PowerBIHelper.GetPBIAccessToken();
                    string ApiUrl = CommonConstant.PBIAPIUrl;

                    var m_tokenCredentials = new TokenCredentials(token, "Bearer");
                    using (var client = new PowerBIClient(new Uri(ApiUrl), m_tokenCredentials))
                    {
                        Report report = await client.Reports.GetReportAsync(reportId);

                        EmbededResult embededResult = new EmbededResult();
                        embededResult.Type = "report";
                        embededResult.AccessToken = token;
                        embededResult.EmbedUrl = report.EmbedUrl;
                        embededResult.Id = report.Id;
                        embededResult.Name = report.Name;
                        embededResult.WebUrl = report.WebUrl;
                        embededResult.EmbedUrl = report.EmbedUrl;
                        embededResult.IsSpnPowerBi = false;
                        return embededResult;
                    }
                }
                else
                {
                    
                    EmbededResult embededResult = new EmbededResult();
                    embededResult.IsSpnPowerBi = true;
                    if (string.IsNullOrEmpty(reportId) || reportId == "null")
                    {
                        embededResult.ErrorMessage = "Report id is not available for selected bot.";
                        return embededResult;
                    }
                    var reportDetails = registeredBots.Where(x => x.ReportId.ToString() == reportId).ToList();
                    if (reportDetails.Count > 0)
                    {
                        string token = await PowerBIHelper.GetPBISPNAccessToken();
                        var m_tokenCredentials = new TokenCredentials(token, "Bearer");
                        using (var client = new PowerBIClient(new Uri(CommonConstant.PBIAPIUrl), m_tokenCredentials))
                        {                            
                            var reports = await client.Reports.GetReportsInGroupAsync(CommonConstant.PBIWorkspaceId);
                            if (reports.Value.Count() == 0)
                            {
                                embededResult.ErrorMessage = "No reports were found in the workspace.";
                                return embededResult;
                            }
                            var report = reports.Value.FirstOrDefault(r => r.Id.Equals(reportId, StringComparison.InvariantCultureIgnoreCase));

                            if (report == null)
                            {
                                embededResult.ErrorMessage = "No report with the given ReportId was found in the workspace. Make sure ReportId is valid.";
                                return embededResult;
                            }
                            GenerateTokenRequest generateTokenRequestParameters = new GenerateTokenRequest(accessLevel: "view");
                            var tokenResponse = await client.Reports.GenerateTokenInGroupAsync(CommonConstant.PBIWorkspaceId, report.Id, generateTokenRequestParameters);
                            if (tokenResponse == null)
                            {
                                embededResult.ErrorMessage = "Failed to generate embed token.";
                                return embededResult;
                            }
                            embededResult.EmbedToken = tokenResponse;
                            embededResult.EmbedUrl = report.EmbedUrl;
                            embededResult.Id = report.Id;

                        }
                    }
                    else
                    {
                        throw new UnauthorizedAccessException();
                    }
                    return embededResult;
                }
            }
            catch (Exception ex)
            {
                Logger.LogError(ErrorCode.ResponseCode.E103, ExceptionHandler.BuildStackTrace(ex));
                throw ex;
            }
        }
    }
}