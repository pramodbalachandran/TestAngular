﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using CBaaS.HIL.ClientPortal.Business.Interfaces;
using CBaaS.HIL.ClientPortal.Business.Services;
using CBaaS.HIL.ClientPortal.Web.Authorization;
using CBaaS.HIL.ClientPortal.Web.Helpers;
using CBaaS.HIL.ClientPortal.Web.Logging;
using CBaaS.HIL.Common.Entities.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace CBaaS.HIL.ClientPortal.Web.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BotRegistrationController : ControllerBase
    {
        private readonly IBotRegistrationService _botRegistrationService;
        private readonly IBotConfigService _botConfigServices;
        private readonly ICacheService _cacheService;
        private readonly IConfiguration _configuration;
        private readonly IUserService _userService;

        public BotRegistrationController(IBotRegistrationService botRegistrationService, ICacheService cacheService, IBotConfigService botConfigService, IConfiguration configuration, IUserService userService)
        {
            this._botRegistrationService = botRegistrationService;
            this._cacheService = cacheService;
            this._botConfigServices = botConfigService;
            this._configuration = configuration;
            this._userService = userService;
        }
        // GET: api/BotRegistration
        [HttpGet]
        [Route("GetAccessedBots")]
        [CustomAuthorization(Roles = "SuperAdmin,ChatbotAdmin,BusinessManager")]
        public IActionResult GetAccessedBots()
        {           
            var userDetails = _userService.GetUserRolesFromSession(HttpContext.Session.GetString("userRoles"));
            Logger.username = userDetails.emailId;
            try
            {
                var registeredBots = _botRegistrationService.GetAllAccessedBotList(userDetails).ToList();

                if (registeredBots == null)
                {
                    Logger.LogError(ErrorCode.ResponseCode.E106, CommonConstant.NoBotsFound);
                    return NotFound();
                }
                else
                {
                    return Ok(registeredBots);
                }

            }
            catch (Exception ex)
            {
                Logger.LogError(ErrorCode.ResponseCode.E103, ExceptionHandler.BuildStackTrace(ex));
                return new ContentResult
                {
                    Content = $"Error: {CommonConstant.GenericErrorMsg}",
                    ContentType = "text/plain",                    
                    StatusCode = (int?)HttpStatusCode.InternalServerError
                };
            }
        }

        [HttpGet]
        [Route("GetRegisteredBotDetails/{botRegistrationId=botRegistrationId}")]
        [CustomAuthorization(Roles = "SuperAdmin")]
        public IActionResult GetRegisteredBotDetails([FromQuery] int botRegistrationId)
        {            
            var userDetails = _userService.GetUserRolesFromSession(HttpContext.Session.GetString("userRoles"));
            Logger.username = userDetails.emailId;

            try
            {
                var botRegistrationInfo = _botRegistrationService.GetRegisteredBotInfo(botRegistrationId);
                var accessibleBots = _botRegistrationService.GetAllAccessedBotList(userDetails);
                List<long> allowedBotConfigIds = new List<long>();
                long requestedBotConfigId = botRegistrationInfo.BotConfigId;
                if (accessibleBots.Any())
                {
                    allowedBotConfigIds = accessibleBots.Select(x => x.BotConfigId).ToList();
                }

                if (!allowedBotConfigIds.Contains(requestedBotConfigId))
                {
                    return new ContentResult
                    {
                        Content = $"Error: {CommonConstant.UnauthorizedMsg}",
                        ContentType = "text/plain",
                        StatusCode = (int?)HttpStatusCode.Unauthorized
                    };
                }
                if (botRegistrationInfo == null)
                {
                    Logger.LogError(ErrorCode.ResponseCode.E106, CommonConstant.BotDoesNotExist);
                    return NotFound();
                }
                else
                {
                    return Ok(botRegistrationInfo);
                }
            }
            catch (Exception ex)
            {
                Logger.LogError(ErrorCode.ResponseCode.E103, ExceptionHandler.BuildStackTrace(ex));
                return new ContentResult
                {
                    Content = $"Error: {CommonConstant.GenericErrorMsg}",
                    ContentType = "text/plain",
                    StatusCode = (int?)HttpStatusCode.InternalServerError
                };
            }
        }

        [HttpGet]
        [Route("GetBotConfigData/{botId=botId}")]
        [CustomAuthorization(Roles = "SuperAdmin")]
        public IActionResult GetBotConfigData([FromQuery] Guid botId)
        {           
            var userDetails = _userService.GetUserRolesFromSession(HttpContext.Session.GetString("userRoles"));
            Logger.username = userDetails.emailId;
            try
            {
                var botConfigData = _botConfigServices.GetBotConfigById(botId);
                if (botConfigData != null)
                {
                    var botRegistrationData = _botRegistrationService.GetRegisteredBotById(botConfigData.Id);
                    if (botRegistrationData.Any())
                    {
                        return new ContentResult
                        {
                            Content = $"Error: {CommonConstant.DuplicateBotRegistration}",
                            ContentType = "text/plain",                            
                            StatusCode = (int?)HttpStatusCode.BadRequest
                        };
                    }  
                }
                else
                {
                    return new ContentResult
                    {
                        Content = $"Error: {CommonConstant.InvalidBotId}",
                        ContentType = "text/plain",                        
                        StatusCode = (int?)HttpStatusCode.BadRequest
                    };                    
                }
                return Ok(botConfigData);
            }
            catch (Exception ex)
            {
                Logger.LogError(ErrorCode.ResponseCode.E103, ExceptionHandler.BuildStackTrace(ex));
                return new ContentResult
                {
                    Content = $"Error: {CommonConstant.GenericErrorMsg}",
                    ContentType = "text/plain",                    
                    StatusCode = (int?)HttpStatusCode.InternalServerError
                };
            }
        }

        [HttpPost]
        [CustomAuthorization(Roles = "SuperAdmin")]
        public IActionResult Post([FromBody] BotRegistration botDetails)
        {           
            var userDetails = _userService.GetUserRolesFromSession(HttpContext.Session.GetString("userRoles"));
            Logger.username = userDetails.emailId;

            try
            {
                var validationMsg = _botRegistrationService.ValidateBotRegistration(botDetails);
                if (validationMsg == CommonConstant.ValidationSuccessful)
                {
                    _botRegistrationService.AddUpdateBotRegistration(botDetails,userDetails.emailId);
                    return Ok();
                }
                else
                {
                    Logger.LogError(ErrorCode.ResponseCode.E107, "Bot Registration validation failed");                    
                    return new ContentResult
                    {
                        Content = $"Error: {validationMsg}",
                        ContentType = "text/plain",                        
                        StatusCode = (int?)HttpStatusCode.BadRequest
                    };
                }
            }
            catch (Exception ex)
            {
                Logger.LogError(ErrorCode.ResponseCode.E103, ExceptionHandler.BuildStackTrace(ex));
                return new ContentResult
                {
                    Content = $"Error: {CommonConstant.GenericErrorMsg}",
                    ContentType = "text/plain",                   
                    StatusCode = (int?)HttpStatusCode.InternalServerError
                };
            }
        }

        [HttpDelete]
        [Route("DeleteRegisteredBot/{botRegistrationId=botRegistrationId}")]
        [CustomAuthorization(Roles = "SuperAdmin")]
        public IActionResult DeleteRegisteredBot([FromQuery] int botRegistrationId)
        {            
            var userDetails = _userService.GetUserRolesFromSession(HttpContext.Session.GetString("userRoles"));
            Logger.username = userDetails.emailId;
            try
            {
                var botConfigId = _botRegistrationService.DeleteBotRegistration(botRegistrationId, userDetails.emailId);
                _userService.DeleteBotRoles(botConfigId,userDetails.emailId);
                return Ok();
            }
            catch (Exception ex)
            {
                Logger.LogError(ErrorCode.ResponseCode.E103, ExceptionHandler.BuildStackTrace(ex));
                return new ContentResult
                {
                    Content = $"Error: {CommonConstant.GenericErrorMsg}",
                    ContentType = "text/plain",                    
                    StatusCode = (int?)HttpStatusCode.InternalServerError
                };
            }
        }

        [HttpGet]
        [Route("GetBotOfferingTypes")]
        [CustomAuthorization(Roles = "SuperAdmin")]
        public IActionResult GetBotOfferingTypes()
        {
            try
            {
                var botOfferingTypes = _configuration.GetValue<string>("ClientPortalOfferingType").Split(",").ToList();
                return Ok(botOfferingTypes);
            }
            catch (Exception ex)
            {
                Logger.LogError(ErrorCode.ResponseCode.E103, ExceptionHandler.BuildStackTrace(ex));
                return new ContentResult
                {
                    Content = $"Error: {CommonConstant.GenericErrorMsg}",
                    ContentType = "text/plain",                    
                    StatusCode = (int?)HttpStatusCode.InternalServerError
                };
            }
        }

    }
}
