﻿using CBaaS.HIL.ClientPortal.Business.Interfaces;
using CBaaS.HIL.ClientPortal.Business.Services;
using CBaaS.HIL.ClientPortal.Web.Authorization;
using CBaaS.HIL.ClientPortal.Web.Helpers;
using CBaaS.HIL.ClientPortal.Web.Logging;
using CBaaS.HIL.Common.Entities.Models;
using CBaaS.HIL.Common.Helper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Graph;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Security.Claims;
using System.Threading.Tasks;
using Logger = CBaaS.HIL.ClientPortal.Web.Logging.Logger;

namespace CBaaS.HIL.ClientPortal.Web.Controllers
{
    [Route("api/[controller]")]
    [ApiController]

    public class UserController : ControllerBase
    {

        private readonly IUserService _userService;
        private readonly ICacheService _cacheService;
        private readonly IConfiguration _configuration;
        private readonly IBotRegistrationService _botRegistrationService;

        public UserController(IUserService userService, ICacheService cacheService, IConfiguration configuration, IBotRegistrationService botRegistrationService)
        {
            this._userService = userService;
            this._cacheService = cacheService;
            this._configuration = configuration;
            this._botRegistrationService = botRegistrationService;
        }
        ////// GET: api/User
        [HttpGet]
        [CustomAuthorization(Roles = CommonConstant.SuperAdmin)]
        [Route("GetAllUsers")]
        public IActionResult GetAllUsers()
        {
            try
            {
                var userDetails = _userService.GetUserRolesFromSession(HttpContext.Session.GetString("userRoles"));
                Logger.username = userDetails.emailId;
                var users = _userService.GetAllUsers();
                return Ok(users);
            }
            catch (Exception ex)
            {
                Logger.LogError(ErrorCode.ResponseCode.E103, ExceptionHandler.BuildStackTrace(ex));
                return new ContentResult
                {
                    Content = $"Error: {CommonConstant.GenericErrorMsg}",
                    ContentType = "text/plain",
                    StatusCode = (int?)HttpStatusCode.InternalServerError
                };
            }

        }

        [HttpGet]
        [Route("GetRoles")]
        [CustomAuthorization(Roles = "SuperAdmin,ChatbotAdmin")]
        public IActionResult GetRoles()
        {
            try
            {
                var userDetails = _userService.GetUserRolesFromSession(HttpContext.Session.GetString("userRoles"));
                Logger.username = userDetails.emailId;
                var roles = _userService.GetRoles();
                return Ok(roles);
            }
            catch (Exception ex)
            {
                Logger.LogError(ErrorCode.ResponseCode.E103, ExceptionHandler.BuildStackTrace(ex));
                return new ContentResult
                {
                    Content = $"Error: {CommonConstant.GenericErrorMsg}",
                    ContentType = "text/plain",
                    StatusCode = (int?)HttpStatusCode.InternalServerError
                };
            }
        }

        [HttpGet]
        [Route("GetUserRoles/{botConfigId=botConfigId}")]
        [CustomAuthorization(Roles = "SuperAdmin,ChatbotAdmin")]
        public IActionResult GetUserRoles([FromQuery] long botConfigId)
        {
            try
            {
                var userDetails = _userService.GetUserRolesFromSession(HttpContext.Session.GetString("userRoles"));
                Logger.username = userDetails.emailId;
                var accessibleBots = _botRegistrationService.GetAllAccessedBotList(userDetails);
                List<long> allowedBotConfigIds = new List<long>();
                if (accessibleBots.Any())
                {
                    allowedBotConfigIds = accessibleBots.Select(x => x.BotConfigId).ToList();
                }

                if (!allowedBotConfigIds.Contains(botConfigId))
                {
                    return new ContentResult
                    {
                        Content = $"Error: {CommonConstant.UnauthorizedMsg}",
                        ContentType = "text/plain",
                        StatusCode = (int?)HttpStatusCode.Unauthorized
                    };
                }
                var roles = _userService.GetAllUsersAllRoles(botConfigId);
                return Ok(roles);
            }
            catch (Exception ex)
            {
                Logger.LogError(ErrorCode.ResponseCode.E103, ExceptionHandler.BuildStackTrace(ex));
                return new ContentResult
                {
                    Content = $"Error: {CommonConstant.GenericErrorMsg}",
                    ContentType = "text/plain",
                    StatusCode = (int?)HttpStatusCode.InternalServerError
                };
            }
        }

        [HttpPost]
        [Route("PostUserBotRoles")]
        [CustomAuthorization(Roles = "SuperAdmin,ChatbotAdmin")]
        public IActionResult PostUserBotRoles([FromBody] List<UserRolesDetails> userRolesDetails)
        {
            try
            {
                var userDetails = _userService.GetUserRolesFromSession(HttpContext.Session.GetString("userRoles"));
                Logger.username = userDetails.emailId;
                var accessibleBots = _botRegistrationService.GetAllAccessedBotList(userDetails);
                List<long> allowedBotConfigIds = new List<long>();
                List<long> requestedBotConfigIds = userRolesDetails.Select(x => x.BotConfigId).ToList();
                if (accessibleBots.Any())
                {
                    allowedBotConfigIds = accessibleBots.Select(x => x.BotConfigId).ToList();
                }
                var isUserAuthorized = allowedBotConfigIds
                               .Intersect(requestedBotConfigIds)
                               .Any();
                if (!isUserAuthorized)
                {
                    return new ContentResult
                    {
                        Content = $"Error: {CommonConstant.UnauthorizedMsg}",
                        ContentType = "text/plain",
                        StatusCode = (int?)HttpStatusCode.Unauthorized
                    };
                }

                foreach (var userRole in userRolesDetails)
                {
                    var msg = _userService.AddUserBotRoles(userRole, userDetails.emailId);
                    if (msg == CommonConstant.InvalidUser)
                    {
                        return new ContentResult
                        {
                            Content = $"Error: {msg}",
                            ContentType = "text/plain",
                            StatusCode = (int?)HttpStatusCode.BadRequest
                        };
                    }
                }
                var newUserRoles = _userService.GetAllUsersAllRoles(userRolesDetails.FirstOrDefault().BotConfigId);

                return Ok(newUserRoles);
            }
            catch (Exception ex)
            {
                Logger.LogError(ErrorCode.ResponseCode.E103, ExceptionHandler.BuildStackTrace(ex));
                return new ContentResult
                {
                    Content = $"Error: {CommonConstant.GenericErrorMsg}",
                    ContentType = "text/plain",
                    StatusCode = (int?)HttpStatusCode.InternalServerError
                };
            }

        }

        [HttpPost]
        [Route("DeleteUserRole/{userRolesDetails=userRolesDetails}")]
        [CustomAuthorization(Roles = "SuperAdmin,ChatbotAdmin")]
        public IActionResult DeleteUserRole([FromBody] UserRolesDetails userRolesDetails)
        {
            try
            {
                var userDetails = _userService.GetUserRolesFromSession(HttpContext.Session.GetString("userRoles"));
                Logger.username = userDetails.emailId;
                var accessibleBots = _botRegistrationService.GetAllAccessedBotList(userDetails);
                List<long> allowedBotConfigIds = new List<long>();
                long requestedBotConfigId = userRolesDetails.BotConfigId;
                if (accessibleBots.Any())
                {
                    allowedBotConfigIds = accessibleBots.Select(x => x.BotConfigId).ToList();
                }

                if (!allowedBotConfigIds.Contains(requestedBotConfigId))
                {
                    return new ContentResult
                    {
                        Content = $"Error: {CommonConstant.UnauthorizedMsg}",
                        ContentType = "text/plain",
                        StatusCode = (int?)HttpStatusCode.Unauthorized
                    };
                }
                _userService.DeleteUserRole(userRolesDetails, userDetails.emailId);

                var newUserRoles = _userService.GetAllUsersAllRoles(userRolesDetails.BotConfigId);
                return Ok(newUserRoles);
            }
            catch (Exception ex)
            {
                Logger.LogError(ErrorCode.ResponseCode.E103, ExceptionHandler.BuildStackTrace(ex));
                return new ContentResult
                {
                    Content = $"Error: {CommonConstant.GenericErrorMsg}",
                    ContentType = "text/plain",
                    StatusCode = (int?)HttpStatusCode.InternalServerError
                };
            }
        }

        [HttpGet]
        [Route("GetLoggedInUserRoles")]
        [CustomAuthorization(Roles = "SuperAdmin,ChatbotAdmin,BusinessManager,Agent")]
        public IActionResult GetLoggedInUserRoles()
        {
            try
            {
                var userDetail = _userService.GetUserRolesFromSession(HttpContext.Session.GetString("userRoles"));
                Logger.username = userDetail.emailId;
                List<UserRolesDetails> userRolesDetails = new List<UserRolesDetails>();
                foreach (var role in userDetail.roles)
                {
                    var details = new UserRolesDetails();
                    var userName = userDetail.emailId.Split(Convert.ToChar(".")).ToList();
                    details.Firstname = userName[0];
                    details.Lastname = userName[1];
                    details.Username = userDetail.emailId;
                    details.Role = role;
                    userRolesDetails.Add(details);
                }
                return Ok(userRolesDetails);
            }
            catch (Exception ex)
            {
                Logger.LogError(ErrorCode.ResponseCode.E103, ExceptionHandler.BuildStackTrace(ex));
                return new ContentResult
                {
                    Content = $"Error: {CommonConstant.GenericErrorMsg}",
                    ContentType = "text/plain",
                    StatusCode = (int?)HttpStatusCode.InternalServerError
                };
            }
        }

        [HttpGet]
        [Route("GetLoggedInUserDetails")]
        [CustomAuthorization(Roles = "SuperAdmin,ChatbotAdmin,BusinessManager,Agent")]
        public IActionResult GetLoggedInUserDetails()
        {
            try
            {
                var userDetail = _userService.GetUserRolesFromSession(HttpContext.Session.GetString("userRoles"));
                Logger.username = userDetail.emailId;
                List<string> userRoles = new List<string>();
                Users userDetails = new Users();
                var userEmailId = userDetail.emailId;
                userDetails = _userService.GetUserByEmail(userEmailId);

                return Ok(userDetails);
            }
            catch (Exception ex)
            {
                Logger.LogError(ErrorCode.ResponseCode.E103, ExceptionHandler.BuildStackTrace(ex));
                return new ContentResult
                {
                    Content = $"Error: {CommonConstant.GenericErrorMsg}",
                    ContentType = "text/plain",
                    StatusCode = (int?)HttpStatusCode.InternalServerError
                };
            }
        }

        [HttpGet]
        [Route("GetMatchingUsers/{user = user}/{userType = userType}")]
        [CustomAuthorization(Roles = "SuperAdmin,ChatbotAdmin")]
        public async Task<IActionResult> GetMatchingUsers([FromQuery] string user, [FromQuery] string userType)
        {
            try
            {
                var userDetails = _userService.GetUserRolesFromSession(HttpContext.Session.GetString("userRoles"));
                Logger.username = userDetails.emailId;
                if (!string.IsNullOrEmpty(userType))
                {
                    var users = new List<UserVM>();
                    if (userType.ToLower() == "internal")
                        users = await GetUser(user);
                    else
                        users = _userService.GetExternalUsers(user);
                    return Ok(users);
                }
                else
                {
                    return BadRequest(new JsonResult("Invalid User Type"));
                }
            }
            catch (Exception ex)
            {
                Logger.LogError(ErrorCode.ResponseCode.E103, ExceptionHandler.BuildStackTrace(ex));
                return new ContentResult
                {
                    Content = $"Error: {CommonConstant.GenericErrorMsg}",
                    ContentType = "text/plain",
                    StatusCode = (int?)HttpStatusCode.InternalServerError
                };
            }
        }

        public async Task<List<UserVM>> GetUser(string user = "")
        {
            try
            {
                List<UserVM> users = new List<UserVM>();
                if (!string.IsNullOrEmpty(user))
                {
                    GraphAPIHelper graphAPIHelper = new GraphAPIHelper(_configuration);
                    GraphServiceClient client = await graphAPIHelper.GetGraphServiceClient();

                    var userList = await client.Users
                                               .Request()
                                               .Top(20)
                                               .Filter($"startsWith(displayName, '{user}') or startswith(mail, '{user}')")
                                               .GetAsync();

                    users = userList.Where(x => !string.IsNullOrEmpty(x.Mail)).ToList().Select(u => new UserVM
                    {
                        EmailAddress = u.Mail,
                        Fullname = u.DisplayName
                    }).ToList();

                }
                return users;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [HttpPost]
        [Route("AddUpdateUser")]
        [CustomAuthorization(Roles = "SuperAdmin")]
        public IActionResult AddUpdateUser([FromBody] Users user)
        {
            var userDetails = _userService.GetUserRolesFromSession(HttpContext.Session.GetString("userRoles"));
            Logger.username = userDetails.emailId;

            try
            {
                string msg = _userService.AddUpdateUserRegistration(user, userDetails.emailId);
                if (msg == CommonConstant.Success)
                {
                    return Ok();
                }
                else
                {
                    return new ContentResult
                    {
                        Content = $"Error: {msg}",
                        ContentType = "text/plain",
                        StatusCode = (int?)HttpStatusCode.BadRequest
                    };
                }

            }
            catch (Exception ex)
            {
                Logger.LogError(ErrorCode.ResponseCode.E103, ExceptionHandler.BuildStackTrace(ex));
                return new ContentResult
                {
                    Content = $"Error: {CommonConstant.GenericErrorMsg}",
                    ContentType = "text/plain",
                    StatusCode = (int?)HttpStatusCode.InternalServerError
                };
            }
        }

        [HttpDelete]
        [Route("DeleteUser/{userId=userId}")]
        [CustomAuthorization(Roles = "SuperAdmin")]
        public IActionResult DeleteUser([FromQuery] int userId)
        {
            var userDetails = _userService.GetUserRolesFromSession(HttpContext.Session.GetString("userRoles"));
            Logger.username = userDetails.emailId;
            try
            {
                _userService.DeleteUserRoles(userId, userDetails.emailId);
                _userService.DeleteUser(userId, userDetails.emailId);
                return Ok();
            }
            catch (Exception ex)
            {
                Logger.LogError(ErrorCode.ResponseCode.E103, ExceptionHandler.BuildStackTrace(ex));
                return new ContentResult
                {
                    Content = $"Error: {CommonConstant.GenericErrorMsg}",
                    ContentType = "text/plain",
                    StatusCode = (int?)HttpStatusCode.InternalServerError
                };
            }
        }

    }
}

