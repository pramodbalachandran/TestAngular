﻿using CBaaS.HIL.ClientPortal.Business.Interfaces;
using CBaaS.HIL.ClientPortal.Business.Services;
using CBaaS.HIL.Common.Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;


namespace CBaaS.HIL.ClientPortal.Web.Helpers
{
    public class AuthorizeUserRoles
    {
        private readonly IUserService _userService;
        private ICacheService _cacheService;
        public AuthorizeUserRoles(IUserService userService, ICacheService cacheService)
        {
            _userService = userService;
            _cacheService = cacheService;
        }

        /// <summary>
        /// Check if user has required roles
        /// </summary>
        /// <param name="emailId"></param>
        /// <param name="requiredRoles"></param>
        /// <returns>bool</returns>
        public bool IsInRole(string emailId, List<string> requiredRoles)
        {
            try
            {
                List<string> userRoles = new List<string>();              
                userRoles = _userService.GetUserRolesByEmail(emailId);
                string userRoleString = String.Join(",", userRoles);               

                if (userRoles.Contains(CommonEnum.UserRoles.SuperAdmin.ToString()))
                {
                    return true;
                }

                return requiredRoles.Select(x => x)
                              .Intersect(userRoles)
                              .Any();

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Check if user has required roles
        /// </summary>
        /// <param name="emailId"></param>
        /// <param name="requiredRoles"></param>
        /// <returns>bool</returns>
        public UserRolesVM GetUserRoles(string emailId)
        {
            try
            {
                List<string> userRoles = new List<string>();
                userRoles = _userService.GetUserRolesByEmail(emailId);
                //userRoles = _userService.GetLoggedInUserRoles(emailId);
                var userRolesDetails = new UserRolesVM
                {
                    emailId = emailId,
                    roles = userRoles
                };
                return userRolesDetails;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        /// <summary>
        /// Check if user has required role specific to Bot
        /// </summary>
        /// <param name="emailId"></param>
        /// <param name="botId"></param>
        /// <param name="requiredRoles"></param>
        /// <returns>bool</returns>
        public bool IsInBotRole(string emailId, int botId, List<string> requiredRoles)
        {
            try
            {
                List<string> userBotRoles = new List<string>();

                userBotRoles = _userService.GetUserBotRoles(emailId, botId);
                string userRoleString = String.Join(",", userBotRoles);

                if (userBotRoles.Contains(CommonEnum.UserRoles.SuperAdmin.ToString()))
                {
                    return true;
                }

                return requiredRoles.Select(x => x)
                          .Intersect(userBotRoles)
                          .Any();

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
