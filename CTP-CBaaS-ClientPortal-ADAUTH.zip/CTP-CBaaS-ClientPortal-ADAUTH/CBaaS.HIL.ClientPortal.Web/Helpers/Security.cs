﻿using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography.X509Certificates;
using CBaaS.HIL.ClientPortal.Business.Services;
using System.Threading.Tasks;
using System.Net.Http;
using Newtonsoft.Json.Linq;
using System.Linq;

namespace CBaaS.HIL.ClientPortal.Web.Helpers
{
    public static partial class Security
    {
        public static ClaimsPrincipal GetClaimsPrincipal(string token, byte[] data)
        {
            try
            {
                X509Certificate cert = new X509Certificate(data);
                SecurityKey DefaultX509Key_Public_2048 = new X509SecurityKey(new X509Certificate2(cert));
                SecurityToken validatedToken;
                TokenValidationParameters validationParameters = new TokenValidationParameters();
                validationParameters.ValidateIssuerSigningKey = true;
                validationParameters.IssuerSigningKey = DefaultX509Key_Public_2048;
                validationParameters.ValidateIssuer = false;
                validationParameters.ValidateAudience = false;
                ClaimsPrincipal principal = new JwtSecurityTokenHandler().ValidateToken(token, validationParameters, out validatedToken);
                return principal;
            }
            catch (Exception)
            {
                return null;
            }
        }

        public static List<Claim> GetClaims(string jwtToken)
        {
            try
            {
                return new JwtSecurityTokenHandler().ReadJwtToken(jwtToken).Claims.ToList();
            }
            catch (Exception)
            {
                return null;
            }
        }
        public static async Task<string> GetAccessToken(string code)
        {
            var client = new HttpClient();
            client.BaseAddress = new Uri($"{CommonConstant.ClientPortalIdaasIssuer}as/token.oauth2");
            var request = new HttpRequestMessage(HttpMethod.Post, "");
            // XXX-Encoded Request paramters
            var dct = new List<KeyValuePair<string, string>>();
            dct.Add(new KeyValuePair<string, string>("grant_type", CommonConstant.AuthorizationCode));
            dct.Add(new KeyValuePair<string, string>("client_id", CommonConstant.ClientPortalIdaasClientId));
            dct.Add(new KeyValuePair<string, string>("client_secret", CommonConstant.ClientPortalIdaasClientSecret));
            dct.Add(new KeyValuePair<string, string>("redirect_uri", CommonConstant.ClientPortalRedirectURL));
            //dct.Add(new KeyValuePair<string, string>("redirect_uri", "http://localhost:3551/home"));
            dct.Add(new KeyValuePair<string, string>("code", code));

            request.Content = new FormUrlEncodedContent(dct);
            string requestJsonData = Newtonsoft.Json.JsonConvert.SerializeObject(dct);

            var response = await client.SendAsync(request);
            response.EnsureSuccessStatusCode();
            string res = string.Empty;
            using (HttpContent content = response.Content)
            {
                Task<string> result = content.ReadAsStringAsync();
                res = result.Result;
                requestJsonData = Newtonsoft.Json.JsonConvert.SerializeObject(res);
            }

            dynamic tokenResponse = JObject.Parse(res);
            var tokN = (String)tokenResponse.access_token;
            return tokN;
        }
    }
}
