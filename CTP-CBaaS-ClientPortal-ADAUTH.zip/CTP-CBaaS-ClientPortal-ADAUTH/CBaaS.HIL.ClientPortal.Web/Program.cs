using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using NLog;
using NLog.Targets;
using NLog.Web;
using System;

namespace CBaaS.HIL.ClientPortal.Web
{
    public class Program
    {
        public static void Main(string[] args)
        {
            CreateWebHostBuilder(args).Build().Run();
        }

        public static IWebHostBuilder CreateWebHostBuilder(string[] args) =>
            WebHost.CreateDefaultBuilder(args)
                .UseStartup<Startup>().ConfigureAppConfiguration(InitConfiguration);


        private static void InitConfiguration(WebHostBuilderContext webHostBuilderContext, IConfigurationBuilder configurationBuilder)
        {
            // _logger.Debug("InitConfiguration");
            IConfiguration configuration = configurationBuilder.Build();

            var dbStorageTarget = (DatabaseTarget)LogManager.Configuration.FindTargetByName("database");
            if (dbStorageTarget != null)
            {
                dbStorageTarget.ConnectionString = configuration.GetConnectionString("BotEntities");
                LogManager.ReconfigExistingLoggers();
            }
            if (configuration["SecretUri"] == null || configuration["VaultClientId"] == null || configuration["ClientSecret"] == null)
            {
                throw new Exception("Please configure Key vault settings.");
            }

            configurationBuilder.AddAzureKeyVault(configuration["SecretUri"], configuration["VaultClientId"], configuration["ClientSecret"]);


        }
    }
}
