using CBaaS.HIL.Common.CoreComponents.Repositories;
using CBaaS.HIL.Common.Entities.Models;
using CBaaS.HIL.Middleware.Business.Services;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace CBaaS.HIL.Middleware.Test
{
    [TestClass]
    public class ChatserviceTest
    {
        
        private ICoreRepository<AgentBotUserMapping> _business;
       
        [TestMethod]
        public void TestMethod1()
        {
            ChatService service = new ChatService(_business);
           // service.CloseObsoleteMappings()
        }
    }
}
