﻿using CBaaS.HIL.Common.Entities.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace CBaaS.HIL.Middleware.Test.MockData
{
    public class AgentBotUserMappingMock
    {
        //public AgentBotUserMapping GetAgentBotUserMappingData()
        //{
           
        //}
    }
}
