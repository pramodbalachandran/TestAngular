﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace CBaaS.HIL.Common.CoreComponents.Repositories
{
    public interface ICoreRepository<TEntity> where TEntity : class
    {
        TEntity Get(int id);
        Task<TEntity> GetAsync(int id);
        IQueryable<TEntity> GetAll();
        Task<ICollection<TEntity>> GetAllAsync();
        TEntity Find(Expression<Func<TEntity, bool>> match);
        Task<TEntity> FindAsync(Expression<Func<TEntity, bool>> match);
        TEntity Find(Expression<Func<TEntity, bool>> match, bool isEager);
        ICollection<TEntity> FindAll(Expression<Func<TEntity, bool>> match);
        ICollection<TEntity> FindAll(Expression<Func<TEntity, bool>> match, bool isEager);
        Task<ICollection<TEntity>> FindAllAsync(Expression<Func<TEntity, bool>> match);
        int Add(TEntity entity);
        Task<int> AddAsync(TEntity entity);
        int AddAll(IEnumerable<TEntity> entityList);
        Task<int> AddAllAsync(IEnumerable<TEntity> entityList);
        int Update(TEntity entity);
        Task<int> UpdateAsync(TEntity entity);
        int Delete(TEntity entity);
        Task<int> DeleteAsync(TEntity entity);
        int Count();
        Task<int> CountAsync();
        DbContext GetDbContext();
    }
}
