﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace CBaaS.HIL.Common.CoreComponents.Repositories
{
    public class CoreRepository<TEntity> : ICoreRepository<TEntity> where TEntity : class
    {
        readonly DbContext _dbcontext;

        string errorMessage = string.Empty;
        public CoreRepository(DbContext dbcontext)
        {
            _dbcontext = dbcontext;
        }

        /// <summary>
        /// Returns a single object with a primary key of the provided id
        /// </summary>
        /// <remarks>Synchronous</remarks>
        /// <param name="id">The primary key of the object to fetch</param>
        /// <returns>A single object with the provided primary key or null</returns>
        public virtual TEntity Get(int id)
        {
            return _dbcontext.Set<TEntity>().Find(id);
        }
        /// <summary>
        /// Returns a single object with a primary key of the provided id
        /// </summary>
        /// <remarks>Asynchronous</remarks>
        /// <param name="id">The primary key of the object to fetch</param>
        /// <returns>A single object with the provided primary key or null</returns>
        public virtual async Task<TEntity> GetAsync(int id)
        {
            return await _dbcontext.Set<TEntity>().FindAsync(id);
        }
        /// <summary>
        /// Gets a collection of all objects in the database
        /// </summary>
        /// <remarks>Synchronous</remarks>
        /// <returns>An ICollection of every object in the database</returns>
        public virtual IQueryable<TEntity> GetAll()
        {
            return _dbcontext.Set<TEntity>().AsNoTracking().AsQueryable();
        }
        /// <summary>
        /// Gets a collection of all objects in the database
        /// </summary>
        /// <remarks>Asynchronous</remarks>
        /// <returns>An ICollection of every object in the database</returns>
        public virtual async Task<ICollection<TEntity>> GetAllAsync()
        {
            return await _dbcontext.Set<TEntity>().AsNoTracking().ToListAsync();
        }
        /// <summary>
        /// Returns a single object which matches the provided expression
        /// </summary>
        /// <remarks>Synchronous</remarks>
        /// <param name="match">A Linq expression filter to find a single result</param>
        /// <returns>A single object which matches the expression filter. 
        /// If more than one object is found or if zero are found, null is returned</returns>
        public virtual TEntity Find(Expression<Func<TEntity, bool>> match)
        {
            return _dbcontext.Set<TEntity>().SingleOrDefault(match);
        }

        /// <summary>
        /// Returns a single object which matches the provided expression
        /// </summary>
        /// <remarks>Asynchronous</remarks>
        /// <param name="match">A Linq expression filter to find a single result</param>
        /// <returns>A single object which matches the expression filter. 
        /// If more than one object is found or if zero are found, null is returned</returns>
        /// 
        public virtual async Task<TEntity> FindAsync(Expression<Func<TEntity, bool>> match)
        {
            return await _dbcontext.Set<TEntity>().SingleOrDefaultAsync(match);
        }


        /// <summary>
        /// Returns a single object which matches the provided expression
        /// </summary>
        /// <remarks>Asynchronous</remarks>
        /// <param name="match"></param>
        /// <param name="isEager"></param>
        /// <returns>A single object which matches the expression filter with navigation properties. 
        /// If more than one object is found or if zero are found, null is returned</returns>

        public TEntity Find(Expression<Func<TEntity, bool>> match, bool isEager)
        {
            return Query(isEager).SingleOrDefault(match);
        }
   
        public virtual IQueryable<TEntity> Query(bool eager = false)
        {
            var query = _dbcontext.Set<TEntity>().AsQueryable();
            if (eager)
            {
                foreach (var property in _dbcontext.Model.FindEntityType(typeof(TEntity)).GetNavigations())
                    query = query.Include(property.Name);
            }
            return query;
        }
        /// <summary>
        /// Returns a collection of objects which match the provided expression
        /// </summary>
        /// <remarks>Synchronous</remarks>
        /// <param name="match">A linq expression filter to find one or more results</param>
        /// <returns>An ICollection of object which match the expression filter</returns>
        public virtual ICollection<TEntity> FindAll(Expression<Func<TEntity, bool>> match)
        {
            return _dbcontext.Set<TEntity>().Where(match).ToList();
        }
        /// <summary>
        /// Returns a collection of objects which match the provided expression
        /// </summary>
        /// <remarks>Synchronous</remarks>
        /// <param name="match">A linq expression filter to find one or more results </param>
        /// <param name="isEager"></param>
        /// <returns>An ICollection of object with navigation properties which match the expression filter</returns>
        public virtual ICollection<TEntity> FindAll(Expression<Func<TEntity, bool>> match, bool isEager)
        {
            return Query(isEager).Where(match).ToList();
        }
        /// <summary>
        /// Returns a collection of objects which match the provided expression
        /// </summary>
        /// <remarks>Asynchronous</remarks>
        /// <param name="match">A linq expression filter to find one or more results</param>
        /// <returns>An ICollection of object which match the expression filter</returns>
        public virtual async Task<ICollection<TEntity>> FindAllAsync(Expression<Func<TEntity, bool>> match)
        {
            return await _dbcontext.Set<TEntity>().Where(match).ToListAsync();
        }

        /// <summary>
        /// Create a single object to the database and commits the change
        /// </summary>
        /// <remarks>Synchronous</remarks>
        /// <param name="entity">The object to insert</param>
        /// <returns>The resulting of the insert</returns>
        public virtual int Add(TEntity entity)
        {

            using (IDbContextTransaction dbContextTransaction = _dbcontext.Database.BeginTransaction())
                try
                {

                    if (entity == null)
                    {
                        throw new ArgumentNullException("entity");
                    }
                    _dbcontext.Set<TEntity>().Add(entity);
                    var Result = _dbcontext.SaveChanges();
                    dbContextTransaction.Commit();
                    return Result;
                }
                catch (Exception ex)
                {
                    throw ex;
                }


        }

        /// <summary>
        /// Inserts a single object to the database and commits the change
        /// </summary>
        /// <remarks>Asynchronous</remarks>
        /// <param name="entity">The object to insert</param>
        /// <returns>The resulting of the insert</returns>
        public virtual async Task<int> AddAsync(TEntity entity)
        {
            using (IDbContextTransaction dbContextTransaction = _dbcontext.Database.BeginTransaction())
                try
                {
                    if (entity == null)
                    {
                        throw new ArgumentNullException("entity");
                    }
                    _dbcontext.Set<TEntity>().Add(entity);
                    var Result = await _dbcontext.SaveChangesAsync();
                    dbContextTransaction.Commit();
                    return Result;
                }
                catch (Exception ex)
                {
                    throw ex;
                }

        }
        /// <summary>
        /// Inserts a collection of objects into the database and commits the changes
        /// </summary>
        /// <remarks>Synchronous</remarks>
        /// <param name="entityList">An IEnumerable list of objects to insert</param>
        /// <returns>The resulting of the insert</returns>
        public virtual int AddAll(IEnumerable<TEntity> entityList)
        {
            using (IDbContextTransaction dbContextTransaction = _dbcontext.Database.BeginTransaction())
                try
                {
                    if (entityList == null)
                    {
                        throw new ArgumentNullException("entity");
                    }
                    _dbcontext.Set<TEntity>().AddRange(entityList);
                    var Result = _dbcontext.SaveChanges();
                    dbContextTransaction.Commit();
                    return Result;
                }
                catch (Exception ex)
                {
                    throw ex;
                }




        }
        /// <summary>
        /// Inserts a collection of objects into the database and commits the changes
        /// </summary>
        /// <remarks>Asynchronous</remarks>
        /// <param name="entityList">An IEnumerable list of objects to insert</param>
        /// <returns>The resulting of the insert</returns>
        public virtual async Task<int> AddAllAsync(IEnumerable<TEntity> entityList)
        {
            using (IDbContextTransaction dbContextTransaction = _dbcontext.Database.BeginTransaction())
                try
                {
                    if (entityList == null)
                    {
                        throw new ArgumentNullException("entity");
                    }
                    _dbcontext.Set<TEntity>().AddRange(entityList);
                    var Result = await _dbcontext.SaveChangesAsync();
                    dbContextTransaction.Commit();
                    return Result;
                }
                catch (Exception ex)
                {
                    throw ex;
                }



        }
        /// <summary>
        /// Updates a single object based on the provided primary key and commits the change
        /// </summary>
        /// <remarks>Synchronous</remarks>
        /// <param name="entity">The updated object to apply to the database</param>
        /// <returns>The resulting  of the update </returns>
        public virtual int Update(TEntity entity)
        {
            using (IDbContextTransaction dbContextTransaction = _dbcontext.Database.BeginTransaction())
                try
                {
                    if (entity == null)
                    {
                        throw new ArgumentNullException("entity");
                    }
                    _dbcontext.Entry(entity).State = EntityState.Modified;
                    // _dbcontext.Set<TEntity>().Add(entity);
                    var Result = _dbcontext.SaveChanges();
                    dbContextTransaction.Commit();
                    return Result;
                }
                catch (Exception ex)
                {
                    throw ex;
                }



        }
        /// <summary>
        /// Updates a single object based on the provided primary key and commits the change
        /// </summary>
        /// <remarks>Asynchronous</remarks>
        /// <param name="entity">The updated object to apply to the database</param>
        /// <returns>The resulting  of the update</returns>
        public virtual async Task<int> UpdateAsync(TEntity entity)
        {
            using (IDbContextTransaction dbContextTransaction = _dbcontext.Database.BeginTransaction())
                try
                {
                    if (entity == null)
                    {
                        throw new ArgumentNullException("entity");
                    }
                    _dbcontext.Entry(entity).State = EntityState.Modified;
                    var Result = await _dbcontext.SaveChangesAsync();
                    dbContextTransaction.Commit();
                    return Result;

                }
                catch (Exception ex)
                {
                    throw ex;
                }

        }
        /// <summary>
        /// Deletes a single object from the database and commits the change
        /// </summary>
        /// <remarks>Synchronous</remarks>
        /// <param name="entity">The object to delete</param>
        /// <returns>The resulting  of the delete</returns>
        public virtual int Delete(TEntity entity)
        {
            using (IDbContextTransaction dbContextTransaction = _dbcontext.Database.BeginTransaction())
                try
                {
                    if (entity == null)
                    {
                        throw new ArgumentNullException("entity");
                    }
                    _dbcontext.Set<TEntity>().Remove(entity);
                    var Result = _dbcontext.SaveChanges();
                    dbContextTransaction.Commit();
                    return Result;

                }
                catch (Exception ex)
                {
                    throw ex;
                }


        }
        /// <summary>
        /// Deletes a single object from the database and commits the change
        /// </summary>
        /// <remarks>Asynchronous</remarks>
        /// <param name="entity">The object to delete</param>
        /// <returns>The resulting  of the delete</returns>
        public virtual async Task<int> DeleteAsync(TEntity entity)
        {
            using (IDbContextTransaction dbContextTransaction = _dbcontext.Database.BeginTransaction())
                try
                {
                    if (entity == null)
                    {
                        throw new ArgumentNullException("entity");
                    }
                    _dbcontext.Set<TEntity>().Remove(entity);
                    var Result = await _dbcontext.SaveChangesAsync();
                    dbContextTransaction.Commit();
                    return Result;

                }
                catch (Exception ex)
                {
                    throw ex;
                }

        }

        /// <summary>
        /// Gets the count of the number of objects in the databse
        /// </summary>
        /// <remarks>Synchronous</remarks>
        /// <returns>The count of the number of objects</returns>
        public virtual int Count()
        {
            return _dbcontext.Set<TEntity>().AsNoTracking().Count();
        }
        /// <summary>
        /// Gets the count of the number of objects in the databse
        /// </summary>
        /// <remarks>Asynchronous</remarks>
        /// <returns>The count of the number of objects</returns>
        public virtual async Task<int> CountAsync()
        {
            return await _dbcontext.Set<TEntity>().AsNoTracking().CountAsync();
        }
        public DbContext GetDbContext()
        {
            return _dbcontext;
        }

      
    }
}
