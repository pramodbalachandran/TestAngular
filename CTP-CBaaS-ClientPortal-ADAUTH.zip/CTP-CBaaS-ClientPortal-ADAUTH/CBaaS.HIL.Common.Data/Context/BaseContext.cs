﻿using CBaaS.HIL.Common.Entities.Models;
using Microsoft.EntityFrameworkCore;

namespace CBaaS.HIL.Common.Data
{
    public partial class BaseContext : DbContext
    {
        private string _connectionString;
        public BaseContext(string connectionString)
        {
            _connectionString = connectionString;
        }

        public BaseContext(DbContextOptions<BaseContext> options)
            : base(options)
        {
        }
        public virtual DbSet<ActivityLog> ActivityLog { get; set; }
        public virtual DbSet<AgentBotUserMapping> AgentBotUserMapping { get; set; }
        public virtual DbSet<AgentSession> AgentSession { get; set; }
        public virtual DbSet<AuthenticationConfig> AuthenticationConfig { get; set; }
        public virtual DbSet<BotConfig> BotConfig { get; set; }
        public virtual DbSet<BotMaster> BotMaster { get; set; }
        public virtual DbSet<BotRegistration> BotRegistration { get; set; }
        public virtual DbSet<BotUserConnection> BotUserConnection { get; set; }
        public virtual DbSet<ChatLogs> ChatLogs { get; set; }
        public virtual DbSet<ErrorLog> ErrorLog { get; set; }
        public virtual DbSet<FeatureMaster> FeatureMaster { get; set; }
        public virtual DbSet<RefreshToken> RefreshToken { get; set; }
        public virtual DbSet<Roles> Roles { get; set; }
        public virtual DbSet<UserBotRoles> UserBotRoles { get; set; }
        public virtual DbSet<UserFeedback> UserFeedback { get; set; }
        public virtual DbSet<Users> Users { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder.UseSqlServer(_connectionString);
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<ActivityLog>(entity =>
            {
                entity.Property(e => e.Id).HasColumnName("ID");

                entity.Property(e => e.Action)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.Module)
                    .IsRequired()
                    .HasMaxLength(255);

                entity.Property(e => e.PerformedBy)
                    .IsRequired()
                    .HasMaxLength(255);

                entity.Property(e => e.PerformedOn).HasColumnType("datetime");

                entity.Property(e => e.Value).IsRequired();
            });

            modelBuilder.Entity<AgentBotUserMapping>(entity =>
            {
                entity.HasKey(e => e.ChatId);

                entity.Property(e => e.ChatId).ValueGeneratedNever();

                entity.Property(e => e.EndTime).HasColumnType("datetime");

                entity.Property(e => e.StartTime).HasColumnType("datetime");

                entity.HasOne(d => d.AgentSession)
                    .WithMany(p => p.AgentBotUserMapping)
                    .HasForeignKey(d => d.AgentSessionId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_AgentBotUserMapping_AgentSession");

                entity.HasOne(d => d.BotUserConnection)
                    .WithMany(p => p.AgentBotUserMapping)
                    .HasForeignKey(d => d.BotUserConnectionId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_AgentBotUserMapping_BotUserConnection");
            });

            modelBuilder.Entity<AgentSession>(entity =>
            {
                entity.Property(e => e.ConnectionId)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.EndTime).HasColumnType("datetime");

                entity.Property(e => e.Remarks).HasMaxLength(200);

                entity.Property(e => e.StartTime).HasColumnType("datetime");

                entity.Property(e => e.Status)
                    .IsRequired()
                    .HasMaxLength(15);

                entity.HasOne(d => d.User)
                    .WithMany(p => p.AgentSession)
                    .HasForeignKey(d => d.UserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_AgentSession_Users");
            });

            modelBuilder.Entity<AuthenticationConfig>(entity =>
            {
                entity.Property(e => e.Botconfigid).HasColumnName("botconfigid");

                entity.Property(e => e.Hint)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.Property(e => e.Scope)
                    .IsRequired()
                    .HasMaxLength(100);

                entity.HasOne(d => d.Botconfig)
                    .WithMany(p => p.AuthenticationConfig)
                    .HasForeignKey(d => d.Botconfigid)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_authenticationconfig");
            });

            modelBuilder.Entity<BotConfig>(entity =>
            {
                entity.Property(e => e.AppId).HasMaxLength(200);

                entity.Property(e => e.AuthType)
                    .HasMaxLength(20)
                    .IsUnicode(false);

                entity.Property(e => e.BotHandle).HasMaxLength(200);

                entity.Property(e => e.BotLogoImage).HasMaxLength(500);

                entity.Property(e => e.BotTheme)
                    .HasMaxLength(200)
                    .HasDefaultValueSql("('ChatHome-EYDefault')");

                entity.Property(e => e.CreatedBy).HasMaxLength(250);

                entity.Property(e => e.CreatedDate).HasColumnType("datetime");

                entity.Property(e => e.DisplayName).HasMaxLength(200);

                entity.Property(e => e.IsFaqBot).HasDefaultValueSql("('False')");

                entity.Property(e => e.LogDbstring).HasColumnName("LogDBString");

                entity.Property(e => e.ModifiedBy).HasMaxLength(250);

                entity.Property(e => e.ModifiedDate).HasColumnType("datetime");

                entity.Property(e => e.Secret).HasMaxLength(200);

                entity.Property(e => e.ServiceLine).HasMaxLength(100);

                entity.Property(e => e.Status).HasMaxLength(50);
            });

            modelBuilder.Entity<BotMaster>(entity =>
            {
                entity.Property(e => e.AccessKey).HasMaxLength(300);

                entity.Property(e => e.EndPoint).HasMaxLength(255);

                entity.Property(e => e.Location).HasMaxLength(100);

                entity.Property(e => e.RegionUri)
                    .HasColumnName("RegionURI")
                    .HasMaxLength(255);

                entity.Property(e => e.StorageAcctKey).HasMaxLength(255);

                entity.Property(e => e.StorageAcctName).HasMaxLength(255);

                entity.HasOne(d => d.BotConfig)
                    .WithMany(p => p.BotMaster)
                    .HasForeignKey(d => d.BotConfigId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__BotMaster__BotCo__5629CD9C");

                entity.HasOne(d => d.Feature)
                    .WithMany(p => p.BotMaster)
                    .HasForeignKey(d => d.FeatureId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__BotMaster__Featu__571DF1D5");
            });

            modelBuilder.Entity<BotRegistration>(entity =>
            {
                entity.Property(e => e.BotType)
                   .IsRequired()
                   .HasMaxLength(20);

                entity.Property(e => e.CustomerContact)
                    .IsRequired()
                    .HasMaxLength(200);

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");

                entity.Property(e => e.OfferingType)
                    .IsRequired()
                    .HasMaxLength(50)
                    .HasDefaultValueSql("(N'Simple FAQ')");

                entity.Property(e => e.ReportConnectionString)
                    .IsRequired()
                    .HasMaxLength(500);

                entity.Property(e => e.ReportSource)
                    .IsRequired()
                    .HasMaxLength(20);
            });

            modelBuilder.Entity<BotUserConnection>(entity =>
            {
                entity.Property(e => e.BotUserId)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.BotUserName)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.ConnectionId)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.ConversationId)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.HasOne(d => d.BotConfig)
                    .WithMany(p => p.BotUserConnection)
                    .HasForeignKey(d => d.BotConfigId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_BotUserConnection_BotConfig");
            });

            modelBuilder.Entity<ChatLogs>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("chatLogs");

                entity.Property(e => e.ActivityId).HasMaxLength(200);

                entity.Property(e => e.AgentEmail).HasMaxLength(100);

                entity.Property(e => e.ConversationId).HasMaxLength(200);

                entity.Property(e => e.Date).HasColumnType("datetime");

                entity.Property(e => e.Email).HasMaxLength(200);

                entity.Property(e => e.Feedback).HasMaxLength(200);

                entity.Property(e => e.FeedbackDate).HasColumnType("datetime");

                entity.Property(e => e.LogId).ValueGeneratedOnAdd();

                entity.Property(e => e.Username).HasMaxLength(200);
            });

            modelBuilder.Entity<ErrorLog>(entity =>
            {
                entity.Property(e => e.Botconfigid).HasColumnName("botconfigid");

                entity.Property(e => e.CreatedBy).HasMaxLength(50);

                entity.Property(e => e.CreatedOn).HasColumnType("datetime");

                entity.Property(e => e.ErrorMessage).HasMaxLength(4000);

                entity.Property(e => e.Level).HasMaxLength(50);

                entity.Property(e => e.StackTrace).HasMaxLength(4000);

                entity.HasOne(d => d.Botconfig)
                    .WithMany(p => p.ErrorLog)
                    .HasForeignKey(d => d.Botconfigid)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_errorlog");
            });

            modelBuilder.Entity<FeatureMaster>(entity =>
            {
                entity.HasIndex(e => e.Feature)
                    .HasName("UQ__FeatureM__10DCAF4CEFB4707F")
                    .IsUnique();

                entity.Property(e => e.Feature)
                    .IsRequired()
                    .HasMaxLength(100);
            });

            modelBuilder.Entity<RefreshToken>(entity =>
            {
                entity.Property(e => e.Expiry).HasColumnType("datetime");

                entity.Property(e => e.Refreshtoken1)
                    .IsRequired()
                    .HasColumnName("Refreshtoken")
                    .HasMaxLength(50);

                entity.Property(e => e.Token).IsRequired();

                entity.Property(e => e.Username)
                    .IsRequired()
                    .HasMaxLength(50);
            });

            modelBuilder.Entity<Roles>(entity =>
            {
                entity.Property(e => e.DisplayName).HasMaxLength(50);

                entity.Property(e => e.Role)
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<UserBotRoles>(entity =>
            {
                entity.Property(e => e.FromDate).HasColumnType("datetime");

                entity.Property(e => e.ToDate).HasColumnType("datetime");

                entity.HasOne(d => d.BotConfig)
                    .WithMany(p => p.UserBotRoles)
                    .HasForeignKey(d => d.BotConfigId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_UserBotRoles_BotConfig");

                entity.HasOne(d => d.Role)
                    .WithMany(p => p.UserBotRoles)
                    .HasForeignKey(d => d.RoleId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_UserBotRoles_Roles");

                entity.HasOne(d => d.User)
                    .WithMany(p => p.UserBotRoles)
                    .HasForeignKey(d => d.UserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_UserBotRoles_Users");
            });

            modelBuilder.Entity<UserFeedback>(entity =>
            {
                entity.Property(e => e.Answer).HasMaxLength(4000);

                entity.Property(e => e.BotName).HasMaxLength(250);

                entity.Property(e => e.Botconfigid).HasColumnName("botconfigid");

                entity.Property(e => e.ChannelType).HasMaxLength(100);

                entity.Property(e => e.Comments).HasMaxLength(500);

                entity.Property(e => e.CreatedDate).HasColumnType("datetime");

                entity.Property(e => e.Emotion).HasMaxLength(50);

                entity.Property(e => e.Luisintent)
                    .HasColumnName("LUISIntent")
                    .HasMaxLength(200);

                entity.Property(e => e.Luisscore)
                    .HasColumnName("LUISScore")
                    .HasMaxLength(50);

                entity.Property(e => e.ModifiedBy).HasMaxLength(100);

                entity.Property(e => e.ModifiedDate).HasColumnType("datetime");

                entity.Property(e => e.QnaScore).HasMaxLength(50);

                entity.Property(e => e.Question).HasMaxLength(4000);

                entity.Property(e => e.Status).HasMaxLength(50);

                entity.Property(e => e.UserEmail).HasMaxLength(250);

                entity.Property(e => e.UserName).HasMaxLength(100);

                entity.HasOne(d => d.Botconfig)
                    .WithMany(p => p.UserFeedback)
                    .HasForeignKey(d => d.Botconfigid)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_userfeedback");
            });

            modelBuilder.Entity<Users>(entity =>
            {
                entity.HasIndex(e => e.UserName)
                    .HasName("UQ__Users__C9F28456BBAF5D9F")
                    .IsUnique();

                entity.Property(e => e.Company).HasMaxLength(50);

                entity.Property(e => e.IsExternal)
                   .IsRequired()
                   .HasDefaultValueSql("((0))");

                entity.Property(e => e.FirstName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.IsActive)
                    .IsRequired()
                    .HasDefaultValueSql("((1))");
                
                entity.Property(e => e.LastName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.NickName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.UserName)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
