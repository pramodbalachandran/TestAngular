using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace CBaaS.HIL.ClientPortal.Test
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
